WARCRAFT PINBALL v3.0 — HUMANS VS ORCS
======================================
A Warcraft II-inspired standalone pinball addon for WoW Forever.
Client Interface: 16001. Fan-made minigame, not an official Blizzard addon.

INSTALL / UPDATE
----------------
1. Exit WoW Forever.
2. Remove your existing WarcraftPinball folder (do not nest folders).
3. Extract this ZIP so the folder is exactly:
   World of Warcraft\_forever_\Interface\AddOns\WarcraftPinball\
4. Restart WoW and type /pinball.

CONTROLS
--------
A / Left arrow      Alliance (BLUE) flipper
D / Right arrow     Horde (RED) flipper
Space               Launch your next ball
Esc                 Close the arcade and return control to WoW
On-screen buttons   Flippers, launch, new game, music, SFX, close
/pinball            Toggle window
/pinball new        New three-ball game
/pinball music on   Play your included song
/pinball music off  Mute the music
/pinball sfx on     Enable arcade effects
/pinball sfx off    Mute pinball effects

V3.0: BETTER PINBALL FEEL
-------------------------
* Fair launch guarantee: a dedicated right-side plunger rail carries every
  launched ball to the top before switching to normal collision physics.
  Entry location and velocity are identical across all three balls.
* 180 Hz fixed-step physics (when framerate permits) makes high-speed contacts
  less likely to tunnel through targets, rails and flippers.
* Retuned gravity, bumper impulses, flipper bounces and velocity cap.
* Anti-stuck logic gently reintroduces a ball if it stalls in the playfield.
* Five top rollovers, additional side/inlane rollovers, new upper guides,
  extra faction shield targets, a Dark Portal bumper and glowing hit effects.
* Complete all three Alliance or all three Horde fortress-bank shields
  during a ball for a 1,500-point siege bonus (affected by combo multiplier).
* Larger and more readable score and best-score board, separate faction totals,
  ball counter, mission progress, and clear status messages.
* Existing short BLUE Alliance and RED Horde flippers with center drain gap.
* Updated launch lane, steel rails and illuminated tabletop targets.
* Arcade sound effects and optional user-supplied song remain in the addon.
* Separate MUSIC and SFX toggles; their settings and high score persist.

IMPORTANT LIMITATIONS
---------------------
* The keyboard focus lock requires the client to support
  SetPropagateKeyboardInput(false). WoW restricts some input API changes in
  combat. If unsupported, the addon reports this and cannot promise that
  movement keys will be blocked. Stop movement before opening the minigame.
* Closing the arcade pauses the table and stops its music.
* In-game UI and audio behavior have not been verified on the live Forever
  client. Lua syntax, simulated gameplay and ZIP integrity were tested.
* The included MP3 was supplied by the user and is intended for personal
  use only; do not redistribute it without obtaining appropriate rights.
