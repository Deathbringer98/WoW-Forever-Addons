-- Warcraft Pinball: Humans vs Orcs, v3.0 / WoW Forever Interface 16001.
-- Standalone arcade minigame; no game-world automation or protected actions.
-- Art and sound effects are custom; music was provided by the user.
local ROOT = "Interface\\AddOns\\WarcraftPinball\\"
local TEX, SND = ROOT.."Textures\\", ROOT.."Audio\\"
local MUSIC = SND.."TheWizard.mp3"
local SOUNDS = {
    flipper=SND.."Flipper.ogg", bumper=SND.."Bumper.ogg",
    target=SND.."Target.ogg", launch=SND.."Launch.ogg",
    drain=SND.."Drain.ogg", start=SND.."Start.ogg",
    victory=SND.."Victory.ogg", sling=SND.."Sling.ogg",
    rollover=SND.."Rollover.ogg", rail=SND.."Rail.ogg",
    combo=SND.."Combo.ogg", bonus=SND.."Bonus.ogg"
}
local W,H=400,600
local LEFT_BASE_X,RIGHT_BASE_X,FLIPPER_Y=118,282,545
local BALL_RADIUS=9
local FIXED_STEP=1/180
local GRAVITY=460
local MAX_BALL_SPEED=850
local FLIPPER_LENGTH,FLIPPER_TEXTURE_SIZE,FLIPPER_HIT_RADIUS=60,84,12
local sin,cos,sqrt,abs,min,max,pi,floor=math.sin,math.cos,math.sqrt,math.abs,math.min,math.max,math.pi,math.floor
local db,window,board,dimScreen,keyCapture
local scoreLabel,highLabel,infoLabel,allianceLabel,orcLabel,musicButton,sfxButton,comboLabel,missionLabel
local ballSprite,leftSprite,rightSprite
local bumperSprites,popupLabels,glowSprites={},{},{}
local keys={}; local mouseLeft,mouseRight=false,false
local musicPlaying,inputIsBlocked=false,false
local game={
    started=false,over=false,waiting=true,score=0,humans=0,orcs=0,
    ballNumber=1,left=false,right=false,leftAngle=.43,rightAngle=pi-.43,
    x=357,y=545,vx=0,vy=0,timer=0,accumulator=0,
    launching=false,launchElapsed=0,launchCount=0,launchGrace=0,stuckTime=0,
    allianceBank=0,hordeBank=0,allianceComplete=false,hordeComplete=false,
    combo=0,comboExpires=0,lastSound={},previousHigh=0
}
local BLUE={.30,.65,1}; local RED={1,.24,.20}; local GOLD={1,.76,.30}
local objects={
    -- Top rollover lanes; ball passes through and lights them up.
    {x=79,y=114,r=10,faction="humans",points=125,rollover=true,color=BLUE},
    {x=141,y=95,r=10,faction="humans",points=125,rollover=true,color=BLUE},
    {x=201,y=86,r=11,faction="neutral",points=200,rollover=true,color=GOLD},
    {x=261,y=95,r=10,faction="orcs",points=125,rollover=true,color=RED},
    {x=322,y=114,r=10,faction="orcs",points=125,rollover=true,color=RED},
    -- The big reactive pop bumpers.
    {x=126,y=225,r=24,faction="humans",points=500,color=BLUE,bumper=true},
    {x=201,y=158,r=23,faction="neutral",points=750,color=GOLD,bumper=true},
    {x=277,y=225,r=24,faction="orcs",points=500,color=RED,bumper=true},
    {x=86,y=305,r=18,faction="humans",points=300,color=BLUE,bumper=true},
    {x=314,y=305,r=18,faction="orcs",points=300,color=RED,bumper=true},
    -- Two vertical banks of hittable shields.
    {x=80,y=362,r=12,faction="humans",points=250,color=BLUE,target=true},
    {x=80,y=399,r=12,faction="humans",points=250,color=BLUE,target=true},
    {x=80,y=436,r=12,faction="humans",points=250,color=BLUE,target=true},
    {x=320,y=362,r=12,faction="orcs",points=250,color=RED,target=true},
    {x=320,y=399,r=12,faction="orcs",points=250,color=RED,target=true},
    {x=320,y=436,r=12,faction="orcs",points=250,color=RED,target=true},
    -- Side inlanes reward clean shots (not solid walls).
    {x=60,y=186,r=11,faction="humans",points=175,rollover=true,color=BLUE,label="STORMWIND LANE"},
    {x=340,y=186,r=11,faction="orcs",points=175,rollover=true,color=RED,label="BLACKROCK LANE"},
    {x=109,y=472,r=10,faction="humans",points=100,rollover=true,color=BLUE,label="ALLIANCE INLANE"},
    {x=291,y=472,r=10,faction="orcs",points=100,rollover=true,color=RED,label="HORDE INLANE"},
    -- Three fortress shields per faction. Clear a bank for a siege bonus.
    {x=116,y=280,r=12,faction="humans",points=350,color=BLUE,target=true,bank=true,label="HUMAN TOWER"},
    {x=155,y=315,r=12,faction="humans",points=350,color=BLUE,target=true,bank=true,label="KEEP"},
    {x=116,y=350,r=12,faction="humans",points=350,color=BLUE,target=true,bank=true,label="KNIGHT"},
    {x=284,y=280,r=12,faction="orcs",points=350,color=RED,target=true,bank=true,label="ORC TOWER"},
    {x=245,y=315,r=12,faction="orcs",points=350,color=RED,target=true,bank=true,label="STRONGHOLD"},
    {x=284,y=350,r=12,faction="orcs",points=350,color=RED,target=true,bank=true,label="GRUNT"},
    -- Centre portal lights up between the rival fortresses.
    {x=200,y=269,r=18,faction="neutral",points=950,color=GOLD,portal=true,bumper=true,label="DARK PORTAL"},
    -- Centre targets and powerful lower slingshots.
    {x=200,y=336,r=13,faction="neutral",points=400,color=GOLD,target=true},
    {x=155,y=386,r=12,faction="humans",points=300,color=BLUE,target=true},
    {x=245,y=386,r=12,faction="orcs",points=300,color=RED,target=true},
    {x=200,y=428,r=12,faction="neutral",points=400,color=GOLD,target=true},
    {x=101,y=480,r=19,faction="humans",points=150,color=BLUE,sling=true},
    {x=299,y=480,r=19,faction="orcs",points=150,color=RED,sling=true},
    -- Steel guides near the flippers.
    {x=83,y=527,r=9,faction="neutral",points=50,color=GOLD,post=true},
    {x=317,y=527,r=9,faction="neutral",points=50,color=GOLD,post=true}
}
local rails={
    {43,362,64,451},{357,362,336,451},
    {38,475,89,510},{362,475,311,510},
    {89,510,147,521},{311,510,253,521},
    -- Short upper guides curve a shot towards faction bumpers without blocking launch.
    {52,230,67,267},{348,230,333,267}
}
local function say(s) print("|cffedc276Warcraft Pinball:|r "..s) end
local function clamp(v,a,b) return max(a,min(b,v)) end
local function num(n)
    local s=tostring(floor(n or 0))
    repeat local t,c=s:gsub("^(-?%d+)(%d%d%d)","%1,%2");s=t;if c==0 then break end until false
    return s
end
local function playSFX(which)
    if not db or not db.sfx or not PlaySoundFile or not SOUNDS[which] then return end
    local t=game.timer
    local cooldown= which=="flipper" and .055 or (which=="rail" and .09 or .055)
    if t-(game.lastSound[which] or -100)>cooldown then
        game.lastSound[which]=t
        PlaySoundFile(SOUNDS[which],"SFX")
    end
end
local function stopMusic()
    if musicPlaying and StopMusic then StopMusic() end
    musicPlaying=false
end
local function startMusic()
    if not db or not db.music or not window or not window:IsShown() or musicPlaying then return end
    if PlayMusic then
        local ok=PlayMusic(MUSIC)
        if ok==false then db.music=false; say("Music could not be played; check your audio settings.")
        else musicPlaying=true end
    end
end
local function textBtn(button,s) if button and button.label then button.label:SetText(s) end end
local function soundBtns()
    textBtn(musicButton,db.music and "MUSIC ON" or "MUSIC OFF")
    textBtn(sfxButton,db.sfx and "SFX ON" or "SFX OFF")
end
local function toggleMusic(on)
    db.music=on
    if on then startMusic() else stopMusic() end
    soundBtns()
end
local function toggleSFX(on) db.sfx=on;soundBtns() end
local function panel(parent,w,h,r,g,b,a)
    local f=CreateFrame("Frame",nil,parent);f:SetSize(w,h)
    local tex=f:CreateTexture(nil,"BACKGROUND");tex:SetAllPoints(f);tex:SetColorTexture(r,g,b,a)
    return f
end
local function label(parent,s,size,color,anchor,relative,x,y,align)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormal")
    t:SetFont("Fonts\\FRIZQT__.TTF",size,"OUTLINE")
    t:SetTextColor(color[1],color[2],color[3])
    t:SetJustifyH(align or "CENTER")
    t:SetPoint(anchor,relative or parent,anchor,x or 0,y or 0)
    t:SetText(s);return t
end
local function button(parent,s,w,h,x,y,fn,tint)
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(w,h);b:SetPoint("BOTTOMLEFT",parent,"BOTTOMLEFT",x,y)
    local c=tint or {.18,.14,.11}
    local bg=b:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints(b)
    bg:SetColorTexture(c[1],c[2],c[3],.99)
    local led=b:CreateTexture(nil,"BORDER")
    led:SetPoint("TOPLEFT",b,"TOPLEFT",0,0);led:SetPoint("TOPRIGHT",b,"TOPRIGHT",0,0)
    led:SetHeight(3);led:SetColorTexture(.84,.66,.32,.99)
    local txt=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    txt:SetPoint("CENTER");txt:SetText(s);txt:SetTextColor(1,.9,.7)
    b.label=txt
    b:SetScript("OnEnter",function() bg:SetColorTexture(clamp(c[1]+.12,0,1),clamp(c[2]+.12,0,1),clamp(c[3]+.12,0,1),.99) end)
    b:SetScript("OnLeave",function() bg:SetColorTexture(c[1],c[2],c[3],.99) end)
    if fn then b:SetScript("OnClick",fn) end
    return b
end
local function spritePos(texture,x,y)
    if not texture or not board then return end
    texture:ClearAllPoints();texture:SetPoint("CENTER",board,"TOPLEFT",x,-y)
end
local function updateFlippers()
    if not leftSprite or not rightSprite then return end
    local a,b=game.leftAngle,game.rightAngle
    spritePos(leftSprite,LEFT_BASE_X+cos(a)*(FLIPPER_LENGTH*0.5),FLIPPER_Y+sin(a)*(FLIPPER_LENGTH*0.5))
    spritePos(rightSprite,RIGHT_BASE_X+cos(b)*(FLIPPER_LENGTH*0.5),FLIPPER_Y+sin(b)*(FLIPPER_LENGTH*0.5))
    leftSprite:SetRotation(-a);rightSprite:SetRotation(-b)
end
local function appliedInputs()
    local l= (keys.A or keys.LEFT or mouseLeft) and true or false
    local r= (keys.D or keys.RIGHT or mouseRight) and true or false
    if l and not game.left then playSFX("flipper") end
    if r and not game.right then playSFX("flipper") end
    game.left,game.right=l,r
    -- Instant snap. Do not interpolate: release must immediately lower the paddle.
    game.leftAngle= l and -.58 or .43
    game.rightAngle=r and (pi+.58) or (pi-.43)
    updateFlippers()
end
local function releaseInputs()
    keys={};mouseLeft=false;mouseRight=false
    game.left,game.right=false,false
    game.leftAngle=.43;game.rightAngle=pi-.43
    updateFlippers()
end
local function showScore()
    if not scoreLabel then return end
    scoreLabel:SetText(num(game.score))
    highLabel:SetText("BEST  "..num(db.highScore or 0))
    allianceLabel:SetText("ALLIANCE  "..num(game.humans))
    orcLabel:SetText("HORDE  "..num(game.orcs))
    comboLabel:SetText(game.combo>=2 and ("x"..min(5,game.combo).." COMBO") or "HUMANS  VS  ORCS")
    if missionLabel then
        if game.allianceComplete and game.hordeComplete then missionLabel:SetText("SIEGE COMPLETE  |  BOTH FORTRESSES TAKEN")
        elseif game.allianceComplete then missionLabel:SetText("ALLIANCE SIEGE COMPLETE  |  HIT HORDE SHIELDS")
        elseif game.hordeComplete then missionLabel:SetText("HORDE SIEGE COMPLETE  |  HIT ALLIANCE SHIELDS")
        else missionLabel:SetText("SIEGE  ALLIANCE "..game.allianceBank.."/3  |  HORDE "..game.hordeBank.."/3") end
    end
    if game.over then infoLabel:SetText("GAME OVER  •  NEW GAME")
    elseif game.waiting then infoLabel:SetText("BALL "..game.ballNumber.." / 3    |    SPACE: LAUNCH")
    elseif game.launching then infoLabel:SetText("BALL "..game.ballNumber.." / 3    |    LAUNCH LANE")
    else infoLabel:SetText("BALL "..game.ballNumber.." / 3    |    A / D OR ARROWS") end
end
local function points(n,faction,x,y,caption)
    if game.timer<game.comboExpires then game.combo=min(5,game.combo+1) else game.combo=1 end
    game.comboExpires=game.timer+1.9
    local pts=n*min(5,game.combo)
    game.score=game.score+pts
    if faction=="humans" then game.humans=game.humans+pts end
    if faction=="orcs" then game.orcs=game.orcs+pts end
    if game.score>(db.highScore or 0) then db.highScore=game.score end
    if game.combo==3 or game.combo==5 then playSFX("combo") end
    for _,p in ipairs(popupLabels) do
        if p.time<=0 then
            p.time=.85;p.x=x;p.y=y
            p.text:SetText(caption and (caption.."  +"..num(pts)) or ("+"..num(pts)))
            p.text:Show();break
        end
    end
    showScore()
end
local function putBall(x,y) game.x,game.y=x,y;spritePos(ballSprite,x,y) end
local function serveBall()
    game.waiting=true;game.launching=false;game.launchGrace=0;game.stuckTime=0;game.vx,game.vy=0,0
    putBall(357,545);showScore()
end
local function newGame()
    releaseInputs()
    game.started,game.over=true,false
    game.score,game.humans,game.orcs=0,0,0
    game.previousHigh=db.highScore or 0
    game.ballNumber=1;game.accumulator=0;game.timer=0
    game.combo,game.comboExpires=0,0
    game.launchCount=0;game.launchElapsed=0
    game.allianceBank,game.hordeBank=0,0
    game.allianceComplete,game.hordeComplete=false,false
    game.lastSound={}
    for _,o in ipairs(objects) do o.lastHit=-100;o.flash=0;o.lit=false end
    serveBall();playSFX("start")
end
local function launchBall()
    if not game.started or game.over then newGame() end
    if not game.waiting then return end
    -- A protected, deterministic plunger lane ensures EVERY launch reaches the
    -- top cleanly. Normal playfield collision begins only after lane exit.
    game.waiting=false;game.launching=true;game.launchElapsed=0
    game.launchCount=game.launchCount+1
    game.x,game.y=357,545
    game.vx,game.vy=0,0
    game.accumulator=0;game.stuckTime=0
    playSFX("launch");showScore()
end
local function endBall()
    if game.waiting or game.over then return end
    playSFX("drain")
    if game.ballNumber>=3 then
        game.over=true;game.waiting=true;game.vx,game.vy=0,0
        putBall(360,552)
        if game.score>game.previousHigh and game.score>0 then playSFX("victory") end
    else
        game.ballNumber=game.ballNumber+1
        serveBall()
    end
    game.combo=0;game.allianceBank,game.hordeBank=0,0
    game.allianceComplete,game.hordeComplete=false,false
    for _,o in ipairs(objects) do if o.bank then o.lit=false end end
    showScore()
end
local function bounce(nx,ny,force,b)
    local vn=game.vx*nx+game.vy*ny
    if vn<0 then
        game.vx=game.vx-(1+b)*vn*nx
        game.vy=game.vy-(1+b)*vn*ny
    end
    local mag=sqrt(game.vx*game.vx+game.vy*game.vy)
    if mag<force then
        game.vx=game.vx+nx*(force-mag)
        game.vy=game.vy+ny*(force-mag)
    end
end
local function hitObject(o)
    local dx,dy=game.x-o.x,game.y-o.y
    local rr=o.r+(o.rollover and 4 or BALL_RADIUS-2)
    if dx*dx+dy*dy>=rr*rr then return end
    if game.timer-(o.lastHit or -100)<(o.rollover and .95 or .14) then return end
    if o.rollover then
        o.lastHit=game.timer;o.flash=.40
        points(o.points,o.faction,o.x,o.y,o.label);playSFX("rollover");return
    end
    local distance=max(.001,sqrt(dx*dx+dy*dy))
    local nx,ny=dx/distance,dy/distance
    game.x=o.x+nx*(rr+.25);game.y=o.y+ny*(rr+.25)
    bounce(nx,ny,o.sling and 440 or (o.bumper and 355 or 255),o.sling and 1.25 or (o.portal and 1.32 or 1.06))
    if o.sling then game.vy=min(game.vy,-225) end
    o.lastHit=game.timer;o.flash=.27
    points(o.points,o.faction,o.x,o.y,o.label)
    if o.bank and not o.lit then
        o.lit=true
        if o.faction=="humans" then
            game.allianceBank=game.allianceBank+1
            if game.allianceBank>=3 and not game.allianceComplete then
                game.allianceComplete=true
                points(1500,"humans",200,310,"ALLIANCE SIEGE")
                playSFX("bonus")
            end
        else
            game.hordeBank=game.hordeBank+1
            if game.hordeBank>=3 and not game.hordeComplete then
                game.hordeComplete=true
                points(1500,"orcs",200,310,"HORDE SIEGE")
                playSFX("bonus")
            end
        end
        showScore()
    end
    if o.sling then playSFX("sling")
    elseif o.bumper then playSFX("bumper")
    else playSFX("target") end
end
local function hitRail(a,b,c,d)
    local dx,dy=c-a,d-b
    local t=clamp(((game.x-a)*dx+(game.y-b)*dy)/(dx*dx+dy*dy),0,1)
    local px,py=a+t*dx,b+t*dy
    local rx,ry=game.x-px,game.y-py
    local rr=BALL_RADIUS;local d2=rx*rx+ry*ry
    if d2>=rr*rr then return end
    local distance=max(sqrt(d2),.001)
    local nx,ny=rx/distance,ry/distance
    if game.vx*nx+game.vy*ny>=0 then return end
    game.x=px+nx*(rr+.15);game.y=py+ny*(rr+.15)
    bounce(nx,ny,185,.85)
    playSFX("rail")
end
local function hitFlipper(left)
    local px=left and LEFT_BASE_X or RIGHT_BASE_X
    local py=FLIPPER_Y;local a=left and game.leftAngle or game.rightAngle
    local dx,dy=cos(a)*FLIPPER_LENGTH,sin(a)*FLIPPER_LENGTH
    local t=clamp(((game.x-px)*dx+(game.y-py)*dy)/(dx*dx+dy*dy),0,1)
    local cx,cy=px+t*dx,py+t*dy
    local rx,ry=game.x-cx,game.y-cy
    if rx*rx+ry*ry>FLIPPER_HIT_RADIUS*FLIPPER_HIT_RADIUS or game.vy < -140 then return end
    -- Avoid the same ball being batted repeatedly each physics substep.
    local hitKey=left and "leftPaddleHit" or "rightPaddleHit"
    if game.timer-(game[hitKey] or -100)<.085 then return end
    game[hitKey]=game.timer
    local active=left and game.left or game.right
    -- The flipper behaves like a sprung paddle, with a bigger impulse on press.
    game.y=min(game.y,cy-FLIPPER_HIT_RADIUS)
    game.vy=-max(active and 650 or 330,abs(game.vy)*.84 + (active and 215 or 45))
    game.vx=clamp(game.vx+(left and 135 or -135)+(t-.42)*240,-590,590)
    if game.timer-(game.lastSound.paddleHit or -100)>.09 then
        game.lastSound.paddleHit=game.timer;playSFX("flipper")
    end
end
local function physics(dt)
    if not game.started or game.over or game.waiting then return end
    if game.launching then
        -- Guaranteed fair launch: straight through a separate, collision-free
        -- launcher rail, then a controlled release at the upper right.
        game.launchElapsed=game.launchElapsed+dt
        game.x=357
        game.y=max(69,545-690*game.launchElapsed)
        if game.y<=69 then
            game.launching=false
            game.x,game.y=334,69
            game.vx,game.vy=-210,115
            game.launchGrace=.10
            showScore()
        end
        return
    end
    if game.launchGrace>0 then game.launchGrace=max(0,game.launchGrace-dt) end
    game.vy=game.vy+GRAVITY*dt
    game.vx=game.vx*(1-.055*dt)
    game.x=game.x+game.vx*dt
    game.y=game.y+game.vy*dt
    if game.x<31 then game.x=31;game.vx=abs(game.vx)*.91;playSFX("rail")
    elseif game.x>369 then game.x=369;game.vx=-abs(game.vx)*.91;playSFX("rail") end
    if game.y<37 then game.y=37;game.vy=abs(game.vy)*.94;playSFX("rail") end
    if game.launchGrace<=0 then
        for _,o in ipairs(objects) do hitObject(o) end
    end
    for _,r in ipairs(rails) do hitRail(r[1],r[2],r[3],r[4]) end
    hitFlipper(true);hitFlipper(false)
    if game.y>478 and game.y<529 then
        if game.x<58 and game.vx<0 then game.vx=abs(game.vx)*.73+22 end
        if game.x>342 and game.vx>0 then game.vx=-abs(game.vx)*.73-22 end
    end
    local speed=sqrt(game.vx*game.vx+game.vy*game.vy)
    if speed>MAX_BALL_SPEED then
        local q=MAX_BALL_SPEED/speed
        game.vx=game.vx*q;game.vy=game.vy*q
    end
    -- Rare edge case: a ball settling between colliders must not softlock.
    if speed<32 and game.y<510 then
        game.stuckTime=game.stuckTime+dt
        if game.stuckTime>2.3 then
            game.vx=game.x<200 and 125 or -125
            game.vy=-315
            game.stuckTime=0
            playSFX("sling")
        end
    else
        game.stuckTime=0
    end
    if game.y>608 then endBall() end
end

local function onUpdate(_,elapsed)
    if not game.started then return end
    -- WoW can miss OnKeyUp when the app loses focus; a long frame gap is a fail-safe.
    if elapsed>.35 then releaseInputs() end
    local dt=min(elapsed,.05)
    game.timer=game.timer+dt
    game.accumulator=min(game.accumulator+dt,.085)
    local steps=0
    while game.accumulator>=FIXED_STEP and steps<16 do
        physics(FIXED_STEP);game.accumulator=game.accumulator-FIXED_STEP;steps=steps+1
    end
    spritePos(ballSprite,game.x,game.y)
    for i,o in ipairs(objects) do
        o.flash=max(0,(o.flash or 0)-dt)
        if bumperSprites[i] then
            local k=o.flash*1.9
            bumperSprites[i]:SetVertexColor(clamp(o.color[1]+k,0,1),clamp(o.color[2]+k,0,1),clamp(o.color[3]+k,0,1),1)
            bumperSprites[i]:SetAlpha(o.bank and o.lit and .42 or 1)
            if glowSprites[i] then
                local idle=o.portal and (.16+.08*sin(game.timer*3.2)) or 0
                glowSprites[i]:SetAlpha(clamp(idle+o.flash*2.5,0,.85))
            end
        end
    end
    for _,p in ipairs(popupLabels) do
        if p.time>0 then
            p.time=max(0,p.time-dt)
            p.text:ClearAllPoints()
            p.text:SetPoint("CENTER",board,"TOPLEFT",p.x,-(p.y-(.85-p.time)*28))
            p.text:SetAlpha(clamp(p.time/.40,0,1))
            if p.time==0 then p.text:Hide() end
        end
    end
    if game.combo>1 and game.timer>game.comboExpires then game.combo=0;showScore() end
end
local function handleKeyDown(_,key)
    if ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow() then releaseInputs();return end
    if key=="ESCAPE" then if window then window:Hide() end;return end
    if key=="A" or key=="LEFT" or key=="D" or key=="RIGHT" then
        keys[key]=true;appliedInputs()
    elseif key=="SPACE" and not keys.SPACE then
        keys.SPACE=true;launchBall()
    end
    -- Every unhandled key is consumed while the arcade is open, preventing movement/spells.
end
local function handleKeyUp(_,key)
    if key=="A" or key=="LEFT" or key=="D" or key=="RIGHT" then
        keys[key]=nil;appliedInputs()
    elseif key=="SPACE" then keys.SPACE=nil end
end
local function prepareCapture()
    if keyCapture then return end
    local input=CreateFrame("Frame","WarcraftPinballKeyboardCapture",UIParent)
    keyCapture=input
    input:SetAllPoints(UIParent)
    input:SetFrameStrata("FULLSCREEN_DIALOG");input:SetFrameLevel(255)
    input:EnableMouse(false)
    input:EnableKeyboard(true)
    input:SetScript("OnKeyDown",handleKeyDown)
    input:SetScript("OnKeyUp",handleKeyUp)
    input:Hide()
    -- Restricted since Retail 10.1.5, so configure ONE TIME outside combat,
    -- never in an OnKey handler or OnUpdate. Hidden frames do not intercept keys.
    if input.SetPropagateKeyboardInput and not (InCombatLockdown and InCombatLockdown()) then
        local ok=pcall(input.SetPropagateKeyboardInput,input,false)
        inputIsBlocked=ok
        if not ok then say("Keyboard lock unsupported: please use the buttons and avoid movement keys.") end
    else
        inputIsBlocked=false
    end
end
local function makeUI()
    if window then return end
    prepareCapture()
    -- A fullscreen mouse shield prevents clicking the game world behind pinball.
    dimScreen=CreateFrame("Frame","WarcraftPinballClickShield",UIParent)
    dimScreen:SetAllPoints(UIParent)
    dimScreen:SetFrameStrata("FULLSCREEN_DIALOG");dimScreen:SetFrameLevel(75)
    dimScreen:EnableMouse(true)
    local shade=dimScreen:CreateTexture(nil,"BACKGROUND")
    shade:SetAllPoints(dimScreen);shade:SetColorTexture(0,0,0,.48)
    dimScreen:Hide()

    local ui=CreateFrame("Frame","WarcraftPinballMain",UIParent)
    window=ui
    ui:SetSize(522,824)
    ui:SetPoint("CENTER",UIParent,"CENTER",0,0)
    ui:SetFrameStrata("FULLSCREEN_DIALOG");ui:SetFrameLevel(100)
    ui:SetMovable(true);ui:SetClampedToScreen(true);ui:EnableMouse(true)
    ui:SetScript("OnUpdate",onUpdate)
    ui:SetScript("OnShow",function()
        releaseInputs();dimScreen:Show();keyCapture:Show();startMusic()
    end)
    ui:SetScript("OnHide",function()
        releaseInputs();keyCapture:Hide();dimScreen:Hide();stopMusic()
    end)

    local frame=ui:CreateTexture(nil,"BACKGROUND");frame:SetAllPoints(ui);frame:SetColorTexture(.06,.045,.035,.98)
    local inner=panel(ui,514,816,.20,.145,.09,1);inner:SetPoint("CENTER")
    local header=panel(ui,512,99,.095,.07,.048,1);header:SetPoint("TOP",ui,"TOP",0,-5)
    -- Scoreboard is drawn on an independent, higher-level frame so the
    -- playfield and opaque panels cannot cover score text on older clients.
    local scoreBoard=CreateFrame("Frame",nil,ui)
    scoreBoard:SetSize(504,94);scoreBoard:SetPoint("TOP",ui,"TOP",0,-7)
    scoreBoard:SetFrameLevel(ui:GetFrameLevel()+22)
    local scoreBackground=scoreBoard:CreateTexture(nil,"BACKGROUND")
    scoreBackground:SetAllPoints(scoreBoard);scoreBackground:SetColorTexture(.075,.052,.032,.99)
    local goldTop=scoreBoard:CreateTexture(nil,"BORDER")
    goldTop:SetPoint("TOPLEFT",scoreBoard,5,-2);goldTop:SetPoint("TOPRIGHT",scoreBoard,-5,-2)
    goldTop:SetHeight(2);goldTop:SetColorTexture(.7,.52,.20,1)
    label(scoreBoard,"WARCRAFT II  |  PINBALL",18,{1,.82,.37},"TOP",scoreBoard,0,-7)
    comboLabel=label(scoreBoard,"HUMANS VS ORCS",11,{.92,.75,.49},"TOPLEFT",scoreBoard,14,-37,"LEFT")
    label(scoreBoard,"SCORE",10,{.78,.73,.6},"TOP",scoreBoard,0,-36)
    scoreLabel=label(scoreBoard,"0",26,{1,.98,.74},"TOP",scoreBoard,0,-48)
    highLabel=label(scoreBoard,"BEST  0",11,{.95,.84,.54},"TOPRIGHT",scoreBoard,-12,-38,"RIGHT")
    local close=button(ui,"X",26,24,483,788,function() ui:Hide() end);close:SetFrameLevel(132)

    board=CreateFrame("Frame",nil,ui)
    board:SetSize(W,H);board:SetPoint("TOP",ui,"TOP",0,-102)
    -- Lift the playfield above the opaque inner frame so the full artwork is visible.
    board:SetFrameLevel(ui:GetFrameLevel()+6)
    local field=board:CreateTexture(nil,"BACKGROUND")
    field:SetAllPoints(board);field:SetTexture(TEX.."Battleground.tga")
    field:SetTexCoord(0,1,0,.75)
    local railsArt=board:CreateTexture(nil,"BORDER")
    railsArt:SetAllPoints(board);railsArt:SetTexture(TEX.."PlayfieldRails.tga")
    railsArt:SetTexCoord(0,1,0,.75)
    local laneArt=board:CreateTexture(nil,"ARTWORK")
    laneArt:SetAllPoints(board)
    laneArt:SetTexture(TEX.."ArcadeLanes.tga")
    laneArt:SetTexCoord(0,1,0,.75)

    for i,o in ipairs(objects) do
        local t=board:CreateTexture(nil,"ARTWORK")
        local image=o.rollover and "Post.tga" or (o.post and "Post.tga" or (o.target and "Target.tga" or (o.sling and "Kicker.tga" or (o.portal and "Portal.tga" or "Bumper.tga"))))
        t:SetTexture(TEX..image)
        t:SetSize(o.rollover and 17 or (o.post and 18 or (o.r*2+12)),o.rollover and 17 or (o.post and 18 or (o.r*2+12)))
        t:SetVertexColor(o.color[1],o.color[2],o.color[3],1)
        spritePos(t,o.x,o.y);bumperSprites[i]=t;o.flash=0
        if o.bumper or o.sling or o.bank then
            local halo=board:CreateTexture(nil,"OVERLAY")
            halo:SetTexture(TEX.."RingGlow.tga")
            halo:SetBlendMode("ADD")
            halo:SetSize((o.r+14)*2,(o.r+14)*2)
            halo:SetVertexColor(o.color[1],o.color[2],o.color[3],1)
            spritePos(halo,o.x,o.y)
            halo:SetAlpha(o.portal and .16 or 0)
            glowSprites[i]=halo
        end
    end
    leftSprite=board:CreateTexture(nil,"OVERLAY")
    leftSprite:SetTexture(TEX.."FlipperAlliance.tga")
    leftSprite:SetSize(FLIPPER_TEXTURE_SIZE,FLIPPER_TEXTURE_SIZE)
    rightSprite=board:CreateTexture(nil,"OVERLAY")
    rightSprite:SetTexture(TEX.."FlipperHorde.tga")
    rightSprite:SetSize(FLIPPER_TEXTURE_SIZE,FLIPPER_TEXTURE_SIZE)
    ballSprite=board:CreateTexture(nil,"OVERLAY")
    ballSprite:SetTexture(TEX.."Ball.tga")
    ballSprite:SetSize(19,19)
    spritePos(ballSprite,game.x,game.y);updateFlippers()
    for i=1,12 do
        local t=board:CreateFontString(nil,"OVERLAY","GameFontNormal")
        t:SetFont("Fonts\\FRIZQT__.TTF",12,"OUTLINE")
        t:SetTextColor(1,.94,.55);t:Hide()
        popupLabels[i]={text=t,time=0,x=0,y=0}
    end

    local foot=panel(ui,512,105,.095,.07,.05,1);foot:SetPoint("BOTTOM",ui,"BOTTOM",0,5)
    local hud=CreateFrame("Frame",nil,ui)
    hud:SetSize(506,31);hud:SetPoint("TOP",board,"BOTTOM",0,-1)
    hud:SetFrameLevel(board:GetFrameLevel()+8)
    local hudBG=hud:CreateTexture(nil,"BACKGROUND");hudBG:SetAllPoints(hud)
    hudBG:SetColorTexture(.055,.047,.039,.98)
    infoLabel=label(hud,"BALL 1 / 3  |  SPACE: LAUNCH",11,{1,.91,.66},"TOP",hud,0,-3)
    allianceLabel=label(hud,"ALLIANCE  0",10,{.39,.77,1},"BOTTOMLEFT",hud,10,3,"LEFT")
    orcLabel=label(hud,"HORDE  0",10,{1,.42,.34},"BOTTOMRIGHT",hud,-10,3,"RIGHT")
    missionLabel=label(hud,"SIEGE  ALLIANCE 0/3  |  HORDE 0/3",9,{.95,.78,.45},"BOTTOM",hud,0,3)
    missionLabel:SetAlpha(.85)
    button(ui,"NEW GAME",94,29,9,55,newGame)
    button(ui,"LAUNCH",83,29,108,55,launchBall)
    musicButton=button(ui,"MUSIC OFF",104,29,196,55,function() toggleMusic(not db.music) end)
    sfxButton=button(ui,"SFX ON",91,29,305,55,function() toggleSFX(not db.sfx) end)
    button(ui,"CLOSE",107,29,400,55,function() ui:Hide() end)
    local leftButton=button(ui,"ALLIANCE  •  A / LEFT",243,34,9,14,nil,{.035,.19,.44})
    local rightButton=button(ui,"HORDE  •  D / RIGHT",243,34,261,14,nil,{.43,.065,.07})
    -- Do NOT toggle on OnClick: mouse-up occurs elsewhere and can stick.
    leftButton:SetScript("OnMouseDown",function(_,mouse) if mouse=="LeftButton" then mouseLeft=true;appliedInputs() end end)
    leftButton:SetScript("OnMouseUp",function() mouseLeft=false;appliedInputs() end)
    leftButton:HookScript("OnLeave",function() mouseLeft=false;appliedInputs() end)
    leftButton:SetScript("OnHide",function() mouseLeft=false;appliedInputs() end)
    rightButton:SetScript("OnMouseDown",function(_,mouse) if mouse=="LeftButton" then mouseRight=true;appliedInputs() end end)
    rightButton:SetScript("OnMouseUp",function() mouseRight=false;appliedInputs() end)
    rightButton:HookScript("OnLeave",function() mouseRight=false;appliedInputs() end)
    rightButton:SetScript("OnHide",function() mouseRight=false;appliedInputs() end)

    local drag=CreateFrame("Frame",nil,ui)
    drag:SetSize(445,46);drag:SetPoint("TOP",ui,"TOP",0,0)
    drag:EnableMouse(true);drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart",function() ui:StartMoving() end)
    drag:SetScript("OnDragStop",function() ui:StopMovingOrSizing() end)
    drag:SetFrameLevel(110)
    local screenH=UIParent:GetHeight()
    if screenH and screenH<880 then ui:SetScale(max(.62,screenH/890)) end
    ui:Hide()
    if not game.started then newGame() end
    soundBtns();showScore()
end
local function openWindow()
    if not db then say("Loading; try again.");return end
    makeUI()
    window:Show()
    if not inputIsBlocked then say("Full keyboard lock unavailable on this client/session; close before moving.") end
end
local function closeWindow() if window then window:Hide() end end
local function help()
    say("/pinball: toggle window,  /pinball new: new game,  /pinball close: close")
    say("/pinball music on|off,  /pinball sfx on|off")
    say("ALLIANCE: A / Left Arrow    HORDE: D / Right Arrow    SPACE: launch")
    say("ESC: close the arcade and return keyboard control to WoW")
end
SLASH_WARCRAFTPINBALL1="/pinball"
SLASH_WARCRAFTPINBALL2="/w2pinball"
SlashCmdList.WARCRAFTPINBALL=function(input)
    local cmd,arg=string.match(string.lower(input or ""),"^%s*(%S*)%s*(%S*)")
    if not db then say("Not ready yet.");return end
    if cmd=="" or cmd=="toggle" then
        if window and window:IsShown() then closeWindow() else openWindow() end
    elseif cmd=="open" or cmd=="show" then openWindow()
    elseif cmd=="close" or cmd=="hide" then closeWindow()
    elseif cmd=="new" or cmd=="reset" then openWindow();newGame()
    elseif cmd=="music" then
        if arg~="on" and arg~="off" then say("/pinball music on|off");return end
        toggleMusic(arg=="on")
    elseif cmd=="sfx" then
        if arg~="on" and arg~="off" then say("/pinball sfx on|off");return end
        toggleSFX(arg=="on")
    else help() end
end
local loader=CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("PLAYER_REGEN_ENABLED")
loader:RegisterEvent("PLAYER_LEAVING_WORLD")
loader:SetScript("OnEvent",function(self,event)
    if event=="PLAYER_LOGIN" then
        WarcraftPinballDB=type(WarcraftPinballDB)=="table" and WarcraftPinballDB or {}
        db=WarcraftPinballDB
        if type(db.highScore)~="number" then db.highScore=0 end
        if type(db.music)~="boolean" then db.music=false end
        if type(db.sfx)~="boolean" then db.sfx=true end
        prepareCapture()
        say("Ready: /pinball | A/D flippers | Space launch | Esc closes")
        self:UnregisterEvent("PLAYER_LOGIN")
    elseif event=="PLAYER_REGEN_ENABLED" and keyCapture and not inputIsBlocked then
        if keyCapture.SetPropagateKeyboardInput then
            inputIsBlocked=pcall(keyCapture.SetPropagateKeyboardInput,keyCapture,false)
        end
    elseif event=="PLAYER_LEAVING_WORLD" then
        releaseInputs()
        if window then window:Hide() end
    end
end)
