-- Casty for World of Warcraft: Forever (Interface 16001)
-- Suggests the next spell to cast with a glowing box: a suggestion window, and a glow on the action
-- bar button that holds the spell. It picks a rotation for your class and talent tree, and switches
-- between PvE and PvP on its own.
--
-- What Casty can see: WoW Forever hides mob auras, real cooldowns, health and your resources from
-- addons during combat. Casty works from what it may read: your own casts (to time damage over time,
-- buffs and cooldowns), procs the game makes glow, what you have learned, range, and Blizzard's own
-- rotation helper when the game offers it for your class.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\"
local PREFIX = "|cff6fd3ffCasty:|r "
local TICK = 0.1
local REFRESH_WINDOW = 1.5     -- re-apply a damage over time or buff this many seconds before it ends
local QUEUE = 3

local db
local playerClass
local box, panel, minimapButton
local spellID = {}              -- spell name -> the learned spell's ID
local timers = { dot = {}, buff = {}, cd = {}, glow = {} }
local combo = 0
local openerUsed = false
local lastFinisherPoints = 0
local treeCache
local buttonsBySpell = {}       -- spell name -> list of action buttons holding it
local glows = {}                -- action button -> our glow frame
local suggestion = {}           -- the names currently shown

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

-- Calls fn and returns its results, or nothing when it errors or returns a secret first value.
local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local results = { pcall(fn, ...) }
    if not results[1] or IsSecret(results[2]) then return nil end
    return select(2, unpack(results))
end

local function Now()
    return GetTime()
end

local function Bool(v)
    if v == true or v == false then return v end
    return nil
end

---------------------------------------------------------------------------
-- Spells and talents
---------------------------------------------------------------------------

local function LearnSpells()
    if InCombatLockdown() then return end
    spellID = {}
    local list = ns.Spells[playerClass]
    if not list then return end
    for name in pairs(list) do
        local info = type(C_Spell) == "table" and Plain(C_Spell.GetSpellInfo, name)
        local id = type(info) == "table" and info.spellID or nil
        if type(id) == "number" and not IsSecret(id) then
            local known = Plain(IsPlayerSpell, id)
            if known == nil and type(C_SpellBook) == "table" then known = Plain(C_SpellBook.IsSpellKnown, id) end
            if known ~= false then spellID[name] = id end
        end
    end
end

local function Known(name)
    return spellID[name] ~= nil
end

-- Talent points per tree, in the order the game lists the trees.
local function ReadTrees()
    local T, CT = C_Traits, C_ClassTalents
    if type(T) ~= "table" or type(CT) ~= "table" then return nil end
    local configID = Plain(CT.GetActiveConfigID)
    local config = configID and Plain(T.GetConfigInfo, configID)
    local treeID = type(config) == "table" and type(config.treeIDs) == "table" and config.treeIDs[1]
    if not treeID then return nil end
    local groups = Plain(T.GetGroupDisplayInfoByTreeID, treeID)
    local nodes = Plain(T.GetTreeNodes, treeID)
    if type(groups) ~= "table" or type(nodes) ~= "table" then return nil end
    local order = {}
    for _, g in ipairs(groups) do
        if type(g) == "table" and type(g.groupID) == "number" then order[#order + 1] = { id = g.groupID, order = g.orderIndex or #order, points = 0, name = g.displayName } end
    end
    table.sort(order, function(a, b) return a.order < b.order end)
    local index = {}
    for i, g in ipairs(order) do index[g.id] = i end
    for _, nodeID in ipairs(nodes) do
        local node = Plain(T.GetNodeInfo, configID, nodeID)
        if type(node) == "table" then
            local rank = node.currentRank or node.ranksPurchased or 0
            if type(rank) == "number" and rank > 0 and type(node.groupIDs) == "table" then
                for _, gid in ipairs(node.groupIDs) do
                    if index[gid] then order[index[gid]].points = order[index[gid]].points + rank break end
                end
            end
        end
    end
    return order
end

local TREE_NAMES = {
    WARRIOR = { "Arms", "Fury", "Protection" }, PALADIN = { "Holy", "Protection", "Retribution" },
    HUNTER = { "Beast Mastery", "Marksmanship", "Survival" }, ROGUE = { "Assassination", "Combat", "Subtlety" },
    PRIEST = { "Discipline", "Holy", "Shadow" }, SHAMAN = { "Elemental", "Enhancement", "Restoration" },
    MAGE = { "Arcane", "Fire", "Frost" }, WARLOCK = { "Affliction", "Demonology", "Destruction" },
    DRUID = { "Balance", "Feral", "Restoration" },
}

local function DetectTree()
    if not InCombatLockdown() then
        local trees = ReadTrees()
        local best, points = nil, 0
        for i, t in ipairs(trees or {}) do
            if i <= 3 and t.points > points then best, points = i, t.points end
        end
        treeCache = best or treeCache
    end
    return treeCache or ns.DefaultTree[playerClass] or 1
end

local function CurrentTree()
    if db.tree and db.tree >= 1 and db.tree <= 3 then return db.tree end
    return DetectTree()
end

local function CurrentMode()
    if db.mode == "PVE" or db.mode == "PVP" then return db.mode end
    local ok, _, instanceType = pcall(GetInstanceInfo)
    if ok and (instanceType == "pvp" or instanceType == "arena") then return "PVP" end
    if Plain(UnitIsPlayer, "target") == true and Plain(UnitCanAttack, "player", "target") ~= false then return "PVP" end
    return "PVE"
end

---------------------------------------------------------------------------
-- Tracking your own casts
---------------------------------------------------------------------------

local function EntryFor(name)
    local rot = ns.Rotations[playerClass]
    if not rot then return nil end
    for _, tree in ipairs(rot) do
        for _, mode in pairs(tree) do
            for _, e in ipairs(mode) do
                if e[1] == name then return e end
            end
        end
    end
    return nil
end

local function ComboPoints()
    if type(UnitPower) == "function" then
        local kind = (type(Enum) == "table" and Enum.PowerType and Enum.PowerType.ComboPoints) or 4
        local cp = Plain(UnitPower, "player", kind)
        if type(cp) == "number" then return cp end
    end
    if type(GetComboPoints) == "function" then
        local cp = Plain(GetComboPoints, "player", "target")
        if type(cp) == "number" then return cp end
    end
    return combo
end

local function OnCast(id)
    local name = type(C_Spell) == "table" and Plain(C_Spell.GetSpellName, id)
    if type(name) ~= "string" then return end
    local info = ns.Spells[playerClass] and ns.Spells[playerClass][name]
    if not info then return end
    local now = Now()
    local e = EntryFor(name) or {}
    openerUsed = true
    -- Cooldowns (the global cooldown does not count).
    if info.cd and info.cd > 1.6 then
        timers.cd[name] = now + info.cd
        if e.group == "shock" then
            for other, oi in pairs(ns.Spells[playerClass]) do
                local oe = EntryFor(other)
                if oe and oe.group == "shock" then timers.cd[other] = now + (oi.cd or info.cd) end
            end
        end
    end
    -- Combo points: finishers spend them, builders add them.
    if ns.Finishers[name] then
        lastFinisherPoints = ComboPoints()
        combo = 0
    elseif e.builder or ns.Builders[name] then
        combo = math.min(5, combo + (e.builder or ns.Builders[name]))
    end
    -- Damage over time and debuffs on the target.
    if e.dot or e.debuff then
        local duration = info.duration or 15
        if name == "Rupture" or name == "Rip" then duration = duration + 2 * math.max(0, lastFinisherPoints - 1) end
        timers.dot[name] = now + duration
    end
    -- Buffs on yourself. No duration in the tooltip means it lasts until you change it.
    if e.buff then
        if e.group then
            for other in pairs(timers.buff) do
                local oe = EntryFor(other)
                if oe and oe.group == e.group then timers.buff[other] = nil end
            end
        end
        local duration = info.duration
        if name == "Slice and Dice" then duration = 9 + 3 * math.max(0, lastFinisherPoints - 1) end
        timers.buff[name] = duration and (now + duration) or math.huge
    end
    if e.clears then
        for other in pairs(timers.buff) do
            local oe = EntryFor(other)
            if oe and oe.group == e.clears then timers.buff[other] = nil end
        end
    end
end

local function OnTargetChanged()
    timers.dot = {}
    combo = 0
    openerUsed = false
end

---------------------------------------------------------------------------
-- Choosing the spell
---------------------------------------------------------------------------

local function Usable(id)
    if type(C_Spell) ~= "table" then return nil end
    local usable, noMana = Plain(C_Spell.IsSpellUsable, id)
    if usable == nil then return nil end
    return usable == true and not noMana
end

local function InRange(id)
    if type(C_Spell) ~= "table" then return nil end
    return Bool(Plain(C_Spell.IsSpellInRange, id, "target"))
end

local function Glowing(id)
    if timers.glow[id] then return true end
    if type(C_SpellActivationOverlay) == "table" then
        return Plain(C_SpellActivationOverlay.IsSpellOverlayed, id) == true
    end
    return false
end

local function Close()
    if type(CheckInteractDistance) ~= "function" then return nil end
    return Bool(Plain(CheckInteractDistance, "target", 3))
end

local function CooldownReady(name, id)
    local now = Now()
    if timers.cd[name] and timers.cd[name] > now + 0.2 then return false end
    -- Out of combat the real cooldown can be read, which catches cooldowns from before a /reload.
    if not InCombatLockdown() and type(C_Spell) == "table" then
        local cd = Plain(C_Spell.GetSpellCooldown, id)
        if type(cd) == "table" and type(cd.startTime) == "number" and type(cd.duration) == "number" and cd.duration > 1.6 then
            if cd.startTime + cd.duration > now + 0.2 then return false end
        end
    end
    return true
end

local function Passes(e)
    local name = e[1]
    local id = spellID[name]
    if not id then return false end
    if e.ifnot and Known(e.ifnot) then return false end
    local now = Now()
    if e.form then
        if type(GetShapeshiftFormID) ~= "function" then return false end
        local ok, form = pcall(GetShapeshiftFormID)
        -- Unknown (hidden by the game): never nag about the form.
        if not ok or IsSecret(form) or form == e.form then return false end
        return Usable(id) ~= false
    end
    if not CooldownReady(name, id) then return false end
    if e.opener and openerUsed then return false end
    if e.dot or e.debuff then
        if timers.dot[name] and timers.dot[name] - now > REFRESH_WINDOW then return false end
        if e.group then
            for other, untilTime in pairs(timers.dot) do
                local oe = EntryFor(other)
                if other ~= name and oe and oe.group == e.group and untilTime - now > REFRESH_WINDOW then return false end
            end
        end
    end
    if e.buff then
        local t = timers.buff[name]
        if t and t - now > REFRESH_WINDOW then return false end
        if e.group then
            for other, untilTime in pairs(timers.buff) do
                local oe = EntryFor(other)
                if other ~= name and oe and oe.group == e.group and untilTime - now > REFRESH_WINDOW then return false end
            end
        end
    end
    if e.finisher and ComboPoints() < e.finisher then return false end
    if e.proc and not Glowing(id) then return false end
    local usable = Usable(id)
    if e.reactive then
        -- Only when the game confirms it, or makes the spell glow.
        if not (usable == true or Glowing(id)) then return false end
    elseif usable == false then
        return false
    end
    if e.close and Close() ~= true then return false end
    local range = InRange(id)
    if range == false then return false end
    if e.melee and range == nil and Close() == false then return false end
    return true
end

local function HasEnemyTarget()
    if Plain(UnitExists, "target") ~= true then return false end
    if Plain(UnitIsDead, "target") == true then return false end
    return Plain(UnitCanAttack, "player", "target") ~= false
end

-- The spells to show, best first, and where the first one came from.
local function Suggest()
    local out, source = {}, "Casty"
    if not HasEnemyTarget() then return out, source end
    local mode = CurrentMode()
    if db.blizzard and mode == "PVE" and type(C_AssistedCombat) == "table" and Plain(C_AssistedCombat.IsAvailable) == true then
        local id = Plain(C_AssistedCombat.GetNextCastSpell, false)
        local name = type(id) == "number" and Plain(C_Spell.GetSpellName, id)
        if type(name) == "string" then
            out[1] = { name = name, id = id }
            source = "Blizzard"
        end
    end
    local rot = ns.Rotations[playerClass]
    local list = rot and rot[CurrentTree()] and rot[CurrentTree()][mode]
    for _, e in ipairs(list or {}) do
        if #out >= QUEUE then break end
        local dup = false
        for _, s in ipairs(out) do if s.name == e[1] then dup = true end end
        if not dup and Passes(e) then out[#out + 1] = { name = e[1], id = spellID[e[1]] } end
    end
    return out, source
end

---------------------------------------------------------------------------
-- Action bar glow and key bindings
---------------------------------------------------------------------------

local BARS = {
    { "ActionButton", "ACTIONBUTTON" }, { "MultiBarBottomLeftButton", "MULTIACTIONBAR1BUTTON" },
    { "MultiBarBottomRightButton", "MULTIACTIONBAR2BUTTON" }, { "MultiBarRightButton", "MULTIACTIONBAR3BUTTON" },
    { "MultiBarLeftButton", "MULTIACTIONBAR4BUTTON" }, { "MultiBar5Button", "MULTIACTIONBAR5BUTTON" },
    { "MultiBar6Button", "MULTIACTIONBAR6BUTTON" }, { "MultiBar7Button", "MULTIACTIONBAR7BUTTON" },
}

local function SlotSpellName(slot)
    if type(GetActionInfo) ~= "function" or type(slot) ~= "number" then return nil end
    local kind, id = Plain(GetActionInfo, slot)
    if kind == "macro" and type(GetMacroSpell) == "function" then
        id = Plain(GetMacroSpell, id)
        kind = id and "spell" or nil
    end
    if kind ~= "spell" or type(id) ~= "number" then return nil end
    return Plain(C_Spell.GetSpellName, id)
end

-- Which action buttons hold which spell. Rebuilt out of combat, since bars cannot change in combat.
local function MapButtons()
    if InCombatLockdown() then return end
    buttonsBySpell = {}
    for _, bar in ipairs(BARS) do
        for i = 1, 12 do
            local button = _G[bar[1] .. i]
            if type(button) == "table" then
                local slot = button.action
                if type(slot) ~= "number" and type(button.GetAttribute) == "function" then slot = Plain(button.GetAttribute, button, "action") end
                local name = SlotSpellName(slot)
                if name then
                    local list = buttonsBySpell[name] or {}
                    list[#list + 1] = { button = button, binding = bar[2] .. i }
                    buttonsBySpell[name] = list
                end
            end
        end
    end
end

local function ShortKey(key)
    if type(key) ~= "string" then return "" end
    key = key:gsub("SHIFT%-", "S"):gsub("CTRL%-", "C"):gsub("ALT%-", "A"):gsub("BUTTON", "M"):gsub("NUMPAD", "N")
    key = key:gsub("MOUSEWHEELUP", "WU"):gsub("MOUSEWHEELDOWN", "WD")
    return key
end

local function KeyFor(name)
    for _, b in ipairs(buttonsBySpell[name] or {}) do
        local key = type(GetBindingKey) == "function" and Plain(GetBindingKey, b.binding)
        if key then return ShortKey(key) end
    end
    return ""
end

local function GlowFrame(button)
    if glows[button] then return glows[button] end
    local g = CreateFrame("Frame", nil, UIParent)
    g:SetPoint("TOPLEFT", button, "TOPLEFT", -9, 9)
    g:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 9, -9)
    g:SetFrameStrata("HIGH")
    g:EnableMouse(false)
    g.tex = g:CreateTexture(nil, "OVERLAY")
    g.tex:SetAllPoints()
    g.tex:SetTexture(TEXTURES .. "Glow.tga")
    g.tex:SetBlendMode("ADD")
    g:Hide()
    glows[button] = g
    return g
end

local function UpdateBarGlow(name, pulse)
    local wanted = {}
    if db.barGlow and name then
        for _, b in ipairs(buttonsBySpell[name] or {}) do
            if b.button:IsVisible() then wanted[b.button] = true end
        end
    end
    for button in pairs(wanted) do GlowFrame(button) end
    for button, g in pairs(glows) do
        if wanted[button] then
            g.tex:SetVertexColor(1, 0.85, 0.3, 0.55 + 0.45 * pulse)
            g:Show()
        else
            g:Hide()
        end
    end
end

---------------------------------------------------------------------------
-- The suggestion box
---------------------------------------------------------------------------

local function SpellIcon(id)
    return (id and type(C_Spell) == "table" and Plain(C_Spell.GetSpellTexture, id)) or 134400
end

local function Icon(parent, size)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(size, size)
    f.icon = f:CreateTexture(nil, "ARTWORK")
    f.icon:SetAllPoints()
    f.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    f.border = f:CreateTexture(nil, "BACKGROUND")
    f.border:SetPoint("TOPLEFT", -2, 2)
    f.border:SetPoint("BOTTOMRIGHT", 2, -2)
    f.border:SetColorTexture(0, 0, 0, 0.9)
    return f
end

local function CreateBox()
    local b = CreateFrame("Frame", "CastyBox", UIParent)
    b:SetSize(140, 92)
    b:SetFrameStrata("MEDIUM")
    b:SetClampedToScreen(true)
    b:SetMovable(true)
    b:RegisterForDrag("LeftButton")
    b:SetScript("OnDragStart", function(self) if not db.locked then self:StartMoving() end end)
    b:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
            db.pos = { point, relPoint, x, y }
        end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
        b:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        b:SetPoint("CENTER", UIParent, "CENTER", 0, -180)
    end
    b.main = Icon(b, 52)
    b.main:SetPoint("TOPLEFT", 4, -4)
    b.glow = b.main:CreateTexture(nil, "OVERLAY")
    b.glow:SetPoint("TOPLEFT", -14, 14)
    b.glow:SetPoint("BOTTOMRIGHT", 14, -14)
    b.glow:SetTexture(TEXTURES .. "Glow.tga")
    b.glow:SetBlendMode("ADD")
    b.key = b.main:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
    b.key:SetPoint("TOPRIGHT", -2, -2)
    b.next = {}
    for i = 1, QUEUE - 1 do
        local n = Icon(b, 30)
        n:SetPoint("TOPLEFT", 64 + (i - 1) * 36, -14)
        n:SetAlpha(0.8)
        b.next[i] = n
    end
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("TOPLEFT", 4, -62)
    b.label:SetPoint("RIGHT", -2, 0)
    b.label:SetJustifyH("LEFT")
    b.label:SetWordWrap(false)
    b.name = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    b.name:SetPoint("TOPLEFT", 4, -76)
    b.name:SetPoint("RIGHT", -2, 0)
    b.name:SetJustifyH("LEFT")
    b.name:SetWordWrap(false)
    b:EnableMouse(not db.locked)
    b:SetScale(db.scale or 1)
    b:Hide()

    local wait, clock = 0, 0
    b:SetScript("OnUpdate", nil)
    local driver = CreateFrame("Frame")
    driver:SetScript("OnUpdate", function(_, elapsed)
        clock = clock + elapsed
        wait = wait + elapsed
        local pulse = 0.5 + 0.5 * math.sin(clock * 5)
        if wait >= TICK then
            wait = 0
            local inCombat = InCombatLockdown()
            local show = db.enabled and (inCombat or (db.outOfCombat and HasEnemyTarget()))
            if show then
                local list, source = Suggest()
                suggestion = list
                if list[1] then
                    b.main.icon:SetTexture(SpellIcon(list[1].id))
                    b.key:SetText(KeyFor(list[1].name))
                    b.name:SetText(list[1].name)
                    for i, n in ipairs(b.next) do
                        local s = list[i + 1]
                        if s then n.icon:SetTexture(SpellIcon(s.id)) n:Show() else n:Hide() end
                    end
                    local tree = TREE_NAMES[playerClass] and TREE_NAMES[playerClass][CurrentTree()] or ""
                    local healer = ns.HealerTrees[playerClass] and ns.HealerTrees[playerClass][CurrentTree()]
                    b.label:SetText(string.format("|cff9d9d9d%s, %s, %s%s|r", tree, CurrentMode() == "PVP" and "PvP" or "PvE", source,
                        healer and ", damage only" or ""))
                    if db.box then b:Show() else b:Hide() end
                else
                    b:Hide()
                end
            else
                suggestion = {}
                b:Hide()
            end
        end
        b.glow:SetVertexColor(1, 0.85, 0.3, 0.45 + 0.55 * pulse)
        UpdateBarGlow(suggestion[1] and suggestion[1].name, pulse)
    end)
    box = b
end

---------------------------------------------------------------------------
-- Settings panel (every setting is a button)
---------------------------------------------------------------------------

local function Button(parent, width, text, onClick, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 22)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.07, 0.14, 0.22, 0.95)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text)
    b.tip = tip
    b:SetScript("OnEnter", function(self)
        bg:SetColorTexture(0.12, 0.28, 0.42, 0.95)
        if self.tip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.tip, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function()
        bg:SetColorTexture(0.07, 0.14, 0.22, 0.95)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", onClick)
    return b
end

local RefreshPanel

local function Apply()
    if box then
        box:EnableMouse(not db.locked)
        box:SetScale(db.scale)
    end
    if ns.UpdateMinimapButton then ns.UpdateMinimapButton() end
    RefreshPanel()
end

local function CreatePanel()
    local p = CreateFrame("Frame", "CastyPanel", UIParent)
    p:SetSize(300, 372)
    p:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
    p:SetFrameStrata("HIGH")
    p:SetClampedToScreen(true)
    p:EnableMouse(true)
    p:SetMovable(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", p.StartMoving)
    p:SetScript("OnDragStop", p.StopMovingOrSizing)
    local border = p:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.3, 0.65, 0.95, 1)
    local bg = p:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 2, -2)
    bg:SetPoint("BOTTOMRIGHT", -2, 2)
    bg:SetColorTexture(0.03, 0.05, 0.08, 0.96)
    local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("Casty")
    local close = Button(p, 22, "X", function() p:Hide() end)
    close:SetPoint("TOPRIGHT", -10, -10)
    p.status = p:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    p.status:SetPoint("TOPLEFT", 14, -40)
    p.status:SetPoint("RIGHT", -14, 0)
    p.status:SetJustifyH("LEFT")

    local rows = {
        { "mode", "Which rotation style to use. Auto picks PvP in battlegrounds, arenas and against enemy players, and PvE everywhere else.", function()
            local order = { AUTO = "PVE", PVE = "PVP", PVP = "AUTO" }
            db.mode = order[db.mode or "AUTO"] or "AUTO"
        end },
        { "tree", "Which talent tree's rotation to use. Auto picks the tree you have put the most points in.", function()
            db.tree = ((db.tree or 0) + 1) % 4
            if db.tree == 0 then db.tree = nil end
        end },
        { "blizzard", "In PvE, use Blizzard's own rotation helper for the first suggestion when the game offers one for your class. It can see more than an addon can.", function() db.blizzard = not db.blizzard end },
        { "barGlow", "Glow the action bar button that holds the suggested spell.", function() db.barGlow = not db.barGlow end },
        { "box", "Show the suggestion box with the next spells.", function() db.box = not db.box end },
        { "outOfCombat", "Also suggest a spell to open with when you target an enemy out of combat.", function() db.outOfCombat = not db.outOfCombat end },
        { "locked", "Lock the suggestion box so clicks go through it. Unlock it to drag it somewhere else.", function() db.locked = not db.locked end },
        { "minimap", "A button on the minimap that opens this panel. Drag it around the minimap to move it.", function() db.minimap = not db.minimap end },
        { "enabled", "Turn Casty on or off.", function() db.enabled = not db.enabled end },
    }
    p.buttons = {}
    for i, r in ipairs(rows) do
        local b = Button(p, 272, "", function()
            r[3]()
            Apply()
        end, r[2])
        b:SetPoint("TOPLEFT", 14, -62 - (i - 1) * 26)
        b.key = r[1]
        p.buttons[i] = b
    end
    local smaller = Button(p, 132, "Box smaller", function()
        db.scale = math.max(0.6, db.scale - 0.1)
        Apply()
    end)
    smaller:SetPoint("TOPLEFT", 14, -62 - #rows * 26)
    local bigger = Button(p, 132, "Box bigger", function()
        db.scale = math.min(2, db.scale + 0.1)
        Apply()
    end)
    bigger:SetPoint("TOPLEFT", 154, -62 - #rows * 26)
    local note = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    note:SetPoint("BOTTOMLEFT", 14, 12)
    note:SetPoint("RIGHT", -14, 0)
    note:SetJustifyH("LEFT")
    note:SetText("Casty times damage over time, buffs and cooldowns from your own casts, since the game hides them from addons in combat.")
    p:SetScript("OnShow", function() RefreshPanel() end)
    p:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "CastyPanel") end
    panel = p
end

local LABELS = {
    mode = function() return "Style: " .. ({ AUTO = "Auto (now " .. (CurrentMode() == "PVP" and "PvP" or "PvE") .. ")", PVE = "PvE", PVP = "PvP" })[db.mode or "AUTO"] end,
    tree = function()
        local names = TREE_NAMES[playerClass] or {}
        if db.tree then return "Talent tree: " .. (names[db.tree] or db.tree) end
        return "Talent tree: Auto (" .. (names[CurrentTree()] or "?") .. ")"
    end,
    blizzard = function() return "Blizzard rotation helper: " .. (db.blizzard and "on" or "off") end,
    barGlow = function() return "Action bar glow: " .. (db.barGlow and "on" or "off") end,
    box = function() return "Suggestion box: " .. (db.box and "on" or "off") end,
    outOfCombat = function() return "Suggest before combat: " .. (db.outOfCombat and "on" or "off") end,
    locked = function() return "Suggestion box: " .. (db.locked and "locked" or "unlocked, drag to move") end,
    minimap = function() return "Minimap button: " .. (db.minimap and "on" or "off") end,
    enabled = function() return "Casty: " .. (db.enabled and "on" or "off") end,
}

RefreshPanel = function()
    if not panel or not panel:IsShown() then return end
    for _, b in ipairs(panel.buttons) do b.label:SetText(LABELS[b.key]()) end
    local available = type(C_AssistedCombat) == "table" and Plain(C_AssistedCombat.IsAvailable) == true
    panel.status:SetText(string.format("|cff9d9d9dBlizzard's helper for your class: %s|r", available and "available" or "not available, Casty's own rotation is used"))
end

local function TogglePanel()
    if not db then return end
    if not panel then CreatePanel() end
    if panel:IsShown() then panel:Hide() else panel:Show() end
end

function Casty_OnCompartmentClick()
    TogglePanel()
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 230)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "CastyMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    local back = b:CreateTexture(nil, "BACKGROUND")
    back:SetSize(22, 22)
    back:SetPoint("CENTER")
    back:SetColorTexture(0.03, 0.05, 0.08, 0.9)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")
    icon:SetTexture(TEXTURES .. "Casty.tga")
    icon:SetVertexColor(0.45, 0.8, 1, 1)
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", TogglePanel)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Casty", 0.45, 0.8, 1)
        GameTooltip:AddLine("Click for settings.", 1, 1, 1)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

ns.UpdateMinimapButton = function()
    if not db or not Minimap then return end
    if db.minimap then
        if not minimapButton then CreateMinimapButton() end
        minimapButton:Show()
    elseif minimapButton then
        minimapButton:Hide()
    end
end

---------------------------------------------------------------------------
-- Slash command and events
---------------------------------------------------------------------------

SLASH_CASTY1 = "/casty"
SlashCmdList.CASTY = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command = string.lower(message or ""):match("^%s*(%S*)")
    if command == "pve" or command == "pvp" or command == "auto" then
        db.mode = string.upper(command)
        Say("style: " .. LABELS.mode():gsub("^Style: ", "") .. ".")
        Apply()
    elseif command == "help" then
        Say("/casty opens the settings, where everything is a button. /casty pve, /casty pvp or /casty auto sets the style.")
    else
        TogglePanel()
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        CastyDB = type(CastyDB) == "table" and CastyDB or {}
        db = CastyDB
        for key, value in pairs({ enabled = true, blizzard = true, barGlow = true, box = true, outOfCombat = true, locked = false, minimap = true }) do
            if type(db[key]) ~= "boolean" then db[key] = value end
        end
        if type(db.scale) ~= "number" then db.scale = 1 end
        if db.mode ~= "PVE" and db.mode ~= "PVP" then db.mode = "AUTO" end
        if type(db.tree) ~= "number" then db.tree = nil end
        local ok, _, classFile = pcall(UnitClass, "player")
        playerClass = ok and classFile or "WARRIOR"
        -- An event name this client does not know makes RegisterEvent throw, so each is tried alone.
        for _, name in ipairs({ "UNIT_SPELLCAST_SUCCEEDED", "PLAYER_TARGET_CHANGED", "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW",
            "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE", "SPELLS_CHANGED", "ACTIONBAR_SLOT_CHANGED", "UPDATE_BINDINGS",
            "PLAYER_REGEN_ENABLED", "PLAYER_DEAD", "TRAIT_CONFIG_UPDATED", "PLAYER_TALENT_UPDATE", "PLAYER_ENTERING_WORLD" }) do
            pcall(self.RegisterEvent, self, name)
        end
        LearnSpells()
        DetectTree()
        MapButtons()
        CreateBox()
        ns.UpdateMinimapButton()
        return
    end
    if not db then return end
    local a1, a2, a3 = ...
    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        if a1 == "player" and type(a3) == "number" and not IsSecret(a3) then OnCast(a3) end
    elseif event == "PLAYER_TARGET_CHANGED" then
        OnTargetChanged()
    elseif event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" then
        if type(a1) == "number" and not IsSecret(a1) then timers.glow[a1] = true end
    elseif event == "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then
        if type(a1) == "number" and not IsSecret(a1) then timers.glow[a1] = nil end
    elseif event == "PLAYER_DEAD" then
        timers.buff, timers.dot = {}, {}
    else
        -- Spells, talents, bars or bindings changed, or combat ended: re-read what can only be read out of combat.
        LearnSpells()
        DetectTree()
        MapButtons()
        RefreshPanel()
    end
end)

-- For the automated tests.
ns.Suggest = Suggest
ns.OnCast = OnCast
ns.Timers = timers
