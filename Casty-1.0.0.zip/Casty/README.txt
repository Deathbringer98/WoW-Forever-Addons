Casty 1.0.0 - World of Warcraft: Forever (Interface 16001)
========================================================

Casty suggests the next spell to cast. The suggested spell gets a glowing
box in two places:
- a suggestion box with the spell's icon, its key binding and the next
  two spells after it
- a glow on the action bar button that holds the spell

It works for all nine classes and all three talent trees of each, and
switches between a PvE and a PvP rotation on its own.

INSTALL
Copy the Casty folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

HOW TO USE
Target an enemy and fight. The box shows up in combat, and also out of
combat when you target an enemy, so you know what to open with.
Drag the box to move it (it can be locked in the settings).

Click the blue sparkle on the minimap (or pick Casty from the minimap
addon menu, or type /casty) for the settings. Every setting is a button:
  Style              Auto, PvE or PvP
  Talent tree        Auto, or pick a tree yourself
  Blizzard helper    use Blizzard's own rotation helper in PvE when the
                     game offers one for your class
  Action bar glow    glow the button that holds the suggested spell
  Suggestion box     show or hide the box
  Suggest before combat
  Lock box           lock it so clicks go through it
  Minimap button     show or hide the minimap button
  Box smaller / bigger
  Casty              turn it all on or off

PVE OR PVP
On Auto, Casty uses the PvP rotation in battlegrounds and arenas, and when
your target is an enemy player. Everywhere else it uses the PvE rotation.
PvP rotations lead with control and burst (Hamstring, Death Coil, Frost
Nova, Kidney Shot and so on). PvE rotations keep your damage over time,
debuffs and buffs up and spend the rest on your strongest spells.

TALENT TREE
On Auto, Casty uses the rotation of the tree you have put the most points
in. Healing trees (Holy, Discipline, Restoration) get their class's damage
spells, since Casty cannot see who needs healing.

WHAT CASTY CAN AND CANNOT SEE
WoW Forever hides a lot from addons during combat: auras on mobs, real
cooldowns, health and your mana, rage, energy or combo points. So Casty:
- times your damage over time, debuffs, buffs and cooldowns from your own
  casts, using each spell's tooltip duration and cooldown
- starts those timers over when you change target
- shows procs only while the game makes the spell glow (Nightfall and so on)
- shows Overpower, Revenge, Execute and other "only now" spells only when
  the game says they can be cast
- counts your combo points from your own builders and finishers when the
  game hides them
- skips spells you have not learned, and spells out of range
It cannot see resists, dispels or a target's health, so it will not call
an execute phase on its own, and it cannot know when you are out of mana.
Blizzard's own helper, when the game offers it for your class, can see
more, which is why Casty uses it first in PvE.

COMMANDS (optional)
/casty           open the settings
/casty pve, /casty pvp, /casty auto   set the style

EDITING ROTATIONS
The rotations are plain lists in Rotations.lua, one per class, tree and
style, with the conditions explained at the top of the file.

CREDITS
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Spell durations and cooldowns read from WoW Forever tooltips via
talentsforever.com (https://talentsforever.com), CC BY 4.0.
