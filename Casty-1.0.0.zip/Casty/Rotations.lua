-- Casty rotations: one priority list per class, talent tree and playstyle (PvE or PvP).
-- The first spell in a list whose conditions pass is the one Casty suggests.
--
-- Conditions (all optional):
--   dot = true        keep it on the target: suggested when it is not on, or about to run out
--   debuff = true     same as dot, for debuffs that do no damage
--   buff = true       keep it on yourself
--   group = "name"    only one spell of the group can be up at once (seals, aspects, curses, banes)
--   reactive = true   only when the game says it can be cast right now (Overpower, Revenge, Execute)
--   proc = true       only while the game makes it glow (a proc, like Nightfall)
--   melee = true      only in melee range
--   close = true      only when the target is within about 10 yards
--   finisher = n      only with at least n combo points (rogues, cat druids)
--   builder = n       adds n combo points (default 1)
--   form = id         a shapeshift form: suggested when you are not in it
--   opener = true     only as the first spell on a new target
--   ifnot = "Spell"   skipped when you know that other spell (a better version)
--   clears = "group"  casting it ends the group's buffs (Judgement ends your seal)
--
-- Spell names are WoW Forever's. Spells you have not learned are skipped automatically.
local _, ns = ...

ns.DefaultTree = { WARRIOR = 1, PALADIN = 3, HUNTER = 1, ROGUE = 2, PRIEST = 3, SHAMAN = 1, MAGE = 3, WARLOCK = 1, DRUID = 1 }

-- Healing trees get their class's damage list, since Casty cannot see who needs healing.
ns.HealerTrees = { PALADIN = { [1] = true }, PRIEST = { [1] = true, [2] = true }, SHAMAN = { [3] = true }, DRUID = { [3] = true } }

ns.Rotations = {
    WARRIOR = {
        { -- Arms
            PVE = {
                { "Battle Shout", buff = true },
                { "Rend", dot = true },
                { "Overpower", reactive = true },
                { "Execute", reactive = true },
                { "Mortal Strike", melee = true },
                { "Victory Rush", reactive = true },
                { "Slam", melee = true },
                { "Heroic Strike", melee = true },
            },
            PVP = {
                { "Charge", reactive = true },
                { "Intercept", reactive = true },
                { "Hamstring", debuff = true, melee = true },
                { "Mortal Strike", melee = true },
                { "Overpower", reactive = true },
                { "Execute", reactive = true },
                { "Rend", dot = true },
                { "Victory Rush", reactive = true },
                { "Heroic Strike", melee = true },
            },
        },
        { -- Fury
            PVE = {
                { "Battle Shout", buff = true },
                { "Execute", reactive = true },
                { "Bloodthirst", melee = true },
                { "Whirlwind", close = true },
                { "Victory Rush", reactive = true },
                { "Heroic Strike", melee = true },
            },
            PVP = {
                { "Charge", reactive = true },
                { "Intercept", reactive = true },
                { "Hamstring", debuff = true, melee = true },
                { "Bloodthirst", melee = true },
                { "Execute", reactive = true },
                { "Whirlwind", close = true },
                { "Victory Rush", reactive = true },
                { "Heroic Strike", melee = true },
            },
        },
        { -- Protection
            PVE = {
                { "Shield Slam", melee = true },
                { "Revenge", reactive = true },
                { "Sunder Armor", debuff = true, melee = true },
                { "Thunder Clap", debuff = true, close = true },
                { "Demoralizing Shout", debuff = true, close = true },
                { "Battle Shout", buff = true },
                { "Heroic Strike", melee = true },
            },
            PVP = {
                { "Charge", reactive = true },
                { "Hamstring", debuff = true, melee = true },
                { "Concussion Blow", melee = true },
                { "Shield Slam", melee = true },
                { "Revenge", reactive = true },
                { "Heroic Strike", melee = true },
            },
        },
    },

    PALADIN = {
        { -- Holy (healer: damage spells only)
            PVE = {
                { "Seal of Righteousness", buff = true, group = "seal" },
                { "Judgement", clears = "seal" },
                { "Holy Shock" },
                { "Exorcism", reactive = true },
                { "Hammer of Wrath", reactive = true },
                { "Holy Strike", melee = true },
            },
            PVP = {
                { "Hammer of Justice", melee = true },
                { "Seal of Righteousness", buff = true, group = "seal" },
                { "Judgement", clears = "seal" },
                { "Holy Shock" },
                { "Hammer of Wrath", reactive = true },
                { "Holy Strike", melee = true },
            },
        },
        { -- Protection
            PVE = {
                { "Righteous Fury", buff = true },
                { "Holy Shield", buff = true },
                { "Seal of Righteousness", buff = true, group = "seal" },
                { "Judgement", clears = "seal" },
                { "Consecration", close = true },
                { "Holy Strike", melee = true },
                { "Exorcism", reactive = true },
            },
            PVP = {
                { "Hammer of Justice", melee = true },
                { "Holy Shield", buff = true },
                { "Seal of Righteousness", buff = true, group = "seal" },
                { "Judgement", clears = "seal" },
                { "Hammer of Wrath", reactive = true },
                { "Holy Strike", melee = true },
            },
        },
        { -- Retribution
            PVE = {
                { "Seal of Command", buff = true, group = "seal" },
                { "Seal of Righteousness", buff = true, group = "seal", ifnot = "Seal of Command" },
                { "Judgement", clears = "seal" },
                { "Hammer of Wrath", reactive = true },
                { "Exorcism", reactive = true },
                { "Holy Strike", melee = true },
                { "Consecration", close = true },
            },
            PVP = {
                { "Hammer of Justice", melee = true },
                { "Seal of Command", buff = true, group = "seal" },
                { "Seal of Righteousness", buff = true, group = "seal", ifnot = "Seal of Command" },
                { "Judgement", clears = "seal" },
                { "Hammer of Wrath", reactive = true },
                { "Holy Strike", melee = true },
                { "Repentance" },
            },
        },
    },

    HUNTER = {
        { -- Beast Mastery
            PVE = {
                { "Aspect of the Hawk", buff = true, group = "aspect" },
                { "Hunter's Mark", debuff = true },
                { "Bestial Wrath" },
                { "Rapid Fire" },
                { "Serpent Sting", dot = true, group = "sting" },
                { "Multi-Shot" },
                { "Arcane Shot" },
                { "Mongoose Bite", reactive = true },
                { "Raptor Strike", melee = true },
            },
            PVP = {
                { "Wing Clip", debuff = true, melee = true },
                { "Mongoose Bite", reactive = true },
                { "Raptor Strike", melee = true },
                { "Hunter's Mark", debuff = true },
                { "Bestial Wrath" },
                { "Concussive Shot", debuff = true },
                { "Serpent Sting", dot = true, group = "sting" },
                { "Arcane Shot" },
                { "Multi-Shot" },
            },
        },
        { -- Marksmanship
            PVE = {
                { "Aspect of the Hawk", buff = true, group = "aspect" },
                { "Hunter's Mark", debuff = true },
                { "Rapid Fire" },
                { "Serpent Sting", dot = true, group = "sting" },
                { "Aimed Shot" },
                { "Multi-Shot" },
                { "Arcane Shot" },
                { "Mongoose Bite", reactive = true },
                { "Raptor Strike", melee = true },
            },
            PVP = {
                { "Wing Clip", debuff = true, melee = true },
                { "Mongoose Bite", reactive = true },
                { "Raptor Strike", melee = true },
                { "Scatter Shot" },
                { "Hunter's Mark", debuff = true },
                { "Concussive Shot", debuff = true },
                { "Serpent Sting", dot = true, group = "sting" },
                { "Aimed Shot" },
                { "Arcane Shot" },
                { "Multi-Shot" },
            },
        },
        { -- Survival
            PVE = {
                { "Aspect of the Hawk", buff = true, group = "aspect" },
                { "Hunter's Mark", debuff = true },
                { "Serpent Sting", dot = true, group = "sting" },
                { "Rapid Fire" },
                { "Multi-Shot" },
                { "Arcane Shot" },
                { "Counterattack", reactive = true },
                { "Mongoose Bite", reactive = true },
                { "Raptor Strike", melee = true },
            },
            PVP = {
                { "Wing Clip", debuff = true, melee = true },
                { "Counterattack", reactive = true },
                { "Mongoose Bite", reactive = true },
                { "Raptor Strike", melee = true },
                { "Hunter's Mark", debuff = true },
                { "Concussive Shot", debuff = true },
                { "Serpent Sting", dot = true, group = "sting" },
                { "Arcane Shot" },
                { "Multi-Shot" },
            },
        },
    },

    ROGUE = {
        { -- Assassination
            PVE = {
                { "Slice and Dice", buff = true, finisher = 1 },
                { "Rupture", dot = true, finisher = 5 },
                { "Cold Blood" },
                { "Eviscerate", finisher = 5 },
                { "Mutilate", builder = 2, melee = true },
                { "Sinister Strike", melee = true, ifnot = "Mutilate" },
            },
            PVP = {
                { "Cheap Shot", reactive = true, builder = 2 },
                { "Ambush", reactive = true, builder = 2 },
                { "Kidney Shot", finisher = 4 },
                { "Cold Blood" },
                { "Eviscerate", finisher = 5 },
                { "Mutilate", builder = 2, melee = true },
                { "Sinister Strike", melee = true, ifnot = "Mutilate" },
            },
        },
        { -- Combat
            PVE = {
                { "Slice and Dice", buff = true, finisher = 1 },
                { "Adrenaline Rush" },
                { "Blade Flurry" },
                { "Riposte", reactive = true },
                { "Eviscerate", finisher = 5 },
                { "Sinister Strike", melee = true },
            },
            PVP = {
                { "Cheap Shot", reactive = true, builder = 2 },
                { "Ambush", reactive = true, builder = 2 },
                { "Kidney Shot", finisher = 4 },
                { "Riposte", reactive = true },
                { "Adrenaline Rush" },
                { "Eviscerate", finisher = 5 },
                { "Sinister Strike", melee = true },
            },
        },
        { -- Subtlety
            PVE = {
                { "Slice and Dice", buff = true, finisher = 1 },
                { "Eviscerate", finisher = 5 },
                { "Ghostly Strike", melee = true },
                { "Hemorrhage", melee = true },
                { "Sinister Strike", melee = true, ifnot = "Hemorrhage" },
            },
            PVP = {
                { "Cheap Shot", reactive = true, builder = 2 },
                { "Ambush", reactive = true, builder = 2 },
                { "Premeditation", reactive = true, builder = 2 },
                { "Kidney Shot", finisher = 4 },
                { "Eviscerate", finisher = 5 },
                { "Ghostly Strike", melee = true },
                { "Hemorrhage", melee = true },
                { "Sinister Strike", melee = true, ifnot = "Hemorrhage" },
            },
        },
    },

    PRIEST = {
        { -- Discipline (healer: damage spells only)
            PVE = {
                { "Shadow Word: Pain", dot = true },
                { "Holy Fire", dot = true },
                { "Penance" },
                { "Mind Blast" },
                { "Smite" },
            },
            PVP = {
                { "Power Word: Shield", buff = true },
                { "Psychic Scream", close = true },
                { "Shadow Word: Pain", dot = true },
                { "Penance" },
                { "Mind Blast" },
                { "Smite" },
            },
        },
        { -- Holy (healer: damage spells only)
            PVE = {
                { "Holy Fire", dot = true },
                { "Shadow Word: Pain", dot = true },
                { "Mind Blast" },
                { "Smite" },
            },
            PVP = {
                { "Power Word: Shield", buff = true },
                { "Psychic Scream", close = true },
                { "Shadow Word: Pain", dot = true },
                { "Holy Fire", dot = true },
                { "Mind Blast" },
                { "Smite" },
            },
        },
        { -- Shadow
            PVE = {
                { "Shadowform", form = 28 },
                { "Shadow Word: Pain", dot = true },
                { "Vampiric Embrace", debuff = true },
                { "Devouring Plague", dot = true },
                { "Mind Blast" },
                { "Shadow Word: Death" },
                { "Mind Flay" },
                { "Smite", ifnot = "Mind Flay" },
            },
            PVP = {
                { "Power Word: Shield", buff = true },
                { "Psychic Scream", close = true },
                { "Shadowform", form = 28 },
                { "Shadow Word: Pain", dot = true },
                { "Vampiric Embrace", debuff = true },
                { "Mind Blast" },
                { "Shadow Word: Death" },
                { "Devouring Plague", dot = true },
                { "Mind Flay" },
            },
        },
    },

    SHAMAN = {
        { -- Elemental
            PVE = {
                { "Lightning Shield", buff = true, group = "shield" },
                { "Flame Shock", dot = true, group = "shock" },
                { "Earth Shock", group = "shock" },
                { "Chain Lightning" },
                { "Lightning Bolt" },
            },
            PVP = {
                { "Lightning Shield", buff = true, group = "shield" },
                { "Frost Shock", debuff = true, group = "shock" },
                { "Flame Shock", dot = true, group = "shock" },
                { "Earth Shock", group = "shock" },
                { "Chain Lightning" },
                { "Lightning Bolt" },
            },
        },
        { -- Enhancement
            PVE = {
                { "Lightning Shield", buff = true, group = "shield" },
                { "Stormstrike", melee = true },
                { "Flame Shock", dot = true, group = "shock" },
                { "Earth Shock", group = "shock" },
            },
            PVP = {
                { "Lightning Shield", buff = true, group = "shield" },
                { "Frost Shock", debuff = true, group = "shock" },
                { "Stormstrike", melee = true },
                { "Earth Shock", group = "shock" },
                { "Flame Shock", dot = true, group = "shock" },
            },
        },
        { -- Restoration (healer: damage spells only)
            PVE = {
                { "Water Shield", buff = true, group = "shield" },
                { "Lightning Shield", buff = true, group = "shield", ifnot = "Water Shield" },
                { "Flame Shock", dot = true, group = "shock" },
                { "Earth Shock", group = "shock" },
                { "Lightning Bolt" },
            },
            PVP = {
                { "Water Shield", buff = true, group = "shield" },
                { "Frost Shock", debuff = true, group = "shock" },
                { "Earth Shock", group = "shock" },
                { "Flame Shock", dot = true, group = "shock" },
                { "Lightning Bolt" },
            },
        },
    },

    MAGE = {
        { -- Arcane
            PVE = {
                { "Arcane Power" },
                { "Presence of Mind" },
                { "Arcane Blast" },
                { "Arcane Missiles" },
                { "Frostbolt", ifnot = "Arcane Missiles" },
            },
            PVP = {
                { "Frost Nova", close = true },
                { "Presence of Mind" },
                { "Fire Blast" },
                { "Arcane Blast" },
                { "Arcane Missiles" },
                { "Frostbolt" },
            },
        },
        { -- Fire
            PVE = {
                { "Pyroblast", opener = true },
                { "Combustion" },
                { "Scorch", debuff = true },
                { "Fire Blast" },
                { "Fireball" },
            },
            PVP = {
                { "Frost Nova", close = true },
                { "Blast Wave", close = true },
                { "Fire Blast" },
                { "Pyroblast", proc = true },
                { "Scorch" },
                { "Fireball" },
            },
        },
        { -- Frost
            PVE = {
                { "Ice Lance", proc = true },
                { "Frostbolt" },
            },
            PVP = {
                { "Frost Nova", close = true },
                { "Cone of Cold", close = true },
                { "Ice Lance", proc = true },
                { "Fire Blast" },
                { "Frostbolt" },
            },
        },
    },

    WARLOCK = {
        { -- Affliction
            PVE = {
                { "Bane of Agony", dot = true, group = "bane" },
                { "Corruption", dot = true },
                { "Siphon Life", dot = true },
                { "Wrack" },
                { "Shadow Bolt", proc = true },
                { "Shadow Bolt" },
            },
            PVP = {
                { "Death Coil" },
                { "Howl of Terror", close = true },
                { "Corruption", dot = true },
                { "Curse of Exhaustion", debuff = true, group = "curse" },
                { "Bane of Agony", dot = true, group = "bane" },
                { "Siphon Life", dot = true },
                { "Shadow Bolt", proc = true },
                { "Drain Life" },
            },
        },
        { -- Demonology
            PVE = {
                { "Corruption", dot = true },
                { "Bane of Agony", dot = true, group = "bane" },
                { "Immolate", dot = true },
                { "Shadow Bolt", proc = true },
                { "Soul Fire", proc = true },
                { "Shadow Bolt" },
            },
            PVP = {
                { "Death Coil" },
                { "Howl of Terror", close = true },
                { "Corruption", dot = true },
                { "Bane of Agony", dot = true, group = "bane" },
                { "Curse of Exhaustion", debuff = true, group = "curse" },
                { "Immolate", dot = true },
                { "Shadow Bolt", proc = true },
                { "Shadow Bolt" },
            },
        },
        { -- Destruction
            PVE = {
                { "Immolate", dot = true },
                { "Conflagrate" },
                { "Bane of Agony", dot = true, group = "bane" },
                { "Soul Fire", proc = true },
                { "Shadowburn" },
                { "Incinerate" },
                { "Shadow Bolt", ifnot = "Incinerate" },
            },
            PVP = {
                { "Death Coil" },
                { "Howl of Terror", close = true },
                { "Immolate", dot = true },
                { "Conflagrate" },
                { "Shadowburn" },
                { "Corruption", dot = true },
                { "Soul Fire", proc = true },
                { "Searing Pain" },
            },
        },
    },

    DRUID = {
        { -- Balance
            PVE = {
                { "Moonkin Form", form = 31 },
                { "Faerie Fire", debuff = true },
                { "Insect Swarm", dot = true },
                { "Moonfire", dot = true },
                { "Starfire" },
                { "Wrath", ifnot = "Starfire" },
            },
            PVP = {
                { "Moonkin Form", form = 31 },
                { "Faerie Fire", debuff = true },
                { "Moonfire", dot = true },
                { "Insect Swarm", dot = true },
                { "Wrath" },
            },
        },
        { -- Feral Combat (cat)
            PVE = {
                { "Cat Form", form = 1 },
                { "Rip", dot = true, finisher = 5 },
                { "Ferocious Bite", finisher = 5 },
                { "Rake", dot = true, melee = true },
                { "Shred", melee = true, proc = true },
                { "Claw", melee = true },
            },
            PVP = {
                { "Cat Form", form = 1 },
                { "Pounce", reactive = true, builder = 1 },
                { "Ravage", reactive = true, builder = 1 },
                { "Rake", dot = true, melee = true },
                { "Ferocious Bite", finisher = 5 },
                { "Rip", dot = true, finisher = 4 },
                { "Claw", melee = true },
            },
        },
        { -- Restoration (healer: damage spells only)
            PVE = {
                { "Moonfire", dot = true },
                { "Insect Swarm", dot = true },
                { "Wrath" },
            },
            PVP = {
                { "Faerie Fire", debuff = true },
                { "Moonfire", dot = true },
                { "Insect Swarm", dot = true },
                { "Wrath" },
            },
        },
    },
}

-- Combo point builders that are not marked in the lists above.
ns.Builders = {
    ["Sinister Strike"] = 1, ["Backstab"] = 1, ["Hemorrhage"] = 1, ["Ghostly Strike"] = 1, ["Mutilate"] = 2,
    ["Gouge"] = 1, ["Riposte"] = 1, ["Cheap Shot"] = 2, ["Ambush"] = 2, ["Garrote"] = 1, ["Premeditation"] = 2,
    ["Claw"] = 1, ["Shred"] = 1, ["Rake"] = 1, ["Pounce"] = 1, ["Ravage"] = 1,
}
ns.Finishers = {
    ["Eviscerate"] = true, ["Slice and Dice"] = true, ["Rupture"] = true, ["Kidney Shot"] = true, ["Expose Armor"] = true,
    ["Ferocious Bite"] = true, ["Rip"] = true,
}
