Forever Addon Hub 1.0.0 - World of Warcraft: Forever (Interface 16001)
====================================================================

One button on the minimap for every addon in the WoW Forever Addons
collection (github.com/Deathbringer98/WoW-Forever-Addons).

INSTALL
Copy the ForeverAddonHub folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

USE
Click the gear button on the minimap: a ring of buttons fans out around the
minimap, one for each addon. Click one to open it; some also do something on
right-click (hover a button to see).

Addons you don't have yet are shown faded. Click one for its download link.
Addons that are installed but turned off say so in their tooltip.

Right-click the hub button for settings:
  Show addons I don't have   on or off
  Keep the ring open         keeps the ring up after you click an addon
  Hide hub button            type /hub to bring it back
Drag the hub button to move it around the minimap.

CREDITS AND LICENSE
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Released under the GNU GPL v3.
