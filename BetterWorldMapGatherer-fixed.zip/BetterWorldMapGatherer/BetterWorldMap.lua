-- BetterWorldMap / Gatherer for World of Warcraft: Forever (Interface 16001)
-- Reveals unexplored areas on the world map and marks flight points, ore veins, herbs and
-- skinnable beasts. Display only: it reads nothing from combat and moves no Blizzard frame.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\"
local PREFIX = "|cff9fe26bBetterWorldMap:|r "
local MAX_LEGEND_ROWS = 34

local db
local overlay, panel, toggleButton
local dotPool, dotsUsed = {}, 0
local pinPool, pinsUsed = {}, 0
local hookedPins = {}
local lastMapID, lastScale, dirty = nil, nil, true
local playerFaction = 3

local defaults = {
    reveal = true,
    flights = true,
    allFlights = false,
    ore = true,
    herb = true,
    beasts = true,
    nearLevel = false,
    panel = true,
    size = 1.0,
    hidden = {},
}

local ORE_COLORS = {
    ["Copper Vein"] = { 0.95, 0.55, 0.25 }, ["Tin Vein"] = { 0.75, 0.78, 0.8 }, ["Silver Vein"] = { 1, 1, 1 },
    ["Iron Deposit"] = { 0.5, 0.56, 0.68 }, ["Gold Vein"] = { 1, 0.86, 0.2 }, ["Mithril Deposit"] = { 0.55, 0.8, 1 },
    ["Truesilver Deposit"] = { 0.3, 1, 0.95 }, ["Dark Iron Deposit"] = { 0.8, 0.25, 0.2 },
    ["Small Thorium Vein"] = { 0.45, 0.9, 0.4 }, ["Rich Thorium Vein"] = { 0.15, 0.7, 0.2 },
}

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, v = pcall(fn, ...)
    if not ok or IsSecret(v) then return nil end
    return v
end

local function Num(v)
    if type(v) == "number" and not IsSecret(v) then return v end
    return nil
end

local function HSV(h, s, v)
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
    i = i % 6
    if i == 0 then return v, t, p elseif i == 1 then return q, v, p elseif i == 2 then return p, v, t
    elseif i == 3 then return p, q, v elseif i == 4 then return t, p, v end
    return v, p, q
end

-- One colour per node type: fixed metal colours for ore, a spread of hues for herbs.
local typeColor = {}
do
    local herbIndex = 0
    for i, info in ipairs(ns.NodeTypes) do
        if info[1] == "ore" then
            typeColor[i] = ORE_COLORS[info[2]] or { 1, 1, 1 }
        else
            herbIndex = herbIndex + 1
            local r, g, b = HSV((herbIndex * 0.381966) % 1, herbIndex % 2 == 0 and 0.55 or 0.85, herbIndex % 3 == 0 and 0.8 or 1)
            typeColor[i] = { r, g, b }
        end
    end
end

-- Skinning skill needed for a creature of this level (original game rules).
local function SkinningSkill(level)
    if level <= 10 then return 1 end
    if level <= 20 then return (level - 10) * 10 end
    return level * 5
end

---------------------------------------------------------------------------
-- Map reveal: draw the exploration overlays the client leaves out for unexplored areas
---------------------------------------------------------------------------

local function RevealPin(pin, fullUpdate)
    if not db or not db.reveal then return end
    local mapID = Num(Plain(WorldMapFrame.GetMapID, WorldMapFrame))
    if not mapID then return end
    local artID = Num(Plain(C_Map.GetMapArtID, mapID))
    local zone = artID and ns.Reveal[artID]
    if not zone then return end

    local explored = {}
    local textures = Plain(C_MapExplorationInfo.GetExploredMapTextures, mapID)
    if type(textures) == "table" then
        for _, info in ipairs(textures) do
            if type(info) == "table" then
                explored[tostring(info.textureWidth) .. ":" .. tostring(info.textureHeight) .. ":" .. tostring(info.offsetX) .. ":" .. tostring(info.offsetY)] = true
            end
        end
    end

    local layerIndex = Num(pin.layerIndex) or 1
    local layers = Plain(C_Map.GetMapArtLayers, mapID)
    local layer = type(layers) == "table" and layers[layerIndex] or nil
    local tileW, tileH = layer and Num(layer.tileWidth), layer and Num(layer.tileHeight)
    if not tileW or not tileH or tileW <= 0 or tileH <= 0 then return end
    if type(pin.overlayTexturePool) ~= "table" then return end

    for key, files in pairs(zone) do
        if not explored[key] then
            local width, height, offsetX, offsetY = strsplit(":", key)
            width, height, offsetX, offsetY = tonumber(width), tonumber(height), tonumber(offsetX), tonumber(offsetY)
            local ids = { strsplit(",", files) }
            local wide, tall = math.ceil(width / tileW), math.ceil(height / tileH)
            for j = 1, tall do
                local pixelH, fileH
                if j < tall then
                    pixelH, fileH = tileH, tileH
                else
                    pixelH = height % tileH
                    if pixelH == 0 then pixelH = tileH end
                    fileH = 16
                    while fileH < pixelH do fileH = fileH * 2 end
                end
                for k = 1, wide do
                    local pixelW, fileW
                    if k < wide then
                        pixelW, fileW = tileW, tileW
                    else
                        pixelW = width % tileW
                        if pixelW == 0 then pixelW = tileW end
                        fileW = 16
                        while fileW < pixelW do fileW = fileW * 2 end
                    end
                    local id = tonumber(ids[(j - 1) * wide + k])
                    if id then
                        local texture = pin.overlayTexturePool:Acquire()
                        texture:SetSize(pixelW, pixelH)
                        texture:SetTexCoord(0, pixelW / fileW, 0, pixelH / fileH)
                        texture:ClearAllPoints()
                        texture:SetPoint("TOPLEFT", offsetX + tileW * (k - 1), -(offsetY + tileH * (j - 1)))
                        texture:SetTexture(id, nil, nil, "TRILINEAR")
                        texture:SetDrawLayer("ARTWORK", -1)
                        texture:Show()
                        if fullUpdate and type(pin.textureLoadGroup) == "table" then
                            pin.textureLoadGroup:AddTexture(texture)
                        end
                    end
                end
            end
        end
    end
end

local function HookExploration(refresh)
    if type(WorldMapFrame.EnumeratePinsByTemplate) ~= "function" then return end
    local ok = pcall(function()
        for pin in WorldMapFrame:EnumeratePinsByTemplate("MapExplorationPinTemplate") do
            if not hookedPins[pin] then
                hookedPins[pin] = true
                hooksecurefunc(pin, "RefreshOverlays", function(self, fullUpdate)
                    local good, err = pcall(RevealPin, self, fullUpdate)
                    if not good and not ns.revealError then
                        ns.revealError = tostring(err)
                    end
                end)
                refresh = true
            end
            if refresh then pin:RefreshOverlays(true) end
        end
    end)
    return ok
end

---------------------------------------------------------------------------
-- Markers
---------------------------------------------------------------------------

local function AcquireDot()
    dotsUsed = dotsUsed + 1
    local tex = dotPool[dotsUsed]
    if not tex then
        tex = overlay:CreateTexture(nil, "ARTWORK")
        dotPool[dotsUsed] = tex
    end
    return tex
end

local function PinOnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    for i, line in ipairs(self.lines) do
        if i == 1 then
            GameTooltip:SetText(line, 1, 0.82, 0)
        else
            GameTooltip:AddLine(line, 1, 1, 1)
        end
    end
    GameTooltip:Show()
end

local function PinOnLeave()
    GameTooltip:Hide()
end

local function AcquirePin()
    pinsUsed = pinsUsed + 1
    local pin = pinPool[pinsUsed]
    if not pin then
        pin = CreateFrame("Frame", nil, overlay)
        pin.icon = pin:CreateTexture(nil, "OVERLAY")
        pin.icon:SetAllPoints()
        pin.label = pin:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        pin.label:SetPoint("TOP", pin, "BOTTOM", 0, 2)
        pin:EnableMouse(true)
        pin:SetScript("OnEnter", PinOnEnter)
        pin:SetScript("OnLeave", PinOnLeave)
        pinPool[pinsUsed] = pin
    end
    return pin
end

local function TypeVisible(index)
    local info = ns.NodeTypes[index]
    if not db[info[1]] then return false end
    return not db.hidden[info[2]]
end

local RefreshPanel

-- Redraws every marker for the map that is open.
local function Draw()
    dirty = false
    for i = 1, dotsUsed do dotPool[i]:Hide() end
    for i = 1, pinsUsed do pinPool[i]:Hide() end
    dotsUsed, pinsUsed = 0, 0
    if not overlay or not overlay:IsVisible() then return end

    local mapID = Num(Plain(WorldMapFrame.GetMapID, WorldMapFrame))
    local canvas = overlay:GetParent()
    local width, height = Num(canvas:GetWidth()), Num(canvas:GetHeight())
    local scale = Num(canvas:GetScale()) or 1
    if not mapID or not width or not height or width <= 0 or scale <= 0 then return end
    local inv = 1 / scale

    -- Ore and herb dots
    local nodes = ns.Nodes[mapID]
    if nodes then
        local size = 9 * db.size * inv
        for index, packed in pairs(nodes) do
            if TypeVisible(index) then
                local info, color = ns.NodeTypes[index], typeColor[index]
                local file = TEXTURES .. (info[1] == "ore" and "Diamond.tga" or "Dot.tga")
                for at = 1, #packed, 4 do
                    local x = tonumber(packed:sub(at, at + 1), 36) / 1000
                    local y = tonumber(packed:sub(at + 2, at + 3), 36) / 1000
                    local tex = AcquireDot()
                    tex:SetTexture(file)
                    tex:SetVertexColor(color[1], color[2], color[3], 1)
                    tex:SetSize(size, size)
                    tex:ClearAllPoints()
                    tex:SetPoint("CENTER", overlay, "TOPLEFT", x * width, -y * height)
                    tex:Show()
                end
            end
        end
    end

    local function Place(pin, x, y, size)
        pin:SetScale(inv)
        pin:SetSize(size, size)
        pin:ClearAllPoints()
        pin:SetPoint("CENTER", overlay, "TOPLEFT", x * width / inv, -y * height / inv)
        pin:Show()
    end

    -- Skinnable beasts
    local beasts = db.beasts and ns.Beasts[mapID] or nil
    if beasts then
        local level = db.nearLevel and Num(Plain(UnitLevel, "player")) or nil
        for _, b in ipairs(beasts) do
            if not level or (b[5] >= level - 6 and b[4] <= level + 3) then
                local pin = AcquirePin()
                pin.icon:SetTexture(TEXTURES .. "Paw.tga")
                pin.icon:SetVertexColor(1, 0.72, 0.4, 1)
                local range = b[4] == b[5] and tostring(b[4]) or (b[4] .. "-" .. b[5])
                pin.label:SetText(range)
                pin.label:Show()
                pin.lines = { b[3] .. (b[7] and " (elite)" or ""), "Level " .. range, "Skinning needed: " .. SkinningSkill(b[5]),
                    "About " .. b[6] .. " spawn here" }
                Place(pin, b[1], b[2], 16 * db.size)
            end
        end
    end

    -- Flight points
    local flights = db.flights and ns.Flights[mapID] or nil
    if flights then
        for _, f in ipairs(flights) do
            local mine = (f[4] == 3) or (f[4] == playerFaction) or playerFaction == 3
            if mine or db.allFlights then
                local pin = AcquirePin()
                pin.icon:SetTexture(TEXTURES .. "Flight.tga")
                if f[4] == 1 then pin.icon:SetVertexColor(0.35, 0.65, 1, 1)
                elseif f[4] == 2 then pin.icon:SetVertexColor(1, 0.3, 0.25, 1)
                else pin.icon:SetVertexColor(1, 0.9, 0.3, 1) end
                pin.label:Hide()
                pin.lines = { f[3], "Flight point (" .. (f[4] == 1 and "Alliance" or f[4] == 2 and "Horde" or "both factions") .. ")" }
                Place(pin, f[1], f[2], 20 * db.size)
            end
        end
    end

    if RefreshPanel then RefreshPanel(mapID) end
end

---------------------------------------------------------------------------
-- Side panel: master switches and a clickable legend for the zone's nodes
---------------------------------------------------------------------------

local function MakeButton(parent, width, height, text)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, height)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text or "")
    function b:Paint(hover)
        if self.selected then
            self.bg:SetColorTexture(0.28, 0.5, 0.18, 0.95)
        elseif hover then
            self.bg:SetColorTexture(0.26, 0.26, 0.32, 0.95)
        else
            self.bg:SetColorTexture(0.12, 0.12, 0.15, 0.92)
        end
    end
    b:SetScript("OnEnter", function(self) self:Paint(true) end)
    b:SetScript("OnLeave", function(self) self:Paint(false) end)
    b:Paint(false)
    return b
end

local SWITCHES = {
    { "reveal", "Reveal map" }, { "flights", "Flight points" }, { "allFlights", "Both factions" },
    { "ore", "Ore" }, { "herb", "Herbs" }, { "beasts", "Beasts" }, { "nearLevel", "Near my level" },
}

RefreshPanel = function(mapID)
    if not panel then return end
    panel:SetShown(db.panel)
    toggleButton.selected = db.panel
    toggleButton:Paint(false)
    if not db.panel then return end
    for _, b in ipairs(panel.switches) do
        b.selected = db[b.field] and true or false
        b:Paint(false)
    end
    local nodes = mapID and ns.Nodes[mapID] or nil
    local used = 0
    if nodes then
        for index, info in ipairs(ns.NodeTypes) do
            local packed = nodes[index]
            if packed and db[info[1]] and used < MAX_LEGEND_ROWS then
                used = used + 1
                local row = panel.rows[used]
                local color = typeColor[index]
                row.nodeName = info[2]
                row.swatch:SetTexture(TEXTURES .. (info[1] == "ore" and "Diamond.tga" or "Dot.tga"))
                local off = db.hidden[info[2]]
                row.swatch:SetVertexColor(color[1], color[2], color[3], off and 0.25 or 1)
                row.text:SetText(string.format("%s (%d)  |cff9d9d9dskill %d|r", info[2], #packed / 4, info[3]))
                row.text:SetTextColor(off and 0.45 or 1, off and 0.45 or 1, off and 0.45 or 1)
                row:Show()
            end
        end
    end
    for i = used + 1, MAX_LEGEND_ROWS do panel.rows[i]:Hide() end
    local beasts = mapID and ns.Beasts[mapID] or nil
    panel.note:SetText(used == 0 and not beasts and "No node or beast data for this map." or "Click a node name to hide or show it.")
    panel:SetHeight(46 + #SWITCHES * 20 + used * 14 + 22)
end

local function CreatePanel()
    local host = WorldMapFrame.ScrollContainer or WorldMapFrame
    toggleButton = MakeButton(WorldMapFrame, 86, 20, "BetterWorldMap")
    toggleButton:SetPoint("TOPLEFT", host, "TOPLEFT", 8, -8)
    toggleButton:SetFrameStrata("HIGH")
    toggleButton:SetScript("OnClick", function()
        db.panel = not db.panel
        RefreshPanel(lastMapID)
    end)

    panel = CreateFrame("Frame", "BetterWorldMapPanel", WorldMapFrame)
    panel:SetPoint("TOPLEFT", toggleButton, "BOTTOMLEFT", 0, -4)
    panel:SetWidth(214)
    panel:SetFrameStrata("HIGH")
    panel:EnableMouse(true)
    local bg = panel:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.03, 0.04, 0.05, 0.88)

    panel.switches = {}
    for i, info in ipairs(SWITCHES) do
        local b = MakeButton(panel, 198, 18, info[2])
        b:SetPoint("TOPLEFT", 8, -8 - (i - 1) * 20)
        b.field = info[1]
        b:SetScript("OnClick", function()
            db[info[1]] = not db[info[1]]
            if info[1] == "reveal" then HookExploration(true) end
            dirty = true
        end)
        panel.switches[i] = b
    end

    panel.rows = {}
    local top = -8 - #SWITCHES * 20 - 6
    for i = 1, MAX_LEGEND_ROWS do
        local row = CreateFrame("Button", nil, panel)
        row:SetSize(198, 14)
        row:SetPoint("TOPLEFT", 8, top - (i - 1) * 14)
        row.swatch = row:CreateTexture(nil, "ARTWORK")
        row.swatch:SetSize(11, 11)
        row.swatch:SetPoint("LEFT", 0, 0)
        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.text:SetPoint("LEFT", row.swatch, "RIGHT", 5, 0)
        row.text:SetPoint("RIGHT", 0, 0)
        row.text:SetJustifyH("LEFT")
        row.text:SetWordWrap(false)
        row:SetScript("OnClick", function(self)
            if self.nodeName then
                db.hidden[self.nodeName] = (not db.hidden[self.nodeName]) or nil
                dirty = true
            end
        end)
        panel.rows[i] = row
    end

    panel.note = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    panel.note:SetPoint("BOTTOMLEFT", 8, 8)
    panel.note:SetPoint("RIGHT", -8, 0)
    panel.note:SetJustifyH("LEFT")
    panel.note:SetWordWrap(false)
end

---------------------------------------------------------------------------
-- Setup
---------------------------------------------------------------------------

local function Setup()
    if overlay or type(WorldMapFrame) ~= "table" or type(WorldMapFrame.GetCanvas) ~= "function" then return overlay ~= nil end
    local canvas = WorldMapFrame:GetCanvas()
    if type(canvas) ~= "table" then return false end
    overlay = CreateFrame("Frame", "BetterWorldMapOverlay", canvas)
    overlay:SetAllPoints(canvas)
    overlay:SetFrameLevel((Num(canvas:GetFrameLevel()) or 1) + 500)
    overlay:EnableMouse(false)
    CreatePanel()

    -- The map has no single event for "the view changed", so the open map is polled a few times a second.
    local wait = 0
    overlay:SetScript("OnUpdate", function(_, elapsed)
        wait = wait + elapsed
        if wait < 0.15 then return end
        wait = 0
        local mapID = Num(Plain(WorldMapFrame.GetMapID, WorldMapFrame))
        local scale = Num(canvas:GetScale())
        if dirty or mapID ~= lastMapID or scale ~= lastScale then
            lastMapID, lastScale = mapID, scale
            HookExploration(false)
            Draw()
        end
    end)
    overlay:SetScript("OnShow", function() dirty = true end)
    WorldMapFrame:HookScript("OnShow", function()
        dirty = true
        HookExploration(false)
    end)
    HookExploration(true)
    return true
end

local function ShowHelp()
    Say("Open the world map and use the BetterWorldMap button in its top left corner.")
    Say("/bwm reveal, flights, ore, herbs, beasts turns that layer on or off.")
    Say("/bwm both shows flight points of both factions. /bwm level shows only beasts near your level.")
    Say("/bwm size 1.0 sets the marker size (0.5 to 2). /bwm showall brings back every hidden node type.")
    Say("/bwm status shows the settings.")
end

SLASH_BETTERWORLDMAP1 = "/bwm"
SLASH_BETTERWORLDMAP2 = "/betterworldmap"
SlashCmdList.BETTERWORLDMAP = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command, arg = string.match(string.lower(message or ""), "^%s*(%S*)%s*(%S*)")
    local field = ({ reveal = "reveal", flights = "flights", ore = "ore", herbs = "herb", herb = "herb", beasts = "beasts",
        both = "allFlights", level = "nearLevel", panel = "panel" })[command]
    if field then
        db[field] = not db[field]
        Say(command .. ": " .. (db[field] and "on" or "off") .. ".")
        if field == "reveal" and overlay then HookExploration(true) end
    elseif command == "size" then
        local n = tonumber(arg)
        if not n then Say("Example: /bwm size 1.2") return end
        db.size = math.max(0.5, math.min(2, n))
    elseif command == "showall" then
        db.hidden = {}
        Say("every node type is shown again.")
    elseif command == "status" then
        Say(string.format("reveal %s | flights %s (both factions %s) | ore %s | herbs %s | beasts %s (near my level %s) | size %.1f",
            db.reveal and "on" or "off", db.flights and "on" or "off", db.allFlights and "on" or "off", db.ore and "on" or "off",
            db.herb and "on" or "off", db.beasts and "on" or "off", db.nearLevel and "on" or "off", db.size))
        Say("map hooked: " .. (next(hookedPins) and "yes" or "not yet (open the world map once)") .. (ns.revealError and (". Reveal error: " .. ns.revealError) or "."))
        return
    else
        ShowHelp()
        return
    end
    dirty = true
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("ADDON_LOADED")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        BetterWorldMapDB = type(BetterWorldMapDB) == "table" and BetterWorldMapDB or {}
        db = BetterWorldMapDB
        for key, value in pairs(defaults) do
            if type(db[key]) ~= type(value) then
                if type(value) == "table" then db[key] = {} else db[key] = value end
            end
        end
        db.size = math.max(0.5, math.min(2, db.size))
        local ok, faction = pcall(UnitFactionGroup, "player")
        if ok and faction == "Alliance" then playerFaction = 1 elseif ok and faction == "Horde" then playerFaction = 2 end
    end
    -- The world map can load after login, so setup is tried again whenever an addon loads.
    if db then Setup() end
end)
