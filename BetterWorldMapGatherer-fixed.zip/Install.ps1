# Run locally after extracting this package. Backups are kept beside the addon.
$ErrorActionPreference = 'Stop'
$source = Join-Path $PSScriptRoot 'BetterWorldMapGatherer'
$targets = @(
    'C:\Projects\WoW-Forever-Addons\BetterWorldMapGatherer',
    'C:\Program Files (x86)\World of Warcraft\_forever_\Interface\AddOns\BetterWorldMapGatherer'
)
if (Get-Process -Name 'Wow*' -ErrorAction SilentlyContinue) {
    throw 'Close World of Warcraft before installing.'
}
foreach ($file in @('BetterWorldMap.lua', 'Data.lua', 'BetterWorldMapGatherer.toc', 'README.txt', 'Textures\Diamond.tga', 'Textures\Dot.tga', 'Textures\Paw.tga', 'Textures\Flight.tga')) {
    if (-not (Test-Path -LiteralPath (Join-Path $source $file) -PathType Leaf)) { throw "Missing package file: $file" }
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
foreach ($target in $targets) {
    if (-not (Test-Path -LiteralPath $target -PathType Container)) { throw "Expected addon folder not found: $target" }
    $backup = "$target.backup-$stamp"
    Copy-Item -LiteralPath $target -Destination $backup -Recurse -ErrorAction Stop
    foreach ($item in Get-ChildItem -LiteralPath $source) {
        Copy-Item -LiteralPath $item.FullName -Destination $target -Recurse -Force -ErrorAction Stop
    }
    foreach ($file in Get-ChildItem -LiteralPath $source -Recurse -File) {
        $relative = $file.FullName.Substring($source.Length + 1)
        if ((Get-FileHash -LiteralPath $file.FullName).Hash -ne (Get-FileHash -LiteralPath (Join-Path $target $relative)).Hash) {
            throw "Installed file verification failed: $relative"
        }
    }
    Write-Host "Installed and verified: $target"
    Write-Host "Backup: $backup"
}
$toolsTarget = 'C:\Projects\WoW-Forever-Addons\BetterWorldMapGatherer-tools'
foreach ($name in @('test.js', 'test.lua')) {
    $existing = Join-Path $toolsTarget $name
    if (Test-Path -LiteralPath $existing) { Copy-Item -LiteralPath $existing -Destination "$existing.backup-$stamp" }
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot "BetterWorldMapGatherer-tools\$name") -Destination $existing -Force
}
Write-Host 'Start WoW Forever, enable BetterWorldMap / Gatherer, open the map, and run /bwm status.'
