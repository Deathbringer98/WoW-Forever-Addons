BetterWorldMap / Gatherer 1.0.1 - World of Warcraft: Forever (Interface 16001)
==============================================================================

Opens up your world map:
- Reveals unexplored areas on the 84 map artworks included in the data.
- Marks flight points, even ones you have not discovered.
- Marks ore veins and herbs.
- Marks groups of skinnable beasts with their level range and the
  skinning skill they need.

INSTALL
Copy the BetterWorldMapGatherer folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

VALIDATION
Version 1.0.1 keeps node, beast and flight markers above the exploration
artwork as MapCanvas changes its frame levels. A regression mock checks
high exploration-pin levels, later level/strata changes, and unchanged
node counts when reveal is toggled. In-game confirmation is still needed.
The renamed addon now resolves marker textures from its actual addon folder.
The Elwynn mock uses Forever's UiMapID 1429 and UiMapArtID 2153 and draws
18 unexplored tiles. Lua 5.1 syntax checks and mocked reveal, layer,
legend, zoom and tooltip checks pass. This is not an in-game validation.
After installing, open Elwynn on the world map and check /bwm status.
Confirm the markers appear and that /bwm reveal switches unexplored
artwork on and off. Original-game spawn positions may differ in Forever.

HOW TO USE
Open the world map (M). A "BetterWorldMap" button sits in the top left
corner of the map. Click it to open or close the panel.

The panel has a switch for each layer:
  Reveal map       show unexplored areas
  Flight points    show flight masters (blue Alliance, red Horde,
                   yellow both)
  Both factions    also show the other faction's flight points
  Ore              diamonds, coloured by metal
  Herbs            round dots, one colour per herb
  Beasts           paw prints with a level range under them
  Near my level    only beasts around your own level

Under the switches is a legend of the ore and herbs in the zone you are
looking at, with how many spots are known and the skill needed.
Click a name in the legend to hide or show just that node type.
Hover a paw print or flight point for details.

Nodes and beasts show on zone maps. Flight points also show on the
continent maps.

CHAT COMMANDS
/bwm reveal | flights | ore | herbs | beasts      turn a layer on or off
/bwm    both         flight points of both factions
/bwm    level        only beasts near your level
/bwm    size 1.2     marker size (0.5 to 2)
/bwm    showall      show every hidden node type again
/bwm    status       show the settings
/betterworldmap also works.

WHERE THE DATA COMES FROM, AND ITS LIMITS
- Map overlays and flight points come from the WoW Forever game client's
  own data tables (read through wago.tools), so they match Forever.
- Ore, herb and beast positions come from the CMaNGOS classic-db world
  database, which describes the ORIGINAL game. Forever is built on the
  original world, so most spots should match, but Blizzard may have moved,
  added or removed spawns, and skill requirements may differ. Zones that
  are new in Forever have no node or beast data.
- A node dot is a place where that node CAN spawn. It will not always be
  there.
- Skinning skill needed uses the original game's rule (5 per creature
  level above level 20).

LICENSE
The spawn data is derived from CMaNGOS classic-db, which is licensed
under the GNU General Public License v3.0. This addon is therefore
distributed under GPL-3.0 as well.
  https://github.com/cmangos/classic-db
  https://www.gnu.org/licenses/gpl-3.0.html

CREDITS
Addon: Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Spawn data: the CMaNGOS project and its contributors
Map data: Blizzard Entertainment game client data, read via wago.tools
Game names belong to Blizzard Entertainment.
