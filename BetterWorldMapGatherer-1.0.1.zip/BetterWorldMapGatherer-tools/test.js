// npm install fengari luaparse, or pass an existing node_modules directory as argv[2].
const fs = require('fs');
const path = require('path');
const modules = process.argv[2];
const dep = name => require(modules ? path.join(modules, name) : name);
const luaparse = dep('luaparse');
const { lua, lauxlib, lualib, to_luastring } = dep('fengari');
const addon = path.resolve(__dirname, '../BetterWorldMapGatherer');
for (const name of ['Data.lua', 'BetterWorldMap.lua', '../BetterWorldMapGatherer-tools/test.lua']) {
  luaparse.parse(fs.readFileSync(path.join(addon, name), 'utf8'), {luaVersion: '5.1'});
  console.log('Lua 5.1 syntax OK: ' + name);
}
const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);
if (lauxlib.luaL_loadfile(L, to_luastring(path.join(__dirname, 'test.lua'))) !== lua.LUA_OK) throw Error(lua.lua_tojsstring(L, -1));
lua.lua_pushstring(L, to_luastring(addon.replace(/\\/g, '/')));
if (lua.lua_pcall(L, 1, 0, 0) !== lua.LUA_OK) throw Error(lua.lua_tojsstring(L, -1));
for (const name of ['Diamond', 'Dot', 'Paw', 'Flight']) {
  const data = fs.readFileSync(path.join(addon, 'Textures', name + '.tga'));
  if (data[2] !== 2 || data[16] !== 32) throw Error('Unexpected TGA format: ' + name);
  console.log('Texture OK: ' + name);
}
