// Builds BetterWorldMapGatherer/Data.lua.
// Inputs (in the folder given as argv[2]):
//   UiMap.csv, UiMapAssignment.csv, UiMapXMapArt.csv, TaxiNodes.csv, WorldMapOverlay.csv, WorldMapOverlayTile.csv
//     from wago.tools for the WoW Forever build (Blizzard client data)
//   classicdb.sql  the CMaNGOS classic-db world database dump (GPL-3.0), for node and creature spawn positions
// Output: argv[3] (Data.lua)
const fs = require("fs");
const path = require("path");
const dir = process.argv[2], outFile = process.argv[3];

// ---------- CSV ----------
function csv(name) {
  const text = fs.readFileSync(path.join(dir, name + ".csv"), "utf8").replace(/^﻿/, "");
  const rows = [];
  let row = [], cell = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; }
      else cell += c;
    } else if (c === '"') q = true;
    else if (c === ",") { row.push(cell); cell = ""; }
    else if (c === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; }
    else if (c !== "\r") cell += c;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  const head = rows.shift();
  return rows.filter((r) => r.length === head.length).map((r) => Object.fromEntries(head.map((h, i) => [h, r[i]])));
}

// ---------- SQL dump ----------
// Yields the value tuples of every "INSERT INTO `table` VALUES (...),(...);" line as arrays of strings.
function* sqlRows(sql, table) {
  const marker = "INSERT INTO `" + table + "` VALUES ";
  let at = 0;
  while ((at = sql.indexOf(marker, at)) !== -1) {
    let i = at + marker.length;
    at = i;
    let row = null, cell = "", inStr = false;
    for (; i < sql.length; i++) {
      const c = sql[i];
      if (inStr) {
        if (c === "\\") { cell += sql[i + 1]; i++; }
        else if (c === "'") inStr = false;
        else cell += c;
      } else if (c === "'") inStr = true;
      else if (c === "(" && row === null) { row = []; cell = ""; }
      else if (c === "," && row !== null) { row.push(cell); cell = ""; }
      else if (c === ")" && row !== null) { row.push(cell); yield row; row = null; }
      else if (c === ";" && row === null) break;
      else if (row !== null) cell += c;
    }
  }
}

const q = (s) => '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
const b36 = (n) => { const s = Math.max(0, Math.min(1295, n)).toString(36); return s.length < 2 ? "0" + s : s; };

// ---------- Maps ----------
const uiMaps = csv("UiMap");
const mapName = Object.fromEntries(uiMaps.map((m) => [m.ID, m.Name_lang]));
const mapType = Object.fromEntries(uiMaps.map((m) => [m.ID, +m.Type]));
// One world rectangle per (uiMap, continent). Type 3 = zone, 2 = continent.
const areas = [];
for (const a of csv("UiMapAssignment")) {
  const type = mapType[a.UiMapID];
  if (type !== 3 && type !== 2) continue;
  if (+a.UiMin_0 !== 0 || +a.UiMin_1 !== 0 || +a.UiMax_0 !== 1 || +a.UiMax_1 !== 1) continue;
  const x0 = +a.Region_0, y0 = +a.Region_1, x1 = +a.Region_3, y1 = +a.Region_4;
  if (!(x1 > x0) || !(y1 > y0)) continue;
  areas.push({ ui: +a.UiMapID, map: +a.MapID, type, x0, y0, x1, y1 });
}
// Zone map rectangles overlap their neighbours, so a spawn in Burning Steppes also lands inside the
// Elwynn rectangle. The exploration overlays of a zone cover its own land, so their bounding boxes
// (in map pixels, 1002 x 668) are used as a mask: a point only counts for a zone if it is on that land.
const MAP_W = 1002, MAP_H = 668;
const artOfMap = {};
for (const x of csv("UiMapXMapArt")) if (+x.PhaseID === 0) artOfMap[x.UiMapID] = x.UiMapArtID;
const maskOfArt = {};
for (const o of csv("WorldMapOverlay")) {
  if (+o.TextureWidth <= 0 || +o.TextureHeight <= 0) continue;
  (maskOfArt[o.UiMapArtID] = maskOfArt[o.UiMapArtID] || []).push([+o.OffsetX, +o.OffsetY, +o.OffsetX + +o.TextureWidth, +o.OffsetY + +o.TextureHeight]);
}
function onLand(ui, u, v, margin) {
  const rects = maskOfArt[artOfMap[ui]];
  if (!rects) return false;
  const px = u * MAP_W, py = v * MAP_H;
  for (const r of rects) if (px >= r[0] - margin && px <= r[2] + margin && py >= r[1] - margin && py <= r[3] + margin) return true;
  return false;
}
// World position -> list of { ui, u, v } (0..1 map coordinates) for every map of that type showing it.
// margin (pixels) loosens the land mask; pass null for no mask.
function place(map, x, y, wantType, margin) {
  const out = [];
  for (const a of areas) {
    if (a.map !== map || a.type !== wantType) continue;
    if (x < a.x0 || x > a.x1 || y < a.y0 || y > a.y1) continue;
    const u = (a.y1 - y) / (a.y1 - a.y0), v = (a.x1 - x) / (a.x1 - a.x0);
    if (margin !== null && margin !== undefined && !onLand(a.ui, u, v, margin)) continue;
    out.push({ ui: a.ui, u, v });
  }
  return out;
}

// ---------- Reveal data ----------
const tilesByOverlay = {};
for (const t of csv("WorldMapOverlayTile")) {
  if (+t.LayerIndex !== 0) continue;
  (tilesByOverlay[t.WorldMapOverlayID] = tilesByOverlay[t.WorldMapOverlayID] || []).push(t);
}
const reveal = {};
let overlayCount = 0;
for (const o of csv("WorldMapOverlay")) {
  const tiles = tilesByOverlay[o.ID];
  if (!tiles || +o.TextureWidth <= 0 || +o.TextureHeight <= 0) continue;
  tiles.sort((a, b) => a.RowIndex - b.RowIndex || a.ColIndex - b.ColIndex);
  const key = [o.TextureWidth, o.TextureHeight, o.OffsetX, o.OffsetY].join(":");
  (reveal[o.UiMapArtID] = reveal[o.UiMapArtID] || {})[key] = tiles.map((t) => t.FileDataID).join(",");
  overlayCount++;
}

// ---------- Flight points ----------
const flights = {};
let flightCount = 0;
for (const n of csv("TaxiNodes")) {
  const faction = +n.Flags & 3; // 1 = Alliance, 2 = Horde, 3 = both
  if (!faction) continue;
  const map = +n.ContinentID;
  let used = false;
  for (const type of [3, 2]) {
    for (const p of place(map, +n.Pos_0, +n.Pos_1, type, type === 3 ? 30 : null)) {
      (flights[p.ui] = flights[p.ui] || []).push({ x: p.u, y: p.v, name: n.Name_lang, faction });
      used = true;
    }
  }
  if (used) flightCount++;
}

// ---------- Gathering nodes ----------
const NODE_TYPES = [
  // kind, name, skill needed (classic values)
  ["ore", "Copper Vein", 1], ["ore", "Tin Vein", 65], ["ore", "Silver Vein", 75], ["ore", "Iron Deposit", 125],
  ["ore", "Gold Vein", 155], ["ore", "Mithril Deposit", 175], ["ore", "Truesilver Deposit", 230], ["ore", "Dark Iron Deposit", 230],
  ["ore", "Small Thorium Vein", 245], ["ore", "Rich Thorium Vein", 275],
  ["herb", "Peacebloom", 1], ["herb", "Silverleaf", 1], ["herb", "Earthroot", 15], ["herb", "Mageroyal", 50],
  ["herb", "Briarthorn", 70], ["herb", "Stranglekelp", 85], ["herb", "Bruiseweed", 100], ["herb", "Wild Steelbloom", 115],
  ["herb", "Grave Moss", 120], ["herb", "Kingsblood", 125], ["herb", "Liferoot", 150], ["herb", "Fadeleaf", 160],
  ["herb", "Goldthorn", 170], ["herb", "Khadgar's Whisker", 185], ["herb", "Wintersbite", 195], ["herb", "Firebloom", 205],
  ["herb", "Purple Lotus", 210], ["herb", "Arthas' Tears", 220], ["herb", "Sungrass", 230], ["herb", "Blindweed", 235],
  ["herb", "Ghost Mushroom", 245], ["herb", "Gromsblood", 250], ["herb", "Golden Sansam", 260], ["herb", "Dreamfoil", 270],
  ["herb", "Mountain Silversage", 280], ["herb", "Plaguebloom", 285], ["herb", "Icecap", 290], ["herb", "Black Lotus", 300],
];
const typeByName = {};
NODE_TYPES.forEach((t, i) => { typeByName[t[1]] = i + 1; });
// Ooze covered veins count as their plain vein.
const alias = (name) => name.replace(/^Ooze Covered /, "").replace(/^Hakkari /, "Small ");

console.log("reading SQL dump...");
const sql = fs.readFileSync(path.join(dir, "classicdb.sql"), "utf8");

const goType = {};
for (const r of sqlRows(sql, "gameobject_template")) {
  if (r[1] !== "3") continue;
  const t = typeByName[alias(r[3])];
  if (t) goType[r[0]] = t;
}
const nodes = {}; // ui -> type -> Set of packed cells
let nodeSpawns = 0, nodePoints = 0;
for (const r of sqlRows(sql, "gameobject")) {
  const t = goType[r[1]];
  if (!t) continue;
  const map = +r[2];
  if (map !== 0 && map !== 1) continue;
  nodeSpawns++;
  for (const p of place(map, +r[4], +r[5], 3, 0)) {
    // snap to a 0.4% grid so pooled spawn points that sit on top of each other merge
    const gx = Math.round(p.u * 250) * 4, gy = Math.round(p.v * 250) * 4;
    const set = ((nodes[p.ui] = nodes[p.ui] || {})[t] = nodes[p.ui][t] || new Set());
    const key = b36(gx) + b36(gy);
    if (!set.has(key)) { set.add(key); nodePoints++; }
  }
}

// ---------- Skinnable creatures ----------
const beasts = {};
const tpl = {};
for (const r of sqlRows(sql, "creature_template")) {
  if (+r[58] <= 0) continue; // SkinningLootId
  tpl[r[0]] = { name: r[1], min: +r[3], max: +r[4], elite: +r[33] > 0 };
}
const spawnCells = {}; // ui|entry|cell -> { sx, sy, n }
for (const r of sqlRows(sql, "creature")) {
  const t = tpl[r[1]];
  if (!t) continue;
  const map = +r[2];
  if (map !== 0 && map !== 1) continue;
  for (const p of place(map, +r[4], +r[5], 3, 0)) {
    const cell = Math.floor(p.u * 12) + ":" + Math.floor(p.v * 12);
    const key = p.ui + "|" + r[1] + "|" + cell;
    const c = (spawnCells[key] = spawnCells[key] || { ui: p.ui, entry: r[1], sx: 0, sy: 0, n: 0 });
    c.sx += p.u; c.sy += p.v; c.n++;
  }
}
let beastPins = 0;
for (const c of Object.values(spawnCells)) {
  if (c.n < 3) continue;
  const t = tpl[c.entry];
  (beasts[c.ui] = beasts[c.ui] || []).push({ x: c.sx / c.n, y: c.sy / c.n, name: t.name, min: t.min, max: t.max, n: c.n, elite: t.elite });
  beastPins++;
}
// Keep the densest groups per zone so the map stays readable.
for (const ui of Object.keys(beasts)) {
  beasts[ui].sort((a, b) => b.n - a.n);
  beasts[ui] = beasts[ui].slice(0, 60);
}

// ---------- Write Lua ----------
const f3 = (n) => (Math.round(n * 1000) / 1000).toString();
let lua = "-- BetterWorldMap / Gatherer data. Generated file, do not edit by hand.\n";
lua += "-- Map overlays and flight points: Blizzard client data for WoW Forever, via wago.tools.\n";
lua += "-- Node and creature spawn positions: derived from the CMaNGOS classic-db world database\n";
lua += "-- (https://github.com/cmangos/classic-db), licensed GPL-3.0. They describe the original game\n";
lua += "-- and may not match WoW Forever everywhere.\n";
lua += "local _, ns = ...\n\n";

lua += "-- [uiMapArtID] = { [\"width:height:offsetX:offsetY\"] = \"fileDataID,fileDataID,...\" }\nns.Reveal = {\n";
for (const art of Object.keys(reveal).sort((a, b) => a - b)) {
  lua += "    [" + art + "] = {\n";
  for (const k of Object.keys(reveal[art])) lua += "        [" + q(k) + "] = " + q(reveal[art][k]) + ",\n";
  lua += "    },\n";
}
lua += "}\n\n";

lua += "-- [uiMapID] = { { x, y, name, faction } }, faction 1 = Alliance, 2 = Horde, 3 = both\nns.Flights = {\n";
for (const ui of Object.keys(flights).sort((a, b) => a - b)) {
  lua += "    [" + ui + "] = { -- " + mapName[ui] + "\n";
  for (const p of flights[ui]) lua += "        { " + f3(p.x) + ", " + f3(p.y) + ", " + q(p.name) + ", " + p.faction + " },\n";
  lua += "    },\n";
}
lua += "}\n\n";

lua += "-- { kind, name, skill needed }\nns.NodeTypes = {\n";
for (const t of NODE_TYPES) lua += "    { " + q(t[0]) + ", " + q(t[1]) + ", " + t[2] + " },\n";
lua += "}\n\n";
lua += "-- [uiMapID] = { [node type index] = packed positions }, four base-36 characters per node:\n";
lua += "-- two for x and two for y, each in thousandths of the map.\nns.Nodes = {\n";
for (const ui of Object.keys(nodes).sort((a, b) => a - b)) {
  lua += "    [" + ui + "] = { -- " + mapName[ui] + "\n";
  for (const t of Object.keys(nodes[ui]).sort((a, b) => a - b)) lua += "        [" + t + "] = " + q([...nodes[ui][t]].join("")) + ",\n";
  lua += "    },\n";
}
lua += "}\n\n";

lua += "-- [uiMapID] = { { x, y, name, min level, max level, spawn count, elite } }\nns.Beasts = {\n";
for (const ui of Object.keys(beasts).sort((a, b) => a - b)) {
  lua += "    [" + ui + "] = { -- " + mapName[ui] + "\n";
  for (const b of beasts[ui]) lua += "        { " + f3(b.x) + ", " + f3(b.y) + ", " + q(b.name) + ", " + b.min + ", " + b.max + ", " + b.n + (b.elite ? ", true" : "") + " },\n";
  lua += "    },\n";
}
lua += "}\n";
fs.writeFileSync(outFile, lua);

console.log("map rectangles: " + areas.length + " (zones " + areas.filter((a) => a.type === 3).length + ")");
console.log("reveal: " + Object.keys(reveal).length + " map arts, " + overlayCount + " overlays");
console.log("flight points placed: " + flightCount + " on " + Object.keys(flights).length + " maps");
console.log("node templates: " + Object.keys(goType).length + ", spawns " + nodeSpawns + ", map points " + nodePoints + " on " + Object.keys(nodes).length + " zones");
console.log("skinnable templates: " + Object.keys(tpl).length + ", beast pins " + beastPins + " (kept " + Object.values(beasts).reduce((s, l) => s + l.length, 0) + ")");
console.log("Data.lua bytes: " + lua.length);
const elw = nodes[1429] || {};
console.log("Elwynn nodes: " + Object.keys(elw).map((t) => NODE_TYPES[t - 1][1] + " " + elw[t].size).join(", "));
console.log("Elwynn flights: " + JSON.stringify(flights[1429]));
console.log("Elwynn beasts: " + (beasts[1429] || []).slice(0, 6).map((b) => `${b.name} ${b.min}-${b.max} x${b.n} @${f3(b.x)},${f3(b.y)}`).join("; "));
