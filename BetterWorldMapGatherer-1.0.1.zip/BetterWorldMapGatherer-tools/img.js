// Tiny image helpers: read/write 32-bit TGA, write PNG.
const fs = require("fs");
const zlib = require("zlib");

function readTGA(file) {
  const b = fs.readFileSync(file);
  const idLen = b[0], type = b[2], w = b.readUInt16LE(12), h = b.readUInt16LE(14), bpp = b[16], desc = b[17];
  if (type !== 2 || (bpp !== 32 && bpp !== 24)) throw new Error("unsupported TGA " + type + "/" + bpp);
  const bytes = bpp / 8, topLeft = (desc & 0x20) !== 0;
  const px = new Uint8Array(w * h * 4);
  let o = 18 + idLen;
  for (let row = 0; row < h; row++) {
    const y = topLeft ? row : h - 1 - row;
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      px[i + 2] = b[o]; px[i + 1] = b[o + 1]; px[i] = b[o + 2]; px[i + 3] = bytes === 4 ? b[o + 3] : 255;
      o += bytes;
    }
  }
  return { w, h, px, info: { idLen, type, bpp, desc, size: b.length, tail: b.slice(o).toString("latin1").replace(/[^\x20-\x7e]/g, ".") } };
}

// px is RGBA, top-left origin. Written as uncompressed 32-bit TGA with a top-left origin.
function writeTGA(file, w, h, px) {
  const head = Buffer.alloc(18);
  // Same layout as the textures the addon already ships: bottom-left origin, 8 alpha bits, TGA 2.0 footer.
  head[2] = 2; head.writeUInt16LE(w, 12); head.writeUInt16LE(h, 14); head[16] = 32; head[17] = 8;
  const body = Buffer.alloc(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const s = (y * w + x) * 4, o = ((h - 1 - y) * w + x) * 4;
      body[o] = px[s + 2]; body[o + 1] = px[s + 1]; body[o + 2] = px[s]; body[o + 3] = px[s + 3];
    }
  }
  const foot = Buffer.concat([Buffer.alloc(8), Buffer.from("TRUEVISION-XFILE.\0", "latin1")]);
  fs.writeFileSync(file, Buffer.concat([head, body, foot]));
}

function writePNG(file, w, h, px) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    Buffer.from(px.buffer, px.byteOffset + y * w * 4, w * 4).copy(raw, y * (w * 4 + 1) + 1);
  }
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type, "latin1"), data]);
    const crc = Buffer.alloc(4); crc.writeUInt32BE(zlib.crc32(td) >>> 0);
    return Buffer.concat([len, td, crc]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  fs.writeFileSync(file, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]));
}

module.exports = { readTGA, writeTGA, writePNG };
