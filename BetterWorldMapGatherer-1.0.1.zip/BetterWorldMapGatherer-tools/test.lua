-- WoW API mock for BetterWorldMap / Gatherer. Not an in-game test.
local ADDON_DIR = ...
local widgets = {}
local function NewWidget(kind, name)
    local w = { __kind = kind, shown = true, scripts = {}, children = {} }
    widgets[#widgets + 1] = w
    local DATA = { text = 1, events = 1, selected = 1, field = 1, nodeName = 1, lines = 1, icon = 1, label = 1, bg = 1,
        swatch = 1, switches = 1, rows = 1, note = 1, ScrollContainer = 1, layerIndex = 1, overlayTexturePool = 1, textureLoadGroup = 1 }
    return setmetatable(w, { __index = function(self, key)
        if DATA[key] then return nil end
        if key == "SetText" then return function(s, t) s.text = t end end
        if key == "Show" then return function(s) local was = s.shown s.shown = true if not was and s.scripts.OnShow then s.scripts.OnShow(s) end end end
        if key == "Hide" then return function(s) s.shown = false end end
        if key == "SetShown" then return function(s, v) s.shown = v and true or false end end
        if key == "IsShown" or key == "IsVisible" then return function(s) return s.shown end end
        if key == "SetScript" or key == "HookScript" then return function(s, n, f) s.scripts[n] = f end end
        if key == "RegisterEvent" then return function(s, n) s.events = s.events or {} s.events[n] = true end end
        if key == "CreateFontString" or key == "CreateTexture" then return function(s) local c = NewWidget(key == "CreateTexture" and "Texture" or "FontString") s.children[#s.children + 1] = c return c end end
        if key == "GetWidth" then return function() return 1002 end end
        if key == "GetHeight" then return function() return 668 end end
        if key == "GetScale" then return function(s) return s.scale or 1 end end
        if key == "GetFrameLevel" then return function(s) return rawget(s, "frameLevel") or 5 end end
        if key == "SetFrameLevel" then return function(s, v) s.frameLevel = v end end
        if key == "GetFrameStrata" then return function(s) return rawget(s, "frameStrata") or "MEDIUM" end end
        if key == "SetFrameStrata" then return function(s, v) s.frameStrata = v end end
        if key == "GetParent" then return function(s) return s.parent end end
        if key == "SetPoint" then return function(s, p, rel, rp, x, y)
            if type(x) == "number" then assert(x == x and y == y, "NaN position") s.x, s.y = x, y end end end
        if key == "SetSize" then return function(s, a, b) assert(type(a) == "number" and a > 0 and type(b) == "number", "bad size") s.w = a end end
        if key == "SetTexture" then return function(s, t)
            if type(t) == "string" then
                local prefix = "Interface\\AddOns\\BetterWorldMapGatherer\\Textures\\"
                assert(t:sub(1, #prefix) == prefix, "Wrong addon texture path: " .. t)
            end
            s.tex = t
        end end
        return function() end
    end })
end

UIParent = NewWidget("Frame")
SlashCmdList = {}
local chat = {}
print = function(...) chat[#chat + 1] = table.concat({ ... }, " ") end
function CreateFrame(kind, name, parent) local w = NewWidget(kind) w.parent = parent if name then _G[name] = w end return w end
function issecretvalue() return false end
function strsplit(sep, s)
    local out = {}
    for piece in (s .. sep):gmatch("(.-)" .. sep:gsub("%p", "%%%0")) do out[#out + 1] = piece end
    return unpack(out)
end
unpack = unpack or table.unpack
function UnitFactionGroup() return "Alliance", "Alliance" end
function UnitLevel() return 8 end
local hooks = {}
function hooksecurefunc(obj, name, fn)
    local orig = obj[name]
    obj[name] = function(...) orig(...) fn(...) end
    hooks[#hooks + 1] = name
end

-- World map with an exploration pin and a texture pool.
local canvas = NewWidget("Frame")
WorldMapFrame = NewWidget("Frame")
WorldMapFrame.mapID = 1429
function WorldMapFrame:GetMapID() return self.mapID end
function WorldMapFrame:GetCanvas() return canvas end
local acquired = 0
local pin = NewWidget("Frame")
pin.layerIndex = 1
-- MapCanvas manages pin levels independently of the canvas frame itself.
pin:SetFrameLevel(2500)
pin:SetFrameStrata("MEDIUM")
pin.overlayTexturePool = { Acquire = function() acquired = acquired + 1 return NewWidget("Texture") end }
pin.textureLoadGroup = { AddTexture = function() end }
function pin.RefreshOverlays(self, full) acquired = 0 end
function WorldMapFrame:EnumeratePinsByTemplate(t)
    assert(t == "MapExplorationPinTemplate")
    local done = false
    return function() if done then return nil end done = true return pin end
end
C_Map = {
    -- Forever UiMapXMapArt.csv: UiMapID 1429 -> UiMapArtID 2153.
    GetMapArtID = function(id) return ({ [1429] = 2153 })[id] end,
    GetMapArtLayers = function() return { { tileWidth = 256, tileHeight = 256 } } end,
}
local exploredTextures = {}
C_MapExplorationInfo = { GetExploredMapTextures = function() return exploredTextures end }

local ns = {}
for _, f in ipairs({ "Data.lua", "BetterWorldMap.lua" }) do assert(loadfile(ADDON_DIR .. "/" .. f))("BetterWorldMapGatherer", ns) end
io.write(string.format("data: reveal arts %d, flight maps %d, node zones %d, beast zones %d\n",
    (function(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end)(ns.Reveal), #(function() local l = {} for k in pairs(ns.Flights) do l[#l + 1] = k end return l end)(),
    (function(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end)(ns.Nodes), (function(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end)(ns.Beasts)))

local function Fire(event) for _, w in ipairs(widgets) do if w.events and w.events[event] and w.scripts.OnEvent then w.scripts.OnEvent(w, event) end end end
Fire("PLAYER_LOGIN")
assert(_G.BetterWorldMapOverlay, "overlay not created")
local overlay = _G.BetterWorldMapOverlay
local function Tick() overlay.scripts.OnUpdate(overlay, 0.2) end
local function Count()
    local dots, pins, paws, flights = 0, 0, 0, 0
    for _, w in ipairs(widgets) do
        if w.shown and w.parent == overlay and w.__kind == "Frame" and w.icon then
            pins = pins + 1
            if w.icon.tex and w.icon.tex:find("Paw") then paws = paws + 1 end
            if w.icon.tex and w.icon.tex:find("Flight") then flights = flights + 1 end
        end
    end
    for _, w in ipairs(overlay.children) do if w.shown and w.__kind == "Texture" then dots = dots + 1 end end
    return dots, pins, paws, flights
end
Tick()
assert(overlay:GetFrameStrata() == pin:GetFrameStrata() and overlay:GetFrameLevel() > pin:GetFrameLevel(), "map artwork can cover markers")
local countBeforeReveal = Count()
SlashCmdList.BETTERWORLDMAP("reveal") Tick()
assert(Count() == countBeforeReveal, "reveal toggle changed node count")
SlashCmdList.BETTERWORLDMAP("reveal") Tick()
assert(Count() == countBeforeReveal, "reveal toggle changed node count")
pin:SetFrameLevel(4000)
pin:RefreshOverlays(true)
Tick()
assert(overlay:GetFrameLevel() > pin:GetFrameLevel(), "pin refresh moved artwork over markers")
pin:SetFrameStrata("HIGH")
Tick()
assert(overlay:GetFrameStrata() == "HIGH", "marker strata did not follow map artwork")
for _, marker in ipairs(widgets) do
    if marker.parent == overlay and marker.__kind == "Frame" then
        assert(marker:GetFrameStrata() == overlay:GetFrameStrata() and marker:GetFrameLevel() > overlay:GetFrameLevel(), "interactive marker is below map artwork")
    end
end
pin:SetFrameStrata("MEDIUM")
Tick()
io.write("reveal hooked: " .. #hooks .. " hook(s), tiles drawn for Elwynn: " .. acquired .. "\n")
assert(#hooks == 1 and acquired > 0, "reveal did not draw tiles")
assert(acquired == 18, "Elwynn should draw 18 tiles from Forever data")
SlashCmdList.BETTERWORLDMAP("reveal")
assert(acquired == 0, "reveal off did not clear tiles")
SlashCmdList.BETTERWORLDMAP("reveal")
assert(acquired == 18, "reveal on did not restore tiles")
pin:RefreshOverlays(true)
assert(acquired == 18, "repeated refresh duplicated tiles")
for key in pairs(ns.Reveal[2153]) do
    local w, h, x, y = strsplit(":", key)
    exploredTextures[#exploredTextures + 1] = { textureWidth = tonumber(w), textureHeight = tonumber(h), offsetX = tonumber(x), offsetY = tonumber(y) }
end
pin:RefreshOverlays(true)
assert(acquired == 0, "already explored overlays were drawn twice")
exploredTextures = {}
pin:RefreshOverlays(true)
assert(acquired == 18 and not ns.revealError, "reveal failed after exploration changed")
io.write(string.format("Elwynn: dots %d, pins %d (paws %d, flight points %d)\n", Count()))
local legend = {}
for _, r in ipairs(_G.BetterWorldMapPanel.rows) do if r.shown then legend[#legend + 1] = r.text.text end end
io.write("legend rows " .. #legend .. ": " .. table.concat(legend, " | "):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):sub(1, 300) .. "\n")

-- toggles and filters
SlashCmdList.BETTERWORLDMAP("level") Tick()
io.write(string.format("near level 8: dots %d, pins %d (paws %d, flight points %d)\n", Count()))
SlashCmdList.BETTERWORLDMAP("herbs") Tick()
local d1 = Count()
assert(d1 == 153, "herb toggle did not leave expected ore dots")
_G.BetterWorldMapPanel.rows[1].scripts.OnClick(_G.BetterWorldMapPanel.rows[1]) Tick()
assert(Count() == 32, "legend did not hide copper dots")
io.write("ore only: " .. d1 .. " dots, after hiding '" .. tostring(_G.BetterWorldMapPanel.rows[1].nodeName) .. "': " .. Count() .. " dots\n")
SlashCmdList.BETTERWORLDMAP("showall") SlashCmdList.BETTERWORLDMAP("herbs") SlashCmdList.BETTERWORLDMAP("level")
-- zoom in: markers keep their on-screen size
canvas.scale = 3 Tick()
local anyPin
for _, w in ipairs(widgets) do if w.shown and w.parent == overlay and w.icon then anyPin = w break end end
io.write("zoomed x3: a dot is " .. string.format("%.2f", overlay.children[1].w) .. " canvas px, " .. Count() .. " dots\n")
canvas.scale = 1
-- continent view: only flight points
WorldMapFrame.mapID = 1415 Tick()
io.write(string.format("Eastern Kingdoms: dots %d, pins %d (paws %d, flight points %d)\n", Count()))
SlashCmdList.BETTERWORLDMAP("both") Tick()
io.write(string.format("  with both factions: flight points %d\n", select(4, Count())))
-- a map with no data
WorldMapFrame.mapID = 99999 Tick()
assert(Count() == 0, "old markers remain on an unsupported map")
io.write("unknown map note: " .. tostring(_G.BetterWorldMapPanel.note.text) .. "\n")
for _, c in ipairs({ "status", "size 1.5", "bogus", "reveal", "reveal" }) do SlashCmdList.BETTERWORLDMAP(c) end
for _, b in ipairs(_G.BetterWorldMapPanel.switches) do b.scripts.OnClick(b) Tick() b.scripts.OnClick(b) Tick() end
-- a paw tooltip
GameTooltip = NewWidget("GameTooltip")
WorldMapFrame.mapID = 1429 Tick()
for _, w in ipairs(widgets) do
    if w.shown and w.parent == overlay and w.lines and w.icon.tex:find("Paw") then
        io.write("paw tooltip: " .. table.concat(w.lines, " / ") .. "\n")
        w.scripts.OnEnter(w)
        break
    end
end
for i = 1, 3 do io.write("  chat: " .. tostring(chat[i]) .. "\n") end
io.write("OK\n")
