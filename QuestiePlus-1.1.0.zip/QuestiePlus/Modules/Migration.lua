---@class Migration
local Migration = QuestieLoader:CreateModule("Migration")
---@type Expansions
local Expansions = QuestieLoader:ImportModule("Expansions")

-- add functions to this table to migrate users who have not yet run said function.
-- make sure to always add to the end of the table as it runs first to last
local migrationFunctions = {
    [1] = function()
        -- this is the big Questie v9.0 settings refactor, implementing profiles
        if Questie.db.char then -- if you actually have previous settings, then on first startup we should notify you of this
            Questie:Print("[Migration] Migrated Questie for v9.0. This will reset all Questie settings to default. Journey history has been preserved.")
        end
        -- theres no need to delete old settings, since we read/write to different addresses now;
        -- old settings can linger unused unless you roll back versions, no harm no foul
    end,
    [2] = function()
        -- Blizzard removed some sounds from Era/SoD, which are present in TBC
        local objectiveSound = Questie.db.profile.objectiveCompleteSoundChoiceName
        if Expansions.Current < Expansions.Tbc and
            objectiveSound == "Explosion" or
            objectiveSound == "Shing!" or
            objectiveSound == "Wham!" or
            objectiveSound == "Simon Chime" or
            objectiveSound == "War Drums" or
            objectiveSound == "Humm" or
            objectiveSound == "Short Circuit"
        then
            Questie.db.profile.objectiveCompleteSoundChoiceName = "ObjectiveDefault"
        end

        local progressSound = Questie.db.profile.objectiveProgressSoundChoiceName
        if Expansions.Current < Expansions.Tbc and
            progressSound == "Explosion" or
            progressSound == "Shing!" or
            progressSound == "Wham!" or
            progressSound == "Simon Chime" or
            progressSound == "War Drums" or
            progressSound == "Humm" or
            progressSound == "Short Circuit"
        then
            Questie.db.profile.objectiveProgressSoundChoiceName = "ObjectiveProgress"
        end
    end,
    [3] = function()
        if Questie.IsSoD then
            if Questie.db.profile.showSoDRunes then
                Questie.db.profile.showRunesOfPhase = {
                    phase1 = true,
                    phase2 = false,
                    phase3 = false,
                    phase4 = false,
                }
            else
                Questie.db.profile.showRunesOfPhase = {
                    phase1 = false,
                    phase2 = false,
                    phase3 = false,
                    phase4 = false,
                }
            end
        end
    end,
    [4] = function()
        Questie.db.profile.tutorialShowRunesDone = false
    end,
    [5] = function()
        Questie.db.profile.enableTooltipsNextInChain = true
    end,
    [6] = function()
        Questie.db.profile.tutorialShowRunesDone = false
    end,
    [7] = function()
        Questie.db.profile.tutorialShowRunesDone = false
    end,
    [8] = function()
        if Questie.IsSoD then
            Questie.db.profile.showAQWarEffortQuests = true
        end
    end,
    [9] = function()
        Questie.db.profile.autoAccept = {
            enabled = Questie.db.profile.autoaccept,
            trivial = Questie.db.profile.acceptTrivial,
            repeatable = true,
        }
        Questie.db.profile.autoaccept = nil
        Questie.db.profile.acceptTrivial = nil
    end,
    [10] = function()
        -- The previous release had the default value set to "true", which was incorrect.
        Questie.db.profile.autoAccept.enabled = false
    end,
    [11] = function()
        Questie.db.profile.autoAccept.pvp = true
    end,
    [12] = function()
        Questie.db.profile.autoAccept.rejectSharedInBattleground = false
        Questie.db.profile.tutorialRejectInBattlegroundsDone = false
    end,
    [13] = function()
        Questie.db.profile.questAnnounceIncompleteBreadcrumb = true
    end,
    [14] = function()
        Questie.db.profile.hideTrackerInPetBattles = true
    end,
    [15] = function()
        Questie.db.profile.globalTownsfolkScale = 0.6
        Questie.db.profile.globalMiniMapTownsfolkScale = 0.7
    end,
    [16] = function()
        if (not Questie.db.global.isleOfQuelDanasPhase) then
            if Expansions.Current > Expansions.Tbc then
                Questie.db.global.isleOfQuelDanasPhase = 9 -- Max phase for everything that comes after TBC
            elseif Expansions.Current == Expansions.Tbc then
                Questie.db.global.isleOfQuelDanasPhase = 1
            end
        end
    end,
    [17] = function()
        Questie.db.global.unavailableQuestsDeterminedByTalking = {}
        ---@type table<string, number>
        Questie.db.global.lastKnownDailyReset = {}
    end,
    [18] = function()
        Questie.db.profile.trackerDisableHoverFade = false
    end,
    [19] = function()
        -- Only migrate if the user has a previous migration
        local previousVersion = Questie.db.profile.migrationVersion or 0
        if previousVersion == 0 then
            return
        end

        -- Preserve previous dungeon hide preference for new flag
        local previousHideInDungeons = Questie.db.profile.hideTrackerInDungeons

        Questie.db.profile.minimizeTrackerInCombat = false
        Questie.db.profile.minimizeTrackerInDungeons = previousHideInDungeons
        Questie.db.profile.hideTrackerInCombat = false
        Questie.db.profile.hideTrackerInDungeons = false
    end,
    [20] = function()
        Questie.db.profile.alwaysGlowMinimap = true
    end,
    [21] = function()
        if Questie.IsTBC then
            Questie.db.profile.showAQWarEffortQuests = false
        end
    end,
    [22] = function()
        local alpha = Questie.db.profile.trackerBackdropAlpha or 1
        Questie.db.profile.trackerBackdropColor = {r = 0, g = 0, b = 0, a = alpha}
        Questie.db.profile.trackerBackdropAlpha = nil
    end,
    [23] = function()
        Questie.db.profile.enableTooltipDroprates = true
    end,
    [24] = function()
        Questie.db.profile.trackerWidthRatio = 0.20
    end,
    [25] = function()
        local playerClass = UnitClassBase("player")
        if playerClass == "ROGUE" and Questie.db.profile.townsfolkConfig["Reagents"] then
            Questie.db.profile.townsfolkConfig["Reagents"] = false
            Questie.db.profile.townsfolkConfig["Poisons"] = true
        else
            Questie.db.profile.townsfolkConfig["Poisons"] = false
        end
    end,
    [26] = function()
        Questie.db.profile.clusterLevelHotzone = nil
        Questie.db.profile.objectiveFilterDistance = 2
    end,
    [27] = function()
        if Questie.db.profile.trackerFontOutline == "None" then
            Questie.db.profile.trackerFontOutline = ""
        end
    end,
    [28] = function()
        Questie.db.profile.trimObjectiveText = true
    end,
    [29] = function()
        Questie.db.profile.showQuestXpAtMaxLevel = false
    end,
    [30] = function()
        Questie.db.profile.autoAccept.abandonBreadcrumbFollowup = false
    end,
    [31] = function()
        Questie.db.profile.showPartyQuestObjectives = true
    end,
    [32] = function()
        Questie.db.profile.skipValidation = nil
    end,
    [33] = function()
        -- trackerFontOutline was previously stored as a localized string (e.g. "None", "无")
        -- because the dropdown used the localized WoW global NONE as a key.
        local outline = Questie.db.profile.trackerFontOutline
        if outline ~= "" and outline ~= "OUTLINE" then
            Questie.db.profile.trackerFontOutline = ""
        end
    end,
    [34] = function()
        Questie.db.profile.enableTooltipsBreadcrumbQuests = false
    end,
    [35] = function()
        Questie.db.global.lastDailyRequestDate = nil
        Questie.db.global.lastDailyRequestResetTime = nil
    end,
    [36] = function()
        Questie.db.global.unavailableDailyQuestsByNpc = {}
    end,
    [37] = function()
        -- Reserved for the former Titan compiler-storage invalidation migration.
    end,
    [38] = function()
        -- Preserve previous dungeon hide & minimize preference for both new flags
        local previousMinimizeInInstances = Questie.db.profile.minimizeTrackerInDungeons
        local previousHideInInstances = Questie.db.profile.hideTrackerInDungeons

        Questie.db.profile.minimizeTrackerInInstances = previousMinimizeInInstances
        Questie.db.profile.hideTrackerInInstances = previousHideInInstances

        Questie.db.profile.minimizeTrackerInDungeons = nil
        Questie.db.profile.hideTrackerInDungeons = nil
    end,
    [39] = function()
        -- Compiler payloads existed in the ordinary, SoD, and Titan global scopes.
        local compilerPayloadKeys = {
            "dbIsCompiled",
            "dbCompiledOnVersion",
            "dbCompiledLang",
            "dbCompiledExpansion",
            "dbCompiledCount",
            "npcBin",
            "npcPtrs",
            "questBin",
            "questPtrs",
            "objBin",
            "objPtrs",
            "itemBin",
            "itemPtrs",
        }
        local compilerScopes = {
            Questie.db.global,
            Questie.db.global.sod,
            Questie.db.global.titanReforged,
        }

        for _, scope in pairs(compilerScopes) do
            if scope then
                for _, key in ipairs(compilerPayloadKeys) do
                    scope[key] = nil
                end
            end
        end

        Questie.db.profile.disableDatabaseWarnings = nil
        Questie.db.char.townsfolkVersion = nil
    end,
    [40] = function()
        -- Townsfolk lookups moved from SavedVariables to the Townsfolk module; they are rebuilt every login.
        Questie.db.global.townsfolk = nil
        Questie.db.global.professionTrainers = nil
        Questie.db.global.classSpecificTownsfolk = nil
        Questie.db.global.factionSpecificTownsfolk = nil
        Questie.db.global.petFoodVendorTypes = nil
    end,
    [41] = function()
        -- Native wording and counter-free fallbacks no longer have a shortened/full display preference.
        Questie.db.profile.trimObjectiveText = nil
    end,
    [42] = function()
        Questie.db.profile.enableTooltipsSpellID = false
    end,
    [43] = function()
        -- NPC patrol path settings, under Map > Waypoints; the hover area under Advanced > Developer Options.
        local profile = Questie.db.profile
        profile.waypointMapEnabled = true
        profile.waypointMinimapEnabled = true
        profile.waypointWidth = 3
        profile.waypointOpacity = 1
        profile.waypointColor = {1, 0.72, 0, 0.5}
        profile.waypointHostileColor = {1, 0.2, 0, 0.7}
        profile.waypointHighlight = true
        profile.waypointHighlightColor = {0.93, 0.46, 0.13, 0.8}
        profile.waypointSmoothing = 0.75
        profile.waypointDebugHover = false
    end,
    [44] = function()
        Questie.db.profile.trackerShowQuestFocusButtons = true
    end,
    [45] = function()
        Questie.db.profile.trackerFadeQuestFocusButtons = false
    end,
    [46] = function()
        Questie.db.profile.trackerShowPlayButtons = true
    end,
    [47] = function()
        Questie.db.profile.trackerFollowSuperTracking = false
    end,
    [48] = function()
        -- New setting: show Questie in the addon compartment by default, mirroring DBM.
        Questie.db.profile.minimap = Questie.db.profile.minimap or {hide = false}
        Questie.db.profile.minimap.showInCompartment = true
    end,
    [49] = function()
        -- The Blizzard quest timer is always hidden now; timed quests are shown in the Questie tracker.
        Questie.db.profile.showBlizzardQuestTimer = nil
    end,
}

function Migration:Migrate()
    if not Questie.db.profile.migrationVersion then
        Questie.db.profile.migrationVersion = 0
    end

    local currentVersion = Questie.db.profile.migrationVersion
    local targetVersion = table.getn(migrationFunctions)

    if currentVersion == targetVersion then
        Questie.Debug(Questie.DEBUG_DEVELOP, "[Migration] Nothing to migrate. Already on latest version:", targetVersion)
        return
    end

    Questie.Debug(Questie.DEBUG_DEVELOP, "[Migration] Starting Questie migration for targetVersion", targetVersion)

    while currentVersion < targetVersion do
        currentVersion = currentVersion + 1
        migrationFunctions[currentVersion]()
    end

    Questie.db.profile.migrationVersion = currentVersion
end
