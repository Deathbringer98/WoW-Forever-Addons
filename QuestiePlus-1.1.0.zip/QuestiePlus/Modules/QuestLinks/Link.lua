---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")

---@class QuestieLink
local QuestieLink = QuestieLoader:CreateModule("QuestieLink")
-------------------------
--Import modules
-------------------------
---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type QuestLogCache
local QuestLogCache = QuestieLoader:ImportModule("QuestLogCache")
---@type ActiveQuests
local ActiveQuests = QuestieLoader:ImportModule("ActiveQuests")
---@type TrackerUtils
local TrackerUtils = QuestieLoader:ImportModule("TrackerUtils")
---@type QuestieEvent
local QuestieEvent = QuestieLoader:ImportModule("QuestieEvent")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")
---@type ZoneDB
local ZoneDB = QuestieLoader:ImportModule("ZoneDB")
---@type QuestieReputation
local QuestieReputation = QuestieLoader:ImportModule("QuestieReputation")
---@type HandleSetHyperlink
local HandleSetHyperlink = QuestieLoader:ImportModule("HandleSetHyperlink")

-- Forward declaration
local _AddQuestTitle, _AddQuestStatus, _AddQuestDescription, _AddQuestRequirements, _AddDungeonInfo, _GetQuestStarter, _GetQuestFinisher, _AddPlayerQuestProgress
local _AddTooltipLine, _AddColoredTooltipLine, _GetObjectiveText
local _InstallSetHyperlinkOverride, _InstallChatFrameHoverHooks, _InstallHyperlinkClickHook

function QuestieLink.Initialize()
    _InstallSetHyperlinkOverride()
    _InstallChatFrameHoverHooks()
    _InstallHyperlinkClickHook()
end

--- Returns a plain, chat-safe quest link string in Questie's own bracket format.
--- This is used for manual linking (shift-click in Tracker/Journey, etc.) where
--- we want a predictable representation that works in chat regardless of whether
--- the quest is in the player's quest log.
---@param questId QuestId
---@return string|nil @nil if the quest is not in the database
function QuestieLink.GetQuestLinkStringById(questId)
    local questName = QuestieDB.QueryQuestSingle(questId, "name")
    if (not questName) then
        return nil
    end
    local questLevel, _ = QuestieLib.GetEffectiveQuestLevel(questId)

    if Questie.db.profile.trackerShowQuestLevel then
        return "[[" .. tostring(questLevel) .. "] " .. questName .. " (" .. tostring(questId) .. ")]"
    else
        return "[" .. questName .. " (" .. tostring(questId) .. ")]"
    end
end

--- Prefers the native Blizzard quest link (works for any player, addon or not),
--- falling back to the Questie format when the API is unavailable or the quest
--- is not in the player's quest log (GetQuestLink only works for those).
---@param questId QuestId
---@return string|nil
function QuestieLink.GetNativeQuestLinkStringById(questId)
    if GetQuestLink then
        local link = QuestieCompat.GetQuestLink(questId)
        if link then
            return link
        end
    end

    return QuestieLink.GetQuestLinkStringById(questId)
end

---@param questId QuestId
---@param senderGUID string
---@return string|nil @nil if the quest is not in the database
function QuestieLink:GetQuestHyperLink(questId, senderGUID)
    if (not QuestieDB.QueryQuestSingle(questId, "name")) then
        return nil
    end

    local coloredQuestName = QuestieLib:GetColoredQuestName(questId, Questie.db.profile.trackerShowQuestLevel, true)
    local questLevel, _ = QuestieLib.GetEffectiveQuestLevel(questId)
    local isRepeatable = QuestieDB.IsRepeatable(questId)
    local isEventQuest = QuestieEvent.IsEventQuest(questId)
    local isPvPQuest = QuestieDB.IsPvPQuest(questId)

    if (not senderGUID) then
        senderGUID = UnitGUID("player")
    end

    local openBracket = QuestieLib:PrintDifficultyColor(questLevel, "[", isRepeatable, isEventQuest, isPvPQuest, questId)
    local closeBracket = QuestieLib:PrintDifficultyColor(questLevel, "]", isRepeatable, isEventQuest, isPvPQuest, questId)
    local questName = openBracket .. coloredQuestName .. closeBracket .. "|h"

    return "|Hquestie:" .. questId .. ":" .. senderGUID .. "|h" .. questName
end

---@param link string
---@param tooltip Frame
function QuestieLink:CreateQuestTooltip(link, tooltip)
    -- Fixes error when clicking quest links before full init
    if (not Questie.started) then
        print(Questie:Colorize(l10n("Please wait a moment for Questie to finish loading")))
        return
    end
    local isQuestieLink, _, _ = string.match(link, "questie:(%d+):.*")
    if isQuestieLink then
        ---@type string
        local questId = tonumber(isQuestieLink)
        local quest = QuestieDB.GetQuest(questId)

        if quest then
            _AddQuestTitle(tooltip, quest)
            _AddQuestStatus(tooltip, quest)

            _AddTooltipLine(tooltip, " ")

            _AddQuestDescription(tooltip, quest)
            _AddDungeonInfo(tooltip, quest)
            _AddQuestRequirements(tooltip, quest)
            local starterName, starterZoneName = _GetQuestStarter(quest)
            local finisherName, finisherZoneName = _GetQuestFinisher(quest)
            _AddPlayerQuestProgress(tooltip, quest, starterName, starterZoneName, finisherName, finisherZoneName)
        end
    end
end

---@param tooltip Frame
---@param text string
---@param wrapText boolean?
_AddTooltipLine = function(tooltip, text, wrapText)
    tooltip:AddLine(text, 1, 1, 1, wrapText)
end

---@param tooltip Frame
---@param text string
---@param color string
---@param wrapText boolean?
_AddColoredTooltipLine = function(tooltip, text, color, wrapText)
    text = Questie:Colorize(text, color)
    tooltip:AddLine(text, 1, 1, 1, wrapText)
end

---@param tooltip Frame
---@param quest Quest
_AddQuestTitle = function(tooltip, quest)
    local questId = quest.Id
    local questName = quest.name
    local questLevel = QuestieLib.GetEffectiveQuestLevel(questId)
    local isRepeatableQuest = QuestieDB.IsRepeatable(questId)
    local isEventQuest = QuestieEvent.IsEventQuest(questId)
    local isPvPQuest = QuestieDB.IsPvPQuest(questId)

    local questLevelString = QuestieLib:GetLevelString(questId, questLevel)
    local titleColor = string.sub(QuestieLib:PrintDifficultyColor(questLevel, "", isRepeatableQuest, isEventQuest, isPvPQuest, questId), 5, 10)

    if Questie.db.profile.trackerShowQuestLevel and Questie.db.profile.enableTooltipsQuestID then
        _AddColoredTooltipLine(tooltip, questLevelString .. questName .. " (" .. questId .. ")", titleColor)
    elseif Questie.db.profile.trackerShowQuestLevel and (not Questie.db.profile.enableTooltipsQuestID) then
        _AddColoredTooltipLine(tooltip, questLevelString .. questName, titleColor)
    elseif Questie.db.profile.enableTooltipsQuestID and (not Questie.db.profile.trackerShowQuestLevel) then
        _AddColoredTooltipLine(tooltip, questName .. " (" .. questId .. ")", titleColor)
    else
        _AddColoredTooltipLine(tooltip, questName, titleColor)
    end
end

---@param tooltip Frame
---@param quest Quest
_AddQuestStatus = function(tooltip, quest)
    local DoableStates = QuestieDB.DoableStates
    local eligibilityText, _, returnReason = QuestieDB.IsDoableVerbose(quest.Id, false, true, true)
    if ActiveQuests.Get(quest.Id) then
        local onQuestText = l10n("You are on this quest")
        local stateText
        local questIsComplete = QuestieDB.IsComplete(quest.Id)
        if questIsComplete == 1 then
            stateText = Questie:Colorize(l10n("Complete"), "green")
        elseif questIsComplete == -1 then
            stateText = Questie:Colorize(l10n("Failed"), "red")
        end

        if stateText then
            _AddTooltipLine(tooltip, onQuestText .. " (" .. stateText .. ")")
        else
            _AddColoredTooltipLine(tooltip, onQuestText, "green")
        end
    elseif Questie.db.char.complete[quest.Id] then
        _AddColoredTooltipLine(tooltip, l10n("You have completed this quest"), "green")
    elseif returnReason ~= DoableStates.AVAILABLE then
        _AddColoredTooltipLine(tooltip, eligibilityText, "red")
    elseif quest.specialFlags == 1 then
        _AddColoredTooltipLine(tooltip, l10n("This quest is repeatable"), "yellow")
    else
        _AddColoredTooltipLine(tooltip, l10n("You have not done this quest"), "yellow")
    end
end

---@param tooltip Frame
---@param quest Quest
_AddQuestDescription = function(tooltip, quest)
    local description = quest.Description
    if description and description[1] then
        _AddColoredTooltipLine(tooltip, description[1], "white", true)
        if #description >= 2 then
            for i = 2, #description do
                --_AddTooltipLine(" ") -- this is just adding extra lines between text definitions in DB files
                _AddColoredTooltipLine(tooltip, description[i], "white", true)
            end
        end
    else
        _AddColoredTooltipLine(tooltip, l10n("This quest is an automatic completion quest and does not contain an objective."), "white", true)
    end
end

---@param tooltip Frame
---@param quest Quest
_AddDungeonInfo = function(tooltip, quest)
    local zoneOrSort = quest.zoneOrSort
    if zoneOrSort and zoneOrSort > 0 then
        local localizedDungeonName = ZoneDB:GetLocalizedDungeonName(zoneOrSort)
        if localizedDungeonName then
            _AddTooltipLine(tooltip, " ")
            _AddColoredTooltipLine(tooltip, l10n("Instance") .. l10n(": ") .. localizedDungeonName, "gray")
        end
    end
end

---@param objectiveId number
---@param objectiveType "event"|"item"|"killcredit"|"monster"|"object"|"reputation"|"spell"
---@return string
_GetObjectiveText = function(objectiveId, objectiveType)
    if objectiveType == "monster" then
        return QuestieDB.QueryNPCSingle(objectiveId, "name")
    elseif objectiveType == "object" then
        return QuestieDB.QueryObjectSingle(objectiveId, "name")
    elseif objectiveType == "item" then
        return QuestieDB.QueryItemSingle(objectiveId, "name")
    elseif objectiveType == "reputation" then
        return QuestieReputation.GetFactionName(objectiveId)
    elseif objectiveType == "spell" then
        return C_Spell.GetSpellName(objectiveId)
    end
    return ""
end

---@param tooltip Frame
---@param quest Quest
_AddQuestRequirements = function(tooltip, quest)
    local questId = quest.Id
    if ActiveQuests.Get(questId) or Questie.db.char.complete[questId] then
        return
    end

    local blizzardObjectives = HaveQuestData(questId) and C_QuestLog.GetQuestObjectives(questId)
    if blizzardObjectives then
        if #quest.ObjectiveData > 0 then
            _AddTooltipLine(tooltip, " ")
            _AddColoredTooltipLine(tooltip, l10n("Objectives"), "gold")
        end
        for i = 1, #blizzardObjectives do
            local objective = blizzardObjectives[i]
            if objective and objective.text ~= "" then
                local text
                if QuestieLib.IsObjectiveDataLoaded(objective) then
                    text = objective.text
                else
                    -- Native wording is still loading. Use database text, never repair the client's sentence.
                    local metadata = quest.ObjectiveData[i]
                    text = metadata and (metadata.Text or _GetObjectiveText(metadata.Id, metadata.Type))
                end
                if text and text ~= "" then
                    _AddColoredTooltipLine(tooltip, " - " .. text, "white")
                end
            end
        end
        return
    end

    -- Fallback: use Questie's static database objective data
    if #quest.ObjectiveData > 0 then
        for i = 1, #quest.ObjectiveData do
            local currentObjective = quest.ObjectiveData[i]
            if currentObjective then
                if currentObjective.Text then
                    if currentObjective == quest.ObjectiveData[1] then
                        _AddTooltipLine(tooltip, " ")
                        _AddColoredTooltipLine(tooltip, l10n("Objectives"), "gold")
                    end
                    _AddColoredTooltipLine(tooltip, " - " .. currentObjective.Text, "white")
                else
                    local objectiveText = _GetObjectiveText(currentObjective.Id, currentObjective.Type)

                    if currentObjective == quest.ObjectiveData[1] then
                        _AddTooltipLine(tooltip, " ")
                        _AddColoredTooltipLine(tooltip, l10n("Objectives"), "gold")
                    end
                    _AddColoredTooltipLine(tooltip, " - " .. objectiveText, "white")
                end
            end
        end
    end
end

---@param quest Quest
---@return string?, string?
_GetQuestStarter = function(quest)
    if quest.Starts then
        local starterName, starterZoneName
        if quest.Starts.NPC ~= nil then
            local npc = QuestieDB:GetNPC(quest.Starts.NPC[1])
            starterName = npc.name

            if npc.zoneID ~= 0 then
                starterZoneName = TrackerUtils:GetZoneNameByID(npc.zoneID)
            else
                starterZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
            end
        elseif quest.Starts.Item ~= nil then
            local item = QuestieDB:GetItem(quest.Starts.Item[1])
            starterName = item.name

            if item.Sources and item.Sources[1] and item.Sources[1].Type then
                local itemSource = item.Sources[1]
                local dropStart

                if itemSource.Type == "monster" then
                    dropStart = QuestieDB:GetNPC(itemSource.Id)
                elseif itemSource.Type == "object" then
                    dropStart = QuestieDB:GetObject(itemSource.Id)
                end

                if item.zoneID ~= 0 then
                    starterZoneName = TrackerUtils:GetZoneNameByID(dropStart.zoneID)
                else
                    starterZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
                end
            else
                starterZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
            end
        elseif quest and quest.Starts and quest.Starts.GameObject and quest.Starts.GameObject[1] then
            local object = QuestieDB:GetObject(quest.Starts.GameObject[1])
            starterName = object.name
            if object.zoneID ~= 0 then
                starterZoneName = TrackerUtils:GetZoneNameByID(object.zoneID)
            else
                starterZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
            end
        else
            starterZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
        end

        return starterName, l10n(starterZoneName)
    end

    return nil, nil
end

---@param quest Quest
---@return string?, string?
_GetQuestFinisher = function(quest)
    local finisherName, finisherZoneName
    if quest.Finisher.NPC then
        local npc = QuestieDB:GetNPC(quest.Finisher.NPC[1])
        finisherName = npc.name

        if npc.zoneID ~= 0 then
            finisherZoneName = TrackerUtils:GetZoneNameByID(npc.zoneID)
        else
            finisherZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
        end
    elseif quest.Finisher.GameObject then
        local object = QuestieDB:GetObject(quest.Finisher.GameObject[1])
        finisherName = object.name
        if object.zoneID ~= 0 then
            finisherZoneName = TrackerUtils:GetZoneNameByID(object.zoneID)
        else
            finisherZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
        end
    else
        finisherZoneName = TrackerUtils:GetZoneNameByID(quest.zoneOrSort)
    end

    return finisherName, l10n(finisherZoneName)
end

---@param tooltip Frame
---@param quest Quest
---@param starterName string?
---@param starterZoneName string?
---@param finisherName string?
---@param finisherZoneName string?
_AddPlayerQuestProgress = function(tooltip, quest, starterName, starterZoneName, finisherName, finisherZoneName)
    if ActiveQuests.Get(quest.Id) then
        -- On Quest: display quest progress
        if (QuestieDB.IsComplete(quest.Id) == 0) then
            _AddTooltipLine(tooltip, " ")
            _AddColoredTooltipLine(tooltip, l10n("Your progress") .. l10n(": "), "gold")
            local cached = QuestLogCache.TryGetQuest(quest.Id)
            for _, objective in pairs(quest.Objectives) do
                -- Use the same accepted native text as the tracker, including counter-free action instructions.
                local native = cached and not objective.IsSourceItem and not objective.IsRequiredSourceItem
                    and cached.objectives[objective.Index]
                if native then
                    _AddTooltipLine(tooltip, " - " .. QuestieLib:GetRGBForObjective(objective) .. native.text .. "|r")
                elseif objective.Needed and objective.Needed > 0 then
                    local lineEnding = tostring(objective.Collected) .. "/" .. tostring(objective.Needed)
                    _AddTooltipLine(tooltip, " - " .. QuestieLib:GetRGBForObjective(objective) .. (objective.Description or "")
                        .. l10n(": ") .. lineEnding .. "|r")
                end
            end
        else
            -- Completed Quest (not turned in): display quest ended by npc and zone
            if finisherName then
                _AddTooltipLine(tooltip, " ")
                _AddTooltipLine(tooltip, (l10n("Ended by") .. l10n(": ") .. Questie:Colorize(finisherName, "gray")))
            end
            if finisherZoneName then
                _AddTooltipLine(tooltip, " ")
                _AddTooltipLine(tooltip, (l10n("Found in") .. l10n(": ") .. Questie:Colorize(finisherZoneName, "gray")))
            end
        end
    else
        -- Completed Quest (turned in)
        if Questie.db.char.complete[quest.Id] == true then
            if Questie.db.char.journey then
                local timestamp
                for i = 1, #Questie.db.char.journey do
                    if Questie.db.char.journey[i].Quest ~= nil and Questie.db.char.journey[i].Quest == quest.Id then
                        timestamp = Questie:Colorize(QuestieLib.FormatDate(Questie.db.char.journey[i].Timestamp) .. " ", "lightBlue")
                    end
                end
                if timestamp then
                    _AddTooltipLine(tooltip, " ")
                    _AddTooltipLine(tooltip, l10n("Completed on") .. l10n(": "))
                    _AddTooltipLine(tooltip, timestamp)
                end
            end
        else
            -- Not on Quest: display quest started by npc and zone
            if starterName then
                _AddTooltipLine(tooltip, " ")
                _AddTooltipLine(tooltip, (l10n("Started by") .. l10n(": ") .. Questie:Colorize(starterName, "gray")))
            end
            if starterZoneName then
                _AddTooltipLine(tooltip, (l10n("Found in") .. l10n(": ") .. Questie:Colorize(starterZoneName, "gray")))
            end
        end
    end
end

_InstallSetHyperlinkOverride = function()
    -- Replacing ItemRefTooltip.SetHyperlink taints every link click on Forever, which breaks
    -- Blizzard's ItemRefSetHyperlink with secret values in instances. Use the link handler API there.
    if Questie.IsForever then
        LinkUtil.RegisterLinkHandler("questie", HandleSetHyperlink.ProcessLink)
        LinkUtil.RegisterLinkHandler("quest", HandleSetHyperlink.ProcessLink)
        return
    end

    local oldItemSetHyperlink = ItemRefTooltip.SetHyperlink

    --- Override of the default SetHyperlink function to filter Questie links
    ---@param link string
    function ItemRefTooltip:SetHyperlink(link, ...)
        HandleSetHyperlink.Run(self, oldItemSetHyperlink, link, ...)
    end
end

-- Show quest tooltip on hover.
local function ShowQuestieHoverTooltip(link)
    local questiePrefix = string.match(link or "", "^(questie):")
    if questiePrefix == "questie" then
        GameTooltip:ClearLines()
        QuestieLink:CreateQuestTooltip(link, GameTooltip)
        GameTooltip:Show()
        return true
    end
    return false
end

-- Chattynator hook: Chattynator replaces default chat frames entirely.
-- Its handler frame is ChattynatorHyperlinkHandler (a ScrollingMessageFrame
-- with hyperlinksEnabled="true" that receives propagated events from its chat frames).
local function HookChattynator()
    local chattynator = _G.Chattynator
    local handler = chattynator and chattynator.API and chattynator.API.GetHyperlinkHandler()
    if not handler then return false end

    handler:HookScript("OnHyperlinkEnter", function(_, hyperlink)
        local linkType = hyperlink:match("^(.-):")
        if linkType == "questie" then
            GameTooltip:SetOwner(handler:GetParent(), "ANCHOR_CURSOR")
            ShowQuestieHoverTooltip(hyperlink)
        end
    end)

    handler:HookScript("OnHyperlinkLeave", function()
        GameTooltip:Hide()
    end)

    return true
end

-- Default chat frame hook: HookScript on each ScrollingMessageFrame.
local function HookDefaultChatFrames()
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local chatFrame = _G["ChatFrame" .. i]
        if chatFrame then
            chatFrame:HookScript("OnHyperlinkEnter", function(self, link, ...)
                local linkType = string.match(link or "", "^(.-):")
                if linkType == "questie" then
                    self._questieHoverActive = true
                    GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
                    GameTooltip:ClearLines()
                    QuestieLink:CreateQuestTooltip(link, GameTooltip)
                    GameTooltip:Show()
                    return
                end
                self._questieHoverActive = false
            end)

            chatFrame:HookScript("OnHyperlinkLeave", function(self, ...)
                if self._questieHoverActive then
                    self._questieHoverActive = false
                    GameTooltip:Hide()
                end
            end)
        end
    end
end

-- Try Chattynator first (returns true if Chattynator is active),
-- otherwise hook the default chat frames, and handle Chattynator loading
-- after Questie via ADDON_LOADED.
_InstallChatFrameHoverHooks = function()
    local chattynatorHooked = HookChattynator()

    if (not chattynatorHooked) then
        HookDefaultChatFrames()

        local loaderFrame = CreateFrame("Frame")
        loaderFrame:RegisterEvent("ADDON_LOADED")
        loaderFrame:SetScript("OnEvent", function(_, _, addonName)
            if addonName == "Chattynator" then
                C_Timer.After(0, function()
                    if HookChattynator() then
                        loaderFrame:UnregisterAllEvents()
                    end
                end)
            end
        end)
    end
end

-- Compatibility: 2.5.5+ uses ChatFrameMixin:OnHyperlinkClick instead of ChatFrame_OnHyperlinkShow
local function HandleHyperlinkClick(link, button)
    -- If Questie hasn't started yet, do nothing to avoid accessing uninitialized DB
    if (not Questie.started) then
        return
    end

    if (IsShiftKeyDown() and ChatEdit_GetActiveWindow() and button == "LeftButton") then
        local linkType, questId, _ = string.split(":", link)
        if linkType and linkType == "questie" and questId then
            Questie.Debug(Questie.DEBUG_DEVELOP, "[QuestieTooltips:OnHyperlinkClick] Relinking Quest Link to chat:", link)
            questId = tonumber(questId)

            local questLink = QuestieLink.GetQuestLinkStringById(questId)
            local activeWindow = ChatEdit_GetActiveWindow()
            if questLink and activeWindow then
                local msg = activeWindow:GetText()
                if msg then
                    activeWindow:SetText("")
                    ChatEdit_InsertLink(questLink)
                end
            end
        end
    end
end

--- Installs the shift-click "insert quest link into chat" hook.
--- Uses the new ChatFrameMixin:OnHyperlinkClick API on 2.5.5+, falling back
--- to hooksecurefunc("ChatFrame_OnHyperlinkShow", ...) on older clients.
_InstallHyperlinkClickHook = function()
    if ChatFrameMixin and ChatFrameMixin.OnHyperlinkClick then
        local function HookChatFrameHyperlink(chatFrame)
            chatFrame:HookScript("OnHyperlinkClick", function(_, link, _, button)
                HandleHyperlinkClick(link, button)
            end)
        end

        for i = 1, (NUM_CHAT_WINDOWS or 10) do
            local chatFrame = _G["ChatFrame" .. i]
            if chatFrame then
                HookChatFrameHyperlink(chatFrame)
            end
        end
    else
        -- Fallback to old API (pre-2.5.5)
        hooksecurefunc("ChatFrame_OnHyperlinkShow", function(_, link, _, button)
            HandleHyperlinkClick(link, button)
        end)
    end
end
