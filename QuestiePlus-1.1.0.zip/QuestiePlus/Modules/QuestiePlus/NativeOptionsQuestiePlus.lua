-- QuestiePlus settings tab in Questie's options window.
---@type QuestieOptionsEngine
local QuestieOptionsEngine = QuestieLoader:ImportModule("QuestieOptionsEngine")
---@type QuestieTracker
local QuestieTracker = QuestieLoader:ImportModule("QuestieTracker")

QuestieOptionsEngine.tabs.questiePlus = { ... }

function QuestieOptionsEngine.tabs.questiePlus:Initialize()
    return {
        title = "QuestiePlus",
        subtitle = "An improved version of the original Questie",
        order = 0.5,
        icon = "Interface\\AddOns\\QuestiePlus\\Icons\\questie.png",
        items = {
            info_text = {
                type = "text",
                order = 0.1,
                title = "",
                description = "QuestiePlus adds a helper window with a suggested quest route (type /qp or middle-click the minimap button), quest chain tooltips, a quest complete banner and a set of fixes for WoW Forever.",
                width = "full",
            },
            openPanel = {
                type = "button",
                order = 0.2,
                title = "Open the QuestiePlus window",
                btnLabel = "Open QuestiePlus window",
                tooltip = "Level-up planner, quests ready to hand in, grey quest cleanup and zone progress.",
                width = "half",
                align = "CENTER",
                func = function()
                    QuestieOptionsEngine:HideFrame()
                    QuestieLoader:ImportModule("QuestiePlusPanel").Toggle()
                end,
            },
            features_group = {
                type = "container",
                order = 1,
                title = "Features",
                items = {
                    questiePlusChainOnHover = {
                        type = "checkbox",
                        order = 1.1,
                        title = "Quest chain on hover",
                        tooltip = "Hovering a quest in the quest log, on the map or in the tracker lists the quests that follow it, with their XP and money, and the total for the rest of the chain.",
                        width = "full",
                        get = function() return Questie.db.profile.questiePlusChainOnHover end,
                        set = function(_, value) Questie.db.profile.questiePlusChainOnHover = value end,
                    },
                    questiePlusCompleteBanner = {
                        type = "checkbox",
                        order = 1.2,
                        title = "Quest complete banner",
                        tooltip = "Shows a big banner in the middle of the screen when you finish the last objective of a quest.",
                        width = "full",
                        get = function() return Questie.db.profile.questiePlusCompleteBanner end,
                        set = function(_, value) Questie.db.profile.questiePlusCompleteBanner = value end,
                    },
                    hideTrackerInPvP = {
                        type = "checkbox",
                        order = 1.3,
                        title = "Hide the tracker in battlegrounds",
                        tooltip = "Hides the Questie Tracker in battlegrounds and arenas, but keeps it in dungeons and raids.",
                        width = "full",
                        enabled = function() return Questie.db.profile.trackerEnabled and not Questie.db.profile.hideTrackerInInstances end,
                        get = function() return Questie.db.profile.hideTrackerInPvP end,
                        set = function(_, value)
                            Questie.db.profile.hideTrackerInPvP = value
                            QuestieTracker.OnHideInInstancesChanged(value)
                        end,
                    },
                    questiePlusRouteOnMap = {
                        type = "checkbox",
                        order = 1.4,
                        title = "Draw the suggested route on the world map",
                        tooltip = "Draws the quickest order for your quests on the world map as a gold line with numbered stops. It is rebuilt from where you stand each time you open the map.",
                        width = "full",
                        get = function() return Questie.db.profile.questiePlusRouteOnMap end,
                        set = function(_, value)
                            Questie.db.profile.questiePlusRouteOnMap = value
                            QuestieLoader:ImportModule("QuestiePlusRoute").RedrawMap()
                        end,
                    },
                    questiePlusRoutePickups = {
                        type = "checkbox",
                        order = 1.5,
                        title = "Add nearby new quests to the route",
                        tooltip = "The suggested route also stops at up to 8 nearby quest givers with quests worth doing at your level.",
                        width = "full",
                        get = function() return Questie.db.profile.questiePlusRoutePickups end,
                        set = function(_, value) Questie.db.profile.questiePlusRoutePickups = value end,
                    },
                },
            },
            tips_text = {
                type = "text",
                order = 2,
                title = "",
                description = "Tips: shift+click a quest objective icon on the map to hide its icons (Show Icons in the tracker menu brings them back). Shift+click or ctrl+click a patrol path to act on its NPC, just like the NPC's icon.",
                width = "full",
            },
        },
    }
end
