-- QuestiePlus core: slash command, start-up, and the "quest done" banner.
---@class QuestiePlusCore
local QuestiePlusCore = QuestieLoader:CreateModule("QuestiePlusCore")

---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type QuestLogCache
local QuestLogCache = QuestieLoader:ImportModule("QuestLogCache")
---@type QuestiePlusPanel
local QuestiePlusPanel = QuestieLoader:ImportModule("QuestiePlusPanel")
---@type QuestiePlusChain
local QuestiePlusChain = QuestieLoader:ImportModule("QuestiePlusChain")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

QuestiePlusCore.VERSION = "1.1.0"

---------------------------------------------------------------------------
-- Quest done banner: a big message in the middle of the screen when the last objective of a quest is done.
---------------------------------------------------------------------------

local banner
local completeState -- questId -> true for quests already complete, nil until the first scan
local scanPending = false

local function _Banner()
    if banner then return banner end
    banner = CreateFrame("Frame", "QuestiePlusBanner", UIParent)
    banner:SetSize(600, 70)
    banner:SetPoint("TOP", 0, -170)
    banner:SetFrameStrata("HIGH")
    banner:EnableMouse(false)
    local fill = banner:CreateTexture(nil, "BORDER")
    fill:SetPoint("TOPLEFT", 60, -8)
    fill:SetPoint("BOTTOMRIGHT", -60, 8)
    fill:SetColorTexture(0.05, 0.05, 0.05, 0.75)
    local line1 = banner:CreateTexture(nil, "ARTWORK")
    line1:SetPoint("TOPLEFT", fill, "TOPLEFT")
    line1:SetPoint("TOPRIGHT", fill, "TOPRIGHT")
    line1:SetHeight(2)
    line1:SetColorTexture(1, 0.82, 0, 0.9)
    local line2 = banner:CreateTexture(nil, "ARTWORK")
    line2:SetPoint("BOTTOMLEFT", fill, "BOTTOMLEFT")
    line2:SetPoint("BOTTOMRIGHT", fill, "BOTTOMRIGHT")
    line2:SetHeight(2)
    line2:SetColorTexture(1, 0.82, 0, 0.9)
    banner.title = banner:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    banner.title:SetPoint("TOP", fill, "TOP", 0, -6)
    banner.text = banner:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    banner.text:SetPoint("TOP", banner.title, "BOTTOM", 0, -4)
    local anim = banner:CreateAnimationGroup()
    local fadeIn = anim:CreateAnimation("Alpha")
    fadeIn:SetFromAlpha(0)
    fadeIn:SetToAlpha(1)
    fadeIn:SetDuration(0.25)
    fadeIn:SetOrder(1)
    local hold = anim:CreateAnimation("Alpha")
    hold:SetFromAlpha(1)
    hold:SetToAlpha(1)
    hold:SetDuration(3)
    hold:SetOrder(2)
    local fadeOut = anim:CreateAnimation("Alpha")
    fadeOut:SetFromAlpha(1)
    fadeOut:SetToAlpha(0)
    fadeOut:SetDuration(0.8)
    fadeOut:SetOrder(3)
    anim:SetScript("OnFinished", function() banner:Hide() end)
    banner.anim = anim
    banner:Hide()
    return banner
end

---@param questId QuestId
function QuestiePlusCore.ShowQuestDone(questId)
    local frame = _Banner()
    frame.title:SetText(l10n("Quest complete!"))
    frame.text:SetText(QuestieLib:GetColoredQuestName(questId, true, false) .. "  |cffbbbbbb" .. l10n("Go hand it in.") .. "|r")
    frame.anim:Stop()
    frame:SetAlpha(0)
    frame:Show()
    frame.anim:Play()
end

local function _ScanCompletes()
    scanPending = false
    if not (Questie.started and QuestieDB.QuestPointers) then return end
    local log = QuestLogCache.questLog_DO_NOT_MODIFY
    local now = {}
    for questId in pairs(log) do
        if QuestieDB.QuestPointers[questId] and QuestieDB.IsComplete(questId) == 1 then
            now[questId] = true
            if completeState and (not completeState[questId]) and Questie.db.profile.questiePlusCompleteBanner then
                QuestiePlusCore.ShowQuestDone(questId)
            end
        end
    end
    completeState = now
end

local function _QueueScan()
    if scanPending then return end
    scanPending = true
    C_Timer.After(0.6, _ScanCompletes)
end

---------------------------------------------------------------------------
-- Start-up
---------------------------------------------------------------------------

-- The route on the world map is rebuilt from where you stand each time the map opens.
local function _RebuildRouteForMap()
    if Questie.db.profile.questiePlusRouteOnMap and Questie.started then
        pcall(QuestieLoader:ImportModule("QuestiePlusRoute").Build)
    end
end

local function _OnReady()
    QuestiePlusChain.Initialize()
    _ScanCompletes()
    local Route = QuestieLoader:ImportModule("QuestiePlusRoute")
    Route.Initialize()
    if WorldMapFrame then
        WorldMapFrame:HookScript("OnShow", _RebuildRouteForMap)
    end
    local events = CreateFrame("Frame")
    events:SetScript("OnEvent", function(_, event)
        if event == "PLAYER_LEAVING_WORLD" then
            completeState = nil -- the quest log reads empty during loading screens; start over afterwards
        elseif event == "PLAYER_ENTERING_WORLD" then
            C_Timer.After(3, _ScanCompletes)
        else
            _QueueScan()
        end
    end)
    events:RegisterEvent("QUEST_LOG_UPDATE")
    events:RegisterEvent("PLAYER_LEAVING_WORLD")
    events:RegisterEvent("PLAYER_ENTERING_WORLD")
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
    if Questie and Questie.API and Questie.API.RegisterOnReady then
        Questie.API.RegisterOnReady(_OnReady)
    end
end)

SLASH_QUESTIEPLUS1 = "/qp"
SLASH_QUESTIEPLUS2 = "/questieplus"
SlashCmdList.QUESTIEPLUS = function()
    QuestiePlusPanel.Toggle()
end
