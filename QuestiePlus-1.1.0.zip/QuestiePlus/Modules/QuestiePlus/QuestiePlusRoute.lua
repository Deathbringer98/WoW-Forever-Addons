-- QuestiePlus route planner: the fastest order to do your quests in.
-- Stops are quest objectives (the nearest spawn of each mob, object or item source), quest hand-ins and,
-- optionally, nearby quests to pick up. A hand-in always comes after that quest's objectives. The order is
-- built nearest-first from where you stand, then shortened with 2-opt swaps, which never break that rule.
-- The route can be drawn on the world map, and each stop can be sent to Blizzard's waypoint arrow.
---@class QuestiePlusRoute
local QuestiePlusRoute = QuestieLoader:CreateModule("QuestiePlusRoute")

---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type ActiveQuests
local ActiveQuests = QuestieLoader:ImportModule("ActiveQuests")
---@type AvailableQuests
local AvailableQuests = QuestieLoader:ImportModule("AvailableQuests")
---@type ZoneDB
local ZoneDB = QuestieLoader:ImportModule("ZoneDB")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

local HBD = LibStub("HereBeDragonsQuestie-2.0")

local MAX_CANDIDATES = 40      -- spawn points kept per stop (the ones nearest to you)
local MAX_PICKUPS = 8          -- new quests to pick up, nearest first
local PICKUP_RANGE = 1500      -- yards: farther quest givers are left out
local RUN_SPEED, MOUNT_SPEED = 7, 11.2

local sqrt = math.sqrt

---------------------------------------------------------------------------
-- Gathering stops
---------------------------------------------------------------------------

---Adds every spawn of spawns ({[areaId] = {{x, y}, ...}}) on the player's continent to list.
local function _AddSpawns(list, spawns, instance, name)
    if type(spawns) ~= "table" then return end
    for areaId, coords in pairs(spawns) do
        local uiMapId = ZoneDB:GetUiMapIdByAreaId(areaId)
        if uiMapId and type(coords) == "table" then
            for _, c in ipairs(coords) do
                local zx, zy = c[1], c[2]
                if zx and zy and zx >= 0 and zy >= 0 then
                    local wx, wy, inst = HBD:GetWorldCoordinatesFromZone(zx / 100, zy / 100, uiMapId)
                    if wx and inst == instance then
                        list[#list + 1] = {wx = wx, wy = wy, uiMapId = uiMapId, zx = zx, zy = zy, name = name}
                    end
                end
            end
        end
    end
end

---Keeps the max nearest candidates to the player.
local function _Trim(list, px, py, max)
    if #list <= max then return list end
    for _, c in ipairs(list) do c.d = (c.wx - px) ^ 2 + (c.wy - py) ^ 2 end
    table.sort(list, function(a, b) return a.d < b.d end)
    for i = #list, max + 1, -1 do list[i] = nil end
    return list
end

---@param starters table {NPC = {ids}, GameObject = {ids}}
local function _NpcAndObjectSpawns(starters, instance)
    local list = {}
    if not starters then return list end
    for _, npcId in ipairs(starters.NPC or {}) do
        _AddSpawns(list, QuestieDB.QueryNPCSingle(npcId, "spawns"), instance, QuestieDB.QueryNPCSingle(npcId, "name"))
    end
    for _, objectId in ipairs(starters.GameObject or {}) do
        _AddSpawns(list, QuestieDB.QueryObjectSingle(objectId, "spawns"), instance, QuestieDB.QueryObjectSingle(objectId, "name"))
    end
    return list
end

---@param objective table A Questie objective with a spawnList.
local function _ObjectiveSpawns(objective, instance)
    local list = {}
    for _, spawnData in pairs(objective.spawnList or {}) do
        _AddSpawns(list, spawnData.Spawns, instance, spawnData.Name)
    end
    return list
end

---Everything the route can visit, as nodes {kind, questId, label, candidates, after = {node indexes}}.
---@return table nodes, number playerX, number playerY, number skipped Stops that are on another continent.
function QuestiePlusRoute.CollectStops(includePickups)
    local px, py, instance = HBD:GetPlayerWorldPosition()
    if not px then return nil end
    local nodes, skipped = {}, 0

    local function Add(node)
        node.candidates = _Trim(node.candidates, px, py, MAX_CANDIDATES)
        if #node.candidates == 0 then
            skipped = skipped + 1
            return nil
        end
        nodes[#nodes + 1] = node
        return #nodes
    end

    for questId in ActiveQuests.Iterate() do
        local quest = QuestieDB.GetQuest(questId)
        if quest and not quest.HideIcons then
            local questName = QuestieLib:GetColoredQuestName(questId, true, false)
            local objectiveNodes = {}
            local isComplete = QuestieDB.IsComplete(questId) == 1
            if not isComplete then
                local objectives = {}
                for _, o in pairs(quest.Objectives or {}) do objectives[#objectives + 1] = o end
                for _, o in pairs(quest.SpecialObjectives or {}) do objectives[#objectives + 1] = o end
                for _, objective in ipairs(objectives) do
                    if (not objective.Completed) and (not objective.HideIcons) and objective.spawnList then
                        local index = Add({
                            kind = "objective", questId = questId, quest = questName,
                            label = objective.Description or l10n("Objective"),
                            candidates = _ObjectiveSpawns(objective, instance),
                        })
                        if index then objectiveNodes[#objectiveNodes + 1] = index end
                    end
                end
            end
            -- An unfinished quest whose objectives have no known spot gets no hand-in stop: you can't finish it on this route.
            if isComplete or #objectiveNodes > 0 then Add({
                kind = "turnin", questId = questId, quest = questName, label = l10n("Hand in"),
                candidates = _NpcAndObjectSpawns(quest.Finisher, instance), after = objectiveNodes,
            }) end
        end
    end

    if includePickups and AvailableQuests.__availableQuests then
        local pickups = {}
        for questId in pairs(AvailableQuests.__availableQuests) do
            local level = QuestieLib.GetEffectiveQuestLevel(questId)
            if not QuestieDB.IsTrivial(level) and not QuestieDB.IsRepeatable(questId) then
                local quest = QuestieDB.GetQuest(questId)
                local candidates = _Trim(_NpcAndObjectSpawns(quest and quest.Starts, instance), px, py, 1)
                local c = candidates[1]
                if c and sqrt((c.wx - px) ^ 2 + (c.wy - py) ^ 2) <= PICKUP_RANGE then
                    pickups[#pickups + 1] = {kind = "pickup", questId = questId, label = l10n("Pick up"),
                        quest = QuestieLib:GetColoredQuestName(questId, true, false), candidates = candidates,
                        d = (c.wx - px) ^ 2 + (c.wy - py) ^ 2}
                end
            end
        end
        table.sort(pickups, function(a, b) return a.d < b.d end)
        for i = 1, math.min(MAX_PICKUPS, #pickups) do Add(pickups[i]) end
    end

    return nodes, px, py, skipped
end

---------------------------------------------------------------------------
-- Ordering
---------------------------------------------------------------------------

local function _Dist(ax, ay, bx, by)
    local dx, dy = ax - bx, ay - by
    return sqrt(dx * dx + dy * dy)
end

---Nearest-first order. Each node uses its candidate spawn nearest to where the route is at that moment.
---@return table order Steps {node, point}.
function QuestiePlusRoute.NearestFirst(nodes, px, py)
    local visited, order = {}, {}
    local x, y = px, py
    for _ = 1, #nodes do
        local bestNode, bestPoint, bestD
        for i, node in ipairs(nodes) do
            if not visited[i] then
                local ready = true
                for _, before in ipairs(node.after or {}) do
                    if not visited[before] then ready = false break end
                end
                if ready then
                    for _, c in ipairs(node.candidates) do
                        local d = _Dist(x, y, c.wx, c.wy)
                        if not bestD or d < bestD then bestNode, bestPoint, bestD = i, c, d end
                    end
                end
            end
        end
        if not bestNode then break end
        visited[bestNode] = true
        order[#order + 1] = {index = bestNode, node = nodes[bestNode], point = bestPoint}
        x, y = bestPoint.wx, bestPoint.wy
    end
    return order
end

local function _Valid(order)
    local position = {}
    for i, step in ipairs(order) do position[step.index] = i end
    for i, step in ipairs(order) do
        for _, before in ipairs(step.node.after or {}) do
            if position[before] and position[before] > i then return false end
        end
    end
    return true
end

---Total travel of an order, starting at the player.
function QuestiePlusRoute.Length(order, px, py)
    local total, x, y = 0, px, py
    for _, step in ipairs(order) do
        total = total + _Dist(x, y, step.point.wx, step.point.wy)
        x, y = step.point.wx, step.point.wy
    end
    return total
end

---2-opt: reverses stretches of the route while that makes it shorter and keeps hand-ins after objectives.
function QuestiePlusRoute.Improve(order, px, py)
    local n = #order
    if n < 3 then return order end
    local improved, passes = true, 0
    while improved and passes < 20 do
        improved, passes = false, passes + 1
        for i = 1, n - 1 do
            for j = i + 1, n do
                local a = i == 1 and {wx = px, wy = py} or order[i - 1].point
                local b, c = order[i].point, order[j].point
                local d = order[j + 1] and order[j + 1].point
                local before = _Dist(a.wx, a.wy, b.wx, b.wy) + (d and _Dist(c.wx, c.wy, d.wx, d.wy) or 0)
                local after = _Dist(a.wx, a.wy, c.wx, c.wy) + (d and _Dist(b.wx, b.wy, d.wx, d.wy) or 0)
                if after + 0.01 < before then
                    local lo, hi = i, j
                    while lo < hi do order[lo], order[hi] = order[hi], order[lo] lo, hi = lo + 1, hi - 1 end
                    if _Valid(order) then
                        improved = true
                    else
                        lo, hi = i, j
                        while lo < hi do order[lo], order[hi] = order[hi], order[lo] lo, hi = lo + 1, hi - 1 end
                    end
                end
            end
        end
    end
    return order
end

---Builds the route. Returns nil when the player position is unknown (for example in a dungeon).
---@return table? route {steps, length (yards), seconds, skipped}
function QuestiePlusRoute.Build()
    local includePickups = Questie.db.profile.questiePlusRoutePickups ~= false
    local nodes, px, py, skipped = QuestiePlusRoute.CollectStops(includePickups)
    if not nodes then return nil end
    local order = QuestiePlusRoute.Improve(QuestiePlusRoute.NearestFirst(nodes, px, py), px, py)
    local length = QuestiePlusRoute.Length(order, px, py)
    local speed = (IsMounted and IsMounted()) and MOUNT_SPEED or RUN_SPEED
    local x, y = px, py
    for _, step in ipairs(order) do
        step.distance = _Dist(x, y, step.point.wx, step.point.wy)
        x, y = step.point.wx, step.point.wy
    end
    QuestiePlusRoute.current = {steps = order, length = length, seconds = length / speed, skipped = skipped, px = px, py = py}
    QuestiePlusRoute.RedrawMap()
    return QuestiePlusRoute.current
end

---Sends a step to Blizzard's waypoint (map pin and on-screen arrow).
function QuestiePlusRoute.Go(step)
    if InCombatLockdown() then
        Questie:Print(l10n("You can't do that while in combat."))
        return
    end
    local p = step and step.point
    if not (p and C_Map.CanSetUserWaypointOnMap and C_Map.CanSetUserWaypointOnMap(p.uiMapId)) then return end
    C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(p.uiMapId, p.zx / 100, p.zy / 100))
    if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then
        C_SuperTrack.SetSuperTrackedUserWaypoint(true)
    end
end

---------------------------------------------------------------------------
-- World map drawing
---------------------------------------------------------------------------

local renderer, view, driver, markers = nil, nil, nil, {}
local drawnMap, drawnWidth, drawnScale

local function _Marker(canvas, i)
    local marker = markers[i]
    if not marker then
        marker = CreateFrame("Frame", nil, canvas)
        marker:SetSize(20, 20)
        marker.bg = marker:CreateTexture(nil, "ARTWORK")
        marker.bg:SetAllPoints()
        marker.bg:SetTexture("Interface\\COMMON\\Indicator-Yellow")
        marker.text = marker:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        marker.text:SetPoint("CENTER", 0, 0)
        marker.text:SetTextColor(1, 1, 1)
        markers[i] = marker
    end
    return marker
end

local function _HideMap()
    if view and renderer then renderer:Release(view) view = nil end
    for _, marker in ipairs(markers) do marker:Hide() end
end

function QuestiePlusRoute.RedrawMap()
    drawnMap = nil
end

local function _DrawOnMap()
    local route = QuestiePlusRoute.current
    local canvas = WorldMapFrame:GetCanvas()
    local mapId = WorldMapFrame:GetMapID()
    local width, height = canvas:GetWidth(), canvas:GetHeight()
    local scale = WorldMapFrame.ScrollContainer:GetCanvasScale()
    if mapId == drawnMap and width == drawnWidth and scale == drawnScale then return end
    drawnMap, drawnWidth, drawnScale = mapId, width, scale
    _HideMap()
    if not (route and Questie.db.profile.questiePlusRouteOnMap and #route.steps > 0 and width > 0) then return end
    local points = {}
    local function Project(wx, wy)
        local x, y = HBD:GetZoneCoordinatesFromWorld(wx, wy, mapId, true)
        if x and y and x > -0.5 and x < 1.5 and y > -0.5 and y < 1.5 then
            return {x = x * width, y = y * height}
        end
    end
    local start = Project(route.px, route.py)
    if start then points[#points + 1] = start end
    local shown = 0
    for i, step in ipairs(route.steps) do
        local p = Project(step.point.wx, step.point.wy)
        if p then
            points[#points + 1] = p
            if p.x >= 0 and p.x <= width and p.y >= 0 and p.y <= height then
                shown = shown + 1
                local marker = _Marker(canvas, shown)
                marker:SetScale(1 / scale)
                marker:ClearAllPoints()
                marker:SetPoint("CENTER", canvas, "TOPLEFT", p.x * scale, -p.y * scale)
                marker:SetFrameLevel(2100)
                marker.text:SetText(i)
                marker:Show()
            end
        end
    end
    if #points >= 2 then
        renderer = renderer or QuestieLoader:ImportModule("WaypointRenderer").New(canvas)
        view = renderer:Draw(nil, {points}, {thickness = 5 / scale, color = {1, 0.82, 0.1, 1}, alpha = 0.9, frameLevel = 2050})
        view:Show()
    end
end

---Starts following the world map. Called once at start-up.
function QuestiePlusRoute.Initialize()
    if driver or not WorldMapFrame then return end
    driver = CreateFrame("Frame", nil, WorldMapFrame:GetCanvas())
    local wait = 0
    driver:SetScript("OnUpdate", function(_, elapsed)
        wait = wait - elapsed
        if wait > 0 then return end
        wait = 0.2
        local ok, err = pcall(_DrawOnMap)
        if not ok then
            Questie.Debug(Questie.DEBUG_DEVELOP, "[QuestiePlusRoute] map draw failed:", err)
        end
    end)
    driver:SetScript("OnHide", function() drawnMap = nil end)
end
