-- QuestiePlus: "Next in chain" lines when hovering a quest in the quest log, on the map or in the tracker.
-- Questie only showed them on its own map icons while holding Shift (Questie #8254).
---@class QuestiePlusChain
local QuestiePlusChain = QuestieLoader:CreateModule("QuestiePlusChain")

---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type QuestieCorrections
local QuestieCorrections = QuestieLoader:ImportModule("QuestieCorrections")
---@type QuestXP
local QuestXP = QuestieLoader:ImportModule("QuestXP")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

local GetCoinTextureString = (C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString) or GetCoinTextureString
local MAX_STEPS = 25

local function _IsSecret(value)
    return issecretvalue and issecretvalue(value)
end

---Follow-up quests the player can get, in order. Stops at quests for another race, class or profession.
---@param questId QuestId
---@return QuestId[]
function QuestiePlusChain.GetFollowUps(questId)
    local list = {}
    if not (QuestieDB.QueryQuestSingle and QuestieDB.QuestPointers and QuestieDB.QuestPointers[questId]) then
        return list
    end
    local DoableStates = QuestieDB.DoableStates
    local seen = {[questId] = true}
    local nextId = QuestieDB.QueryQuestSingle(questId, "nextQuestInChain")
    while type(nextId) == "number" and nextId > 0 and (not seen[nextId]) and #list < MAX_STEPS do
        if QuestieCorrections.hiddenQuests and QuestieCorrections.hiddenQuests[nextId] then break end
        if not QuestieDB.QuestPointers[nextId] then break end
        local _, _, reason = QuestieDB.IsDoableVerbose(nextId, false, true, true)
        if reason == DoableStates.WRONG_RACE or reason == DoableStates.WRONG_CLASS
            or reason == DoableStates.PROFESSION_MISSING or reason == DoableStates.PROFESSION_SPECIALIZATION then
            break
        end
        seen[nextId] = true
        list[#list + 1] = nextId
        nextId = QuestieDB.QueryQuestSingle(nextId, "nextQuestInChain")
    end
    return list
end

---Adds the chain lines to a tooltip. Returns true when anything was added.
---@param tooltip GameTooltip
---@param questId QuestId
---@return boolean
function QuestiePlusChain.AddLines(tooltip, questId)
    local followUps = QuestiePlusChain.GetFollowUps(questId)
    if #followUps == 0 then
        return false
    end
    local ignoreLevel = Questie.db.profile.showQuestXpAtMaxLevel
    tooltip:AddLine(" ")
    tooltip:AddLine(l10n("Next in chain") .. l10n(": "), 1, 0.82, 0)
    local totalXp, totalMoney = 0, 0
    for _, nextId in ipairs(followUps) do
        local xp = QuestXP:GetQuestLogRewardXP(nextId, ignoreLevel) or 0
        local okMoney, money = pcall(QuestXP.GetQuestRewardMoney, nextId)
        money = (okMoney and type(money) == "number") and money or 0
        totalXp, totalMoney = totalXp + xp, totalMoney + money
        local reward = ""
        if xp > 0 then reward = FormatLargeNumber(xp) .. " " .. l10n("xp") end
        if money > 0 then reward = reward .. (reward ~= "" and "  " or "") .. GetCoinTextureString(money) end
        tooltip:AddDoubleLine("  " .. QuestieLib:GetColoredQuestName(nextId, true, false), reward, 1, 1, 1, 0.8, 0.8, 0.8)
    end
    if #followUps > 1 and (totalXp > 0 or totalMoney > 0) then
        local total = totalXp > 0 and (FormatLargeNumber(totalXp) .. " " .. l10n("xp")) or ""
        if totalMoney > 0 then total = total .. (total ~= "" and "  " or "") .. GetCoinTextureString(totalMoney) end
        tooltip:AddDoubleLine(l10n("Rest of the chain (%d quests)", #followUps), total, 0.6, 1, 0.6, 0.6, 1, 0.6)
    end
    return true
end

---@param owner Frame?
---@return QuestId?
local function _QuestIdFromOwner(owner)
    if not owner or _IsSecret(owner) or type(owner) ~= "table" then return nil end
    local ok, questId = pcall(function()
        local id = rawget(owner, "questID")
        if id == nil and type(rawget(owner, "Quest")) == "table" then
            id = owner.Quest.Id
        end
        return id
    end)
    if ok and (not _IsSecret(questId)) and type(questId) == "number" and questId > 0 then
        return questId
    end
    return nil
end

local adding = false
local added = setmetatable({}, {__mode = "k"})

local function _OnTooltipShow(tooltip)
    if adding or added[tooltip] or (not Questie.started) or InCombatLockdown() then return end
    if not Questie.db.profile.questiePlusChainOnHover then return end
    local questId = _QuestIdFromOwner(tooltip:GetOwner())
    if not questId then return end
    adding = true
    local ok, any = pcall(QuestiePlusChain.AddLines, tooltip, questId)
    added[tooltip] = true
    if ok and any then
        tooltip:Show()
    end
    adding = false
end

---Hooks GameTooltip so quest log rows and quest map pins (frames with a questID) show the chain.
function QuestiePlusChain.Initialize()
    if QuestiePlusChain.initialized then return end
    QuestiePlusChain.initialized = true
    hooksecurefunc(GameTooltip, "Show", _OnTooltipShow)
    GameTooltip:HookScript("OnTooltipCleared", function(tooltip) added[tooltip] = nil end)
    GameTooltip:HookScript("OnHide", function(tooltip) added[tooltip] = nil end)
end

---Tooltip for a Questie tracker quest line when Questie's own (group only) tooltip does not show.
---@param line Frame
---@param questId QuestId
---@return boolean shown
function QuestiePlusChain.ShowForTrackerLine(line, questId)
    if not (Questie.db.profile.questiePlusChainOnHover and Questie.started) or InCombatLockdown() then
        return false
    end
    if #QuestiePlusChain.GetFollowUps(questId) == 0 then
        return false
    end
    adding = true
    GameTooltip:SetOwner(line, "ANCHOR_NONE")
    GameTooltip:ClearAllPoints()
    GameTooltip:SetPoint("BOTTOMLEFT", line, "TOPLEFT")
    GameTooltip:AddLine(QuestieLib:GetColoredQuestName(questId, true, false))
    QuestiePlusChain.AddLines(GameTooltip, questId)
    added[GameTooltip] = true
    GameTooltip:Show()
    adding = false
    QuestiePlusChain.trackerOwner = line
    return true
end

---@param line Frame?
function QuestiePlusChain.HideForTrackerLine(line)
    local owner = QuestiePlusChain.trackerOwner
    if owner and (line == nil or line == owner) then
        QuestiePlusChain.trackerOwner = nil
        if GameTooltip:GetOwner() == owner then
            GameTooltip:Hide()
        end
    end
end
