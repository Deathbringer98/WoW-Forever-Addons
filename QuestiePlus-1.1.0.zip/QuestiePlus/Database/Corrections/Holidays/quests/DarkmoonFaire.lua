---@type QuestieEvent
local QuestieEvent = QuestieLoader:ImportModule("QuestieEvent")
---@type Expansions
local Expansions = QuestieLoader:ImportModule("Expansions")

local tinsert = table.insert
local eventQuests = QuestieEvent.eventQuests

tinsert(eventQuests, {"Darkmoon Faire", 7881, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Carnival Boots
tinsert(eventQuests, {"Darkmoon Faire", 7882, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Carnival Jerkins
tinsert(eventQuests, {"Darkmoon Faire", 7883, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- The World's Largest Gnome!
tinsert(eventQuests, {"Darkmoon Faire", 7884, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Crocolisk Boy and the Bearded Murloc
tinsert(eventQuests, {"Darkmoon Faire", 7885, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Armor Kits
tinsert(eventQuests, {"Darkmoon Faire", 7889, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Coarse Weightstone
tinsert(eventQuests, {"Darkmoon Faire", 7890, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Heavy Grinding Stone
tinsert(eventQuests, {"Darkmoon Faire", 7891, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Green Iron Bracers
tinsert(eventQuests, {"Darkmoon Faire", 7892, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Big Black Mace
tinsert(eventQuests, {"Darkmoon Faire", 7893, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Rituals of Strength
tinsert(eventQuests, {"Darkmoon Faire", 7894, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Copper Modulator
tinsert(eventQuests, {"Darkmoon Faire", 7895, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Whirring Bronze Gizmo
tinsert(eventQuests, {"Darkmoon Faire", 7896, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Green Fireworks
tinsert(eventQuests, {"Darkmoon Faire", 7897, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Mechanical Repair Kits
tinsert(eventQuests, {"Darkmoon Faire", 7898, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Thorium Widget
tinsert(eventQuests, {"Darkmoon Faire", 7899, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Small Furry Paws
tinsert(eventQuests, {"Darkmoon Faire", 7900, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Torn Bear Pelts
tinsert(eventQuests, {"Darkmoon Faire", 7901, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Soft Bushy Tails
tinsert(eventQuests, {"Darkmoon Faire", 7902, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Vibrant Plumes
tinsert(eventQuests, {"Darkmoon Faire", 7903, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Evil Bat Eyes
tinsert(eventQuests, {"Darkmoon Faire", 7905}) -- The Darkmoon Faire
tinsert(eventQuests, {"Darkmoon Faire", 7907}) -- Darkmoon Beast Deck
tinsert(eventQuests, {"Darkmoon Faire", 7926}) -- The Darkmoon Faire
tinsert(eventQuests, {"Darkmoon Faire", 7927}) -- Darkmoon Portals Deck
tinsert(eventQuests, {"Darkmoon Faire", 7928}) -- Darkmoon Warlords Deck
tinsert(eventQuests, {"Darkmoon Faire", 7929}) -- Darkmoon Elementals Deck
tinsert(eventQuests, {"Darkmoon Faire", 7930, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 5 Tickets - Darkmoon Flower
tinsert(eventQuests, {"Darkmoon Faire", 7931, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 5 Tickets - Minor Darkmoon Prize
tinsert(eventQuests, {"Darkmoon Faire", 7932, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 12 Tickets - Lesser Darkmoon Prize
tinsert(eventQuests, {"Darkmoon Faire", 7933, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 40 Tickets - Greater Darkmoon Prize
tinsert(eventQuests, {"Darkmoon Faire", 7934, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 50 Tickets - Darkmoon Storage Box
tinsert(eventQuests, {"Darkmoon Faire", 7935, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 10 Tickets - Last Month's Mutton
tinsert(eventQuests, {"Darkmoon Faire", 7936, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 50 Tickets - Last Year's Mutton
tinsert(eventQuests, {"Darkmoon Faire", 7937, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- Your Fortune Awaits You...
tinsert(eventQuests, {"Darkmoon Faire", 7938, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- Your Fortune Awaits You...
tinsert(eventQuests, {"Darkmoon Faire", 7939, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- More Dense Grinding Stones
tinsert(eventQuests, {"Darkmoon Faire", 7940, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 1200 Tickets - Orb of the Darkmoon
tinsert(eventQuests, {"Darkmoon Faire", 7941, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- More Armor Kits
tinsert(eventQuests, {"Darkmoon Faire", 7942, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- More Thorium Widgets
tinsert(eventQuests, {"Darkmoon Faire", 7943, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- More Bat Eyes
tinsert(eventQuests, {"Darkmoon Faire", 7944, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- Your Fortune Awaits You...
tinsert(eventQuests, {"Darkmoon Faire", 7945, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- Your Fortune Awaits You...
tinsert(eventQuests, {"Darkmoon Faire", 7946, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Spawn of Jubjub
tinsert(eventQuests, {"Darkmoon Faire", 7981, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 1200 Tickets - Amulet of the Darkmoon
tinsert(eventQuests, {"Darkmoon Faire", 8222, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- Glowing Scorpid Blood
tinsert(eventQuests, {"Darkmoon Faire", 8223, nil, nil, nil, nil, Questie.IsSoD or Expansions.Current >= Expansions.Cata}) -- More Glowing Scorpid Blood

-- SoD quests
tinsert(eventQuests, {"Darkmoon Faire", 79588}) -- Small Furry Paws
tinsert(eventQuests, {"Darkmoon Faire", 79589}) -- Torn Bear Pelts
tinsert(eventQuests, {"Darkmoon Faire", 79590}) -- Heavy Grinding Stone
tinsert(eventQuests, {"Darkmoon Faire", 79591}) -- Whirring Bronze Gizmo
tinsert(eventQuests, {"Darkmoon Faire", 79592}) -- Carnival Jerkins
tinsert(eventQuests, {"Darkmoon Faire", 79593}) -- Coarse Weightstone
tinsert(eventQuests, {"Darkmoon Faire", 79594}) -- Copper Modulator
tinsert(eventQuests, {"Darkmoon Faire", 79595}) -- Carnival Boots
tinsert(eventQuests, {"Darkmoon Faire", 80417}) -- Soft Bushy Tails
tinsert(eventQuests, {"Darkmoon Faire", 80421}) -- Green Iron Bracers
tinsert(eventQuests, {"Darkmoon Faire", 80422}) -- Green Fireworks
tinsert(eventQuests, {"Darkmoon Faire", 80423}) -- The World's Largest Gnome!
tinsert(eventQuests, {"Darkmoon Faire", 82323}) -- Vibrant Plumes
tinsert(eventQuests, {"Darkmoon Faire", 82271}) -- More Glowing Scorpid Blood
tinsert(eventQuests, {"Darkmoon Faire", 82272}) -- Glowing Scorpid Blood
tinsert(eventQuests, {"Darkmoon Faire", 82273}) -- More Evil Bat Eyes
tinsert(eventQuests, {"Darkmoon Faire", 82274}) -- Evil Bat Eyes
tinsert(eventQuests, {"Darkmoon Faire", 82275}) -- Big Black Mace
tinsert(eventQuests, {"Darkmoon Faire", 82276}) -- Rituals of Strength
tinsert(eventQuests, {"Darkmoon Faire", 82277}) -- More Dense Grinding Stones
tinsert(eventQuests, {"Darkmoon Faire", 82278}) -- More Thorium Widgets
tinsert(eventQuests, {"Darkmoon Faire", 82279}) -- Thorium Widget
tinsert(eventQuests, {"Darkmoon Faire", 82280}) -- Mechanical Repair Kits
tinsert(eventQuests, {"Darkmoon Faire", 82281}) -- More Armor Kits
tinsert(eventQuests, {"Darkmoon Faire", 82282}) -- Armor Kits
tinsert(eventQuests, {"Darkmoon Faire", 82283}) -- Crocolisk Boy and the Bearded Murloc

-- TBC quests
tinsert(eventQuests, {"Darkmoon Faire", 9249, nil, nil, nil, nil, Expansions.Current >= Expansions.Cata}) -- 40 Tickets - Schematic: Steam Tonk Controller
tinsert(eventQuests, {"Darkmoon Faire", 10938}) -- Darkmoon Blessings Deck
tinsert(eventQuests, {"Darkmoon Faire", 10939}) -- Darkmoon Storms Deck
tinsert(eventQuests, {"Darkmoon Faire", 10940}) -- Darkmoon Furies Deck
tinsert(eventQuests, {"Darkmoon Faire", 10941}) -- Darkmoon Lunacy Deck

-- WotLK quests
tinsert(eventQuests, {"Darkmoon Faire", 13324}) -- Darkmoon Prisms Deck
tinsert(eventQuests, {"Darkmoon Faire", 13325}) -- Darkmoon Chaos Deck
tinsert(eventQuests, {"Darkmoon Faire", 13326}) -- Darkmoon Nobles Deck
tinsert(eventQuests, {"Darkmoon Faire", 13327}) -- Darkmoon Undeath Deck

-- Cata quests
tinsert(eventQuests, {"Darkmoon Faire", 27664}) -- Darkmoon Volcanic Deck
tinsert(eventQuests, {"Darkmoon Faire", 27665}) -- Darkmoon Hurricane Deck
tinsert(eventQuests, {"Darkmoon Faire", 27666}) -- Darkmoon Tsunami Deck
tinsert(eventQuests, {"Darkmoon Faire", 27667}) -- Darkmoon Earthquake Deck
tinsert(eventQuests, {"Darkmoon Faire", 29433}) -- Test Your Strength
tinsert(eventQuests, {"Darkmoon Faire", 29434}) -- Tonk Commander
tinsert(eventQuests, {"Darkmoon Faire", 29436}) -- The Humanoid Cannonball
tinsert(eventQuests, {"Darkmoon Faire", 29438}) -- He Shoots, He Scores!
tinsert(eventQuests, {"Darkmoon Faire", 29443}) -- A Curious Crystal
tinsert(eventQuests, {"Darkmoon Faire", 29444}) -- An Exotic Egg
tinsert(eventQuests, {"Darkmoon Faire", 29445}) -- An Intriguing Grimoire
tinsert(eventQuests, {"Darkmoon Faire", 29446}) -- A Wondrous Weapon
tinsert(eventQuests, {"Darkmoon Faire", 29451}) -- The Master Strategist
tinsert(eventQuests, {"Darkmoon Faire", 29455}) -- Target: Turtle
tinsert(eventQuests, {"Darkmoon Faire", 29456}) -- A Captured Banner
tinsert(eventQuests, {"Darkmoon Faire", 29457}) -- The Enemy's Insignia
tinsert(eventQuests, {"Darkmoon Faire", 29458}) -- The Captured Journal
tinsert(eventQuests, {"Darkmoon Faire", 29463}) -- It's Hammer Time
tinsert(eventQuests, {"Darkmoon Faire", 29464}) -- Tools of Divination
tinsert(eventQuests, {"Darkmoon Faire", 29506}) -- A Fizzy Fusion
tinsert(eventQuests, {"Darkmoon Faire", 29507}) -- Fun for the Little Ones
tinsert(eventQuests, {"Darkmoon Faire", 29508}) -- Baby Needs Two Pair of Shoes
tinsert(eventQuests, {"Darkmoon Faire", 29509}) -- Putting the Crunch in the Frog
tinsert(eventQuests, {"Darkmoon Faire", 29510}) -- Putting Trash to Good Use
tinsert(eventQuests, {"Darkmoon Faire", 29511}) -- Talkin' Tonks
tinsert(eventQuests, {"Darkmoon Faire", 29512}) -- Putting the Carnies Back Together Again
tinsert(eventQuests, {"Darkmoon Faire", 29513}) -- Spoilin' for Salty Sea Dogs
tinsert(eventQuests, {"Darkmoon Faire", 29514}) -- Herbs for Healing
tinsert(eventQuests, {"Darkmoon Faire", 29515}) -- Writing the Future
tinsert(eventQuests, {"Darkmoon Faire", 29516}) -- Keeping the Faire Sparkling
tinsert(eventQuests, {"Darkmoon Faire", 29517}) -- Eyes on the Prizes
tinsert(eventQuests, {"Darkmoon Faire", 29518}) -- Rearm, Reuse, Recycle
tinsert(eventQuests, {"Darkmoon Faire", 29519}) -- Tan My Hide
tinsert(eventQuests, {"Darkmoon Faire", 29520}) -- Banners, Banners Everywhere!
tinsert(eventQuests, {"Darkmoon Faire", 29760}) -- Pit Fighter
tinsert(eventQuests, {"Darkmoon Faire", 29761}) -- Master Pit Fighter

-- MoP quests
tinsert(eventQuests, {"Darkmoon Faire", 30449}) -- Darkmoon Crane Deck
tinsert(eventQuests, {"Darkmoon Faire", 30450}) -- Darkmoon Ox Deck
tinsert(eventQuests, {"Darkmoon Faire", 30451}) -- Darkmoon Serpent Deck
tinsert(eventQuests, {"Darkmoon Faire", 30452}) -- Darkmoon Tiger Deck
tinsert(eventQuests, {"Darkmoon Faire", 32175}) -- Darkmoon Pet Battle!
tinsert(eventQuests, {"Darkmoon Faire", 33354}) -- Den Mother's Demise
