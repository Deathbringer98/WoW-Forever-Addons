# QuestiePlus changes to Questie 12.7.0

This file is the GPL v3 notice of modifications. QuestiePlus (1.0.0 and later) was made on 2026-11-11 by Matthew Menchinton (CircuitSpecter Studio) from Questie 12.7.0 (build commit d9e00cb94dac879ef4447ccb1d7c411bbe425c61). Every changed spot in the code is marked with a "QuestiePlus" comment.

## 1.1.0 (2026-11-11)
- `Modules/VersionCheckDB.lua`, `Modules/Status/SourceModeStatus.lua`: read `X-QuestieDB-Contract` from the `QuestiePlus` TOC. 1.0.0 still asked for the `Questie` TOC and stopped at start-up.
- `Modules/QuestiePlus/QuestiePlusRoute.lua` (new): suggested quest route (nearest-first order improved with 2-opt, hand-ins after their objectives, nearby pick-ups), Go buttons for the waypoint arrow, and the route drawn on the world map.
- `Modules/QuestiePlus/QuestiePlusPanel.lua`, `QuestiePlusCore.lua`, `NativeOptionsQuestiePlus.lua`, `Modules/Options/QuestieOptionsDefaults.lua`: route section, map rebuild on open, and two new settings.

## Renamed and rebranded
- Folder and TOC are now `QuestiePlus` / `QuestiePlus.toc` (WoW Forever only, Interface 16001). The other game flavour TOCs were removed.
- `Modules/VersionCheck.lua`: accepts the `QuestiePlus` folder name; when the original Questie is also enabled it offers to turn Questie off instead of erroring.
- All `Interface\AddOns\Questie\` texture paths point at `QuestiePlus`, and metadata lookups use the `QuestiePlus` folder.
- New logo (`Icons/questie.png`, `questie_flat.png`, `questie_portrait.png`), drawn by `QuestiePlus-tools/make_logo.js`.
- Window titles, the minimap tooltip and the settings category say QuestiePlus. `## Version` stays 12.7.0 so party sync with Questie players keeps working; the QuestiePlus version is in `X-QuestiePlus-Version`.
- `QuestieDB` is a required dependency (`## Dependencies`), so a missing database shows in the AddOns list instead of a wall of Lua errors (see Questie #8248).

## Bug fixes
- `Modules/QuestieAnnounce.lua`: the private "item starts a quest" message respects the item announcement and shut-up settings (#8260).
- `Modules/Quest/QuestieQuest.lua`, `Modules/Quest/Lifecycle/QuestLifecycle.lua`, `Modules/EventHandler/EventHandler.lua`: required source item objectives complete from the bags and when the quest is complete, so their pins clear (#8222, #8243).
- `Modules/Auto/AutoQuesting.lua`: escort quests (tag 84) are never auto-accepted (#8272).
- `Libs/HereBeDragons/HereBeDragons-Pins-2.0.lua`: minimap pins redraw after LOADING_SCREEN_DISABLED (#7988).
- `Modules/Map/Waypoints/WaypointHover.lua`, `WaypointMap.lua`: modifier clicks on a hovered patrol path reach its NPC icon (#8053).
- `Modules/QuestieCompat.lua`, `Modules/Tracker/TrackerUtils.lua`, `Modules/Tracker/QuestieTracker.lua`: super tracking changes wait for the end of combat and are skipped when a quest leaves the log (mitigation for #8230).

## New features
- `Modules/QuestiePlus/QuestiePlusPanel.lua`: the QuestiePlus window (level-up planner, ready to hand in, grey quests, zone progress).
- `Modules/QuestiePlus/QuestiePlusChain.lua`, `Modules/Tracker/TrackerQuestTooltip.lua`: quest chain lines on quest log, map pin and tracker hover (#8254).
- `Modules/QuestiePlus/QuestiePlusCore.lua`: `/qp`, start-up, quest complete banner.
- `Modules/QuestiePlus/NativeOptionsQuestiePlus.lua`: QuestiePlus settings tab.
- `Modules/Tracker/QuestieTracker.lua`, `Modules/Options/NativeOptions/NativeOptionsTracker.lua`: "Hide In Battlegrounds" tracker option (#8265).
- `Modules/FramePool/QuestieFrame.lua`: shift+click an objective icon to hide that objective's icons (#8214).
- `Modules/MinimapIcon.lua`: middle click opens the QuestiePlus window.
- `Modules/Options/QuestieOptionsDefaults.lua`: defaults for the new settings.
