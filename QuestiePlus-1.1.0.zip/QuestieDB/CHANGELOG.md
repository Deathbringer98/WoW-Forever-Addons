# QuestieDB 1.0.15

### Quest fixes

- [Forever] Update quest XP data ([BreakBB](https://github.com/Questie/QuestieDB/commit/44fbc874a512d19d56e1f1a496fb734e50043f3f))
- [Forever] show objective locations for "My Little Friends" ([BreakBB](https://github.com/Questie/QuestieDB/commit/c3f76d44f06bb5f4cbaf5dbb32a367e1272385fa))

### Database fixes

- [Forever] Update quests, NPCs, objects and items data ([BreakBB](https://github.com/Questie/QuestieDB/commit/8ab68aed2d8caf525500ee47ad2b017373fc61f5))

### Localization fixes

- [Forever] Update all translations ([BreakBB](https://github.com/Questie/QuestieDB/commit/a40ff7e36156a07b5735fc95af87aa625c0e8183))

[All changes since v1.0.14](https://github.com/Questie/QuestieDB/compare/v1.0.14..c7ccd23e17a222e083c4215144ef9db301db27ce)
