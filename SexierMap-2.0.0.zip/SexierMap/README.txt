SexierMap 2.0.0 - World of Warcraft: Forever (Interface 16001)
=============================================================

Animated, Warcraft-themed rings around your circular minimap.
Formerly FelSummonMinimap. Cosmetic only: your minimap can still be
clicked and zoomed normally.

INSTALL
1. Close World of Warcraft: Forever.
2. Copy the SexierMap folder to:
   World of Warcraft\_forever_\Interface\AddOns\
3. Remove the old FelSummonMinimap folder if it is still there, or you
   will see two rings.
4. Launch Forever and make sure the addon is enabled at character select.

THEMES
  class      follows your class (warlock fel, mage arcane, paladin and
             priest holy, druid and hunter nature, rogue void, shaman
             storm, warrior faction)
  faction    Horde or Alliance colours
  fel        Fel Summoning: green runes, fel fire, orbiting motes
  felclassic Fel Classic: the original FelSummonMinimap ring
  arcane     Arcane Sanctum: counter-rotating rune bands, sparkles
  holy       Holy Light: golden sunburst
  frost      Frozen Throne: ice shards and falling snow
  fire       Molten Core: curling flames and rising embers
  nature     Emerald Dream: a vine with leaves and fireflies
  shadow     Void: swirling purple wisps
  storm      Stormcaller: flickering lightning
  gnomish    Gnomish Engineering: a turning brass cog
  horde      For the Horde: crimson spikes and embers
  alliance   For the Alliance: blue and gold sunburst with runes

COMMANDS (type in chat)
/smap                    open the options window
/smap theme frost        pick a theme by name
/smap next               switch to the next theme
/smap on | off | toggle  show or hide the ring
/smap animate            turn animation on or off
/smap particles          turn particles on or off
/smap combat             turn the combat flare on or off
/smap scale 1.2          size of the ring (0.6 to 1.8)
/smap alpha 0.8          opacity (0.2 to 1)
/smap reset              restore the defaults
/smap status             show the current settings
/sexiermap and the old /felmap also work.

NOTES
- Combat flare: while you are in combat the glow turns red and the
  animation speeds up.
- Your old FelSummonMinimap size, opacity and on/off settings carry over
  the first time SexierMap loads.
- Built for a circular minimap. Square minimap mods may not line up.
- The ring follows the minimap when you move or resize it in Edit Mode.
- No other addons or libraries are required.
- To make your own theme, add an entry to Themes.lua.

CREDITS
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
