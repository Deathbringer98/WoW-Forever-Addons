-- SexierMap themes. Generated from themes.js, edit there or here by hand.
-- Layer fields: tex, color (defaults to the theme color), alpha, add (additive blend), spin (radians per second),
-- pulse { min, max, speed }, scale, glow (reacts to combat), flicker, raw (not tinted).
-- Particles: tex, count, mode (orbit, rise, fall, twinkle), size (fraction of the ring), color, speed.
local _, ns = ...

ns.ThemeOrder = { "fel", "felclassic", "arcane", "holy", "frost", "fire", "nature", "shadow", "storm", "gnomish", "horde", "alliance" }

ns.Themes = {
    fel = {
        name = "Fel Summoning",
        color = { 0.4, 1, 0.5 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.25, 0.6, 0.9 } },
            { tex = "Flames", color = { 0.6, 1, 0.25 }, alpha = 0.4, add = true, spin = -0.05 },
            { tex = "Ring" },
            { tex = "Runes", spin = 0.05, alpha = 0.95 },
        },
        particles = { tex = "Mote", count = 6, mode = "orbit", size = 0.075, color = { 0.7, 1, 0.45 }, speed = 0.25 },
    },
    felclassic = {
        name = "Fel Classic",
        color = { 0.4, 1, 0.6 },
        layers = {
            { tex = "Circle", raw = true },
            { tex = "Pulse", raw = true, add = true, glow = true, pulse = { 0.1, 0.28, 0.95 } },
        },
        particles = { tex = "Ember", raw = true, count = 4, mode = "orbit", size = 0.1, speed = 0.22 },
    },
    arcane = {
        name = "Arcane Sanctum",
        color = { 0.74, 0.5, 1 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.3, 0.65, 0.7 } },
            { tex = "Ring", color = { 0.6, 0.75, 1 } },
            { tex = "Runes", spin = 0.09 },
            { tex = "Runes", spin = -0.06, scale = 1.085, alpha = 0.4, color = { 0.5, 0.8, 1 } },
        },
        particles = { tex = "Spark", count = 7, mode = "twinkle", size = 0.085, color = { 0.85, 0.8, 1 }, speed = 0.7 },
    },
    holy = {
        name = "Holy Light",
        color = { 1, 0.86, 0.45 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.35, 0.7, 0.6 } },
            { tex = "Rays", add = true, spin = 0.025, pulse = { 0.55, 0.9, 0.5 } },
            { tex = "Ring", color = { 1, 0.95, 0.75 } },
        },
        particles = { tex = "Spark", count = 5, mode = "twinkle", size = 0.09, color = { 1, 0.97, 0.8 }, speed = 0.55 },
    },
    frost = {
        name = "Frozen Throne",
        color = { 0.55, 0.85, 1 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.25, 0.5, 0.4 } },
            { tex = "Shards", alpha = 0.9 },
            { tex = "Ring", color = { 0.85, 0.95, 1 } },
        },
        particles = { tex = "Mote", count = 9, mode = "fall", size = 0.045, color = { 1, 1, 1 }, speed = 0.5 },
    },
    fire = {
        name = "Molten Core",
        color = { 1, 0.45, 0.1 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.35, 0.75, 1.6 } },
            { tex = "Flames", add = true, spin = 0.07, pulse = { 0.7, 1, 2.2 } },
            { tex = "Flames", add = true, spin = -0.05, scale = 0.975, alpha = 0.55, color = { 1, 0.8, 0.25 } },
            { tex = "Ring", color = { 1, 0.78, 0.35 } },
        },
        particles = { tex = "Mote", count = 9, mode = "rise", size = 0.05, color = { 1, 0.7, 0.25 }, speed = 0.8 },
    },
    nature = {
        name = "Emerald Dream",
        color = { 0.45, 0.9, 0.42 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.15, 0.4, 0.45 } },
            { tex = "Ring", alpha = 0.55, color = { 0.75, 0.9, 0.55 } },
            { tex = "Thorns", spin = 0.018 },
        },
        particles = { tex = "Mote", count = 7, mode = "twinkle", size = 0.05, color = { 0.9, 1, 0.45 }, speed = 0.35 },
    },
    shadow = {
        name = "Void",
        color = { 0.62, 0.36, 0.96 },
        layers = {
            { tex = "Glow", add = true, glow = true, color = { 0.42, 0.2, 0.85 }, pulse = { 0.3, 0.6, 0.5 } },
            { tex = "Void", add = true, spin = -0.14 },
            { tex = "Void", add = true, spin = 0.08, scale = 1.02, alpha = 0.5, color = { 0.85, 0.45, 1 } },
            { tex = "Ring", alpha = 0.6 },
        },
        particles = { tex = "Mote", count = 5, mode = "orbit", size = 0.06, color = { 0.8, 0.55, 1 }, speed = -0.15 },
    },
    storm = {
        name = "Stormcaller",
        color = { 0.5, 0.76, 1 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.2, 0.6, 2.4 } },
            { tex = "Lightning", add = true, flicker = true, color = { 0.85, 0.93, 1 } },
            { tex = "Ring" },
        },
        particles = { tex = "Spark", count = 6, mode = "twinkle", size = 0.075, color = { 0.9, 0.96, 1 }, speed = 1.4 },
    },
    gnomish = {
        name = "Gnomish Engineering",
        color = { 0.9, 0.72, 0.4 },
        layers = {
            { tex = "Glow", add = true, glow = true, alpha = 0.5, pulse = { 0.1, 0.3, 0.5 } },
            { tex = "Ring", alpha = 0.35, spin = -0.1 },
            { tex = "Cog", spin = 0.12 },
        },
        particles = { tex = "Spark", count = 3, mode = "twinkle", size = 0.07, color = { 1, 0.95, 0.6 }, speed = 1.8 },
    },
    horde = {
        name = "For the Horde",
        color = { 0.92, 0.16, 0.1 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.3, 0.6, 0.8 } },
            { tex = "Shards", color = { 1, 0.24, 0.14 }, alpha = 0.95 },
            { tex = "Ring", color = { 1, 0.62, 0.35 } },
        },
        particles = { tex = "Mote", count = 6, mode = "rise", size = 0.045, color = { 1, 0.55, 0.2 }, speed = 0.6 },
    },
    alliance = {
        name = "For the Alliance",
        color = { 0.3, 0.55, 1 },
        layers = {
            { tex = "Glow", add = true, glow = true, pulse = { 0.3, 0.6, 0.6 } },
            { tex = "Rays", color = { 1, 0.85, 0.4 }, alpha = 0.75, spin = -0.02 },
            { tex = "Ring", color = { 0.7, 0.85, 1 } },
            { tex = "Runes", color = { 1, 0.88, 0.5 }, alpha = 0.8, spin = 0.03 },
        },
        particles = { tex = "Spark", count = 4, mode = "twinkle", size = 0.08, color = { 1, 0.92, 0.6 }, speed = 0.5 },
    },
}

-- Which theme the "class" setting picks. Warriors follow their faction.
ns.ClassTheme = { WARLOCK = "fel", MAGE = "arcane", PALADIN = "holy", PRIEST = "holy", DRUID = "nature", HUNTER = "nature", ROGUE = "shadow", SHAMAN = "storm", WARRIOR = "faction" }
ns.FactionTheme = { Horde = "horde", Alliance = "alliance" }
