-- SexierMap for World of Warcraft: Forever (Interface 16001)
-- Animated, Warcraft-themed rings around the minimap. Formerly FelSummonMinimap.
-- Cosmetic only: it never touches combat logic or the minimap's mouse input.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\SexierMap\\Textures\\"
local MAX_LAYERS = 5
local MAX_PARTICLES = 10
local TICK = 0.033
local PREFIX = "|cffff7ad9SexierMap:|r "
local pi, sin, cos, abs, random = math.pi, math.sin, math.cos, math.abs, math.random

local db
local root
local layers, particles = {}, {}
local theme, themeKey
local diameter = 0
local clock, tick = 0, 0
local inCombat, combatMix = false, 0
local options

local defaults = {
    enabled = true,
    animated = true,
    particles = true,
    combat = true,
    scale = 1.0,
    opacity = 0.9,
    theme = "class",
}

local function Say(text)
    print(PREFIX .. text)
end

local function Clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

---------------------------------------------------------------------------
-- Theme selection
---------------------------------------------------------------------------

local function PlayerFactionTheme()
    local ok, faction = pcall(UnitFactionGroup, "player")
    if ok and type(faction) == "string" and ns.FactionTheme[faction] then return ns.FactionTheme[faction] end
    return "arcane"
end

-- Turns the saved setting ("class", "faction" or a theme key) into a real theme key.
local function ResolveTheme(setting)
    if setting == "class" then
        local ok, _, classFile = pcall(UnitClass, "player")
        setting = ok and type(classFile) == "string" and ns.ClassTheme[classFile] or "fel"
    end
    if setting == "faction" then setting = PlayerFactionTheme() end
    if not ns.Themes[setting] then setting = "fel" end
    return setting
end

local function SettingLabel(setting)
    if setting == "class" then return "My class (" .. ns.Themes[ResolveTheme("class")].name .. ")" end
    if setting == "faction" then return "My faction (" .. ns.Themes[ResolveTheme("faction")].name .. ")" end
    return ns.Themes[setting] and ns.Themes[setting].name or setting
end

---------------------------------------------------------------------------
-- Ring
---------------------------------------------------------------------------

local function RingSize()
    local width = Minimap:GetWidth() or 140
    local scale = (Minimap:GetEffectiveScale() or 1) / (UIParent:GetEffectiveScale() or 1)
    return math.max(1, width * scale * 1.35 * db.scale)
end

local function UpdateVisibility()
    if not root then return end
    if db.enabled and Minimap:IsVisible() then
        root:Show()
    else
        root:Hide()
    end
end

local function Resize(force)
    local size = RingSize()
    if not force and abs(size - diameter) < 0.2 then return end
    diameter = size
    root:SetSize(size, size)
    for i = 1, MAX_LAYERS do
        local layer = layers[i]
        if layer.def then
            local s = size * (layer.def.scale or 1)
            layer.tex:SetSize(s, s)
        end
    end
end

local function ResetParticle(p, def, index, first)
    p.angle = random() * 2 * pi
    p.radius = 0.39 + random() * 0.055
    p.seed = random() * 10
    local speed = math.max(0.15, abs(def.speed or 1))
    if def.mode == "orbit" then
        p.angle = (index - 1) * (2 * pi / def.count)
        p.radius = 0.405
        p.life = math.huge
    elseif def.mode == "twinkle" then
        p.life = (0.9 + random() * 1.4) / speed
    else
        p.life = (1.6 + random() * 1.6) / speed
    end
    p.age = first and p.life ~= math.huge and random() * p.life or 0
end

local function ApplyTheme()
    themeKey = ResolveTheme(db.theme)
    theme = ns.Themes[themeKey]
    for i = 1, MAX_LAYERS do
        local layer, def = layers[i], theme.layers[i]
        layer.def = def
        layer.angle = 0
        layer.jump = 0
        if def then
            local c = def.raw and { 1, 1, 1 } or def.color or theme.color
            layer.tex:SetTexture(TEXTURES .. def.tex .. ".tga")
            layer.tex:SetBlendMode(def.add and "ADD" or "BLEND")
            layer.tex:SetVertexColor(c[1], c[2], c[3], 1)
            layer.tex:SetRotation(0)
            layer.tex:SetAlpha(def.alpha or 1)
            layer.tex:Show()
        else
            layer.tex:Hide()
        end
    end
    local def = theme.particles
    for i = 1, MAX_PARTICLES do
        local p = particles[i]
        p.active = def ~= nil and i <= def.count
        if p.active then
            local c = def.raw and { 1, 1, 1 } or def.color or theme.color
            p.tex:SetTexture(TEXTURES .. def.tex .. ".tga")
            p.tex:SetVertexColor(c[1], c[2], c[3], 1)
            ResetParticle(p, def, i, true)
        end
        p.tex:Hide()
    end
    Resize(true)
end

-- Draws one frame of the animation. With animation off it draws a single calm frame.
local function Animate(dt)
    local moving = db.animated
    local target = (inCombat and db.combat) and 1 or 0
    if combatMix ~= target then
        combatMix = Clamp(combatMix + (target > combatMix and dt or -dt) * 2.5, 0, 1)
    end
    local rush = 1 + 1.4 * combatMix

    for i = 1, MAX_LAYERS do
        local layer = layers[i]
        local def = layer.def
        if def then
            local alpha = def.alpha or 1
            if def.pulse then
                local wave = moving and (0.5 + 0.5 * sin(clock * def.pulse[3] * rush)) or 0.6
                alpha = alpha * (def.pulse[1] + (def.pulse[2] - def.pulse[1]) * wave)
            end
            if def.spin and moving then
                layer.angle = (layer.angle + def.spin * dt * rush) % (2 * pi)
                layer.tex:SetRotation(layer.angle)
            end
            if def.flicker and moving then
                layer.jump = layer.jump - dt
                if layer.jump <= 0 then
                    layer.jump = 0.25 + random() * 0.6
                    layer.tex:SetRotation(random() * 2 * pi)
                end
                local f = abs(sin(clock * 19) * sin(clock * 7.7))
                alpha = alpha * (f > 0.22 and f or 0.06)
            end
            if def.glow and not def.raw then
                local c = def.color or theme.color
                local m = 0.6 * combatMix
                layer.tex:SetVertexColor(c[1] + (1 - c[1]) * m, c[2] + (0.15 - c[2]) * m, c[3] + (0.1 - c[3]) * m, 1)
            end
            layer.tex:SetAlpha(Clamp(alpha, 0, 1))
        end
    end

    local def = theme.particles
    local show = def ~= nil and moving and db.particles
    for i = 1, MAX_PARTICLES do
        local p = particles[i]
        if p.active and show then
            local x, y, alpha, grow = 0, 0, 1, 1
            if def.mode == "orbit" then
                p.angle = p.angle + (def.speed or 0.2) * (1 + 0.08 * i) * dt * rush
                local r = diameter * (p.radius + sin(clock * 0.45 + i) * 0.004)
                x, y = cos(p.angle) * r, sin(p.angle) * r
                alpha = 0.35 + 0.45 * (0.5 + 0.5 * sin(clock * 1.25 + i))
            else
                p.age = p.age + dt * rush
                if p.age >= p.life then ResetParticle(p, def, i, false) end
                local phase = sin(pi * p.age / p.life)
                x, y = cos(p.angle) * diameter * p.radius, sin(p.angle) * diameter * p.radius
                if def.mode == "twinkle" then
                    alpha = phase * phase
                    grow = 0.55 + 0.75 * phase
                else
                    local drift = p.age * diameter * 0.03 * math.max(0.3, abs(def.speed or 1))
                    y = y + (def.mode == "rise" and drift or -drift)
                    x = x + sin(p.age * 2.6 + p.seed) * diameter * (def.mode == "fall" and 0.012 or 0.006)
                    alpha = phase
                end
            end
            local size = diameter * def.size * grow
            p.tex:SetSize(size, size)
            p.tex:ClearAllPoints()
            p.tex:SetPoint("CENTER", root, "CENTER", x, y)
            p.tex:SetAlpha(Clamp(alpha, 0, 1))
            p.tex:Show()
        else
            p.tex:Hide()
        end
    end
end

local function Redraw()
    if not root then return end
    ApplyTheme()
    root:SetAlpha(db.opacity)
    UpdateVisibility()
    Animate(0)
end

local function CreateRing()
    root = CreateFrame("Frame", "SexierMapRing", MinimapCluster or UIParent)
    root:SetFrameStrata("MEDIUM")
    root:SetFrameLevel(8)
    root:EnableMouse(false)
    root:SetPoint("CENTER", Minimap, "CENTER", 0, 0)

    for i = 1, MAX_LAYERS do
        local tex = root:CreateTexture(nil, "ARTWORK", nil, i)
        tex:SetPoint("CENTER", root, "CENTER", 0, 0)
        layers[i] = { tex = tex, angle = 0, jump = 0 }
    end
    for i = 1, MAX_PARTICLES do
        local tex = root:CreateTexture(nil, "OVERLAY")
        tex:SetBlendMode("ADD")
        particles[i] = { tex = tex, active = false }
    end

    -- 30 frames per second at most, to stay light on the CPU.
    root:SetScript("OnUpdate", function(_, elapsed)
        tick = tick + elapsed
        if tick < TICK then return end
        local dt = math.min(tick, 0.25)
        tick = 0
        clock = clock + dt
        Resize(false) -- follows minimap resizing and Edit Mode changes
        if db.animated or combatMix > 0 or (inCombat and db.combat) then Animate(dt) end
    end)

    Minimap:HookScript("OnShow", UpdateVisibility)
    Minimap:HookScript("OnHide", UpdateVisibility)
    Redraw()
end

---------------------------------------------------------------------------
-- Options window
---------------------------------------------------------------------------

local function MakeButton(parent, width, height, text)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, height)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text or "")
    function b:Paint(hover)
        if self.selected then
            self.bg:SetColorTexture(0.62, 0.22, 0.5, 0.95)
        elseif hover then
            self.bg:SetColorTexture(0.26, 0.26, 0.32, 0.95)
        else
            self.bg:SetColorTexture(0.14, 0.14, 0.18, 0.95)
        end
    end
    b:SetScript("OnEnter", function(self) self:Paint(true) end)
    b:SetScript("OnLeave", function(self) self:Paint(false) end)
    b:Paint(false)
    return b
end

local function RefreshOptions()
    if not options or not options:IsShown() then return end
    for _, b in ipairs(options.themeButtons) do
        b.selected = (db.theme == b.setting)
        b.label:SetText(SettingLabel(b.setting))
        b:Paint(false)
    end
    for _, b in ipairs(options.toggles) do
        b.selected = db[b.field] and true or false
        b.label:SetText(b.title .. (db[b.field] and ": on" or ": off"))
        b:Paint(false)
    end
    options.scaleText:SetText(string.format("Size %d%%", math.floor(db.scale * 100 + 0.5)))
    options.alphaText:SetText(string.format("Opacity %d%%", math.floor(db.opacity * 100 + 0.5)))
end

local function CreateOptions()
    local f = CreateFrame("Frame", "SexierMapOptions", UIParent)
    local settings = { "class", "faction" }
    for _, key in ipairs(ns.ThemeOrder) do settings[#settings + 1] = key end
    local rows = math.ceil(#settings / 2)
    f:SetSize(392, 150 + rows * 26)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)

    local border = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.62, 0.22, 0.5, 1)
    local bg = f:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 1, -1)
    bg:SetPoint("BOTTOMRIGHT", -1, 1)
    bg:SetColorTexture(0.04, 0.04, 0.06, 0.96)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("SexierMap")
    local close = MakeButton(f, 22, 20, "X")
    close:SetPoint("TOPRIGHT", -10, -10)
    close:SetScript("OnClick", function() f:Hide() end)

    local heading = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    heading:SetPoint("TOPLEFT", 14, -40)
    heading:SetText("Theme")

    f.themeButtons = {}
    for n, setting in ipairs(settings) do
        local b = MakeButton(f, 178, 22, "")
        local col, row = (n - 1) % 2, math.floor((n - 1) / 2)
        b:SetPoint("TOPLEFT", 14 + col * 186, -58 - row * 26)
        b.setting = setting
        b:SetScript("OnClick", function()
            db.theme = setting
            Redraw()
            RefreshOptions()
        end)
        f.themeButtons[n] = b
    end

    local y = -58 - rows * 26 - 10
    f.toggles = {}
    local toggles = {
        { "enabled", "Ring" }, { "animated", "Animation" }, { "particles", "Particles" }, { "combat", "Combat flare" },
    }
    for n, info in ipairs(toggles) do
        local b = MakeButton(f, 86, 22, "")
        b:SetPoint("TOPLEFT", 14 + (n - 1) * 92, y)
        b.field, b.title = info[1], info[2]
        b:SetScript("OnClick", function()
            db[info[1]] = not db[info[1]]
            Redraw()
            RefreshOptions()
        end)
        f.toggles[n] = b
    end

    local function Stepper(x, getText, change)
        local minus = MakeButton(f, 22, 22, "-")
        minus:SetPoint("TOPLEFT", x, y - 32)
        local text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        text:SetPoint("LEFT", minus, "RIGHT", 6, 0)
        text:SetWidth(96)
        text:SetJustifyH("CENTER")
        local plus = MakeButton(f, 22, 22, "+")
        plus:SetPoint("LEFT", text, "RIGHT", 6, 0)
        minus:SetScript("OnClick", function() change(-1) Redraw() RefreshOptions() end)
        plus:SetScript("OnClick", function() change(1) Redraw() RefreshOptions() end)
        return text
    end
    f.scaleText = Stepper(14, nil, function(dir) db.scale = Clamp(db.scale + dir * 0.05, 0.6, 1.8) end)
    f.alphaText = Stepper(200, nil, function(dir) db.opacity = Clamp(db.opacity + dir * 0.05, 0.2, 1.0) end)

    local hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("BOTTOMLEFT", 14, 8)
    hint:SetText("/smap opens this window. /smap help lists the chat commands.")

    f:SetScript("OnShow", RefreshOptions)
    f:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "SexierMapOptions") end
    return f
end

local function ToggleOptions()
    if not options then options = CreateOptions() end
    if options:IsShown() then options:Hide() else options:Show() end
end

function SexierMap_OnCompartmentClick()
    if db then ToggleOptions() end
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------

local function ShowHelp()
    Say("/smap opens the options window.")
    Say("/smap theme <name> picks a theme: class, faction, " .. table.concat(ns.ThemeOrder, ", ") .. ".")
    Say("/smap next switches to the next theme.")
    Say("/smap on, off or toggle shows or hides the ring.")
    Say("/smap animate, particles or combat turns that effect on or off.")
    Say("/smap scale 1.0 sets the size (0.6 to 1.8). /smap alpha 0.9 sets the opacity (0.2 to 1).")
    Say("/smap reset restores the defaults. /smap status shows the settings.")
end

local function SetTheme(setting)
    if setting ~= "class" and setting ~= "faction" and not ns.Themes[setting] then
        Say("Unknown theme. Try: class, faction, " .. table.concat(ns.ThemeOrder, ", ") .. ".")
        return false
    end
    db.theme = setting
    return true
end

SLASH_SEXIERMAP1 = "/smap"
SLASH_SEXIERMAP2 = "/sexiermap"
SLASH_SEXIERMAP3 = "/felmap"
SlashCmdList.SEXIERMAP = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command, arg = string.match(string.lower(message or ""), "^%s*(%S*)%s*(%S*)")
    if command == "" or command == "options" or command == "config" then
        ToggleOptions()
        return
    elseif command == "on" then
        db.enabled = true
    elseif command == "off" then
        db.enabled = false
    elseif command == "toggle" then
        db.enabled = not db.enabled
    elseif command == "animate" or command == "particles" or command == "combat" then
        local field = command == "animate" and "animated" or command
        if arg == "on" then db[field] = true
        elseif arg == "off" then db[field] = false
        else db[field] = not db[field] end
    elseif command == "theme" then
        if not SetTheme(arg) then return end
    elseif command == "next" then
        local list = { "class", "faction" }
        for _, key in ipairs(ns.ThemeOrder) do list[#list + 1] = key end
        local index = 1
        for i, key in ipairs(list) do
            if key == db.theme then index = i break end
        end
        db.theme = list[index % #list + 1]
    elseif command == "scale" then
        local n = tonumber(arg)
        if not n then Say("Example: /smap scale 1.2") return end
        db.scale = Clamp(n, 0.6, 1.8)
    elseif command == "alpha" or command == "opacity" then
        local n = tonumber(arg)
        if not n then Say("Example: /smap alpha 0.8") return end
        db.opacity = Clamp(n, 0.2, 1.0)
    elseif command == "reset" then
        for key, value in pairs(defaults) do db[key] = value end
    elseif command == "status" then
        Say(string.format("%s | theme %s | animation %s | particles %s | combat flare %s | size %.2f | opacity %.2f",
            db.enabled and "visible" or "hidden", SettingLabel(db.theme), db.animated and "on" or "off",
            db.particles and "on" or "off", db.combat and "on" or "off", db.scale, db.opacity))
        return
    elseif ns.Themes[command] or command == "class" or command == "faction" then
        db.theme = command
    else
        ShowHelp()
        return
    end
    Redraw()
    RefreshOptions()
    Say("Theme: " .. SettingLabel(db.theme) .. ".")
end

---------------------------------------------------------------------------
-- Startup
---------------------------------------------------------------------------

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:RegisterEvent("PLAYER_REGEN_DISABLED")
loader:RegisterEvent("PLAYER_REGEN_ENABLED")
loader:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_DISABLED" then
        inCombat = true
        return
    elseif event == "PLAYER_REGEN_ENABLED" then
        inCombat = false
        return
    end
    SexierMapDB = type(SexierMapDB) == "table" and SexierMapDB or {}
    db = SexierMapDB
    -- First run after the rename: carry over the old FelSummonMinimap settings and keep its look.
    if not db.migrated then
        db.migrated = true
        if type(FelSummonDB) == "table" then
            for _, key in ipairs({ "enabled", "animated", "scale", "opacity" }) do
                if type(FelSummonDB[key]) == type(defaults[key]) then db[key] = FelSummonDB[key] end
            end
        end
    end
    for key, value in pairs(defaults) do
        if type(db[key]) ~= type(value) then db[key] = value end
    end
    db.scale = Clamp(db.scale, 0.6, 1.8)
    db.opacity = Clamp(db.opacity, 0.2, 1.0)
    if Minimap then CreateRing() end
end)
