-- DungeonGuide for World of Warcraft: Forever (Interface 16001)
-- A dungeon atlas: the map of every dungeon and raid floor, with every boss marked on it.
-- Display only. The maps are the game's own dungeon map textures, loaded by file ID.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\DungeonGuide\\Textures\\"
local PREFIX = "|cffe8b04fDungeonGuide:|r "
local MAP_SCALE = 0.62
local MAP_W, MAP_H = math.floor(1002 * MAP_SCALE), math.floor(668 * MAP_SCALE)
local LIST_W, BOSS_W = 190, 210
local LIST_ROWS, BOSS_ROWS = 27, 27
local ROW_H = 16
local MAX_FLOORS, MAX_PINS = 7, 24

local db
local frame
local current, currentFloor = nil, 1
local listOffset = 0
local entries = {}

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

-- The instance the player is in, as the instance map ID, or nil.
local function CurrentInstanceID()
    if type(GetInstanceInfo) ~= "function" then return nil end
    local ok, _, instanceType, _, _, _, _, _, instanceID = pcall(GetInstanceInfo)
    if not ok or IsSecret(instanceID) or IsSecret(instanceType) then return nil end
    if instanceType ~= "party" and instanceType ~= "raid" then return nil end
    return type(instanceID) == "number" and instanceID or nil
end

local function FindDungeon(id)
    for _, d in ipairs(ns.Dungeons) do
        if d.id == id then return d end
    end
    return nil
end

-- The list shows a "Dungeons" header, the dungeons, a "Raids" header, then the raids.
local function BuildEntries()
    entries = { { header = "Dungeons" } }
    local raidHeader = false
    for _, d in ipairs(ns.Dungeons) do
        if d.raid and not raidHeader then
            raidHeader = true
            entries[#entries + 1] = { header = "Raids" }
        end
        entries[#entries + 1] = { dungeon = d }
    end
end

---------------------------------------------------------------------------
-- Widgets
---------------------------------------------------------------------------

local function MakeButton(parent, width, height, text)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, height)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("LEFT", 6, 0)
    b.label:SetPoint("RIGHT", -6, 0)
    b.label:SetJustifyH("LEFT")
    b.label:SetWordWrap(false)
    b.label:SetText(text or "")
    function b:Paint(hover)
        if self.selected then
            self.bg:SetColorTexture(0.55, 0.38, 0.1, 0.95)
        elseif hover then
            self.bg:SetColorTexture(0.24, 0.22, 0.2, 0.95)
        else
            self.bg:SetColorTexture(0.1, 0.09, 0.08, 0.85)
        end
    end
    b:SetScript("OnEnter", function(self) self:Paint(true) end)
    b:SetScript("OnLeave", function(self) self:Paint(false) end)
    b:Paint(false)
    return b
end

local Refresh

local function Select(dungeon, floor)
    current = dungeon
    currentFloor = floor or 1
    if dungeon then db.last = dungeon.id end
    Refresh()
end

local function PinOnEnter(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(self.number .. ". " .. self.bossName, 1, 0.82, 0)
    GameTooltip:Show()
end

local function PinOnLeave()
    GameTooltip:Hide()
end

local function CreateWindow()
    local f = CreateFrame("Frame", "DungeonGuideFrame", UIParent)
    f:SetSize(12 + LIST_W + 10 + MAP_W + 10 + BOSS_W + 12, 76 + MAP_H + 30)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
            db.pos = { point, relPoint, x, y }
        end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
        f:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
    end

    local border = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.55, 0.42, 0.18, 1)
    local bg = f:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 1, -1)
    bg:SetPoint("BOTTOMRIGHT", -1, 1)
    bg:SetColorTexture(0.05, 0.045, 0.04, 0.97)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOPLEFT", 14, -12)
    f.title:SetText("DungeonGuide")
    local close = MakeButton(f, 22, 20, "X")
    close.label:SetJustifyH("CENTER")
    close:SetPoint("TOPRIGHT", -10, -10)
    close:SetScript("OnClick", function() f:Hide() end)
    local here = MakeButton(f, 96, 20, "Where am I?")
    here:SetPoint("RIGHT", close, "LEFT", -8, 0)
    here:SetScript("OnClick", function()
        local d = FindDungeon(CurrentInstanceID())
        if d then Select(d, 1) else Say("you are not inside a dungeon or raid this guide knows.") end
    end)

    -- Dungeon list, scrolled with the mouse wheel
    f.list = {}
    local listTop = -44
    for i = 1, LIST_ROWS do
        local b = MakeButton(f, LIST_W, ROW_H - 1, "")
        b:SetPoint("TOPLEFT", 12, listTop - (i - 1) * ROW_H)
        b:SetScript("OnClick", function(self)
            if self.dungeon then Select(self.dungeon, 1) end
        end)
        f.list[i] = b
    end
    f:EnableMouseWheel(true)
    f:SetScript("OnMouseWheel", function(_, delta)
        listOffset = math.max(0, math.min(#entries - LIST_ROWS, listOffset - delta * 3))
        Refresh()
    end)

    -- Map area
    local mapLeft = 12 + LIST_W + 10
    f.name = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.name:SetPoint("TOPLEFT", mapLeft, -44)
    f.floors = {}
    for i = 1, MAX_FLOORS do
        local b = MakeButton(f, 86, 18, "")
        b:SetScript("OnClick", function(self) Select(current, self.floor) end)
        -- Names can be cut short when many floors share the row, so the tooltip shows the full name.
        b:SetScript("OnEnter", function(self)
            self:Paint(true)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:SetText(self.fullName or "", 1, 1, 1)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave", function(self)
            self:Paint(false)
            GameTooltip:Hide()
        end)
        f.floors[i] = b
    end
    f.map = CreateFrame("Frame", nil, f)
    f.map:SetSize(MAP_W, MAP_H)
    f.map:SetPoint("TOPLEFT", mapLeft, -76)
    if type(f.map.SetClipsChildren) == "function" then f.map:SetClipsChildren(true) end
    local mapBg = f.map:CreateTexture(nil, "BACKGROUND")
    mapBg:SetAllPoints()
    mapBg:SetColorTexture(0, 0, 0, 0.6)
    f.tiles = {}
    local tile = 256 * MAP_SCALE
    for row = 0, 2 do
        for col = 0, 3 do
            local t = f.map:CreateTexture(nil, "ARTWORK")
            t:SetSize(tile, tile)
            t:SetPoint("TOPLEFT", col * tile, -row * tile)
            f.tiles[#f.tiles + 1] = t
        end
    end
    f.noMap = f.map:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    f.noMap:SetPoint("CENTER")
    f.noMap:SetWidth(MAP_W - 60)
    f.noMap:SetText("There is no map for this dungeon in the game files yet.\nIts bosses are listed on the right.")
    f.pins = {}
    for i = 1, MAX_PINS do
        local pin = CreateFrame("Frame", nil, f.map)
        pin:SetSize(20, 20)
        pin:SetFrameLevel(f.map:GetFrameLevel() + 5)
        pin.icon = pin:CreateTexture(nil, "OVERLAY")
        pin.icon:SetAllPoints()
        pin.icon:SetTexture(TEXTURES .. "Pin.tga")
        pin.icon:SetVertexColor(0.85, 0.12, 0.08, 1)
        pin.text = pin:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        pin.text:SetPoint("CENTER", 0, 0)
        pin:EnableMouse(true)
        pin:SetScript("OnEnter", PinOnEnter)
        pin:SetScript("OnLeave", PinOnLeave)
        f.pins[i] = pin
    end

    -- Boss list
    local bossLeft = mapLeft + MAP_W + 10
    local bossTitle = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    bossTitle:SetPoint("TOPLEFT", bossLeft, -44)
    bossTitle:SetText("Bosses")
    f.bosses = {}
    for i = 1, BOSS_ROWS do
        local b = MakeButton(f, BOSS_W, ROW_H - 1, "")
        b:SetPoint("TOPLEFT", bossLeft, -62 - (i - 1) * ROW_H)
        b:SetScript("OnClick", function(self)
            if self.floor and self.floor ~= currentFloor then Select(current, self.floor) end
        end)
        f.bosses[i] = b
    end

    f.note = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.note:SetPoint("BOTTOMLEFT", 12, 9)
    f.note:SetPoint("RIGHT", -12, 0)
    f.note:SetJustifyH("LEFT")
    f.note:SetText("Click a boss on another floor to jump to it. Scroll the dungeon list with the mouse wheel. Boss positions: CMaNGOS classic-db (GPL-3.0).")

    f:SetScript("OnShow", function() Refresh() end)
    f:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "DungeonGuideFrame") end
    return f
end

---------------------------------------------------------------------------
-- Drawing
---------------------------------------------------------------------------

Refresh = function()
    if not frame or not frame:IsShown() then return end

    -- List
    for i = 1, LIST_ROWS do
        local b, e = frame.list[i], entries[i + listOffset]
        if e then
            b.dungeon = e.dungeon
            if e.header then
                b.label:SetText("|cffffd100" .. e.header .. "|r")
                b.selected = false
                b:EnableMouse(false)
                b.bg:SetColorTexture(0, 0, 0, 0)
            else
                b.label:SetText(e.dungeon.name .. (#e.dungeon.floors == 0 and " |cff9d9d9d(no map)|r" or ""))
                b.selected = (e.dungeon == current)
                b:EnableMouse(true)
                b:Paint(false)
            end
            b:Show()
        else
            b:Hide()
        end
    end

    local d = current
    if not d then
        frame.name:SetText("Pick a dungeon on the left.")
        for _, b in ipairs(frame.floors) do b:Hide() end
        for _, t in ipairs(frame.tiles) do t:Hide() end
        for _, p in ipairs(frame.pins) do p:Hide() end
        for _, b in ipairs(frame.bosses) do b:Hide() end
        frame.noMap:Hide()
        return
    end
    frame.name:SetText(d.name .. (d.raid and "  |cff9d9d9d(raid)|r" or ""))

    -- Floors
    local floors = d.floors
    if currentFloor > #floors then currentFloor = 1 end
    -- Floor buttons size to their names, and share the map's width evenly when they would not fit.
    local count = (#floors > 1) and math.min(#floors, MAX_FLOORS) or 0
    local widths, total = {}, 0
    for i = 1, count do
        frame.floors[i].label:SetText(floors[i][1])
        widths[i] = math.min(150, math.max(60, (frame.floors[i].label:GetStringWidth() or 60) + 14))
        total = total + widths[i] + 4
    end
    local even = count > 0 and math.floor((MAP_W - 4 * (count - 1)) / count) or 0
    local x = 0
    for i, b in ipairs(frame.floors) do
        if i <= count then
            local width = total > MAP_W and even or widths[i]
            b.floor = i
            b.fullName = floors[i][1]
            b:SetWidth(width)
            b:ClearAllPoints()
            b:SetPoint("TOPLEFT", frame.map, "TOPLEFT", x, 22)
            x = x + width + 4
            b.selected = (i == currentFloor)
            b:Paint(false)
            b:Show()
        else
            b:Hide()
        end
    end

    -- Map tiles
    local fl = floors[currentFloor]
    if fl then
        local ids = { strsplit(",", fl[2]) }
        for i, t in ipairs(frame.tiles) do
            local id = tonumber(ids[i])
            if id then
                t:SetTexture(id)
                t:Show()
            else
                t:Hide()
            end
        end
        frame.noMap:Hide()
    else
        for _, t in ipairs(frame.tiles) do t:Hide() end
        frame.noMap:Show()
    end

    -- Pins and boss list
    local used = 0
    for i, boss in ipairs(d.bosses) do
        if fl and boss[2] == currentFloor and used < MAX_PINS then
            used = used + 1
            local pin = frame.pins[used]
            pin.number, pin.bossName = i, boss[1]
            pin.text:SetText(i)
            pin:ClearAllPoints()
            pin:SetPoint("CENTER", frame.map, "TOPLEFT", boss[3] * 1002 * MAP_SCALE, -boss[4] * 668 * MAP_SCALE)
            pin:Show()
        end
    end
    for i = used + 1, MAX_PINS do frame.pins[i]:Hide() end

    for i = 1, BOSS_ROWS do
        local b, boss = frame.bosses[i], d.bosses[i]
        if boss then
            b.floor = boss[2]
            local text = i .. ". " .. boss[1]
            if not boss[2] then
                text = text .. " |cff9d9d9d(no pin)|r"
            elseif boss[2] ~= currentFloor and floors[boss[2]] then
                text = text .. " |cff9d9d9d(" .. floors[boss[2]][1] .. ")|r"
            end
            b.label:SetText(text)
            b.selected = (boss[2] == currentFloor and fl ~= nil)
            b:Paint(false)
            b:Show()
        else
            b:Hide()
        end
    end
end

local function Toggle(dungeon)
    if not db then return end
    if not frame then frame = CreateWindow() end
    if dungeon then
        current, currentFloor = dungeon, 1
        db.last = dungeon.id
        frame:Show()
        Refresh()
        return
    end
    if frame:IsShown() then
        frame:Hide()
    else
        -- Open on the dungeon you are standing in, else the last one you looked at.
        local d = FindDungeon(CurrentInstanceID()) or FindDungeon(db.last)
        if d and d ~= current then current, currentFloor = d, 1 end
        frame:Show()
    end
end

function DungeonGuide_OnCompartmentClick()
    Toggle()
end

---------------------------------------------------------------------------
-- Slash commands and events
---------------------------------------------------------------------------

SLASH_DUNGEONGUIDE1 = "/dg"
SLASH_DUNGEONGUIDE2 = "/dungeonguide"
SlashCmdList.DUNGEONGUIDE = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local text = string.lower(strtrim and strtrim(message or "") or (message or ""))
    if text == "" then
        Toggle()
    elseif text == "auto" then
        db.auto = not db.auto
        Say("open automatically when you enter a dungeon: " .. (db.auto and "on." or "off."))
    elseif text == "reset" then
        db.pos = nil
        if frame then
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
        end
        Say("window position reset.")
    elseif text == "help" then
        Say("/dg opens or closes the guide. /dg <name> opens a dungeon, for example /dg deadmines.")
        Say("/dg auto opens the guide when you enter a dungeon. /dg reset moves the window back to the middle.")
    else
        for _, d in ipairs(ns.Dungeons) do
            if string.find(string.lower(d.name), text, 1, true) then
                Toggle(d)
                return
            end
        end
        Say("no dungeon matches \"" .. text .. "\". Type /dg help for the commands.")
    end
end

local lastInstance
local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        DungeonGuideDB = type(DungeonGuideDB) == "table" and DungeonGuideDB or {}
        db = DungeonGuideDB
        if type(db.auto) ~= "boolean" then db.auto = false end
        BuildEntries()
        return
    end
    if not db then return end
    local id = CurrentInstanceID()
    if id ~= lastInstance then
        lastInstance = id
        local d = FindDungeon(id)
        if d and db.auto then Toggle(d) end
    end
end)
