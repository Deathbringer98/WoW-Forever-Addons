DungeonGuide 1.0.0 - World of Warcraft: Forever (Interface 16001)
================================================================

A dungeon atlas for WoW Forever. Pick any dungeon or raid to see its map,
floor by floor, with every boss marked by a numbered pin.

INSTALL
Copy the DungeonGuide folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

HOW TO USE
/dg                open or close the guide. It opens on the dungeon you are
                   in, or the last one you looked at.
/dg deadmines      open a dungeon by name (any part of the name works)
/dg auto           open the guide by itself whenever you enter a dungeon
/dg reset          move the window back to the middle
/dg help           list the commands
/dungeonguide also works, and so does the addon button by the minimap.

In the window:
- The list on the left has every dungeon, then every raid. Scroll it
  with the mouse wheel.
- Multi-floor dungeons have a button for each floor above the map.
- Pins are numbered to match the boss list on the right. Hover a pin
  for the boss name.
- A boss on another floor shows that floor's name in grey. Click it to
  jump to that floor.
- "Where am I?" jumps to the dungeon you are standing in.

WHAT IS COVERED
- 26 classic dungeons and raids have full maps: Ragefire Chasm through
  Naxxramas.
- Dungeons that are new in WoW Forever (Demon Fall Canyon, Karazhan
  Crypts, Scarlet Enclave and others) have no map in the game files yet.
  For those the guide lists the bosses only.
- Some bosses have no pin, for example event or summoned bosses, and the
  Upper Blackrock Spire bosses, which are not drawn on the Blackrock Spire
  maps. They are still listed.

ACCURACY
- Boss positions come from where each boss spawns in the original game.
  WoW Forever may have moved some of them.
- In dungeons where several floors share the same space (Shadowfang Keep,
  Blackfathom Deeps, Scholomance and a few others) the floor for a few
  bosses was worked out from the map art and nearby bosses. A handful may
  show on the wrong floor.

WHERE THE DATA COMES FROM
- Maps: the game's own dungeon map textures, loaded from the game files by
  file ID. No map images are shipped with this addon.
- Dungeon and boss lists: the WoW Forever game client's own data, read
  through wago.tools.
- Boss positions: the CMaNGOS classic-db world database.
  https://github.com/cmangos/classic-db

LICENSE
The boss position data is derived from CMaNGOS classic-db, which is
licensed under the GNU General Public License v3.0, so this addon is
distributed under GPL-3.0 as well.
  https://www.gnu.org/licenses/gpl-3.0.html

CREDITS
Addon: Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Boss positions: the CMaNGOS project and its contributors
Maps and game data: Blizzard Entertainment, read via wago.tools
