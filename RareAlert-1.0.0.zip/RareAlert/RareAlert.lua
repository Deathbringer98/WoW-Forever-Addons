-- Rare Alert for World of Warcraft: Forever (Interface 16001)
-- Warns you the moment a rare mob shows up near you, and lists the rares of the zone you are in
-- with their known spawn spots. Detection uses nameplates, your target, mouseover and minimap
-- vignettes. Out of combat only: the game hides who a mob is while you are fighting.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\"
local PREFIX = "|cffff9f3fRare Alert:|r "
local ALERT_SECONDS = 25
local SAME_MOB_SECONDS = 300      -- the same spawned mob alerts once per 5 minutes
local SAME_KIND_SECONDS = 60      -- the same kind of rare alerts once a minute
local MAX_ROWS = 14
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

local db
local panel, alert, targetButton, minimapButton
local alertedGUID, alertedNPC = {}, {}
local pendingTargetHide = false

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, v = pcall(fn, ...)
    if not ok or IsSecret(v) then return nil end
    return v
end

local function Now()
    return (type(GetTime) == "function" and GetTime()) or 0
end

local function Ago(seconds)
    if seconds < 90 then return "just now" end
    if seconds < 3600 then return math.floor(seconds / 60) .. " min ago" end
    if seconds < 86400 then return math.floor(seconds / 3600) .. " h ago" end
    return math.floor(seconds / 86400) .. " days ago"
end

-- NPC ID from a creature GUID ("Creature-0-1-2-3-<npcID>-<spawn>"), or nil.
local function NpcID(guid)
    if type(guid) ~= "string" or IsSecret(guid) then return nil end
    local kind, _, _, _, _, id = strsplit("-", guid)
    if kind ~= "Creature" and kind ~= "Vehicle" then return nil end
    return tonumber(id)
end

-- The zone map the player is on, walking up from a city or cave map when needed.
local function PlayerZone()
    local id = Plain(C_Map.GetBestMapForUnit, "player")
    local guard = 0
    while id and not ns.ZoneRares[id] and not ns.ZoneSize[id] and guard < 5 do
        local info = Plain(C_Map.GetMapInfo, id)
        id = info and not IsSecret(info.parentMapID) and info.parentMapID or nil
        guard = guard + 1
    end
    return id
end

local function PlayerPosition(mapID)
    if not mapID then return nil end
    local pos = Plain(C_Map.GetPlayerMapPosition, mapID, "player")
    if type(pos) ~= "table" or type(pos.GetXY) ~= "function" then return nil end
    local ok, x, y = pcall(pos.GetXY, pos)
    if not ok or IsSecret(x) or IsSecret(y) or type(x) ~= "number" or type(y) ~= "number" or (x == 0 and y == 0) then return nil end
    return x, y
end

local function ZoneName(mapID)
    local info = mapID and Plain(C_Map.GetMapInfo, mapID)
    local name = info and info.name
    if type(name) == "string" and not IsSecret(name) then return name end
    return "this zone"
end

local function Sound(kit)
    if not db.sound then return end
    if type(SOUNDKIT) == "table" and SOUNDKIT[kit] and type(PlaySound) == "function" then
        pcall(PlaySound, SOUNDKIT[kit], "Master")
    end
end

-- Puts a map pin (the yellow waypoint arrow) on a spot of a zone map.
local function SetWaypoint(mapID, x, y, label)
    if not (mapID and x and y and type(UiMapPoint) == "table" and type(C_Map.SetUserWaypoint) == "function") then
        Say("map pins are not available here.")
        return
    end
    local ok = pcall(function()
        C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(mapID, x, y))
        if type(C_SuperTrack) == "table" and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
    end)
    if ok then
        Say(string.format("map pin set for %s at %.1f, %.1f.", label or "the rare", x * 100, y * 100))
    else
        Say("could not set a map pin on this map.")
    end
end

-- Unpacks "xxyy" base-36 spawn spots into { {x, y}, ... }.
local function Spots(packed)
    local out = {}
    for at = 1, #packed, 4 do
        out[#out + 1] = { tonumber(packed:sub(at, at + 1), 36) / 1000, tonumber(packed:sub(at + 2, at + 3), 36) / 1000 }
    end
    return out
end

local COMPASS = { "N", "NE", "E", "SE", "S", "SW", "W", "NW" }

-- Nearest known spot to the player: spot, yards, compass direction.
local function Nearest(mapID, packed)
    local spots = Spots(packed)
    local px, py = PlayerPosition(mapID)
    local size = ns.ZoneSize[mapID]
    if not px or not size then return spots[1], nil, nil end
    local best, dist
    for _, s in ipairs(spots) do
        local dx, dy = (s[1] - px) * size[1], (s[2] - py) * size[2]
        local d = math.sqrt(dx * dx + dy * dy)
        if not dist or d < dist then best, dist = s, d end
    end
    local dx, dy = (best[1] - px) * size[1], (py - best[2]) * size[2]
    local angle = math.deg(atan2(dx, dy)) % 360
    return best, dist, COMPASS[math.floor((angle + 22.5) / 45) % 8 + 1]
end

---------------------------------------------------------------------------
-- The alert
---------------------------------------------------------------------------

local function Button(parent, width, text, onClick, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 20)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.18, 0.11, 0.05, 0.95)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text)
    b.tip = tip
    b:SetScript("OnEnter", function(self)
        bg:SetColorTexture(0.4, 0.24, 0.08, 0.95)
        if self.tip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.tip, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function()
        bg:SetColorTexture(0.18, 0.11, 0.05, 0.95)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", onClick)
    return b
end

local function HideTarget()
    if not targetButton then return end
    if InCombatLockdown() then
        -- A secure button cannot be hidden in combat; make it see-through and hide it afterwards.
        targetButton:SetAlpha(0)
        pendingTargetHide = true
    else
        targetButton:Hide()
        targetButton:SetAlpha(1)
        pendingTargetHide = false
    end
end

local function HideAlert()
    if alert then alert:Hide() end
    HideTarget()
end

local function CreateAlert()
    local a = CreateFrame("Frame", "RareAlertBanner", UIParent)
    a:SetSize(380, 74)
    a:SetPoint("TOP", UIParent, "TOP", 0, -150)
    a:SetFrameStrata("HIGH")
    a:EnableMouse(true)
    local border = a:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.85, 0.55, 0.15, 1)
    local bg = a:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 2, -2)
    bg:SetPoint("BOTTOMRIGHT", -2, 2)
    bg:SetColorTexture(0.07, 0.04, 0.03, 0.95)
    a.icon = a:CreateTexture(nil, "ARTWORK")
    a.icon:SetSize(40, 40)
    a.icon:SetPoint("LEFT", 12, 6)
    a.icon:SetTexture(TEXTURES .. "Rare.tga")
    a.icon:SetVertexColor(1, 0.75, 0.25, 1)
    a.title = a:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    a.title:SetPoint("TOPLEFT", 62, -10)
    a.title:SetPoint("RIGHT", -10, 0)
    a.title:SetJustifyH("LEFT")
    a.title:SetWordWrap(false)
    a.sub = a:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    a.sub:SetPoint("TOPLEFT", a.title, "BOTTOMLEFT", 0, -3)
    a.sub:SetPoint("RIGHT", -10, 0)
    a.sub:SetJustifyH("LEFT")
    a.sub:SetWordWrap(false)
    a.pin = Button(a, 84, "Map pin", function()
        if a.mapID then SetWaypoint(a.mapID, a.x, a.y, a.name) end
    end, "Puts a pin on your map where the rare was spotted.")
    a.pin:SetPoint("BOTTOMRIGHT", -98, 8)
    a.close = Button(a, 84, "Dismiss", HideAlert)
    a.close:SetPoint("BOTTOMRIGHT", -10, 8)
    a:SetScript("OnUpdate", function(self)
        -- Stays up while you are in combat or hovering it.
        if self.expires and Now() > self.expires and not InCombatLockdown() and not self:IsMouseOver() then HideAlert() end
    end)
    a:Hide()
    alert = a

    -- Clicking a secure button is the only way an addon may target a mob for you.
    local t = CreateFrame("Button", "RareAlertTargetButton", UIParent, "SecureActionButtonTemplate")
    t:SetSize(84, 20)
    t:SetFrameStrata("DIALOG")
    t:SetPoint("BOTTOMLEFT", a, "BOTTOMLEFT", 62, 8)
    t:RegisterForClicks("AnyUp", "AnyDown")
    t:SetAttribute("type", "macro")
    local tbg = t:CreateTexture(nil, "BACKGROUND")
    tbg:SetAllPoints()
    tbg:SetColorTexture(0.55, 0.12, 0.08, 0.95)
    local tl = t:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    tl:SetPoint("CENTER")
    tl:SetText("Target it")
    t:Hide()
    targetButton = t
end

local function ShowAlert(info)
    if not alert then CreateAlert() end
    local a = alert
    a.name, a.mapID, a.x, a.y = info.name, info.mapID, info.x, info.y
    local level = info.level and ("level " .. info.level) or "level unknown"
    a.title:SetText("Rare: " .. (info.name or "unknown mob"))
    a.sub:SetText(level .. (info.elite and ", elite" or "") .. "  |cff9d9d9dspotted " .. (info.how or "nearby") .. " in " .. ZoneName(info.mapID) .. "|r")
    a.pin:SetShown(info.mapID ~= nil and info.x ~= nil)
    a.expires = Now() + ALERT_SECONDS
    a:Show()

    -- The target button can only be set up out of combat, and needs a name to target.
    if targetButton and not InCombatLockdown() and info.name then
        targetButton:SetAttribute("macrotext", "/targetexact " .. info.name)
        targetButton:SetAlpha(1)
        targetButton:Show()
        pendingTargetHide = false
    end

    if db.flash then
        if type(FlashClientIcon) == "function" then pcall(FlashClientIcon) end
        if type(RaidNotice_AddMessage) == "function" and RaidWarningFrame and type(ChatTypeInfo) == "table" then
            pcall(RaidNotice_AddMessage, RaidWarningFrame, "Rare nearby: " .. (info.name or "unknown"), ChatTypeInfo["RAID_WARNING"])
        end
    end
    Sound("RAID_WARNING")
    if db.chat then
        Say(string.format("|cffffd100%s|r (%s%s) spotted %s in %s.", info.name or "a rare mob", level, info.elite and ", elite" or "", info.how or "nearby", ZoneName(info.mapID)))
    end
end

---------------------------------------------------------------------------
-- Detection
---------------------------------------------------------------------------

local RefreshPanel

local function Remember(npcID, mapID, x, y)
    if not npcID then return end
    db.seen[npcID] = { t = (type(time) == "function" and time()) or 0, map = mapID, x = x, y = y }
end

-- Decides whether to alert for a mob. guid may be nil (vignettes without one).
local function Found(guid, npcID, name, level, elite, how, mapID, x, y)
    if not db.enabled then return end
    if npcID and db.ignore[npcID] then return end
    local now = Now()
    if guid and alertedGUID[guid] and now - alertedGUID[guid] < SAME_MOB_SECONDS then return end
    local kindKey = npcID or name or "?"
    if alertedNPC[kindKey] and now - alertedNPC[kindKey] < SAME_KIND_SECONDS then return end
    if guid then alertedGUID[guid] = now end
    alertedNPC[kindKey] = now
    Remember(npcID, mapID, x, y)
    ShowAlert({ name = name, level = level, elite = elite, how = how, mapID = mapID, x = x, y = y })
    if RefreshPanel then RefreshPanel() end
end

local HOW = { target = "as your target", mouseover = "under your mouse" }

local function CheckUnit(unit)
    if not db or not db.enabled or InCombatLockdown() then return end
    if Plain(UnitExists, unit) ~= true then return end
    if Plain(UnitIsPlayer, unit) == true then return end
    if Plain(UnitIsDead, unit) == true then return end
    local guid = Plain(UnitGUID, unit)
    local npcID = NpcID(guid)
    local known = npcID and ns.Rares[npcID]
    local class = Plain(UnitClassification, unit)
    local isRare = class == "rare" or class == "rareelite" or known ~= nil
    if not isRare then return end
    -- Friendly rares (some quest givers count as rare) are not worth an alarm.
    if Plain(UnitCanAttack, "player", unit) == false then return end
    local name = Plain(UnitName, unit)
    if type(name) ~= "string" then name = known and known[1] or nil end
    local level = Plain(UnitLevel, unit)
    if type(level) ~= "number" or level <= 0 then level = known and known[3] or nil end
    local elite = class == "rareelite" or (known and known[4]) or false
    local mapID = PlayerZone()
    local x, y = PlayerPosition(mapID)
    Found(guid, npcID, name, level, elite, HOW[unit] or "nearby", mapID, x, y)
end

local function CheckVignette(vignetteGUID)
    if not db or not db.enabled or InCombatLockdown() then return end
    if type(C_VignetteInfo) ~= "table" then return end
    local info = Plain(C_VignetteInfo.GetVignetteInfo, vignetteGUID)
    if type(info) ~= "table" then return end
    local npcID = NpcID(info.objectGUID)
    local known = npcID and ns.Rares[npcID]
    local atlas = type(info.atlasName) == "string" and not IsSecret(info.atlasName) and info.atlasName or ""
    if not known and not atlas:find("VignetteKill") then return end
    if info.isDead == true then return end
    local name = type(info.name) == "string" and not IsSecret(info.name) and info.name or (known and known[1])
    local mapID = PlayerZone()
    local x, y
    local pos = mapID and Plain(C_VignetteInfo.GetVignettePosition, vignetteGUID, mapID)
    if type(pos) == "table" and type(pos.GetXY) == "function" then
        local ok, vx, vy = pcall(pos.GetXY, pos)
        if ok and not IsSecret(vx) and type(vx) == "number" then x, y = vx, vy end
    end
    if not x then x, y = PlayerPosition(mapID) end
    Found(info.objectGUID, npcID, name, known and known[3], known and known[4], "on your minimap", mapID, x, y)
end

---------------------------------------------------------------------------
-- The zone panel
---------------------------------------------------------------------------

local SETTINGS = {
    { "enabled", "Alerts", "Warn me when a rare mob shows up near me." },
    { "sound", "Sound", "Play the raid warning sound with each alert." },
    { "flash", "Screen flash", "Big warning text on screen and a flashing taskbar icon." },
    { "chat", "Chat line", "Also write each alert in your chat window." },
    { "minimap", "Minimap button", "A button on the minimap that opens this panel. Drag it around the minimap to move it." },
}

local function CreatePanel()
    local p = CreateFrame("Frame", "RareAlertPanel", UIParent)
    p:SetSize(430, 120 + MAX_ROWS * 20 + 64)
    p:SetFrameStrata("HIGH")
    p:SetClampedToScreen(true)
    p:EnableMouse(true)
    p:SetMovable(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", p.StartMoving)
    p:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
            db.pos = { point, relPoint, x, y }
        end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
        p:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        p:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
    local border = p:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.85, 0.55, 0.15, 1)
    local bg = p:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 2, -2)
    bg:SetPoint("BOTTOMRIGHT", -2, 2)
    bg:SetColorTexture(0.06, 0.04, 0.03, 0.96)

    local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("Rare Alert")
    local close = Button(p, 22, "X", function() p:Hide() end)
    close:SetPoint("TOPRIGHT", -10, -10)
    local test = Button(p, 84, "Test alert", function()
        ShowAlert({ name = "Test Rare", level = 30, elite = true, how = "as a test", mapID = PlayerZone() })
    end, "Shows what an alert looks and sounds like.")
    test:SetPoint("RIGHT", close, "LEFT", -8, 0)

    p.zone = p:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    p.zone:SetPoint("TOPLEFT", 14, -44)
    p.zone:SetPoint("RIGHT", -14, 0)
    p.zone:SetJustifyH("LEFT")

    -- Settings buttons
    p.toggles = {}
    for i, s in ipairs(SETTINGS) do
        local b = Button(p, 78, "", function()
            db[s[1]] = not db[s[1]]
            if s[1] == "minimap" and ns.UpdateMinimapButton then ns.UpdateMinimapButton() end
            RefreshPanel()
        end, s[3])
        b:SetPoint("BOTTOMLEFT", 14 + (i - 1) * 82, 36)
        b.field, b.title = s[1], s[2]
        p.toggles[i] = b
    end

    -- Rows: name and level on the left, last seen and nearest spot on the right, a map pin button.
    p.rows = {}
    for i = 1, MAX_ROWS do
        local r = CreateFrame("Button", nil, p)
        r:SetSize(402, 19)
        r:SetPoint("TOPLEFT", 14, -66 - (i - 1) * 20)
        local rbg = r:CreateTexture(nil, "BACKGROUND")
        rbg:SetAllPoints()
        rbg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.04 or 0.0)
        r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.name:SetPoint("LEFT", 4, 0)
        r.name:SetWidth(180)
        r.name:SetJustifyH("LEFT")
        r.name:SetWordWrap(false)
        r.info = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        r.info:SetPoint("LEFT", 186, 0)
        r.info:SetWidth(156)
        r.info:SetJustifyH("LEFT")
        r.info:SetWordWrap(false)
        r.pin = Button(r, 52, "Pin", function(self)
            local row = self:GetParent()
            if row.spot then SetWaypoint(row.mapID, row.spot[1], row.spot[2], row.rareName) end
        end, "Puts a pin on your map at the nearest known spawn spot.")
        r.pin:SetPoint("RIGHT", 0, 0)
        r.pin:SetHeight(17)
        r:SetScript("OnEnter", function(self)
            if not self.npcID then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.rareName or "", 1, 0.82, 0)
            GameTooltip:AddLine(self.spotCount .. " known spawn spot" .. (self.spotCount == 1 and "" or "s") .. " in this zone.", 1, 1, 1)
            GameTooltip:AddLine("Right-click to " .. (db.ignore[self.npcID] and "stop ignoring it." or "ignore it (no more alerts)."), 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        r:SetScript("OnLeave", function() GameTooltip:Hide() end)
        r:RegisterForClicks("RightButtonUp")
        r:SetScript("OnClick", function(self)
            if not self.npcID then return end
            db.ignore[self.npcID] = (not db.ignore[self.npcID]) or nil
            RefreshPanel()
        end)
        p.rows[i] = r
    end
    p.empty = p:CreateFontString(nil, "OVERLAY", "GameFontDisable")
    p.empty:SetPoint("TOP", 0, -100)
    p.empty:SetWidth(380)

    p.note = p:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    p.note:SetPoint("BOTTOMLEFT", 14, 12)
    p.note:SetPoint("RIGHT", -14, 0)
    p.note:SetJustifyH("LEFT")
    p.note:SetText("Spawn spots: CMaNGOS classic-db (GPL-3.0). Alerts work out of combat.")

    local wait = 0
    p:SetScript("OnUpdate", function(_, elapsed)
        wait = wait + elapsed
        if wait >= 1 then wait = 0 RefreshPanel() end
    end)
    p:SetScript("OnShow", function() RefreshPanel() end)
    p:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "RareAlertPanel") end
    return p
end

RefreshPanel = function()
    if not panel or not panel:IsShown() then return end
    for _, b in ipairs(panel.toggles) do
        b.label:SetText(b.title .. ": " .. (db[b.field] and "on" or "off"))
    end
    local mapID = PlayerZone()
    local rares = mapID and ns.ZoneRares[mapID]
    local list = {}
    if rares then
        for npcID, packed in pairs(rares) do
            local r = ns.Rares[npcID]
            if r then list[#list + 1] = { id = npcID, name = r[1], min = r[2], max = r[3], elite = r[4], packed = packed } end
        end
    end
    table.sort(list, function(a, b) if a.min ~= b.min then return a.min < b.min end return a.name < b.name end)
    panel.zone:SetText("Rares in " .. ZoneName(mapID) .. "  |cff9d9d9d(" .. #list .. " known)|r")
    local now = (type(time) == "function" and time()) or 0
    for i, row in ipairs(panel.rows) do
        local e = list[i]
        if e then
            local spot, dist, dir = Nearest(mapID, e.packed)
            row.npcID, row.rareName, row.mapID, row.spot = e.id, e.name, mapID, spot
            row.spotCount = #e.packed / 4
            local level = e.min == e.max and tostring(e.min) or (e.min .. "-" .. e.max)
            local ignored = db.ignore[e.id]
            row.name:SetText((ignored and "|cff7f7f7f" or "") .. e.name .. "  |cffffd100" .. level .. (e.elite and " elite" or "") .. "|r" .. (ignored and " (ignored)|r" or ""))
            local seen = db.seen[e.id]
            local parts = {}
            if dist then parts[#parts + 1] = string.format("%d yd %s", math.floor(dist + 0.5), dir) end
            if seen and seen.t then parts[#parts + 1] = "seen " .. Ago(now - seen.t) end
            row.info:SetText(table.concat(parts, ", "))
            row:Show()
        else
            row:Hide()
        end
    end
    if #list == 0 then
        panel.empty:SetText("No known rares in " .. ZoneName(mapID) .. ".\nAlerts still work here: any mob the game marks as rare is caught.")
        panel.empty:Show()
    elseif #list > MAX_ROWS then
        panel.empty:Hide()
        panel.zone:SetText("Rares in " .. ZoneName(mapID) .. "  |cff9d9d9d(" .. #list .. " known, lowest " .. MAX_ROWS .. " shown)|r")
    else
        panel.empty:Hide()
    end
end

local function TogglePanel()
    if not db then return end
    if not panel then panel = CreatePanel() end
    if panel:IsShown() then panel:Hide() else panel:Show() end
end

function RareAlert_OnCompartmentClick()
    TogglePanel()
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 160)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "RareAlertMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    local back = b:CreateTexture(nil, "BACKGROUND")
    back:SetSize(22, 22)
    back:SetPoint("CENTER")
    back:SetColorTexture(0.05, 0.04, 0.03, 0.9)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")
    icon:SetTexture(TEXTURES .. "Rare.tga")
    icon:SetVertexColor(1, 0.75, 0.25, 1)
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", TogglePanel)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Rare Alert", 1, 0.82, 0)
        GameTooltip:AddLine("Click to see the rares in this zone.", 1, 1, 1)
        GameTooltip:AddLine("Alerts are " .. (db.enabled and "on." or "off."), 0.7, 0.7, 0.7)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

ns.UpdateMinimapButton = function()
    if not db or not Minimap then return end
    if db.minimap then
        if not minimapButton then CreateMinimapButton() end
        minimapButton:Show()
    elseif minimapButton then
        minimapButton:Hide()
    end
end

---------------------------------------------------------------------------
-- Slash commands and events
---------------------------------------------------------------------------

SLASH_RAREALERT1 = "/rare"
SLASH_RAREALERT2 = "/rarealert"
SlashCmdList.RAREALERT = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command = string.lower(message or ""):match("^%s*(%S*)")
    if command == "test" then
        ShowAlert({ name = "Test Rare", level = 30, elite = true, how = "as a test", mapID = PlayerZone() })
    elseif command == "on" or command == "off" then
        db.enabled = command == "on"
        Say("alerts " .. command .. ".")
    elseif command == "help" then
        Say("/rare opens the zone panel, where every setting is a button. /rare test shows a test alert.")
        Say("/rare on or /rare off turns alerts on or off. /rare minimap shows or hides the minimap button.")
    elseif command == "minimap" then
        db.minimap = not db.minimap
        ns.UpdateMinimapButton()
    else
        TogglePanel()
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event, arg1)
    if event == "PLAYER_LOGIN" then
        RareAlertDB = type(RareAlertDB) == "table" and RareAlertDB or {}
        db = RareAlertDB
        for key, value in pairs({ enabled = true, sound = true, flash = true, chat = true, minimap = true }) do
            if type(db[key]) ~= "boolean" then db[key] = value end
        end
        if type(db.seen) ~= "table" then db.seen = {} end
        if type(db.ignore) ~= "table" then db.ignore = {} end
        -- An event name this client does not know makes RegisterEvent throw, so each is tried alone.
        for _, name in ipairs({ "NAME_PLATE_UNIT_ADDED", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT",
            "VIGNETTE_MINIMAP_UPDATED", "VIGNETTES_UPDATED", "PLAYER_REGEN_ENABLED", "ZONE_CHANGED_NEW_AREA" }) do
            pcall(self.RegisterEvent, self, name)
        end
        ns.UpdateMinimapButton()
        return
    end
    if not db then return end
    if event == "NAME_PLATE_UNIT_ADDED" then
        if type(arg1) == "string" and not IsSecret(arg1) then CheckUnit(arg1) end
    elseif event == "PLAYER_TARGET_CHANGED" then
        CheckUnit("target")
    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        CheckUnit("mouseover")
    elseif event == "VIGNETTE_MINIMAP_UPDATED" then
        if arg1 then CheckVignette(arg1) end
    elseif event == "VIGNETTES_UPDATED" then
        local list = type(C_VignetteInfo) == "table" and Plain(C_VignetteInfo.GetVignettes)
        if type(list) == "table" then
            for _, guid in ipairs(list) do CheckVignette(guid) end
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if pendingTargetHide then HideTarget() end
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        RefreshPanel()
    end
end)

-- For the automated tests.
ns.CheckUnit = CheckUnit
ns.CheckVignette = CheckVignette
