Rare Alert 1.0.0 - World of Warcraft: Forever (Interface 16001)
==============================================================

Warns you the moment a rare mob shows up near you, so you can find it and
kill it before someone else does. It also lists the rares of the zone
you are in, with how far away their nearest known spawn spot is.

INSTALL
Copy the RareAlert folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

THE ALERT
When a rare mob appears near you, you get:
- a banner at the top of the screen with its name, level and zone
- the raid warning sound and big warning text
- a flashing game icon on your taskbar, if the game is in the background
- a line in your chat window
The banner has three buttons:
  Target it   targets the rare for you
  Map pin     puts a pin on your map where it was spotted
  Dismiss     closes the banner
The banner closes by itself after 25 seconds, but stays up while you are
in combat or have the mouse over it.

HOW RARES ARE SPOTTED
- Their nameplates. Turn on enemy nameplates (default key V) so the game
  shows them: this is what catches rares from the furthest away.
- Your target and your mouseover.
- Minimap markers, if the game puts one on a rare.
The addon knows 323 open-world rares by name, and also catches any mob the
game itself marks as rare, so new WoW Forever rares are caught too.

Alerts only happen out of combat. While you are fighting, the game hides
who a mob is from addons.

THE ZONE PANEL
Click the star button on the minimap (or pick Rare Alert from the minimap
addon menu, or type /rare). It shows:
- every known rare in your zone, lowest level first, with elite marked
- the distance and direction to its nearest known spawn spot
- when you last saw it
- a Pin button that puts a map pin on that nearest spot
Right-click a rare to ignore it (no more alerts for it). Right-click again
to stop ignoring it.

Buttons along the bottom turn things on and off: Alerts, Sound, Screen
flash, Chat line and Minimap button. "Test alert" at the top shows what an
alert looks and sounds like.

COMMANDS (optional, everything is also a button)
/rare           open or close the zone panel
/rare test      show a test alert
/rare on, off   turn alerts on or off
/rare minimap   show or hide the minimap button
/rarealert also works.

LIMITS
- Spawn spots come from the original game. WoW Forever may have moved some
  rares or added new ones; new ones are still caught by the alert, they
  just have no spots in the panel.
- Some rares near zone borders are listed in both zones.

LICENSE
The rare mob list and spawn spots are derived from CMaNGOS classic-db,
licensed under the GNU General Public License v3.0, so this addon is
distributed under GPL-3.0 as well.
  https://github.com/cmangos/classic-db
  https://www.gnu.org/licenses/gpl-3.0.html

CREDITS
Addon: Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Rare data: the CMaNGOS project and its contributors
Zone data: Blizzard Entertainment game client data, read via wago.tools
