Shift-Click Returns 1.0.0 - World of Warcraft: Forever (Interface 16001)
=======================================================================

Shift-click a player's name and do something with it in one click:
invite them to your group or guild, whisper them, add them as a friend,
look them up, or copy their name.

INSTALL
Copy the Shift-Click_returns folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

HOW TO USE
Shift-click any of these and the name lands in the Shift-Click Returns
window:
- a player's name in chat
- their target frame, focus frame or party frame
Then click a button:
  Invite to group    invite them to your party or raid
  Invite to guild    invite them to your guild (needs the guild rank)
  Whisper            opens a whisper to them in your chat box
  Add friend         adds them to your friends list
  Who is this?       looks them up: level, class, guild and zone
  Copy name          selects the name so Ctrl+C copies it
"My target" puts your current target's name in the box, and you can also
type a name in yourself. The last 8 names are listed under Recent; click
one to use it again.

BLIZZARD'S OWN NAME BOXES
If Blizzard's Add Friend, Add Ignore, guild invite or channel invite box
is open when you shift-click a name, the name goes straight into that box
instead.

WHILE TYPING IN CHAT
If you are typing a chat message, shift-clicking a name still puts it into
your message, as normal. The window does not open then.

OPENING IT
Click the green arrow on the minimap, pick it from the minimap addon menu,
or type /scr (or /shiftclick). /scr Name opens it with that name.

SETTINGS (buttons at the bottom of the window)
  Chat names         catch shift-clicks on names in chat
  Unit frames        catch shift-clicks on target, focus and party frames
  Fill invite boxes  put names into Blizzard's open name boxes
  Minimap button     show or hide the minimap button

CREDITS
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
