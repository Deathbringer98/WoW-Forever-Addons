-- ForeverOneBag 1.0.0
-- Uses WoW: Forever's native combined-bag UI instead of replacing protected item buttons.

local ADDON = ... or "ForeverOneBag"
local BAG_COUNT = NUM_BAG_SLOTS or 4 -- Bag 0 is the backpack; bags 1-4 are equipped bags.
local db
local counter
local lastFree, lastTotal = 0, 0

local function Chat(message)
    local prefix = "|cff19c7bbForeverOneBag|r: "
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(prefix .. message)
    elseif print then
        print(ADDON .. ": " .. message)
    end
end

local function ReadCombinedSetting()
    if C_CVar and C_CVar.GetCVar then
        return C_CVar.GetCVar("combinedBags")
    end
    if GetCVar then
        return GetCVar("combinedBags")
    end
    return nil
end

local function WriteCombinedSetting(enabled)
    local value = enabled and "1" or "0"
    local ok, err = pcall(function()
        if C_CVar and C_CVar.SetCVar then
            C_CVar.SetCVar("combinedBags", value)
        elseif SetCVar then
            SetCVar("combinedBags", value)
        else
            error("SetCVar API is unavailable")
        end
    end)
    if not ok then
        Chat("Could not set Combine Bags: " .. tostring(err))
    end
    return ok
end

local function CreateCounter()
    if counter then
        return
    end

    counter = CreateFrame("Frame", "ForeverOneBagFreeSlots", UIParent)
    counter:SetSize(94, 19)
    counter:SetFrameStrata("MEDIUM")

    local background = counter:CreateTexture(nil, "BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(0.02, 0.04, 0.05, 0.82)

    counter.label = counter:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    counter.label:SetPoint("CENTER", counter, "CENTER", 0, 0)
    counter.label:SetTextColor(0.95, 0.84, 0.42)
    counter.label:SetText("Free 0 / 0")

    -- Decoration only; inventory interactions remain controlled by Blizzard's UI.
    counter:EnableMouse(true)
    counter:SetScript("OnEnter", function(self)
        if GameTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_TOPRIGHT")
            GameTooltip:AddLine("ForeverOneBag", 0.15, 0.8, 0.72)
            GameTooltip:AddLine("Free / total slots in your backpack and bags.", 1, 1, 1)
            GameTooltip:AddLine("/onebag for commands", 0.8, 0.8, 0.8)
            GameTooltip:Show()
        end
    end)
    counter:SetScript("OnLeave", function()
        if GameTooltip then GameTooltip:Hide() end
    end)

    local backpackButton = _G.MainMenuBarBackpackButton
    if not backpackButton and _G.BagsBar then
        backpackButton = _G.BagsBar.Backpack
    end

    counter:ClearAllPoints()
    if backpackButton then
        counter:SetPoint("BOTTOM", backpackButton, "TOP", 0, 5)
    else
        -- Safe fallback if a custom UI hides or replaces the bag bar.
        counter:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -20, 94)
    end
end

local function UpdateCounter()
    if not db then return end
    CreateCounter()

    if not db.showCounter then
        counter:Hide()
        return
    end
    counter:Show()

    -- Modern WoW can mark certain values secret in combat. Keep the last
    -- confirmed count rather than attempting arithmetic on unreadable values.
    if InCombatLockdown and InCombatLockdown() then
        counter.label:SetFormattedText("Free %d / %d", lastFree, lastTotal)
        return
    end

    local free, total = 0, 0
    if not C_Container or not C_Container.GetContainerNumSlots
       or not C_Container.GetContainerNumFreeSlots then
        counter.label:SetText("Bags: N/A")
        return
    end

    for bag = 0, BAG_COUNT do
        local slots = C_Container.GetContainerNumSlots(bag)
        local empty = C_Container.GetContainerNumFreeSlots(bag)

        if (issecretvalue and (issecretvalue(slots) or issecretvalue(empty))) then
            counter.label:SetFormattedText("Free %d / %d", lastFree, lastTotal)
            return
        end
        if type(slots) == "number" and type(empty) == "number" then
            total = total + slots
            free = free + empty
        end
    end

    lastFree, lastTotal = free, total
    counter.label:SetFormattedText("Free %d / %d", free, total)
end

local function SetEnabled(value)
    db.enabled = value
    if WriteCombinedSetting(value) then
        Chat(value and "Combined bags enabled. Reopen your bags with B."
             or "Combined bags disabled. Reopen your bags with B.")
    end
end

local function ShowStatus()
    local current = ReadCombinedSetting()
    local state = (current == "1") and "ON" or ((current == "0") and "OFF" or "UNKNOWN")
    Chat("Combine Bags: " .. state .. "; slot counter: "
         .. (db.showCounter and "ON" or "OFF") .. ".")
end

local function HandleCommand(message)
    if not db then
        Chat("The addon is still loading.")
        return
    end

    local command, argument = (message or ""):lower():match("^%s*(%S*)%s*(%S*)")

    if command == "on" then
        SetEnabled(true)
    elseif command == "off" then
        SetEnabled(false)
    elseif command == "count" or command == "counter" then
        if argument == "on" then
            db.showCounter = true
        elseif argument == "off" then
            db.showCounter = false
        else
            db.showCounter = not db.showCounter
        end
        UpdateCounter()
        Chat("Slot counter " .. (db.showCounter and "enabled." or "disabled."))
    elseif command == "status" or command == "" then
        ShowStatus()
    else
        Chat("Commands: /onebag on | off | count [on/off] | status | help")
    end
end

SLASH_FOREVERONEBAG1 = "/onebag"
SLASH_FOREVERONEBAG2 = "/fob"
SlashCmdList["FOREVERONEBAG"] = HandleCommand

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("BAG_UPDATE")
events:RegisterEvent("BAG_UPDATE_DELAYED")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        ForeverOneBagDB = type(ForeverOneBagDB) == "table" and ForeverOneBagDB or {}
        db = ForeverOneBagDB
        if db.enabled == nil then db.enabled = true end
        if db.showCounter == nil then db.showCounter = true end

        if db.enabled then WriteCombinedSetting(true) end
        UpdateCounter()
    elseif db then
        UpdateCounter()
    end
end)
