ForeverOneBag v1.0.0 — for World of Warcraft: Forever (Interface 16001)
========================================================================

WHAT IT DOES
- Automatically enables WoW: Forever's own Combine Bags setting.
- Your backpack and your four equipped regular bags appear in one native window.
- Shows a small 'Free X / Y' slot counter near the backpack button (or in the
  lower-right corner if that button is not found).
- Keeps Blizzard's normal item dragging, trading, selling and sorting behavior.
- Does not add inventory slots, replace the bank, or merge specialty/reagent bags.

INSTALLATION (WINDOWS)
1. Close WoW: Forever.
2. Open your World of Warcraft folder, then:
   _forever_\Interface\AddOns\
3. Extract the ForeverOneBag folder from the ZIP into AddOns.
4. Verify this exact file exists:
   _forever_\Interface\AddOns\ForeverOneBag\ForeverOneBag.toc
5. Launch the game. If necessary, enable ForeverOneBag under AddOns on the
   character selection screen.
6. Press B to open your now-combined bag window.

COMMANDS (IN CHAT)
/onebag           Show the current setting
/onebag on        Enable the native combined bags setting
/onebag off       Return to separate bags
/onebag count     Toggle the free-slot counter
/onebag count off Hide the counter
/onebag count on  Show the counter
/onebag help      List commands
/fob              Short alias for /onebag

NOTES
- WoW: Forever already includes Combine Bags under Options > Controls.
  This addon is a convenience wrapper around the native implementation.
- The free-space count includes slots in bags 0 through 4, including any
  specialty bags equipped in those slots; it doesn't count the reagent bag.
- If you change a combined-bags setting while bags are open, close and reopen
  them for the native UI to refresh.
- The addon avoids reparenting or replacing protected bag item buttons.
- The client-side addon cannot be fully tested outside WoW: Forever. If you see
  a Lua error, enable /console scriptErrors 1 and report its message.
