-- QuestiePlus helper window: level-up planner, quests ready to hand in, quest log cleanup and zone progress.
-- Open it with /qp, a middle click on the Questie minimap button, or the button in the QuestiePlus settings tab.
---@class QuestiePlusPanel
local QuestiePlusPanel = QuestieLoader:CreateModule("QuestiePlusPanel")

---@type QuestieDB
local QuestieDB = QuestieLoader:ImportModule("QuestieDB")
---@type QuestieLib
local QuestieLib = QuestieLoader:ImportModule("QuestieLib")
---@type QuestieCompat
local QuestieCompat = QuestieLoader:ImportModule("QuestieCompat")
---@type QuestieCorrections
local QuestieCorrections = QuestieLoader:ImportModule("QuestieCorrections")
---@type QuestiePlayer
local QuestiePlayer = QuestieLoader:ImportModule("QuestiePlayer")
---@type QuestLogCache
local QuestLogCache = QuestieLoader:ImportModule("QuestLogCache")
---@type QuestXP
local QuestXP = QuestieLoader:ImportModule("QuestXP")
---@type ZoneDB
local ZoneDB = QuestieLoader:ImportModule("ZoneDB")
---@type QuestieJourney
local QuestieJourney = QuestieLoader:ImportModule("QuestieJourney")
---@type QuestiePopup
local Popup = QuestieLoader:ImportModule("QuestiePopup")
---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

local GetCoinTextureString = (C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString) or GetCoinTextureString
local WIDTH, HEIGHT, ROW_HEIGHT = 440, 560, 20
local GOLD = {1, 0.82, 0}

local window, scrollChild, xpBar, xpReadyBar, xpText, summaryText
local rows, rowCount = {}, 0
local refreshPending = false

local function _IsSecret(value)
    return issecretvalue and issecretvalue(value)
end

local function _Number(value)
    if _IsSecret(value) or type(value) ~= "number" then return nil end
    return value
end

---------------------------------------------------------------------------
-- Data
---------------------------------------------------------------------------

---@param questId QuestId
---@return number
local function _QuestXp(questId)
    local ok, xp = pcall(QuestXP.GetQuestLogRewardXP, QuestXP, questId, false)
    return (ok and type(xp) == "number") and xp or 0
end

---@param questId QuestId
---@return number
local function _QuestMoney(questId)
    local ok, money = pcall(QuestXP.GetQuestRewardMoney, questId)
    return (ok and type(money) == "number") and money or 0
end

---Where to hand a quest in: name, uiMapId, x, y (0-100). Prefers a spot in the player's zone.
---@param questId QuestId
local function _Finisher(questId)
    local quest = QuestieDB.GetQuest(questId)
    if not (quest and quest.Finisher) then return nil end
    local currentZone = QuestiePlayer:GetCurrentZoneId()
    local candidates = {}
    for _, npcId in ipairs(quest.Finisher.NPC or {}) do
        candidates[#candidates + 1] = {QuestieDB.QueryNPCSingle(npcId, "name"), QuestieDB.QueryNPCSingle(npcId, "spawns")}
    end
    for _, objectId in ipairs(quest.Finisher.GameObject or {}) do
        candidates[#candidates + 1] = {QuestieDB.QueryObjectSingle(objectId, "name"), QuestieDB.QueryObjectSingle(objectId, "spawns")}
    end
    local best
    for _, candidate in ipairs(candidates) do
        local name, spawns = candidate[1], candidate[2]
        if name and type(spawns) == "table" then
            for areaId, coords in pairs(spawns) do
                local first = coords and coords[1]
                local uiMapId = ZoneDB:GetUiMapIdByAreaId(areaId)
                if first and first[1] and first[1] >= 0 and uiMapId then
                    local spot = {name = name, uiMapId = uiMapId, x = first[1], y = first[2], areaId = areaId}
                    if areaId == currentZone then return spot end
                    best = best or spot
                end
            end
        end
        if best == nil and name then
            best = {name = name}
        end
    end
    return best
end

---@return table ready, table grey, number readyXp, number logXp, number readyMoney
local function _CollectQuestLog()
    local ready, grey = {}, {}
    local readyXp, logXp, readyMoney = 0, 0, 0
    for questId in pairs(QuestLogCache.questLog_DO_NOT_MODIFY) do
        if QuestieDB.QuestPointers and QuestieDB.QuestPointers[questId] then
            local xp = _QuestXp(questId)
            logXp = logXp + xp
            local level = QuestieLib.GetEffectiveQuestLevel(questId)
            local entry = {id = questId, xp = xp, level = level, money = _QuestMoney(questId)}
            if QuestieDB.IsComplete(questId) == 1 then
                readyXp = readyXp + xp
                readyMoney = readyMoney + entry.money
                ready[#ready + 1] = entry
            elseif QuestieDB.IsTrivial(level) then
                grey[#grey + 1] = entry
            end
        end
    end
    table.sort(ready, function(a, b) return a.xp > b.xp end)
    table.sort(grey, function(a, b) return a.level < b.level end)
    return ready, grey, readyXp, logXp, readyMoney
end

---Counts the current zone's quests: done, open to you now, and the total you can ever do.
local function _ZoneProgress()
    local areaId = QuestiePlayer:GetCurrentZoneId()
    local zoneMap = QuestieJourney.zoneMap
    if not (areaId and zoneMap and zoneMap[areaId]) then return nil end
    local DoableStates = QuestieDB.DoableStates
    local done, open, total = 0, 0, 0
    for questId in pairs(zoneMap[areaId]) do
        local hidden = QuestieCorrections.hiddenQuests and QuestieCorrections.hiddenQuests[questId]
        if (not hidden) and QuestieDB.QuestPointers[questId] and (not QuestieDB.IsRepeatable(questId)) then
            local ok, _, _, reason = pcall(QuestieDB.IsDoableVerbose, questId, false, true, true)
            if ok and reason ~= DoableStates.WRONG_RACE and reason ~= DoableStates.WRONG_CLASS
                and reason ~= DoableStates.BLACKLISTED and reason ~= DoableStates.PROFESSION_MISSING then
                total = total + 1
                if reason == DoableStates.COMPLETED or Questie.db.char.complete[questId] then
                    done = done + 1
                elseif reason == DoableStates.AVAILABLE or reason == DoableStates.QUEST_LOG then
                    open = open + 1
                end
            end
        end
    end
    local name = C_Map.GetMapInfo(ZoneDB:GetUiMapIdByAreaId(areaId) or 0)
    return (name and name.name) or GetRealZoneText(), done, open, total
end

---------------------------------------------------------------------------
-- Actions
---------------------------------------------------------------------------

Popup.Dialogs["QUESTIEPLUS_ABANDON"] = {
    text = "%s",
    button1 = YES,
    button2 = NO,
    OnAccept = function(self)
        local questId = self.data
        if InCombatLockdown() or not questId then return end
        if C_QuestLog and C_QuestLog.SetSelectedQuest then
            C_QuestLog.SetSelectedQuest(questId)
            C_QuestLog.SetAbandonQuest()
            C_QuestLog.AbandonQuest()
        end
    end,
    OnShow = function(self)
        self:SetFrameStrata("TOOLTIP")
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

---@param spot table
local function _ShowOnMap(spot)
    if InCombatLockdown() then
        Questie:Print(l10n("You can't do that while in combat."))
        return
    end
    if not (spot and spot.uiMapId) then return end
    if C_Map.CanSetUserWaypointOnMap and C_Map.CanSetUserWaypointOnMap(spot.uiMapId) and UiMapPoint then
        C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(spot.uiMapId, spot.x / 100, spot.y / 100))
    end
    QuestieCompat.OpenWorldMap(spot.uiMapId)
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------

local function _Backdrop(frame, alpha)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 14,
        insets = {left = 3, right = 3, top = 3, bottom = 3},
    })
    frame:SetBackdropColor(0.05, 0.05, 0.08, alpha or 0.95)
    frame:SetBackdropBorderColor(0.85, 0.7, 0.3, 1)
end

local function _SmallButton(parent, label, width)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetSize(width or 64, ROW_HEIGHT - 2)
    button:SetText(label)
    button:GetFontString():SetFontObject("GameFontNormalSmall")
    return button
end

local function _GetRow()
    rowCount = rowCount + 1
    local row = rows[rowCount]
    if not row then
        row = CreateFrame("Frame", nil, scrollChild)
        row:SetSize(WIDTH - 50, ROW_HEIGHT)
        row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.text:SetPoint("LEFT", 4, 0)
        row.text:SetJustifyH("LEFT")
        row.right = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.right:SetJustifyH("RIGHT")
        row.button = _SmallButton(row, "", 64)
        row.button:SetPoint("RIGHT", -2, 0)
        row:EnableMouse(true)
        row:SetScript("OnEnter", function(self)
            if not self.tooltipLines then return end
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            for i, line in ipairs(self.tooltipLines) do
                if i == 1 then GameTooltip:SetText(line) else GameTooltip:AddLine(line, 1, 1, 1, true) end
            end
            if self.questId then
                QuestieLoader:ImportModule("QuestiePlusChain").AddLines(GameTooltip, self.questId)
            end
            GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        rows[rowCount] = row
    end
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", 4, -((rowCount - 1) * ROW_HEIGHT))
    row.text:SetFontObject("GameFontHighlightSmall")
    row.text:SetTextColor(1, 1, 1)
    row.right:ClearAllPoints()
    row.right:SetPoint("RIGHT", -4, 0)
    row.button:Hide()
    row.tooltipLines, row.questId = nil, nil
    row:Show()
    return row
end

local function _Header(text)
    local row = _GetRow()
    row.text:SetFontObject("GameFontNormal")
    row.text:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
    row.text:SetText(text)
    row.right:SetText("")
    return row
end

local function _Line(text, right)
    local row = _GetRow()
    row.text:SetText(text)
    row.right:SetText(right or "")
    return row
end

local function _Spacer()
    local row = _GetRow()
    row.text:SetText("")
    row.right:SetText("")
end

local function _WithButton(row, label, onClick)
    row.button:SetText(label)
    row.button:SetScript("OnClick", onClick)
    row.button:Show()
    row.right:ClearAllPoints()
    row.right:SetPoint("RIGHT", row.button, "LEFT", -6, 0)
end

local function _XpString(xp)
    return xp > 0 and (FormatLargeNumber(xp) .. " " .. l10n("xp")) or ""
end

---@param count number
---@return string
local function _QuestCount(count)
    if count == 1 then
        return l10n("your finished quest")
    end
    return l10n("your %d finished quests", count)
end

function QuestiePlusPanel.Refresh()
    if not (window and window:IsShown()) then return end
    if not Questie.started then
        summaryText:SetText(l10n("Questie is still loading..."))
        return
    end

    for i = 1, rowCount do rows[i]:Hide() end
    rowCount = 0

    local ready, grey, readyXp, logXp, readyMoney = _CollectQuestLog()

    -- Level-up planner
    local level = UnitLevel("player")
    local maxLevel = GetMaxPlayerLevel and GetMaxPlayerLevel() or 60
    local xp, xpMax = _Number(UnitXP("player")), _Number(UnitXPMax("player"))
    if level >= maxLevel or not (xp and xpMax and xpMax > 0) then
        xpBar:SetMinMaxValues(0, 1)
        xpBar:SetValue(1)
        xpReadyBar:SetMinMaxValues(0, 1)
        xpReadyBar:SetValue(0)
        xpText:SetText(l10n("Max level"))
        if #ready == 0 then
            summaryText:SetText(l10n("No quests are ready to hand in yet."))
        else
            summaryText:SetText(l10n("Handing in %s gives %s.", _QuestCount(#ready), GetCoinTextureString(readyMoney)))
        end
    else
        local need = xpMax - xp
        xpBar:SetMinMaxValues(0, xpMax)
        xpBar:SetValue(xp)
        xpReadyBar:SetMinMaxValues(0, xpMax)
        xpReadyBar:SetValue(math.min(xpMax, xp + readyXp))
        xpText:SetText(string.format("%s / %s  (%d%%)", FormatLargeNumber(xp), FormatLargeNumber(xpMax), math.floor(xp / xpMax * 100)))
        local summary
        if #ready == 0 or readyXp == 0 then
            summary = l10n("No quests with XP are ready to hand in yet. %s to the next level.", _XpString(need))
        elseif readyXp >= need then
            summary = "|cff40ff40" .. l10n("Hand in %s to reach level %d!", _QuestCount(#ready), level + 1) .. "|r"
        else
            summary = l10n("Handing in %s gives %s, %d%% of what you need for level %d.", _QuestCount(#ready), _XpString(readyXp),
                math.floor(readyXp / need * 100), level + 1)
        end
        if logXp > readyXp then
            summary = summary .. "\n" .. l10n("Finishing everything in your quest log gives %s in total.", _XpString(logXp))
        end
        summaryText:SetText(summary)
    end

    -- Ready to hand in
    _Header(l10n("Ready to hand in") .. " (" .. #ready .. ")")
    if #ready == 0 then
        _Line("|cff999999" .. l10n("Nothing yet. Keep questing!") .. "|r")
    end
    for _, entry in ipairs(ready) do
        local spot = _Finisher(entry.id)
        local row = _Line(QuestieLib:GetColoredQuestName(entry.id, true, false), _XpString(entry.xp))
        row.questId = entry.id
        local where = spot and spot.name or l10n("Unknown")
        if spot and spot.uiMapId then
            local info = C_Map.GetMapInfo(spot.uiMapId)
            where = where .. "  (" .. ((info and info.name) or "") .. string.format(" %.1f, %.1f)", spot.x, spot.y)
        end
        row.tooltipLines = {QuestieLib:GetColoredQuestName(entry.id, true, false), l10n("Hand in to: %s", where)}
        if spot and spot.uiMapId then
            _WithButton(row, l10n("Map"), function() _ShowOnMap(spot) end)
        end
    end

    -- Quest log cleanup
    _Spacer()
    _Header(l10n("Grey quests in your log") .. " (" .. #grey .. ")")
    if #grey == 0 then
        _Line("|cff999999" .. l10n("None. Your quest log is tidy.") .. "|r")
    else
        _Line("|cff999999" .. l10n("These give little XP now. Abandon them to make room.") .. "|r")
    end
    for _, entry in ipairs(grey) do
        local row = _Line(QuestieLib:GetColoredQuestName(entry.id, true, false), _XpString(entry.xp))
        row.questId = entry.id
        row.tooltipLines = {QuestieLib:GetColoredQuestName(entry.id, true, false), l10n("Grey quest: it is far below your level.")}
        _WithButton(row, l10n("Abandon"), function()
            if InCombatLockdown() then
                Questie:Print(l10n("You can't do that while in combat."))
                return
            end
            Popup.Show("QUESTIEPLUS_ABANDON", l10n("Abandon %s?", QuestieLib:GetColoredQuestName(entry.id, true, false)), nil, entry.id)
        end)
    end

    -- Zone progress
    _Spacer()
    local zoneName, done, open, total = _ZoneProgress()
    _Header(l10n("Zone progress"))
    if zoneName and total and total > 0 then
        _Line(zoneName, string.format("%d / %d  (%d%%)", done, total, math.floor(done / total * 100)))
        _Line("|cff999999" .. l10n("%d quests you can pick up or have in your log here.", open) .. "|r")
    else
        _Line("|cff999999" .. l10n("No quest data for this zone.") .. "|r")
    end

    scrollChild:SetHeight(math.max(1, rowCount * ROW_HEIGHT))
end

local function _QueueRefresh()
    if refreshPending or not (window and window:IsShown()) then return end
    refreshPending = true
    C_Timer.After(0.5, function()
        refreshPending = false
        QuestiePlusPanel.Refresh()
    end)
end

local function _Create()
    window = CreateFrame("Frame", "QuestiePlusPanelFrame", UIParent, "BackdropTemplate")
    window:SetSize(WIDTH, HEIGHT)
    window:SetPoint("CENTER", 220, 0)
    window:SetFrameStrata("HIGH")
    window:SetClampedToScreen(true)
    window:SetMovable(true)
    window:EnableMouse(true)
    window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStart", window.StartMoving)
    window:SetScript("OnDragStop", window.StopMovingOrSizing)
    _Backdrop(window)
    tinsert(UISpecialFrames, "QuestiePlusPanelFrame")

    local icon = window:CreateTexture(nil, "ARTWORK")
    icon:SetSize(28, 28)
    icon:SetPoint("TOPLEFT", 12, -10)
    icon:SetTexture(QuestieLib.AddonPath .. "Icons\\questie.png")

    local title = window:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", icon, "RIGHT", 8, 0)
    title:SetText("QuestiePlus")

    local close = CreateFrame("Button", nil, window, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)

    local options = _SmallButton(window, l10n("Settings"), 70)
    options:SetPoint("TOPRIGHT", -34, -12)
    options:SetScript("OnClick", function()
        window:Hide()
        QuestieLoader:ImportModule("QuestieOptionsEngine"):ToggleConfigWindow()
    end)

    local barBg = CreateFrame("Frame", nil, window, "BackdropTemplate")
    barBg:SetPoint("TOPLEFT", 14, -48)
    barBg:SetPoint("TOPRIGHT", -14, -48)
    barBg:SetHeight(20)
    _Backdrop(barBg, 0.9)
    xpReadyBar = CreateFrame("StatusBar", nil, barBg)
    xpReadyBar:SetPoint("TOPLEFT", 4, -4)
    xpReadyBar:SetPoint("BOTTOMRIGHT", -4, 4)
    xpReadyBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    xpReadyBar:SetStatusBarColor(0.25, 0.85, 0.35, 0.7)
    xpBar = CreateFrame("StatusBar", nil, barBg)
    xpBar:SetAllPoints(xpReadyBar)
    xpBar:SetFrameLevel(xpReadyBar:GetFrameLevel() + 1)
    xpBar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    xpBar:SetStatusBarColor(0.58, 0.0, 0.85, 1)
    xpText = xpBar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    xpText:SetPoint("CENTER")

    local legend = window:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    legend:SetPoint("TOPLEFT", barBg, "BOTTOMLEFT", 2, -2)
    legend:SetText("|cff9400d9" .. l10n("Purple: your XP") .. "|r   |cff40d95a" .. l10n("Green: XP from finished quests") .. "|r")

    summaryText = window:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    summaryText:SetPoint("TOPLEFT", barBg, "BOTTOMLEFT", 2, -18)
    summaryText:SetPoint("RIGHT", window, "RIGHT", -16, 0)
    summaryText:SetJustifyH("LEFT")
    summaryText:SetSpacing(2)

    local scroll = CreateFrame("ScrollFrame", nil, window, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 10, -122)
    scroll:SetPoint("BOTTOMRIGHT", -30, 12)
    scrollChild = CreateFrame("Frame", nil, scroll)
    scrollChild:SetSize(WIDTH - 44, 1)
    scroll:SetScrollChild(scrollChild)

    window:SetScript("OnShow", QuestiePlusPanel.Refresh)
    window:SetScript("OnEvent", _QueueRefresh)
    for _, event in ipairs({"QUEST_LOG_UPDATE", "PLAYER_XP_UPDATE", "PLAYER_LEVEL_UP", "ZONE_CHANGED_NEW_AREA"}) do
        pcall(window.RegisterEvent, window, event)
    end
    window:Hide()
end

function QuestiePlusPanel.Toggle()
    if not window then _Create() end
    if window:IsShown() then
        window:Hide()
    else
        window:Show()
    end
end

function QuestiePlusPanel.IsShown()
    return window and window:IsShown() or false
end
