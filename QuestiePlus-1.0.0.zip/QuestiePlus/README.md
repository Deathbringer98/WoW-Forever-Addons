# QuestiePlus

**An improved version of the original Questie, for World of Warcraft: Forever.**

QuestiePlus is an unofficial fork of [Questie](https://github.com/Questie/Questie) 12.7.0 by Matthew Menchinton (CircuitSpecter Studio). It fixes a set of known Questie bugs on WoW Forever and adds new features. It is not made or supported by the Questie team, so please report QuestiePlus problems to us, not to them.

## Install

1. QuestiePlus needs the **QuestieDB** addon (Questie's quest database). Get the Forever build from the [QuestieDB releases](https://github.com/Questie/QuestieDB/releases/latest) (`QuestieDB-x.y.z-Forever.zip`) and put the `QuestieDB` folder in `World of Warcraft\_forever_\Interface\AddOns\`.
2. Put the `QuestiePlus` folder in the same `AddOns` folder.
3. Turn off the original **Questie** if you have it. QuestiePlus replaces it and keeps the same settings format. If both are on, QuestiePlus offers to turn Questie off for you.
4. Restart the game.

## New features

- **QuestiePlus window** (`/qp`, middle-click the Questie minimap button, or the button in the QuestiePlus settings tab):
  - **Level-up planner:** your XP bar with the XP from finished quests drawn on top, and whether handing them in is enough to level up.
  - **Ready to hand in:** every finished quest with its XP, who to hand it in to, and a **Map** button that opens the map with a waypoint on that NPC.
  - **Grey quests:** quests far below your level, with an **Abandon** button (it always asks first) to free up quest log space.
  - **Zone progress:** how many of the current zone's quests you have done, out of the ones your character can do.
- **Quest chain on hover:** hovering a quest in the quest log, a quest pin on the map, or a quest in the tracker lists the follow-up quests with their XP and money, and the total for the rest of the chain (Questie request #8254).
- **Quest complete banner:** a big banner in the middle of the screen when you finish the last objective of a quest.
- **Hide the tracker in battlegrounds:** hides the tracker in battlegrounds and arenas but keeps it in dungeons (Questie request #8265).
- **Shift+click an objective icon** on the map to hide that objective's icons when they clutter the map. "Show Icons" in the tracker menu brings them back (Questie request #8214).

All of these can be turned on and off in the new **QuestiePlus** tab of the settings.

## Bug fixes

| Questie issue | Problem | Fix |
|---|---|---|
| #8260 | The "you picked up an item that starts a quest" message printed even with every chat message setting off | It now follows the item announcement setting and the "shut up" setting |
| #8222 | Map pins for items a quest needs before you can start it (for example the Fresh Zhevra Carcass for Ishamuhale) stayed up after you looted the item | The pins clear once the item is in your bags, and stay cleared after you use it |
| #8243 | Changing the icon style brought those pins back on quests that were already complete | Complete quests never show them |
| #8272 | Auto Accept took new Forever escort quests, so the NPC walked off before you were ready | Escort quests are never auto-accepted |
| #7988 | Minimap icons did not show after a hearthstone or portal until you moved | The minimap redraws a few times after every loading screen |
| #8053 | Shift+click on a patrol path did nothing | Shift+click and ctrl+click on a path act like the same click on its NPC's icon |
| #8230 | "Questie tried to call the protected function SetPassThroughButtons" | Mitigation: Questie no longer changes Blizzard's quest focus during combat or when a quest leaves the log. The report has more than one possible cause, so this may not stop it every time |

## Credits and license

- Original addon: **Questie** by Aero, Logon, Muehe, TheCrux (BreakBB), Drejjmit, Dyaxler, Cheeq, TechnoHunter, Yttrium and everyone else on the Questie team.
- QuestiePlus changes: Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org).
- Licensed under the **GNU GPL v3** like the Questie code it builds on. See `LICENSE.md`, `gpl-3.0.md` and `CHANGES.md`. The libraries in `Libs` keep their own licenses.
- The QuestiePlus logo is new art made for this fork; the Questie logo is not used.
