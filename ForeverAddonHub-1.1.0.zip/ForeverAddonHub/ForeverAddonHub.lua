-- Forever Addon Hub: one minimap button that fans out a ring of buttons around the minimap,
-- one for every addon in the WoW Forever Addons collection. Installed addons open with a click;
-- the ones you don't have yet are shown faded, with where to get them.
-- It also tucks every addon's own minimap button away (ours, plus any other addon that uses
-- LibDBIcon) so the hub is the only button left on the minimap, and those other addons get a
-- button in the ring too.
local addonName = ...
local db
local GITHUB = "github.com/Deathbringer98/WoW-Forever-Addons"

local function I(name) return "Interface\\Icons\\" .. name end
local function Slash(key, arg)
    return function()
        local fn = SlashCmdList[key]
        if fn then fn(arg or "") end
    end
end
local function Global(name)
    return function()
        local fn = _G[name]
        if type(fn) == "function" then fn() end
    end
end

-- Every addon in the collection. left/right: what a left or right click does.
local ADDONS = {
    { addon = "QuestiePlus", button = "LibDBIcon10_Questie", name = "QuestiePlus", icon = "Interface\\AddOns\\QuestiePlus\\Icons\\questie.png", fallback = I("INV_Misc_Book_08"),
        text = "Quest helper with a suggested route and level-up planner.",
        left = Slash("QUESTIEPLUS"), leftText = "Open the QuestiePlus window" },
    { addon = "GnomishGrudgeMatch", button = "GnomishGrudgeMatchMinimapButton", name = "Gnomish Grudge Match", icon = I("INV_Gizmo_02"),
        text = "Gnome and goblin mech battles vs bots or players.",
        left = Global("GnomishGrudgeMatch_OnCompartmentClick"), leftText = "Open the lobby",
        right = Slash("GNOMISHGRUDGEMATCH", "bot normal"), rightText = "Quick fight vs a bot" },
    { addon = "DungeonGuide", name = "DungeonGuide", icon = I("INV_Misc_Key_14"),
        text = "Maps of every dungeon with the bosses marked.",
        left = Global("DungeonGuide_OnCompartmentClick"), leftText = "Open the dungeon atlas" },
    { addon = "RareAlert", button = "RareAlertMinimapButton", name = "Rare Alert", icon = I("INV_Misc_Spyglass_02"),
        text = "Warns you when a rare mob is near.",
        left = Global("RareAlert_OnCompartmentClick"), leftText = "Open the zone's rare list" },
    { addon = "BetterWorldMapGatherer", name = "BetterWorldMap / Gatherer", icon = I("Trade_Herbalism"),
        text = "Full world map, flight points, ore, herbs and skinning spots.",
        left = function() if not InCombatLockdown() and C_Map and C_Map.OpenWorldMap then C_Map.OpenWorldMap() end end,
        leftText = "Open the world map", right = Slash("BETTERWORLDMAP", "status"), rightText = "Show what's turned on" },
    { addon = "TalentSuggester", name = "Talent Suggester", icon = I("INV_Misc_Book_11"),
        text = "PvE and PvP talent builds for every class, explained.",
        left = Global("TalentSuggester_OnCompartmentClick"), leftText = "Open talent suggestions" },
    { addon = "Casty", button = "CastyMinimapButton", name = "Casty", icon = I("Spell_Holy_MagicalSentry"),
        text = "Suggests the next spell to cast in combat.",
        left = Global("Casty_OnCompartmentClick"), leftText = "Open Casty settings" },
    { addon = "EasyHeals", button = "EasyHealsMinimapButton", name = "Easy Heals", icon = I("Spell_Holy_FlashHeal"),
        text = "Click-to-heal frames made for new healers.",
        left = Global("EasyHeals_OnCompartmentClick"), leftText = "Open Easy Heals settings" },
    { addon = "Shift-Click_returns", button = "ShiftClickReturnsMinimapButton", name = "Shift-Click Returns", icon = I("INV_Letter_15"),
        text = "Shift-click names to invite, whisper or add friends.",
        left = Global("ShiftClickReturns_OnCompartmentClick"), leftText = "Open the window" },
    { addon = "LivingPortraits", name = "Living Portraits", icon = I("INV_Misc_Head_Human_01"),
        text = "Animated 3D portraits on your unit frames.",
        left = Slash("LIVINGPORTRAITS", "big"), leftText = "Show or hide the big portrait",
        right = Slash("LIVINGPORTRAITS", "toggle"), rightText = "Turn portraits on or off" },
    { addon = "SexierMap", name = "SexierMap", icon = I("INV_Misc_Map_01"),
        text = "Warcraft-themed minimap rings.",
        left = Global("SexierMap_OnCompartmentClick"), leftText = "Pick a minimap theme" },
    { addon = "ForeverOneBag", name = "ForeverOneBag", icon = I("INV_Misc_Bag_08"),
        text = "All your bags in one window (press B).",
        left = Slash("FOREVERONEBAG", "status"), leftText = "Show its status in chat" },
    { addon = "WarcraftTetris", button = "WarcraftTetrisMinimapButton", name = "Warcraft Tetris", icon = I("INV_Misc_Gem_Variety_01"),
        text = "A falling-blocks puzzle game.",
        left = Global("WarcraftTetris_OnCompartmentClick"), leftText = "Play" },
    { addon = "WarcraftPinball", name = "Warcraft Pinball", icon = I("INV_Misc_Orb_04"),
        text = "Humans vs Orcs pinball.",
        left = Slash("WARCRAFTPINBALL"), leftText = "Play" },
}

local function State(entry)
    if entry.extra then return "loaded" end
    if C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded(entry.addon) then return "loaded" end
    if C_AddOns and C_AddOns.DoesAddOnExist and C_AddOns.DoesAddOnExist(entry.addon) then return "off" end
    return "missing"
end

---------------------------------------------------------------------------
-- Link box for addons you don't have
---------------------------------------------------------------------------

local linkBox
local function ShowLink(entry)
    if not linkBox then
        linkBox = CreateFrame("Frame", "ForeverAddonHubLink", UIParent, "BackdropTemplate")
        linkBox:SetSize(380, 112)
        linkBox:SetPoint("CENTER", 0, 120)
        linkBox:SetFrameStrata("DIALOG")
        linkBox:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border", tile = true, tileSize = 32, edgeSize = 24,
            insets = { left = 6, right = 6, top = 6, bottom = 6 } })
        linkBox.text = linkBox:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        linkBox.text:SetPoint("TOP", 0, -18)
        linkBox.text:SetWidth(340)
        linkBox.edit = CreateFrame("EditBox", nil, linkBox, "InputBoxTemplate")
        linkBox.edit:SetSize(320, 24)
        linkBox.edit:SetPoint("TOP", linkBox.text, "BOTTOM", 0, -10)
        linkBox.edit:SetAutoFocus(true)
        linkBox.edit:SetScript("OnEscapePressed", function() linkBox:Hide() end)
        linkBox.edit:SetScript("OnTextChanged", function(self) self:SetText(GITHUB) self:HighlightText() end)
        local close = CreateFrame("Button", nil, linkBox, "UIPanelButtonTemplate")
        close:SetSize(90, 22)
        close:SetPoint("BOTTOM", 0, 12)
        close:SetText(CLOSE or "Close")
        close:SetScript("OnClick", function() linkBox:Hide() end)
        tinsert(UISpecialFrames, "ForeverAddonHubLink")
    end
    linkBox.text:SetText("|cffffd100" .. entry.name .. "|r isn't installed. Get it here (press Ctrl+C to copy):")
    linkBox.edit:SetText(GITHUB)
    linkBox:Show()
    linkBox.edit:SetFocus()
    linkBox.edit:HighlightText()
end

---------------------------------------------------------------------------
-- Tucking other minimap buttons into the hub
---------------------------------------------------------------------------

local hooked = {}   -- buttons we already watch
local tucked = {}   -- buttons we hid, so they can come back if tucking is turned off
local extras = {}   -- ring entries for other addons' LibDBIcon buttons

local function Tuck(b)
    if not b or b:GetName() == "ForeverAddonHubButton" then return end
    if not hooked[b] then
        hooked[b] = true
        b:HookScript("OnShow", function(self)
            if db and db.tuck then
                tucked[self] = true
                self:Hide()
            end
        end)
    end
    if db.tuck and b:IsShown() then
        tucked[b] = true
        b:Hide()
    end
end

local function Untuck()
    for b in pairs(tucked) do b:Show() end
    wipe(tucked)
end

local function LibIcon()
    return LibStub and LibStub("LibDBIcon-1.0", true)
end

-- Clicking a ring button for another addon does what clicking its own minimap button did.
local function ExtraEntry(name, b)
    local obj = b.dataObject or {}
    return {
        extra = true, button = b:GetName(), name = obj.label or name, icon = obj.icon or I("INV_Misc_QuestionMark"),
        text = "Its own minimap button is tucked in here.", obj = obj, frame = b,
        left = function(mouse)
            if obj.OnClick then obj.OnClick(b, mouse or "LeftButton")
            elseif b:GetScript("OnClick") then b:GetScript("OnClick")(b, mouse or "LeftButton") end
        end,
        leftText = "Click it like its minimap button",
    }
end

local function Sweep()
    if not db then return end
    local known = {}
    for _, entry in ipairs(ADDONS) do
        if entry.button then
            known[entry.button] = true
            local b = _G[entry.button]
            if b then Tuck(b) end
        end
    end
    local lib = LibIcon()
    if lib and lib.objects then
        for name, b in pairs(lib.objects) do
            if not known[b:GetName() or ""] then
                local have
                for _, e in ipairs(extras) do if e.frame == b then have = true end end
                if not have then extras[#extras + 1] = ExtraEntry(name, b) end
                Tuck(b)
            end
        end
        table.sort(extras, function(x, y) return tostring(x.name) < tostring(y.name) end)
    end
end

---------------------------------------------------------------------------
-- The ring
---------------------------------------------------------------------------

local hub, ring, buttons = nil, nil, {}

local function Tooltip(button, entry)
    GameTooltip:SetOwner(button, "ANCHOR_LEFT")
    if entry.extra and entry.obj.OnTooltipShow then
        local ok = pcall(entry.obj.OnTooltipShow, GameTooltip)
        if ok then GameTooltip:Show() return end
        GameTooltip:ClearLines()
    end
    GameTooltip:SetText(entry.name, 1, 0.82, 0)
    GameTooltip:AddLine(entry.text, 1, 1, 1, true)
    local state = State(entry)
    if state == "loaded" then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cffffd100Click:|r " .. entry.leftText, 1, 1, 1)
        if entry.right then GameTooltip:AddLine("|cffffd100Right-click:|r " .. entry.rightText, 1, 1, 1) end
    elseif state == "off" then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Installed but turned off. Turn it on in the AddOns list at character select.", 1, 0.5, 0.5, true)
    else
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Not installed. Click for the download link.", 0.7, 0.7, 0.7, true)
    end
    GameTooltip:Show()
end

local function MakeButton(i)
    local b = CreateFrame("Button", nil, ring)
    b:SetSize(31, 31)
    b:RegisterForClicks("AnyUp")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b.icon = b:CreateTexture(nil, "BACKGROUND")
    b.icon:SetSize(20, 20)
    b.icon:SetPoint("CENTER", 0, 1)
    local mask = b:CreateMaskTexture()
    mask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(b.icon)
    b.icon:AddMaskTexture(mask)
    b.border = b:CreateTexture(nil, "OVERLAY")
    b.border:SetSize(53, 53)
    b.border:SetPoint("TOPLEFT")
    b.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b.pop = b:CreateAnimationGroup()
    local grow = b.pop:CreateAnimation("Scale")
    grow:SetScaleFrom(0.2, 0.2)
    grow:SetScaleTo(1, 1)
    grow:SetDuration(0.18)
    local fade = b.pop:CreateAnimation("Alpha")
    fade:SetFromAlpha(0)
    fade:SetToAlpha(1)
    fade:SetDuration(0.18)
    b:SetScript("OnEnter", function(self) Tooltip(self, self.entry) end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnClick", function(self, mouse)
        local entry = self.entry
        local state = State(entry)
        if state == "missing" then ShowLink(entry) return end
        if state == "off" then return end
        local action = (mouse == "RightButton" and entry.right) or entry.left
        local ok, err = pcall(action, mouse)
        if not ok then print("|cffffd100Addon Hub:|r " .. entry.name .. " couldn't open: " .. tostring(err)) end
        if not db.keepOpen then ring:Hide() end
    end)
    buttons[i] = b
    return b
end

local function LayoutRing()
    Sweep()
    local shown = {}
    for _, entry in ipairs(ADDONS) do
        local state = State(entry)
        if state == "loaded" or db.showMissing then shown[#shown + 1] = { entry = entry, state = state } end
    end
    if db.tuck then
        for _, entry in ipairs(extras) do shown[#shown + 1] = { entry = entry, state = "loaded" } end
    end
    local inner = (Minimap:GetWidth() / 2) + 28
    local count = #shown
    local perRing = math.max(6, math.floor(2 * math.pi * inner / 33) - 1)
    for i = 1, math.max(#buttons, count) do
        local b = buttons[i] or (i <= count and MakeButton(i))
        if b then
            local item = shown[i]
            if item then
                b.entry = item.entry
                b.icon:SetTexture(item.entry.icon)
                if item.entry.fallback and item.state ~= "loaded" then b.icon:SetTexture(item.entry.fallback) end
                b.icon:SetDesaturated(item.state ~= "loaded")
                b:SetAlpha(item.state == "loaded" and 1 or 0.55)
                -- the first ring fans out from just past the hub button; extra buttons go on a wider ring
                local r = math.floor((i - 1) / perRing)
                local inRing = math.min(perRing, count - r * perRing)
                local step = 360 / (inRing + 1)
                local radius = inner + r * 34
                local angle = math.rad(db.angle + step * ((i - 1) % perRing + 1) + r * step / 2)
                b:ClearAllPoints()
                b:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
                b:Show()
                b.pop:Stop()
                C_Timer.After((i - 1) * 0.025, function() if b:IsShown() then b.pop:Play() end end)
            else
                b:Hide()
            end
        end
    end
end

local function ToggleRing()
    if ring:IsShown() then
        ring:Hide()
    else
        ring:Show()
        LayoutRing()
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPEN or 850)
    end
end

---------------------------------------------------------------------------
-- Hub button and its little settings menu
---------------------------------------------------------------------------

local menu

local function ShowMenu()
    if not menu then
        menu = CreateFrame("Frame", "ForeverAddonHubMenu", UIParent, "BackdropTemplate")
        menu:SetSize(230, 160)
        menu:SetFrameStrata("DIALOG")
        menu:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
            insets = { left = 3, right = 3, top = 3, bottom = 3 } })
        local title = menu:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        title:SetPoint("TOP", 0, -10)
        title:SetText("Addon Hub")
        menu.buttons = {}
        local options = {
            { key = "showMissing", on = "Show addons I don't have: on", off = "Show addons I don't have: off" },
            { key = "keepOpen", on = "Keep the ring open: on", off = "Keep the ring open: off" },
            { key = "tuck", on = "Tuck other minimap buttons: on", off = "Tuck other minimap buttons: off" },
        }
        for i, opt in ipairs(options) do
            local b = CreateFrame("Button", nil, menu, "UIPanelButtonTemplate")
            b:SetSize(206, 24)
            b:SetPoint("TOP", 0, -28 - (i - 1) * 28)
            b:SetScript("OnClick", function()
                db[opt.key] = not db[opt.key]
                if opt.key == "tuck" then
                    if db.tuck then Sweep() else Untuck() end
                end
                ShowMenu()
                if ring:IsShown() then LayoutRing() end
            end)
            b.opt = opt
            menu.buttons[i] = b
        end
        local hide = CreateFrame("Button", nil, menu, "UIPanelButtonTemplate")
        hide:SetSize(206, 24)
        hide:SetPoint("TOP", 0, -112)
        hide:SetText("Hide hub button (/hub brings it back)")
        hide:GetFontString():SetFontObject("GameFontNormalSmall")
        hide:SetScript("OnClick", function() db.hidden = true hub:Hide() ring:Hide() menu:Hide() end)
        tinsert(UISpecialFrames, "ForeverAddonHubMenu")
    end
    for _, b in ipairs(menu.buttons) do b:SetText(db[b.opt.key] and b.opt.on or b.opt.off) end
    menu:ClearAllPoints()
    menu:SetPoint("TOPRIGHT", hub, "BOTTOMLEFT", 0, 0)
    menu:Show()
end

local function PlaceHub()
    local angle = math.rad(db.angle)
    local radius = (Minimap:GetWidth() / 2) + 5
    hub:ClearAllPoints()
    hub:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateHub()
    ring = CreateFrame("Frame", "ForeverAddonHubRing", Minimap)
    ring:SetAllPoints()
    ring:SetFrameStrata("MEDIUM")
    ring:SetFrameLevel(9)
    ring:Hide()

    hub = CreateFrame("Button", "ForeverAddonHubButton", Minimap)
    hub:SetSize(33, 33)
    hub:SetFrameStrata("MEDIUM")
    hub:SetFrameLevel(10)
    hub:RegisterForClicks("AnyUp")
    hub:RegisterForDrag("LeftButton")
    hub:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local icon = hub:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(21, 21)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture(I("Trade_Engineering"))
    local border = hub:CreateTexture(nil, "OVERLAY")
    border:SetSize(55, 55)
    border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetVertexColor(1, 0.85, 0.4)
    hub:SetScript("OnClick", function(_, mouse)
        if mouse == "RightButton" then ShowMenu() else ToggleRing() end
    end)
    hub:SetScript("OnDragStart", function(self)
        ring:Hide()
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            db.angle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
            PlaceHub()
        end)
    end)
    hub:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    hub:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Addon Hub", 1, 0.82, 0)
        local loaded = 0
        for _, entry in ipairs(ADDONS) do if State(entry) == "loaded" then loaded = loaded + 1 end end
        GameTooltip:AddLine(string.format("All the WoW Forever addons in one place. You have %d of %d.", loaded, #ADDONS), 1, 1, 1, true)
        if db.tuck and #extras > 0 then
            GameTooltip:AddLine(string.format("Plus %d other addon button%s tucked in.", #extras, #extras == 1 and "" or "s"), 0.8, 0.8, 0.8, true)
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cffffd100Click:|r show or hide the addon buttons", 1, 1, 1)
        GameTooltip:AddLine("|cffffd100Right-click:|r settings", 1, 1, 1)
        GameTooltip:AddLine("|cffffd100Drag:|r move this button", 1, 1, 1)
        GameTooltip:Show()
    end)
    hub:SetScript("OnLeave", function() GameTooltip:Hide() end)
    PlaceHub()
    hub:SetShown(not db.hidden)
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent", function(self, _, name)
    if name ~= addonName then return end
    self:UnregisterEvent("ADDON_LOADED")
    ForeverAddonHubDB = type(ForeverAddonHubDB) == "table" and ForeverAddonHubDB or {}
    db = ForeverAddonHubDB
    if db.angle == nil then db.angle = 135 end
    if db.showMissing == nil then db.showMissing = true end
    if db.keepOpen == nil then db.keepOpen = false end
    if db.tuck == nil then db.tuck = true end
    CreateHub()
    self:RegisterEvent("PLAYER_LOGIN")
    self:SetScript("OnEvent", function()
        Sweep()
        C_Timer.After(1, Sweep)
        C_Timer.After(5, Sweep)
        local lib = LibIcon()
        if lib and lib.RegisterCallback then
            pcall(lib.RegisterCallback, ADDONS, "LibDBIcon_IconCreated", function() C_Timer.After(0, Sweep) end)
        end
    end)
end)

SLASH_FOREVERADDONHUB1 = "/hub"
SLASH_FOREVERADDONHUB2 = "/addonhub"
SlashCmdList.FOREVERADDONHUB = function()
    db.hidden = false
    hub:Show()
    if not ring:IsShown() then ToggleRing() end
end

function ForeverAddonHub_OnCompartmentClick()
    if not ring:IsShown() then ToggleRing() end
end
