Forever Addon Hub 1.1.0 - World of Warcraft: Forever (Interface 16001)
======================================================================

One button on the minimap for every addon in the WoW Forever Addons
collection (github.com/Deathbringer98/WoW-Forever-Addons).

INSTALL
Copy the ForeverAddonHub folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

USE
Click the gear button on the minimap: a ring of buttons fans out around the
minimap, one for each addon. Click one to open it; some also do something on
right-click (hover a button to see).

Every addon's own minimap button is tucked away, so the hub is the only
button left on your minimap. That includes other addons that use the common
LibDBIcon minimap button: they get a button in the ring too, and clicking it
works the same as clicking their old minimap button.

Addons you don't have yet are shown faded. Click one for its download link.
Addons that are installed but turned off say so in their tooltip.

Right-click the hub button for settings:
  Show addons I don't have   on or off
  Keep the ring open         keeps the ring up after you click an addon
  Tuck other minimap buttons on: only the hub stays on the minimap
                             off: every button goes back to the minimap
  Hide hub button            type /hub to bring it back
Drag the hub button to move it around the minimap.

CREDITS AND LICENSE
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Released under the GNU GPL v3.
