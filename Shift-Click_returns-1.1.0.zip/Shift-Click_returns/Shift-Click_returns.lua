-- Shift-Click Returns for World of Warcraft: Forever (Interface 16001)
-- Shift-click a player's name in chat, or their target, focus or party frame, and the name drops into a
-- small window with buttons to invite them to your group or guild, whisper, add as a friend, look up or
-- copy. If Blizzard's own "add" or "invite" name box is open, the name goes straight into it instead.
--
-- How the buttons stay allowed: the game only lets its own interface call invite, friend and who
-- functions directly. So each button is a secure button that runs the slash command you would type
-- yourself (/invite, /ginvite, /friend, /who). Clicking it counts as you doing it. Secure buttons can
-- only be changed out of combat, so the window closes in combat and the name updates after it.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\"
local PREFIX = "|cff7cf0a8Shift-Click Returns:|r "
local MAX_HISTORY = 8

local db
local window, minimapButton
local pendingName          -- a name caught during combat, shown when combat ends
local commandsStale = false -- the buttons still hold an older name (changed during combat)

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local results = { pcall(fn, ...) }
    if not results[1] or IsSecret(results[2]) then return nil end
    return select(2, unpack(results))
end

local function Clean(name)
    if type(name) ~= "string" or IsSecret(name) then return nil end
    name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
    -- Names never contain these; dropping them keeps a typed name from adding a second command.
    name = name:gsub("[\n\r\"/;]", "")
    if name == "" then return nil end
    return name
end

local function InCombat()
    return type(InCombatLockdown) == "function" and InCombatLockdown()
end

-- A player's full name from a unit, with the realm when it is not yours.
local function UnitFullName(unit)
    if Plain(UnitIsPlayer, unit) ~= true then return nil end
    if Plain(UnitIsUnit, unit, "player") == true then return nil end
    local name = Plain(GetUnitName, unit, true)
    if not Clean(name) then name = Plain(UnitName, unit) end
    return Clean(name)
end

---------------------------------------------------------------------------
-- Blizzard's own name boxes (Add Friend, Add Ignore, guild invite, channel invite)
---------------------------------------------------------------------------

local function PopupEditBox(popup)
    if type(popup) ~= "table" then return nil end
    if type(popup.GetEditBox) == "function" then
        local box = Plain(popup.GetEditBox, popup)
        if box then return box end
    end
    return popup.editBox or popup.EditBox
end

-- Puts the name into an open Blizzard "add" or "invite" box. Returns true when it did.
local function FillBlizzardBox(name)
    if not db.fillPopups then return false end
    for i = 1, 4 do
        local popup = _G["StaticPopup" .. i]
        if type(popup) == "table" and popup:IsShown() then
            local which = popup.which
            local def = type(StaticPopupDialogs) == "table" and type(which) == "string" and StaticPopupDialogs[which]
            local nameBox = type(which) == "string" and (which:find("^ADD_") or which:find("INVITE") or which:find("GUILD"))
            local box = PopupEditBox(popup)
            if def and def.hasEditBox and nameBox and box then
                box:SetText(name)
                box:SetFocus()
                return true
            end
        end
    end
    return false
end

---------------------------------------------------------------------------
-- The window
---------------------------------------------------------------------------

local function Style(b, width, text, tip)
    b:SetSize(width, 22)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.06, 0.18, 0.12, 0.95)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text)
    b.tip = tip
    b:HookScript("OnEnter", function(self)
        bg:SetColorTexture(0.12, 0.36, 0.24, 0.95)
        if self.tip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.tip, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:HookScript("OnLeave", function()
        bg:SetColorTexture(0.06, 0.18, 0.12, 0.95)
        GameTooltip:Hide()
    end)
    return b
end

local function Button(parent, width, text, onClick, tip)
    local b = Style(CreateFrame("Button", nil, parent), width, text, tip)
    b:SetScript("OnClick", onClick)
    return b
end

local RefreshWindow

local function CurrentName()
    if not window then return nil end
    return Clean(window.box:GetText())
end

-- Slash commands the secure buttons run. %s is the name.
local COMMANDS = {
    { "Invite to group", "/invite %s", "Invites them to your party or raid." },
    { "Invite to guild", "/ginvite %s", "Invites them to your guild. You need the rank to invite." },
    { "Add friend", "/friend %s", "Adds them to your friends list." },
    { "Who is this?", '/who n-"%s"', "Looks them up with /who: level, class, guild and zone." },
}

-- Writes the current name into the secure buttons. Only possible out of combat.
local function UpdateCommands()
    if not window then return end
    if InCombat() then
        commandsStale = true
        return
    end
    local name = CurrentName()
    for _, b in ipairs(window.commands) do
        b:SetAttribute("macrotext", name and string.format(b.command, name) or "")
    end
    commandsStale = false
end

local function SetName(name)
    if not window then return end
    window.box:SetText(name or "")
    window.box:ClearFocus()
    if name then
        for i = #db.history, 1, -1 do
            if db.history[i] == name then table.remove(db.history, i) end
        end
        table.insert(db.history, 1, name)
        while #db.history > MAX_HISTORY do table.remove(db.history) end
    end
    UpdateCommands()
    RefreshWindow()
end

-- Whispering: the chat box is Blizzard's, so the addon writes a player link into your chat window.
-- Clicking that link opens the whisper through Blizzard's own code.
local function WhisperLink(name)
    local link = "|Hplayer:" .. name .. "|h|cff7cf0a8[" .. name .. "]|r|h"
    local frame = (type(SELECTED_CHAT_FRAME) == "table" and SELECTED_CHAT_FRAME) or DEFAULT_CHAT_FRAME
    if type(frame) == "table" and type(frame.AddMessage) == "function" then
        frame:AddMessage(PREFIX .. "click " .. link .. " to whisper them.")
    else
        Say("click " .. link .. " to whisper them.")
    end
end

local function CreateWindow()
    if InCombat() then return false end
    -- A secure frame: the game hides it on its own when combat starts, since its buttons are secure.
    local w = CreateFrame("Frame", "ShiftClickReturnsFrame", UIParent, "SecureHandlerStateTemplate")
    w:SetSize(300, 200 + MAX_HISTORY * 18)
    w:SetFrameStrata("DIALOG")
    w:SetClampedToScreen(true)
    w:EnableMouse(true)
    w:SetMovable(true)
    w:RegisterForDrag("LeftButton")
    w:SetScript("OnDragStart", function(self) if not InCombat() then self:StartMoving() end end)
    w:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
            db.pos = { point, relPoint, x, y }
        end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
        w:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        w:SetPoint("CENTER", UIParent, "CENTER", 260, 60)
    end
    if type(RegisterStateDriver) == "function" then
        w:SetAttribute("_onstate-combat", [[ if newstate == "1" then self:Hide() end ]])
        pcall(RegisterStateDriver, w, "combat", "[combat] 1; 0")
    end
    local border = w:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.35, 0.85, 0.55, 1)
    local bg = w:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 2, -2)
    bg:SetPoint("BOTTOMRIGHT", -2, 2)
    bg:SetColorTexture(0.03, 0.06, 0.05, 0.96)
    local title = w:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("Shift-Click Returns")
    local close = Button(w, 22, "X", function() if not InCombat() then w:Hide() end end)
    close:SetPoint("TOPRIGHT", -10, -10)

    -- The name box: filled by shift-clicks, and you can type in it too.
    local frameBg = w:CreateTexture(nil, "BACKGROUND", nil, -6)
    frameBg:SetPoint("TOPLEFT", 14, -40)
    frameBg:SetSize(194, 24)
    frameBg:SetColorTexture(0, 0, 0, 0.8)
    local box = CreateFrame("EditBox", "ShiftClickReturnsName", w)
    box:SetPoint("TOPLEFT", 20, -40)
    box:SetSize(184, 24)
    box:SetAutoFocus(false)
    box:SetFontObject("ChatFontNormal")
    box:SetMaxLetters(64)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    box:SetScript("OnEnterPressed", function(self) self:ClearFocus() SetName(Clean(self:GetText())) end)
    box:SetScript("OnTextChanged", function(_, userInput) if userInput then UpdateCommands() end end)
    w.box = box
    local fromTarget = Button(w, 74, "My target", function()
        local name = UnitFullName("target")
        if name then SetName(name) else Say("your target is not another player.") end
    end, "Puts your current target's name in the box.")
    fromTarget:SetPoint("TOPLEFT", 214, -41)

    -- Secure buttons: each runs a slash command with the name, exactly as if you typed it.
    w.commands = {}
    for i, c in ipairs(COMMANDS) do
        local b = Style(CreateFrame("Button", nil, w, "SecureActionButtonTemplate"), 132, c[1], c[3])
        b:SetAttribute("type", "macro")
        b:SetAttribute("macrotext", "")
        b:RegisterForClicks("AnyUp", "AnyDown")
        b.command = c[2]
        b:SetScript("PostClick", function()
            if not CurrentName() then Say("shift-click a player's name first, or type one in.") end
        end)
        w.commands[i] = b
    end
    local whisper = Button(w, 132, "Whisper", function()
        local name = CurrentName()
        if name then WhisperLink(name) else Say("shift-click a player's name first, or type one in.") end
    end, "Puts a link to them in your chat window. Click the link to start the whisper.")
    local copy = Button(w, 132, "Copy name", function()
        if not CurrentName() then Say("shift-click a player's name first, or type one in.") return end
        box:SetFocus()
        box:HighlightText()
        Say("name selected: press Ctrl+C to copy it.")
    end, "Selects the name so you can press Ctrl+C to copy it.")
    local order = { w.commands[1], w.commands[2], whisper, w.commands[3], w.commands[4], copy }
    for i, b in ipairs(order) do
        b:SetPoint("TOPLEFT", 14 + ((i - 1) % 2) * 140, -72 - math.floor((i - 1) / 2) * 26)
    end

    local recent = w:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    recent:SetPoint("TOPLEFT", 14, -156)
    recent:SetText("Recent")
    w.history = {}
    for i = 1, MAX_HISTORY do
        local r = CreateFrame("Button", nil, w)
        r:SetSize(272, 17)
        r:SetPoint("TOPLEFT", 14, -174 - (i - 1) * 18)
        r.text = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.text:SetPoint("LEFT", 4, 0)
        local hl = r:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(1, 1, 1, 0.08)
        r:SetScript("OnClick", function(self) if self.name then SetName(self.name) end end)
        w.history[i] = r
    end
    w.empty = w:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    w.empty:SetPoint("TOPLEFT", 18, -176)
    w.empty:SetWidth(264)
    w.empty:SetJustifyH("LEFT")
    w.empty:SetText("Shift-click a player's name in chat, or shift-click their target, focus or party frame.")

    -- Settings
    w.toggles = {}
    local settings = {
        { "chat", "Chat names", "Shift-clicking a player's name in chat sends it here (unless you are typing in chat)." },
        { "frames", "Unit frames", "Shift-clicking a player's target, focus or party frame sends their name here." },
        { "fillPopups", "Fill invite boxes", "When Blizzard's Add Friend, Add Ignore or guild or channel invite box is open, the name goes straight into it." },
        { "minimap", "Minimap button", "A button on the minimap that opens this window. Drag it around the minimap to move it." },
    }
    for i, s in ipairs(settings) do
        local b = Button(w, 132, "", function()
            db[s[1]] = not db[s[1]]
            if s[1] == "minimap" and ns.UpdateMinimapButton then ns.UpdateMinimapButton() end
            RefreshWindow()
        end, s[3])
        b:SetPoint("BOTTOMLEFT", 14 + ((i - 1) % 2) * 140, 38 - math.floor((i - 1) / 2) * 26)
        b.field, b.title = s[1], s[2]
        w.toggles[i] = b
    end

    w:SetScript("OnShow", function() RefreshWindow() end)
    w:Hide()
    window = w
    return true
end

RefreshWindow = function()
    if not window or not window:IsShown() then return end
    for i, r in ipairs(window.history) do
        local name = db.history[i]
        r.name = name
        r.text:SetText(name or "")
        r:SetShown(name ~= nil)
    end
    window.empty:SetShown(#db.history == 0)
    for _, b in ipairs(window.toggles) do
        b.label:SetText(b.title .. ": " .. (db[b.field] and "on" or "off"))
    end
end

-- Opens the window, with a name if given. In combat it waits until the fight is over.
local function Open(name)
    if not db then return end
    if InCombat() then
        if name then
            pendingName = name
            Say(name .. " saved. The window opens when your fight is over.")
        else
            Say("the window opens out of combat.")
        end
        return
    end
    if not window and not CreateWindow() then return end
    window:Show()
    if name then SetName(name) end
end

local function ToggleWindow()
    if not db then return end
    if window and window:IsShown() then
        if not InCombat() then window:Hide() end
    else
        Open()
    end
end

function ShiftClickReturns_OnCompartmentClick()
    ToggleWindow()
end

---------------------------------------------------------------------------
-- Catching the shift-clicks
---------------------------------------------------------------------------

-- A name was shift-clicked somewhere.
local function Caught(name)
    name = Clean(name)
    if not name then return end
    if FillBlizzardBox(name) then return end
    Open(name)
end

local function TypingInChat()
    if type(ChatEdit_GetActiveWindow) == "function" and Plain(ChatEdit_GetActiveWindow) then return true end
    if type(ChatFrameUtil) == "table" and type(ChatFrameUtil.GetActiveWindow) == "function" and Plain(ChatFrameUtil.GetActiveWindow) then return true end
    return false
end

-- Chat: player links look like "player:Name-Realm:lineID:chatType".
local function OnItemRef(link, text, button)
    if not db or not db.chat then return end
    if type(link) ~= "string" or IsSecret(link) then return end
    if not IsShiftKeyDown() or (button and button ~= "LeftButton") then return end
    local name = link:match("^player:([^:]+)")
    if not name then return end
    -- Typing in chat: Blizzard puts the name into your message, so leave it there.
    if TypingInChat() and not FillBlizzardBox(name) then return end
    Caught(name)
end

local UNIT_FRAMES = { "TargetFrame", "FocusFrame", "TargetFrameToT", "FocusFrameToT", "PartyMemberFrame1", "PartyMemberFrame2", "PartyMemberFrame3", "PartyMemberFrame4" }

local hookedFrames = {}
local function HookFrame(frame)
    if type(frame) ~= "table" or hookedFrames[frame] or type(frame.HookScript) ~= "function" then return end
    hookedFrames[frame] = true
    -- A post-hook: the frame still targets as normal, this only reads the name.
    frame:HookScript("OnClick", function(self, button)
        if not db or not db.frames or button ~= "LeftButton" or not IsShiftKeyDown() then return end
        local unit = self.unit
        if type(unit) ~= "string" and type(self.GetAttribute) == "function" then unit = Plain(self.GetAttribute, self, "unit") end
        if type(unit) ~= "string" or IsSecret(unit) then return end
        local name = UnitFullName(unit)
        if name then Caught(name) end
    end)
end

local function HookUnitFrames()
    if InCombat() then return end
    for _, n in ipairs(UNIT_FRAMES) do HookFrame(_G[n]) end
    if type(PartyFrame) == "table" then
        for i = 1, 4 do HookFrame(PartyFrame["MemberFrame" .. i]) end
    end
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 120)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "ShiftClickReturnsMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    local back = b:CreateTexture(nil, "BACKGROUND")
    back:SetSize(22, 22)
    back:SetPoint("CENTER")
    back:SetColorTexture(0.03, 0.06, 0.05, 0.9)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")
    icon:SetTexture(TEXTURES .. "Icon.tga")
    icon:SetVertexColor(0.5, 1, 0.7, 1)
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", ToggleWindow)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Shift-Click Returns", 0.5, 1, 0.7)
        GameTooltip:AddLine("Click to open. Shift-click a player's name to fill it.", 1, 1, 1, true)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

ns.UpdateMinimapButton = function()
    if not db or not Minimap then return end
    if db.minimap then
        if not minimapButton then CreateMinimapButton() end
        minimapButton:Show()
    elseif minimapButton then
        minimapButton:Hide()
    end
end

---------------------------------------------------------------------------
-- Slash command and events
---------------------------------------------------------------------------

SLASH_SHIFTCLICKRETURNS1 = "/scr"
SLASH_SHIFTCLICKRETURNS2 = "/shiftclick"
SlashCmdList.SHIFTCLICKRETURNS = function(message)
    local name = Clean(message)
    if name and name:lower() == "help" then
        Say("/scr opens the window. /scr Name opens it with that name. Everything else is a button.")
    elseif name then
        Open(name)
    else
        ToggleWindow()
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        ShiftClickReturnsDB = type(ShiftClickReturnsDB) == "table" and ShiftClickReturnsDB or {}
        db = ShiftClickReturnsDB
        for key, value in pairs({ chat = true, frames = true, fillPopups = true, minimap = true }) do
            if type(db[key]) ~= "boolean" then db[key] = value end
        end
        if type(db.history) ~= "table" then db.history = {} end
        if type(SetItemRef) == "function" then hooksecurefunc("SetItemRef", OnItemRef) end
        HookUnitFrames()
        pcall(self.RegisterEvent, self, "GROUP_ROSTER_UPDATE")
        pcall(self.RegisterEvent, self, "PLAYER_REGEN_ENABLED")
        CreateWindow()
        ns.UpdateMinimapButton()
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        if commandsStale then UpdateCommands() end
        if pendingName then
            local name = pendingName
            pendingName = nil
            Open(name)
        end
    end
    -- Party frames can be made later: hook any new ones, out of combat.
    HookUnitFrames()
end)

-- For the automated tests.
ns.OnItemRef = OnItemRef
