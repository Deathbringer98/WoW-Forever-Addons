-- Living Portraits for World of Warcraft: Forever (Interface 16001)
-- Replaces the flat unit frame portraits with live, animated 3D heads, in the spirit of Warcraft III.
-- Cosmetic only. It adds its own frames under the Blizzard unit frames and never moves, resizes or
-- re-anchors a Blizzard frame, so it stays clear of combat lockdown.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\LivingPortraits\\Textures\\"
local PREFIX = "|cff7fd4ffLiving Portraits:|r "
local ANIM_STAND, ANIM_DEAD, ANIM_TALK = 0, 6, 60

local db
local slots = {}
local bySlotKey = {}
local big

local defaults = {
    enabled = true,
    talk = true,
    backdrop = true,
    big = false,
    fill = 0.82,
    units = { player = true, target = true, focus = true, pet = true, tot = true, party = true },
}

local GROUP_LABEL = { player = "player", target = "target", focus = "focus", pet = "pet", tot = "target of target", party = "party" }

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

-- Calls fn safely and returns its first result, or nil on an error or a secret value.
local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, v = pcall(fn, ...)
    if not ok or IsSecret(v) then return nil end
    return v
end

local function Clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

-- Safe nested lookup: Field(PlayerFrame, "PlayerFrameContainer", "PlayerPortrait")
local function Field(root, ...)
    local v = root
    for i = 1, select("#", ...) do
        if type(v) ~= "table" then return nil end
        v = v[select(i, ...)]
    end
    return v
end

local function IsTexture(obj)
    if type(obj) ~= "table" or type(obj.GetObjectType) ~= "function" then return false end
    local ok, kind = pcall(obj.GetObjectType, obj)
    return ok and kind == "Texture"
end

local function FirstTexture(...)
    for i = 1, select("#", ...) do
        local obj = select(i, ...)
        if IsTexture(obj) then return obj end
    end
    return nil
end

---------------------------------------------------------------------------
-- Where the Blizzard portraits live. Each finder returns the unit frame and its portrait texture.
---------------------------------------------------------------------------

local function Finder(getFrame, ...)
    local path = { ... }
    return function()
        local frame = getFrame()
        if type(frame) ~= "table" then return nil end
        local portrait = FirstTexture(frame.portrait, frame.Portrait)
        if not portrait then
            for _, keys in ipairs(path) do
                if type(keys) == "string" then
                    portrait = FirstTexture(_G[keys])
                else
                    portrait = FirstTexture(Field(frame, unpack(keys)))
                end
                if portrait then break end
            end
        end
        if portrait then return frame, portrait end
        return nil
    end
end

local function AddSlot(key, group, unit, find)
    local slot = { key = key, group = group, unit = unit, find = find }
    slots[#slots + 1] = slot
    bySlotKey[key] = slot
end

AddSlot("player", "player", "player", Finder(function() return _G.PlayerFrame end,
    { "PlayerFrameContainer", "PlayerPortrait" }, "PlayerPortrait"))
AddSlot("target", "target", "target", Finder(function() return _G.TargetFrame end,
    { "TargetFrameContainer", "Portrait" }, "TargetFramePortrait"))
AddSlot("focus", "focus", "focus", Finder(function() return _G.FocusFrame end,
    { "TargetFrameContainer", "Portrait" }, "FocusFramePortrait"))
AddSlot("pet", "pet", "pet", Finder(function() return _G.PetFrame end, "PetPortrait"))
AddSlot("targettarget", "tot", "targettarget", Finder(function() return _G.TargetFrameToT or Field(_G.TargetFrame, "totFrame") end,
    "TargetFrameToTPortrait"))
AddSlot("focustarget", "tot", "focustarget", Finder(function() return _G.FocusFrameToT or Field(_G.FocusFrame, "totFrame") end,
    "FocusFrameToTPortrait"))
for i = 1, 4 do
    AddSlot("party" .. i, "party", "party" .. i, Finder(function()
        return Field(_G.PartyFrame, "MemberFrame" .. i) or _G["PartyMemberFrame" .. i]
    end, "PartyMemberFrame" .. i .. "Portrait"))
end

---------------------------------------------------------------------------
-- Models
---------------------------------------------------------------------------

local function ApplyCamera(model)
    pcall(model.SetPortraitZoom, model, model.lpZoom or 1)
    pcall(model.SetCamDistanceScale, model, 1)
    pcall(model.SetPosition, model, 0, 0, 0)
    if model.lpAnim then pcall(model.SetAnimation, model, model.lpAnim) end
end

local function NewModel(parent, name)
    local model = CreateFrame("PlayerModel", name, parent)
    model:EnableMouse(false)
    model:SetScript("OnModelLoaded", ApplyCamera)
    return model
end

-- Puts a unit on a model. Returns false when the client refuses.
local function ShowUnit(model, unit)
    pcall(model.ClearModel, model)
    local ok = pcall(model.SetUnit, model, unit)
    if not ok then return false end
    model.lpAnim = (Plain(UnitIsDeadOrGhost, unit) == true) and ANIM_DEAD or ANIM_STAND
    model.lpTalk = (model.lpTalk or 0) + 1 -- cancels a talk animation that is still running
    ApplyCamera(model)
    return true
end

local function Layout(slot)
    local inset = 0
    local width = Plain(slot.portrait.GetWidth, slot.portrait)
    if type(width) == "number" and width > 0 then inset = width * (1 - db.fill) / 2 end
    slot.model:ClearAllPoints()
    slot.model:SetPoint("TOPLEFT", slot.holder, "TOPLEFT", inset, -inset)
    slot.model:SetPoint("BOTTOMRIGHT", slot.holder, "BOTTOMRIGHT", -inset, inset)
    slot.disc:SetShown(db.backdrop)
end

-- Builds the holder and model for a slot the first time its Blizzard frame is found.
local function Build(slot)
    if slot.holder then return true end
    local owner, portrait = slot.find()
    if not owner then return false end
    slot.owner, slot.portrait = owner, portrait

    -- The holder sits one level under the unit frame, so the frame's ring art draws over the model.
    local holder = CreateFrame("Frame", "LivingPortraits_" .. slot.key, owner)
    holder:SetAllPoints(portrait)
    holder:EnableMouse(false)
    local level = Plain(owner.GetFrameLevel, owner)
    local base = math.max(0, (type(level) == "number" and level or 2) - 2)
    local strata = Plain(owner.GetFrameStrata, owner)
    if type(strata) == "string" then holder:SetFrameStrata(strata) end
    holder:SetFrameLevel(base)
    slot.holder = holder

    slot.disc = holder:CreateTexture(nil, "BACKGROUND")
    slot.disc:SetAllPoints(holder)
    slot.disc:SetTexture(TEXTURES .. "Disc.tga")
    slot.disc:SetVertexColor(0.05, 0.06, 0.09, 0.92)

    slot.model = NewModel(holder, nil)
    slot.model:SetFrameLevel((type(level) == "number" and base + 1 < level) and base + 1 or base)
    Layout(slot)
    holder:Hide()
    return true
end

local function SlotUnit(slot)
    -- The player frame switches its unit to the vehicle while you ride one.
    local unit = slot.owner and slot.owner.unit
    if type(unit) == "string" and not IsSecret(unit) and unit ~= "" then return unit end
    return slot.unit
end

local function Wanted(slot)
    if not db.enabled or not db.units[slot.group] then return false end
    local unit = SlotUnit(slot)
    if Plain(UnitExists, unit) == false then return false end
    -- A unit that is out of sight has no model to draw, so the flat portrait stays.
    if Plain(UnitIsVisible, unit) == false then return false end
    return true
end

local function Restore(slot)
    if slot.holder then slot.holder:Hide() end
    if slot.live then
        slot.live = false
        pcall(slot.portrait.SetAlpha, slot.portrait, 1)
    end
end

-- force = put the unit on the model again (the unit changed). Otherwise only visibility is checked.
local function Refresh(slot, force)
    if not Build(slot) then return end
    if not Wanted(slot) then
        Restore(slot)
        return
    end
    if force or not slot.live then
        if not ShowUnit(slot.model, SlotUnit(slot)) then
            Restore(slot)
            return
        end
    end
    slot.live = true
    slot.holder:Show()
    pcall(slot.portrait.SetAlpha, slot.portrait, 0)
end

local function RefreshAll(force)
    for _, slot in ipairs(slots) do Refresh(slot, force) end
end

local function RefreshKey(key, force)
    local slot = bySlotKey[key]
    if slot then Refresh(slot, force) end
end

---------------------------------------------------------------------------
-- The big Warcraft III style portrait window
---------------------------------------------------------------------------

local function BigUnit()
    if Plain(UnitExists, "target") == true then return "target" end
    return "player"
end

local function RefreshBig(force)
    if not db.big or not db.enabled then
        if big then big:Hide() end
        return
    end
    if not big then
        big = CreateFrame("Frame", "LivingPortraitsBig", UIParent)
        big:SetSize(150, 176)
        big:SetFrameStrata("MEDIUM")
        big:SetClampedToScreen(true)
        big:EnableMouse(true)
        big:SetMovable(true)
        big:RegisterForDrag("LeftButton")
        big:SetScript("OnDragStart", big.StartMoving)
        big:SetScript("OnDragStop", function(self)
            self:StopMovingOrSizing()
            local point, _, relPoint, x, y = self:GetPoint(1)
            if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
                db.bigPos = { point, relPoint, x, y }
            end
        end)
        local pos = db.bigPos
        if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
            big:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
        else
            big:SetPoint("BOTTOM", UIParent, "BOTTOM", -250, 160)
        end
        local border = big:CreateTexture(nil, "BACKGROUND", nil, -8)
        border:SetAllPoints()
        border:SetColorTexture(0.72, 0.58, 0.22, 1)
        local inner = big:CreateTexture(nil, "BACKGROUND", nil, -7)
        inner:SetPoint("TOPLEFT", 2, -2)
        inner:SetPoint("BOTTOMRIGHT", -2, 2)
        inner:SetColorTexture(0.03, 0.04, 0.07, 0.95)
        big.model = NewModel(big, nil)
        big.model.lpZoom = 0.88
        big.model:SetPoint("TOPLEFT", 4, -4)
        big.model:SetPoint("BOTTOMRIGHT", -4, 24)
        big.name = big:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        big.name:SetPoint("BOTTOMLEFT", 6, 6)
        big.name:SetPoint("BOTTOMRIGHT", -6, 6)
        big.name:SetWordWrap(false)
        force = true
    end
    local unit = BigUnit()
    if force or big.unit ~= unit or not big:IsShown() then
        big.unit = unit
        ShowUnit(big.model, unit)
        -- A name can be a secret value in combat. SetText accepts it as long as we never inspect it.
        if not pcall(function() big.name:SetText(UnitName(unit)) end) then big.name:SetText("") end
    end
    big:Show()
end

---------------------------------------------------------------------------
-- Talking: play the talk animation on whoever just spoke
---------------------------------------------------------------------------

local function Talk(model, seconds)
    model.lpTalk = (model.lpTalk or 0) + 1
    local token = model.lpTalk
    pcall(model.SetAnimation, model, ANIM_TALK)
    C_Timer.After(seconds, function()
        if model.lpTalk == token then pcall(model.SetAnimation, model, model.lpAnim or ANIM_STAND) end
    end)
end

local function OnChat(text, sender, guid)
    if not db.talk or not db.enabled then return end
    local seconds = 2.5
    if type(text) == "string" and not IsSecret(text) then seconds = Clamp(#text * 0.06, 1.5, 6) end
    local senderGUID = (type(guid) == "string" and not IsSecret(guid) and guid ~= "") and guid or nil
    local senderName = (type(sender) == "string" and not IsSecret(sender) and sender ~= "") and sender or nil
    if not senderGUID and not senderName then return end
    local function Matches(unit)
        if senderGUID then
            local unitGUID = Plain(UnitGUID, unit)
            if unitGUID then return unitGUID == senderGUID end
        end
        if senderName then
            local name = Plain(UnitName, unit)
            if name then return name == senderName or senderName:find(name .. "-", 1, true) == 1 end
        end
        return false
    end
    for _, slot in ipairs(slots) do
        if slot.live and Matches(SlotUnit(slot)) then Talk(slot.model, seconds) end
    end
    if big and big:IsShown() and big.unit and Matches(big.unit) then Talk(big.model, seconds) end
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------

local function Apply()
    for _, slot in ipairs(slots) do
        if slot.holder then Layout(slot) end
    end
    RefreshAll(true)
    RefreshBig(true)
end

local function OnOff(v)
    return v and "on" or "off"
end

local function ShowHelp()
    Say("/lp on, off or toggle turns the 3D portraits on or off.")
    Say("/lp player, target, focus, pet, tot or party turns that frame's 3D portrait on or off.")
    Say("/lp big shows or hides the large Warcraft III style portrait window (drag to move it).")
    Say("/lp talk turns talking animations on or off.")
    Say("/lp backdrop turns the dark disc behind the head on or off.")
    Say("/lp fill 0.82 sets how much of the circle the head fills (0.6 to 1).")
    Say("/lp reset restores the defaults. /lp status shows the settings.")
end

SLASH_LIVINGPORTRAITS1 = "/lp"
SLASH_LIVINGPORTRAITS2 = "/livingportraits"
SlashCmdList.LIVINGPORTRAITS = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command, arg = string.match(string.lower(message or ""), "^%s*(%S*)%s*(%S*)")
    if command == "on" then
        db.enabled = true
    elseif command == "off" then
        db.enabled = false
    elseif command == "toggle" then
        db.enabled = not db.enabled
    elseif db.units[command] ~= nil then
        db.units[command] = not db.units[command]
        Say(GROUP_LABEL[command] .. " portrait: " .. OnOff(db.units[command]) .. ".")
    elseif command == "big" or command == "talk" or command == "backdrop" then
        db[command] = not db[command]
        Say(command .. ": " .. OnOff(db[command]) .. ".")
    elseif command == "fill" then
        local n = tonumber(arg)
        if not n then Say("Example: /lp fill 0.82") return end
        db.fill = Clamp(n, 0.6, 1)
        Say(string.format("fill: %.2f.", db.fill))
    elseif command == "reset" then
        for key, value in pairs(defaults) do
            if type(value) == "table" then
                db[key] = {}
                for k, v in pairs(value) do db[key][k] = v end
            else
                db[key] = value
            end
        end
        db.bigPos = nil
        Say("defaults restored.")
    elseif command == "status" then
        local parts = {}
        for _, group in ipairs({ "player", "target", "focus", "pet", "tot", "party" }) do
            parts[#parts + 1] = group .. " " .. OnOff(db.units[group])
        end
        Say(string.format("%s | %s | big window %s | talk %s | backdrop %s | fill %.2f",
            db.enabled and "enabled" or "disabled", table.concat(parts, ", "), OnOff(db.big), OnOff(db.talk), OnOff(db.backdrop), db.fill))
        local found, missing = {}, {}
        for _, slot in ipairs(slots) do
            if slot.holder then found[#found + 1] = slot.key else missing[#missing + 1] = slot.key end
        end
        Say("frames found: " .. (found[1] and table.concat(found, ", ") or "none") .. ".")
        if missing[1] then Say("frames not found yet: " .. table.concat(missing, ", ") .. ".") end
        return
    else
        ShowHelp()
        return
    end
    Apply()
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------

local UNIT_SLOT = { player = "player", vehicle = "player", target = "target", focus = "focus", pet = "pet",
    party1 = "party1", party2 = "party2", party3 = "party3", party4 = "party4" }

local CHAT_EVENTS = { "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID",
    "CHAT_MSG_RAID_LEADER", "CHAT_MSG_MONSTER_SAY", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_MONSTER_PARTY" }

local handlers = {}

function handlers.PLAYER_ENTERING_WORLD()
    RefreshAll(true)
    RefreshBig(true)
end

function handlers.PLAYER_TARGET_CHANGED()
    RefreshKey("target", true)
    RefreshKey("targettarget", true)
    RefreshBig(true)
end

function handlers.PLAYER_FOCUS_CHANGED()
    RefreshKey("focus", true)
    RefreshKey("focustarget", true)
end

function handlers.UNIT_TARGET(unit)
    if IsSecret(unit) then return end
    if unit == "target" then RefreshKey("targettarget", true) end
    if unit == "focus" then RefreshKey("focustarget", true) end
end

function handlers.GROUP_ROSTER_UPDATE()
    for i = 1, 4 do RefreshKey("party" .. i, true) end
end

function handlers.UNIT_PET(unit)
    if IsSecret(unit) then return end
    if unit == "player" then RefreshKey("pet", true) end
end

local function UnitChanged(unit)
    if IsSecret(unit) or type(unit) ~= "string" then return end
    local key = UNIT_SLOT[unit]
    if key then RefreshKey(key, true) end
    if big and big:IsShown() and big.unit == unit then RefreshBig(true) end
end
handlers.UNIT_MODEL_CHANGED = UnitChanged
handlers.UNIT_PORTRAIT_UPDATE = UnitChanged
handlers.UNIT_ENTERED_VEHICLE = UnitChanged
handlers.UNIT_EXITED_VEHICLE = UnitChanged

local function PlayerLifeChanged()
    RefreshKey("player", true)
    RefreshBig(true)
end
handlers.PLAYER_DEAD = PlayerLifeChanged
handlers.PLAYER_ALIVE = PlayerLifeChanged
handlers.PLAYER_UNGHOST = PlayerLifeChanged

for _, name in ipairs(CHAT_EVENTS) do
    handlers[name] = function(text, sender, _, _, _, _, _, _, _, _, _, guid)
        OnChat(text, sender, guid)
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        LivingPortraitsDB = type(LivingPortraitsDB) == "table" and LivingPortraitsDB or {}
        db = LivingPortraitsDB
        for key, value in pairs(defaults) do
            if type(db[key]) ~= type(value) then
                if type(value) == "table" then db[key] = {} else db[key] = value end
            end
            if type(value) == "table" then
                for k, v in pairs(value) do
                    if type(db[key][k]) ~= type(v) then db[key][k] = v end
                end
            end
        end
        db.fill = Clamp(db.fill, 0.6, 1)
        -- An event name this client does not know makes RegisterEvent throw, so each is tried alone.
        for name in pairs(handlers) do pcall(self.RegisterEvent, self, name) end
        -- Party members walking in and out of sight, and frames Blizzard builds late, are caught here.
        C_Timer.NewTicker(1, function()
            for _, slot in ipairs(slots) do
                if slot.live then
                    pcall(slot.portrait.SetAlpha, slot.portrait, 0)
                    if not Wanted(slot) then Refresh(slot, false) end
                elseif db.enabled and db.units[slot.group] then
                    Refresh(slot, false)
                end
            end
        end)
        return
    end
    local handler = handlers[event]
    if handler and db then handler(...) end
end)
