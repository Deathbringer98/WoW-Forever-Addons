Living Portraits 1.0.0 - World of Warcraft: Forever (Interface 16001)
====================================================================

Replaces the flat portraits on your unit frames with live, animated 3D
heads, in the spirit of Warcraft III. The heads breathe, blink and look
around, and they talk when that character speaks.

WHAT GETS A 3D PORTRAIT
- Your player frame (and your vehicle while you ride one)
- Target and focus
- Target of target and focus target
- Your pet
- Party members 1 to 4

A unit that is too far away to be drawn (a party member in another zone,
for example) keeps its normal flat portrait until it comes into view.

INSTALL
Copy the LivingPortraits folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

COMMANDS (type in chat)
/lp on | off | toggle   turn the 3D portraits on or off
/lp player              turn one frame's 3D portrait on or off
                        (player, target, focus, pet, tot, party)
/lp big                 show or hide the large Warcraft III style portrait
                        window. It shows your target, or you when you have
                        no target. Drag it to move it.
/lp talk                turn talking animations on or off
/lp backdrop            turn the dark disc behind the head on or off
/lp fill 0.82           how much of the circle the head fills (0.6 to 1)
/lp reset               restore the defaults
/lp status              show the settings and which frames were found
/livingportraits also works.

NOTES
- Cosmetic only. It adds its own frames beneath the Blizzard unit frames
  and never moves or resizes them.
- Built for the default Blizzard unit frames. Addons that replace those
  frames will not get 3D portraits from this addon.
- No other addons or libraries are required.

CREDITS
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
