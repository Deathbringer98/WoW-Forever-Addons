Talent Suggester 1.1.0 -World of Warcraft: Forever (Interface 16001)
=====================================================================

Pick PvE or PvP and the addon shows popular talent builds for your class,
what you already have, and the next point to spend. It works for all nine
classes, and you can browse the builds of classes you are not playing.

It only suggests. It never spends, resets or changes your talents.

INSTALL
Copy the TalentSuggester folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Restart the game (a new addon needs a full restart, not just /reload).

COMMANDS
/tsug            open or close the window
/tsug pve        open on PvE builds
/tsug pvp        open on PvP builds
/tsug announce   turn the level-up chat reminder on or off
/tsug reset      move the window back to the middle
/tsug help       list commands

READING THE WINDOW
- Top right: your class. Use < and > to browse other classes.
- PvE / PvP: the playstyle. Under it are up to four builds for that playstyle.
- Each tree column lists the talents the build uses as "yours/planned".
  Green = done, yellow = started, grey = not started, red = more ranks than
  the build uses, orange with ">" = the next point to spend.
- Hover a talent for its tooltip.

LEARNING THE BUILD (new in 1.1.0)
The addon explains its picks so you learn the build instead of copying it.
- Hover any talent to see why it is there: what it unlocks, what it needs,
  and how many tagged builds of the same kind take it.
  Core pick   = 90% or more take it.
  Common pick = 50% to 89% take it.
  Flex pick   = under 50% take it, so it is a matter of taste. These are
                marked (flex) and the tooltip names what others take instead.
- The "Why:" line under "Next point" explains the next suggested talent.
- Click "Skipped talents" to also list what the build passes over, with how
  often other builds take each one.
- Where the PvE and PvP builds of the same spec differ, the tooltip says so.
Pick rates are only shown when at least 3 different builds of that kind were
tagged. What a talent does comes from the game's own tooltip.

WHERE THE BUILDS COME FROM
The talent trees and the builds come from talentsforever.com (CC BY 4.0).
The builds are the ones its users tagged most often as PvE or PvP for each
spec, read on 2026-11-09. They are popular picks, not guaranteed best builds,
and they will age as Blizzard tunes the game. Some classes have only one
PvP build because few were tagged.

To refresh the data later, regenerate Data.lua from the site's data export.

CREDITS
Addon: Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Talent data and build picks: talentsforever.com (https://talentsforever.com), CC BY 4.0
Game names and tooltip text belong to Blizzard Entertainment.
