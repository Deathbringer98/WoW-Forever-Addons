-- Talent Suggester for World of Warcraft: Forever (Interface 16001)
-- Shows popular PvE and PvP talent builds for every class and the next point to spend.
-- Read-only: it never spends, resets or changes talents, and uses no protected actions.
local ADDON, ns = ...

local CLASS_ORDER = { "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST", "SHAMAN", "MAGE", "WARLOCK", "DRUID" }
local MODE_LABEL = { PVE = "PvE", PVP = "PvP" }
local MAX_BUILD_BUTTONS = 4
local MAX_ROWS = 22
local ROW_H = 15
local COL_W = 232
local PREFIX = "|cffffd100Talent Suggester:|r "

local db
local playerClass
local viewClass
local frame
local refreshQueued = false

---------------------------------------------------------------------------
-- Small helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

-- Calls fn safely and returns its first result, or nil on error or a secret value.
local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, v = pcall(fn, ...)
    if not ok or IsSecret(v) then return nil end
    return v
end

local function Num(v)
    if type(v) == "number" and not IsSecret(v) then return v end
    return nil
end

local function Str(v)
    if type(v) == "string" and not IsSecret(v) and v ~= "" then return v end
    return nil
end

local function ClassColor(classKey)
    local c = type(RAID_CLASS_COLORS) == "table" and RAID_CLASS_COLORS[classKey] or nil
    if type(c) == "table" and Num(c.r) and Num(c.g) and Num(c.b) then return c.r, c.g, c.b end
    return 1, 0.82, 0
end

local function DetectClass()
    local ok, _, classFile = pcall(UnitClass, "player")
    if ok and Str(classFile) and ns.Data[classFile] then return classFile end
    if type(UnitClassBase) == "function" then
        local base = Plain(UnitClassBase, "player")
        if Str(base) and ns.Data[base] then return base end
    end
    return nil
end

---------------------------------------------------------------------------
-- Reading the player's own talents (Forever's trait tree, C_Traits)
---------------------------------------------------------------------------

-- Turns node positions into 1-based rows or columns: the smallest gap is one step.
local function GridSteps(list, key)
    local vals = {}
    for _, t in ipairs(list) do vals[#vals + 1] = t[key] end
    table.sort(vals)
    local gap
    for i = 2, #vals do
        local d = vals[i] - vals[i - 1]
        if d > 0.5 and (not gap or d < gap) then gap = d end
    end
    return vals[1] or 0, gap
end

-- Returns { byName = { [name] = node }, trees = { { name =, nodes = {} } }, total = n } or nil, reason.
local function ReadGame()
    local T, CT = C_Traits, C_ClassTalents
    if type(T) ~= "table" or type(CT) ~= "table" then return nil, "This client has no talent tree API." end
    local configID = Num(Plain(CT.GetActiveConfigID))
    if not configID then return nil, "Your talents are not available yet (they unlock at level 10)." end
    local config = Plain(T.GetConfigInfo, configID)
    local treeID = type(config) == "table" and type(config.treeIDs) == "table" and Num(config.treeIDs[1]) or nil
    if not treeID then return nil, "Your talent tree could not be read." end

    local game = { byName = {}, trees = {}, total = 0 }
    local treeByGroup = {}
    local infos = Plain(T.GetGroupDisplayInfoByTreeID, treeID)
    if type(infos) == "table" then
        local groups = {}
        for _, g in ipairs(infos) do
            if type(g) == "table" and Num(g.groupID) then
                groups[#groups + 1] = { id = g.groupID, name = Str(g.displayName), order = Num(g.orderIndex) or #groups }
            end
        end
        table.sort(groups, function(a, b)
            if a.order ~= b.order then return a.order < b.order end
            return a.id < b.id
        end)
        for i, g in ipairs(groups) do
            game.trees[i] = { name = g.name, nodes = {} }
            treeByGroup[g.id] = game.trees[i]
        end
    end

    local nodes = Plain(T.GetTreeNodes, treeID)
    if type(nodes) ~= "table" then return nil, "Your talent tree could not be read." end
    for _, nodeID in ipairs(nodes) do
        local info = Num(nodeID) and Plain(T.GetNodeInfo, configID, nodeID) or nil
        if type(info) == "table" and info.isVisible ~= false then
            local entryID = type(info.activeEntry) == "table" and Num(info.activeEntry.entryID) or nil
            if not entryID and type(info.entryIDs) == "table" then entryID = Num(info.entryIDs[1]) end
            local entry = entryID and Plain(T.GetEntryInfo, configID, entryID) or nil
            local defID = type(entry) == "table" and Num(entry.definitionID) or nil
            local def = defID and Plain(T.GetDefinitionInfo, defID) or nil
            if type(def) ~= "table" then def = {} end
            local spellID = Num(def.spellID)
            if spellID and spellID <= 0 then spellID = nil end
            local name = Str(def.overrideName)
            if not name and spellID and type(C_Spell) == "table" then name = Str(Plain(C_Spell.GetSpellName, spellID)) end
            local node = {
                name = name,
                spellID = spellID,
                rank = Num(info.currentRank) or Num(info.activeRank) or Num(info.ranksPurchased) or 0,
                x = Num(info.posX),
                y = Num(info.posY),
            }
            game.total = game.total + node.rank
            if name then game.byName[name] = node end
            if type(info.groupIDs) == "table" and node.x and node.y then
                for _, gid in ipairs(info.groupIDs) do
                    local tree = treeByGroup[gid]
                    if tree then
                        tree.nodes[#tree.nodes + 1] = node
                        break
                    end
                end
            end
        end
    end

    for _, tree in ipairs(game.trees) do
        local x0, dx = GridSteps(tree.nodes, "x")
        local y0, dy = GridSteps(tree.nodes, "y")
        tree.byCell = {}
        for _, node in ipairs(tree.nodes) do
            local col = dx and math.floor((node.x - x0) / dx + 0.5) + 1 or 1
            local row = dy and math.floor((node.y - y0) / dy + 0.5) + 1 or 1
            tree.byCell[row .. ":" .. col] = node
        end
    end
    return game
end

-- Finds the game node for one talent of our data: by name first, then by tree and grid cell.
local function FindNode(game, class, treeIndex, talent)
    local node = game.byName[talent[1]]
    if node then return node end
    local dataTree = class.trees[treeIndex]
    local gameTree
    for _, t in ipairs(game.trees) do
        if t.name == dataTree.name then gameTree = t break end
    end
    gameTree = gameTree or game.trees[treeIndex]
    if gameTree and gameTree.byCell then return gameTree.byCell[talent[3] .. ":" .. talent[4]] end
    return nil
end

---------------------------------------------------------------------------
-- Builds: targets and a legal order to spend the points in
---------------------------------------------------------------------------

local function BuildsFor(classKey, mode)
    local out = {}
    for _, b in ipairs(ns.Data[classKey].builds) do
        if b.mode == mode then out[#out + 1] = b end
    end
    return out
end

local function BuildLabel(class, build)
    return string.format("%s %s %d/%d/%d", class.trees[build.main].name, build.role, build.points[1], build.points[2], build.points[3])
end

local planCache = {}

local function MakePlan(class, build)
    if planCache[build] then return planCache[build] end
    local plan = { target = {}, order = {}, total = 0 }
    for t, tree in ipairs(class.trees) do
        plan.target[t] = {}
        local code = build.codes[t] or ""
        for i = 1, #tree.talents do
            local r = tonumber(code:sub(i, i)) or 0
            plan.target[t][i] = r
            plan.total = plan.total + r
        end
    end

    -- Main tree first, then the others from most points to fewest.
    local treeOrder = {}
    for t = 1, #class.trees do treeOrder[t] = t end
    table.sort(treeOrder, function(a, b)
        if a == build.main or b == build.main then return a == build.main and b ~= build.main end
        if build.points[a] ~= build.points[b] then return build.points[a] > build.points[b] end
        return a < b
    end)

    for _, t in ipairs(treeOrder) do
        local talents = class.trees[t].talents
        local got, spent, remaining = {}, 0, 0
        for i = 1, #talents do remaining = remaining + plan.target[t][i] end
        local function ReqMet(reqName)
            if not reqName then return true end
            for j, other in ipairs(talents) do
                if other[1] == reqName then return (got[j] or 0) >= other[2] end
            end
            return true
        end
        while remaining > 0 do
            local best
            for i, tal in ipairs(talents) do
                if plan.target[t][i] - (got[i] or 0) > 0 and spent >= 5 * (tal[3] - 1) and ReqMet(tal[5]) then
                    local cur = best and talents[best]
                    if not cur or tal[3] < cur[3] or (tal[3] == cur[3] and tal[4] < cur[4]) then best = i end
                end
            end
            if not best then
                for i = 1, #talents do
                    if plan.target[t][i] - (got[i] or 0) > 0 then best = i break end
                end
            end
            got[best] = (got[best] or 0) + 1
            spent = spent + 1
            remaining = remaining - 1
            plan.order[#plan.order + 1] = { t, best }
        end
    end
    planCache[build] = plan
    return plan
end

-- Current ranks for every talent of the class, or nil when they are not the player's to read.
local function ReadHave(classKey)
    if classKey ~= playerClass then return nil, nil, nil end
    local game, reason = ReadGame()
    if not game then return nil, nil, reason end
    local class = ns.Data[classKey]
    local have, spell = {}, {}
    for t, tree in ipairs(class.trees) do
        have[t], spell[t] = {}, {}
        for i, tal in ipairs(tree.talents) do
            local node = FindNode(game, class, t, tal)
            have[t][i] = node and node.rank or 0
            spell[t][i] = node and node.spellID or nil
        end
    end
    return have, spell, nil, game.total
end

-- The next points to spend: up to `count` distinct talents, in plan order.
local function NextSteps(plan, have, count)
    local steps, seen, counter = {}, {}, {}
    for _, step in ipairs(plan.order) do
        local t, i = step[1], step[2]
        local key = t .. ":" .. i
        counter[key] = (counter[key] or 0) + 1
        if counter[key] > (have and have[t][i] or 0) and not seen[key] then
            seen[key] = true
            steps[#steps + 1] = { t = t, i = i }
            if #steps >= count then break end
        end
    end
    return steps
end

---------------------------------------------------------------------------
-- Explanations: why a talent is in the build, or what skipping it means
---------------------------------------------------------------------------

local MIN_BUILDS_FOR_RATES = 3

-- Pick rates among builds of the same playstyle, main tree and role, when enough were tagged.
local function RatesFor(class, build)
    local pop = class.pop and class.pop[build.mode .. ":" .. build.main .. ":" .. build.role] or nil
    if pop and pop.builds >= MIN_BUILDS_FOR_RATES then return pop end
    return nil
end

-- The same spec's build for the other playstyle, if one is listed.
local function Counterpart(class, build)
    local found
    for _, other in ipairs(class.builds) do
        if other.mode ~= build.mode and other.main == build.main then
            if other.role == build.role then return other end
            found = found or other
        end
    end
    return found
end

local function KindLabel(class, build)
    return MODE_LABEL[build.mode] .. " " .. class.trees[build.main].name .. " " .. build.role
end

-- Returns a list of plain sentences about talent i of tree t in this build.
local function Why(class, build, plan, t, i)
    local lines = {}
    local tree = class.trees[t]
    local tal = tree.talents[i]
    local want = plan.target[t][i]
    local rates = RatesFor(class, build)
    local rate = rates and rates[t][i] or nil
    local kind = KindLabel(class, build)

    if want > 0 then
        if tal[6] then lines[#lines + 1] = "Gives you a new ability to use." end
        for j, other in ipairs(tree.talents) do
            if other[5] == tal[1] and plan.target[t][j] > 0 then
                lines[#lines + 1] = "Has to be maxed before you can take " .. other[1] .. "."
            end
        end
        if tal[5] then lines[#lines + 1] = "Needs " .. tal[5] .. " maxed first." end
        if tal[3] >= 7 then
            lines[#lines + 1] = string.format("The final talent of %s. It needs %d points in the tree.", tree.name, 5 * (tal[3] - 1))
        end
        if want < tal[2] then
            lines[#lines + 1] = string.format("The build stops at %d of %d ranks to save points for other talents.", want, tal[2])
        end
        if rate then
            if rate >= 90 then
                lines[#lines + 1] = string.format("Core pick: %d%% of tagged %s builds take it.", rate, kind)
            elseif rate >= 50 then
                lines[#lines + 1] = string.format("Common pick: %d%% of tagged %s builds take it.", rate, kind)
            else
                lines[#lines + 1] = string.format("Flex pick: only %d%% of tagged %s builds take it, so this spot is a matter of taste.", rate, kind)
                local alts = {}
                for t2, tree2 in ipairs(class.trees) do
                    for j, other in ipairs(tree2.talents) do
                        if plan.target[t2][j] == 0 and rates[t2][j] >= 25 then alts[#alts + 1] = { other[1], rates[t2][j] } end
                    end
                end
                table.sort(alts, function(a, b) return a[2] > b[2] end)
                if alts[1] then
                    local text = string.format("%s (%d%%)", alts[1][1], alts[1][2])
                    if alts[2] then text = text .. string.format(", %s (%d%%)", alts[2][1], alts[2][2]) end
                    lines[#lines + 1] = "Others spend these points on: " .. text .. "."
                end
            end
        end
    else
        lines[#lines + 1] = "This build skips it."
        if rate then
            if rate >= 50 then
                lines[#lines + 1] = string.format("But %d%% of tagged %s builds take it, so it is worth a look.", rate, kind)
            elseif rate > 0 then
                lines[#lines + 1] = string.format("%d%% of tagged %s builds take it.", rate, kind)
            else
                lines[#lines + 1] = string.format("No tagged %s build takes it.", kind)
            end
        end
    end

    if not rates and want > 0 then
        lines[#lines + 1] = "Too few builds of this kind were tagged to say how common this pick is."
    end

    local other = Counterpart(class, build)
    if other then
        local otherWant = tonumber((other.codes[t] or ""):sub(i, i)) or 0
        if otherWant ~= want then
            local label = MODE_LABEL[other.mode] .. " " .. class.trees[other.main].name
            if otherWant == 0 then
                lines[#lines + 1] = "The " .. label .. " build skips this."
            elseif tal[2] == 1 then
                lines[#lines + 1] = "The " .. label .. " build takes this."
            else
                lines[#lines + 1] = string.format("The %s build takes %d of %d ranks here.", label, otherWant, tal[2])
            end
        end
    end
    return lines
end

-- True when the pick is a matter of taste according to the pick rates.
local function IsFlex(class, build, plan, t, i)
    local rates = RatesFor(class, build)
    return rates ~= nil and plan.target[t][i] > 0 and rates[t][i] < 50
end

---------------------------------------------------------------------------
-- Selection state
---------------------------------------------------------------------------

local function CurrentBuild()
    local builds = BuildsFor(viewClass, db.mode)
    if #builds == 0 then return nil, builds end
    db.pick[viewClass] = db.pick[viewClass] or {}
    local index = db.pick[viewClass][db.mode] or 1
    if index < 1 or index > #builds then index = 1 end
    db.pick[viewClass][db.mode] = index
    return builds[index], builds, index
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------

local function MakeButton(parent, width, height, text)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, height)
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    b.bg:SetAllPoints()
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text or "")
    function b:Paint(hover)
        if self.selected then
            self.bg:SetColorTexture(0.55, 0.42, 0.08, 0.95)
        elseif hover then
            self.bg:SetColorTexture(0.26, 0.26, 0.32, 0.95)
        else
            self.bg:SetColorTexture(0.14, 0.14, 0.18, 0.95)
        end
    end
    b:SetScript("OnEnter", function(self) self:Paint(true) end)
    b:SetScript("OnLeave", function(self) self:Paint(false) end)
    b:Paint(false)
    return b
end

local Refresh

local function RowOnEnter(self)
    if not self.talentName then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local shown = false
    if self.spellID and type(GameTooltip.SetSpellByID) == "function" then
        shown = pcall(GameTooltip.SetSpellByID, GameTooltip, self.spellID)
    end
    if not shown then GameTooltip:SetText(self.talentName, 1, 1, 1) end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(string.format("Plan: %d of %d ranks (row %d)", self.target or 0, self.maxRank or 0, self.gridRow or 0), 1, 0.82, 0)
    if self.have and self.have > (self.target or 0) then
        GameTooltip:AddLine("You have more ranks here than this build uses.", 1, 0.3, 0.3, true)
    end
    if type(self.why) == "table" then
        for _, line in ipairs(self.why) do
            GameTooltip:AddLine(line, 0.75, 0.9, 1, true)
        end
    end
    GameTooltip:Show()
end

local function RowOnLeave()
    GameTooltip:Hide()
end

local function CreateWindow()
    local f = CreateFrame("Frame", "TalentSuggesterFrame", UIParent)
    f:SetSize(COL_W * 3 + 32, 186 + MAX_ROWS * ROW_H)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if Str(point) and Str(relPoint) and Num(x) and Num(y) then
            db.pos = { point, relPoint, x, y }
        end
    end)
    if type(db.pos) == "table" and Str(db.pos[1]) and Str(db.pos[2]) and Num(db.pos[3]) and Num(db.pos[4]) then
        f:SetPoint(db.pos[1], UIParent, db.pos[2], db.pos[3], db.pos[4])
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
    end

    local border = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.45, 0.36, 0.12, 1)
    local bg = f:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 1, -1)
    bg:SetPoint("BOTTOMRIGHT", -1, 1)
    bg:SetColorTexture(0.04, 0.04, 0.06, 0.96)

    f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.title:SetPoint("TOPLEFT", 14, -12)
    f.title:SetText("Talent Suggester")

    local close = MakeButton(f, 22, 20, "X")
    close:SetPoint("TOPRIGHT", -10, -10)
    close:SetScript("OnClick", function() f:Hide() end)

    -- Class picker
    f.nextClass = MakeButton(f, 22, 20, ">")
    f.nextClass:SetPoint("RIGHT", close, "LEFT", -14, 0)
    f.className = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.className:SetPoint("RIGHT", f.nextClass, "LEFT", -6, 0)
    f.className:SetWidth(84)
    f.className:SetJustifyH("CENTER")
    f.prevClass = MakeButton(f, 22, 20, "<")
    f.prevClass:SetPoint("RIGHT", f.className, "LEFT", -6, 0)
    local function StepClass(delta)
        local index = 1
        for i, key in ipairs(CLASS_ORDER) do
            if key == viewClass then index = i break end
        end
        index = (index - 1 + delta) % #CLASS_ORDER + 1
        viewClass = CLASS_ORDER[index]
        Refresh()
    end
    f.prevClass:SetScript("OnClick", function() StepClass(-1) end)
    f.nextClass:SetScript("OnClick", function() StepClass(1) end)
    f.mine = MakeButton(f, 64, 20, "My class")
    f.mine:SetPoint("RIGHT", f.prevClass, "LEFT", -8, 0)
    f.mine:SetScript("OnClick", function()
        if playerClass then
            viewClass = playerClass
            Refresh()
        end
    end)

    -- Mode buttons
    f.modeButtons = {}
    local x = 14
    for _, mode in ipairs({ "PVE", "PVP" }) do
        local b = MakeButton(f, 70, 22, MODE_LABEL[mode])
        b:SetPoint("TOPLEFT", x, -42)
        b:SetScript("OnClick", function()
            db.mode = mode
            Refresh()
        end)
        f.modeButtons[mode] = b
        x = x + 76
    end

    -- Shows the talents the build passes over, so the trade-offs are visible.
    f.skipped = MakeButton(f, 150, 22, "")
    f.skipped:SetPoint("TOPLEFT", x + 10, -42)
    f.skipped:SetScript("OnClick", function()
        db.showSkipped = not db.showSkipped
        Refresh()
    end)

    f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.hint:SetPoint("LEFT", f.skipped, "RIGHT", 12, 0)
    f.hint:SetText("Hover a talent to see why it is picked or skipped.")

    -- Build buttons
    f.buildButtons = {}
    local buildWidth = math.floor((COL_W * 3 + 32 - 28 - (MAX_BUILD_BUTTONS - 1) * 6) / MAX_BUILD_BUTTONS)
    for i = 1, MAX_BUILD_BUTTONS do
        local b = MakeButton(f, buildWidth, 22, "")
        b:SetPoint("TOPLEFT", 14 + (i - 1) * (buildWidth + 6), -70)
        b:SetScript("OnClick", function()
            db.pick[viewClass] = db.pick[viewClass] or {}
            db.pick[viewClass][db.mode] = i
            Refresh()
        end)
        f.buildButtons[i] = b
    end

    f.status = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.status:SetPoint("TOPLEFT", 14, -100)
    f.status:SetPoint("RIGHT", f, "RIGHT", -14, 0)
    f.status:SetJustifyH("LEFT")
    f.status:SetWordWrap(false)

    f.nextLine = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    f.nextLine:SetPoint("TOPLEFT", 14, -116)
    f.nextLine:SetPoint("RIGHT", f, "RIGHT", -14, 0)
    f.nextLine:SetJustifyH("LEFT")
    f.nextLine:SetWordWrap(false)

    f.whyLine = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    f.whyLine:SetPoint("TOPLEFT", 14, -134)
    f.whyLine:SetPoint("RIGHT", f, "RIGHT", -14, 0)
    f.whyLine:SetJustifyH("LEFT")
    f.whyLine:SetWordWrap(false)
    f.whyLine:SetTextColor(0.75, 0.9, 1)

    -- Three tree columns
    f.columns = {}
    for t = 1, 3 do
        local col = { rows = {} }
        local left = 16 + (t - 1) * COL_W
        col.header = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        col.header:SetPoint("TOPLEFT", left, -156)
        col.header:SetWidth(COL_W - 12)
        col.header:SetJustifyH("LEFT")
        for r = 1, MAX_ROWS do
            local row = CreateFrame("Frame", nil, f)
            row:SetSize(COL_W - 12, ROW_H)
            row:SetPoint("TOPLEFT", left, -156 - 4 - r * ROW_H)
            row:EnableMouse(true)
            row.count = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.count:SetPoint("RIGHT", 0, 0)
            row.count:SetWidth(34)
            row.count:SetJustifyH("RIGHT")
            row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.name:SetPoint("LEFT", 0, 0)
            row.name:SetPoint("RIGHT", row.count, "LEFT", -2, 0)
            row.name:SetJustifyH("LEFT")
            row.name:SetWordWrap(false)
            row:SetScript("OnEnter", RowOnEnter)
            row:SetScript("OnLeave", RowOnLeave)
            col.rows[r] = row
        end
        f.columns[t] = col
    end

    f.credit = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.credit:SetPoint("BOTTOMLEFT", 14, 8)
    f.credit:SetText("Builds and talent data: talentsforever.com (CC BY 4.0). Suggestions only, nothing is spent for you.")

    f:SetScript("OnShow", function() Refresh() end)
    f:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "TalentSuggesterFrame") end
    return f
end

Refresh = function()
    if not frame or not frame:IsShown() or not db then return end
    local class = ns.Data[viewClass]
    local r, g, b = ClassColor(viewClass)
    frame.className:SetText(class.name)
    frame.className:SetTextColor(r, g, b)
    frame.mine:SetShown(playerClass ~= nil and viewClass ~= playerClass)

    for mode, button in pairs(frame.modeButtons) do
        button.selected = (mode == db.mode)
        button:Paint(false)
    end

    local build, builds, index = CurrentBuild()
    for i, button in ipairs(frame.buildButtons) do
        local b2 = builds[i]
        if b2 then
            button.label:SetText(BuildLabel(class, b2))
            button.selected = (i == index)
            button:Paint(false)
            button:Show()
        else
            button:Hide()
        end
    end

    if not build then
        frame.status:SetText("No " .. MODE_LABEL[db.mode] .. " build is listed for this class yet.")
        frame.nextLine:SetText("")
        frame.whyLine:SetText("")
        for _, col in ipairs(frame.columns) do
            col.header:SetText("")
            for _, row in ipairs(col.rows) do row:Hide() end
        end
        return
    end

    local plan = MakePlan(class, build)
    local have, spell, reason, totalSpent = ReadHave(viewClass)
    local steps = NextSteps(plan, have, 3)
    local nextKey = steps[1] and (steps[1].t .. ":" .. steps[1].i) or nil

    -- Status line
    local status = string.format("Tagged %s by %d players. Plan: %d of 51 points.", MODE_LABEL[db.mode], build.votes, plan.total)
    if viewClass ~= playerClass then
        status = status .. "  |cff9d9d9dBrowsing another class.|r"
    elseif not have then
        status = status .. "  |cffff7f50" .. (reason or "Your talents could not be read.") .. "|r"
    else
        local onPlan, offPlan = 0, 0
        for t, tree in ipairs(class.trees) do
            for i = 1, #tree.talents do
                local h, want = have[t][i], plan.target[t][i]
                onPlan = onPlan + math.min(h, want)
                offPlan = offPlan + math.max(0, h - want)
            end
        end
        status = status .. string.format("  You: |cff40ff40%d on plan|r", onPlan)
        if offPlan > 0 then status = status .. string.format(", |cffff4040%d off plan|r", offPlan) end
        local level = Num(Plain(UnitLevel, "player"))
        if level and totalSpent then
            local unspent = math.max(0, level - 9) - totalSpent
            if unspent > 0 then status = status .. string.format(", |cffffd100%d unspent|r", unspent) end
        end
    end
    frame.status:SetText(status)

    -- Next points
    frame.skipped.label:SetText(db.showSkipped and "Skipped talents: shown" or "Skipped talents: hidden")
    frame.skipped.selected = db.showSkipped and true or false
    frame.skipped:Paint(false)

    if #steps == 0 then
        frame.nextLine:SetText(have and "|cff40ff40This build is complete.|r" or "")
        frame.whyLine:SetText("")
    else
        local why = Why(class, build, plan, steps[1].t, steps[1].i)
        frame.whyLine:SetText(why[1] and ("Why: " .. table.concat(why, " ", 1, math.min(2, #why))) or "")
        local parts = {}
        for n, step in ipairs(steps) do
            local tal = class.trees[step.t].talents[step.i]
            local text = tal[1]
            if n == 1 then
                local h = have and have[step.t][step.i] or 0
                text = string.format("|cffff9a2e%s|r (%s, rank %d of %d)", tal[1], class.trees[step.t].name, h + 1, plan.target[step.t][step.i])
            end
            parts[#parts + 1] = text
        end
        local lead = have and "Next point: " or "Start with: "
        frame.nextLine:SetText(lead .. parts[1] .. (parts[2] and ("   then " .. table.concat(parts, ", ", 2)) or ""))
    end

    -- Columns
    for t, col in ipairs(frame.columns) do
        local tree = class.trees[t]
        col.header:SetText(string.format("%s  |cffffffff%d|r", tree.name, build.points[t]))
        local used = 0
        for i, tal in ipairs(tree.talents) do
            local want = plan.target[t][i]
            local h = have and have[t][i] or nil
            if (want > 0 or (h and h > 0) or db.showSkipped) and used < MAX_ROWS then
                used = used + 1
                local row = col.rows[used]
                row.talentName, row.target, row.maxRank, row.gridRow = tal[1], want, tal[2], tal[3]
                row.spellID = spell and spell[t][i] or nil
                row.have = h
                row.why = Why(class, build, plan, t, i)
                local isNext = (nextKey == t .. ":" .. i)
                local skippedRow = (want == 0 and not (h and h > 0))
                row.name:SetText((isNext and "> " or "") .. tal[1] .. (IsFlex(class, build, plan, t, i) and " |cff8fd0ff(flex)|r" or ""))
                if skippedRow then
                    row.count:SetText("skip")
                elseif h then
                    row.count:SetText(h .. "/" .. want)
                else
                    row.count:SetText(want .. "/" .. tal[2])
                end
                local cr, cg, cb = 0.85, 0.85, 0.85
                if skippedRow then
                    cr, cg, cb = 0.42, 0.42, 0.42
                elseif h then
                    if h > want then cr, cg, cb = 1, 0.3, 0.3
                    elseif h == want then cr, cg, cb = 0.25, 1, 0.25
                    elseif h > 0 then cr, cg, cb = 1, 0.9, 0.3
                    else cr, cg, cb = 0.62, 0.62, 0.62 end
                end
                if isNext then cr, cg, cb = 1, 0.6, 0.18 end
                row.name:SetTextColor(cr, cg, cb)
                row.count:SetTextColor(cr, cg, cb)
                row:Show()
            end
        end
        for r = used + 1, MAX_ROWS do col.rows[r]:Hide() end
    end
end

local function QueueRefresh()
    if refreshQueued or not frame or not frame:IsShown() then return end
    refreshQueued = true
    C_Timer.After(0.2, function()
        refreshQueued = false
        Refresh()
    end)
end

local function Toggle()
    if not db then return end
    if not frame then frame = CreateWindow() end
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
    end
end

-- Addon compartment entry (the dropdown by the minimap), where the client has one.
function TalentSuggester_OnCompartmentClick()
    Toggle()
end

---------------------------------------------------------------------------
-- Chat reminder on level up
---------------------------------------------------------------------------

local function AnnounceNext()
    if not db or not db.announce or not playerClass then return end
    local saved = viewClass
    viewClass = playerClass
    local build = CurrentBuild()
    viewClass = saved
    if not build then return end
    local class = ns.Data[playerClass]
    local have = ReadHave(playerClass)
    if not have then return end
    local plan = MakePlan(class, build)
    local step = NextSteps(plan, have, 1)[1]
    if step then
        local tal = class.trees[step.t].talents[step.i]
        Say(string.format("new talent point. %s suggestion: |cffff9a2e%s|r in %s. Type /tsug for the full build.", MODE_LABEL[db.mode], tal[1], class.trees[step.t].name))
        local why = Why(class, build, plan, step.t, step.i)
        if why[1] then Say("Why: " .. why[1]) end
    end
end

---------------------------------------------------------------------------
-- Slash commands
---------------------------------------------------------------------------

SLASH_TALENTSUGGESTER1 = "/tsug"
SLASH_TALENTSUGGESTER2 = "/talentsuggester"
SLASH_TALENTSUGGESTER3 = "/talentsuggest"
SlashCmdList.TALENTSUGGESTER = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command = string.lower(message or ""):match("^%s*(%S*)")
    if command == "pve" or command == "pvp" then
        db.mode = string.upper(command)
        if not frame then frame = CreateWindow() end
        if frame:IsShown() then Refresh() else frame:Show() end
    elseif command == "announce" then
        db.announce = not db.announce
        Say("level-up reminders are now " .. (db.announce and "on." or "off."))
    elseif command == "reset" then
        db.pos = nil
        if frame then
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "CENTER", 0, 40)
        end
        Say("window position reset.")
    elseif command == "help" then
        Say("/tsug opens or closes the window.")
        Say("/tsug pve or /tsug pvp opens it on that playstyle.")
        Say("/tsug announce turns level-up reminders on or off.")
        Say("/tsug reset moves the window back to the middle.")
    else
        Toggle()
    end
end

---------------------------------------------------------------------------
-- Startup and events
---------------------------------------------------------------------------

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        TalentSuggesterDB = type(TalentSuggesterDB) == "table" and TalentSuggesterDB or {}
        db = TalentSuggesterDB
        if db.mode ~= "PVE" and db.mode ~= "PVP" then db.mode = "PVE" end
        if type(db.pick) ~= "table" then db.pick = {} end
        if db.announce == nil then db.announce = true end
        if db.showSkipped == nil then db.showSkipped = false end
        playerClass = DetectClass()
        viewClass = playerClass or CLASS_ORDER[1]
        -- An event name this client does not know makes RegisterEvent throw, so each is tried alone.
        for _, name in ipairs({ "TRAIT_CONFIG_UPDATED", "TRAIT_NODE_CHANGED", "TRAIT_TREE_CURRENCY_INFO_UPDATED",
            "TRAIT_CONFIG_LIST_UPDATED", "PLAYER_TALENT_UPDATE", "PLAYER_LEVEL_UP" }) do
            pcall(self.RegisterEvent, self, name)
        end
        return
    end
    if event == "PLAYER_LEVEL_UP" then
        C_Timer.After(2, AnnounceNext)
    end
    QueueRefresh()
end)
