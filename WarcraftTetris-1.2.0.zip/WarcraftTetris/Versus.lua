-- Warcraft Tetris versus mode: play a bot or another player.
-- Both sides get the same pieces. Clearing lines sends grey garbage rows to your rival,
-- and the first to top out loses. Players talk through hidden addon messages
-- (whispers, so both need the addon and must be on the same faction).
local ADDON, ns = ...

local PREFIX = "WTET1"
local INVITE_TIME = 30      -- seconds to answer a challenge
local SILENCE_LIMIT = 20    -- a rival we haven't heard from in this long has left
local SEND_GAP = 0.8        -- at most one board update this often
local PING_GAP = 5
local COUNTDOWN = 3
local MAX_RISE = 8          -- garbage rows that can rise at once

-- Garbage sent for 1, 2, 3 or 4 lines.
local GARBAGE = { 0, 1, 2, 4 }

local BOTS = {
    { key = "easy", name = "Kobold Tunneler", level = "Easy", think = 2.1, mistakes = 0.5, pool = 6, blunder = 0.15,
        tip = "Slow, and often puts pieces in the wrong place." },
    { key = "normal", name = "Goblin Sapper", level = "Normal", think = 1.4, mistakes = 0.25, pool = 4, blunder = 0.03,
        tip = "Steady and tidy. A fair fight." },
    { key = "hard", name = "Dalaran Archmage", level = "Hard", think = 1.05, mistakes = 0.25, pool = 3,
        tip = "Fast, and plans every piece. Good luck." },
}
local BOT_BY_KEY = {}
for _, b in ipairs(BOTS) do BOT_BY_KEY[b.key] = b end

local M          -- the current match, or nil
local panel      -- the versus panel beside the game window
local popup      -- the challenge popup
local queue, queueTicker = {}, nil

local function IsSecret(v) return issecretvalue ~= nil and issecretvalue(v) end
local function Now() return GetTime() end

local function FullName(name)
    if type(name) ~= "string" or IsSecret(name) or name == "" then return nil end
    name = name:gsub("%s", "")
    if name == "" then return nil end
    if name:find("-", 1, true) then return name end
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    return realm and (name .. "-" .. realm) or name
end

local function Short(name)
    if not name then return "?" end
    return (name:gsub("%-.*", ""))
end

local function MyName() return FullName(UnitName("player")) end

local function Record()
    local db = ns.DB()
    db.vs = type(db.vs) == "table" and db.vs or {}
    db.vs.wins = db.vs.wins or 0
    db.vs.losses = db.vs.losses or 0
    db.vs.rivals = type(db.vs.rivals) == "table" and db.vs.rivals or {}
    return db.vs
end

---------------------------------------------------------------------------
-- Messages
---------------------------------------------------------------------------

local function SendOk(result)
    if result == nil or result == true or result == 0 then return true end
    if Enum and Enum.SendAddonMessageResult and result == Enum.SendAddonMessageResult.Success then return true end
    return false
end

local function TrySend(text, target)
    if not (C_ChatInfo and C_ChatInfo.SendAddonMessage) then return true end
    local ok, result = pcall(C_ChatInfo.SendAddonMessage, PREFIX, text, "WHISPER", target)
    return ok and SendOk(result)
end

local function Pump()
    while queue[1] do
        local item = queue[1]
        if TrySend(item.text, item.target) then
            table.remove(queue, 1)
        else
            item.tries = item.tries + 1
            if item.tries > 20 then table.remove(queue, 1) end
            return
        end
    end
    if queueTicker then queueTicker:Cancel() queueTicker = nil end
end

-- Important messages (challenge, answer, win, leave) are retried until they go through.
local function Send(target, ...)
    local text = table.concat({ ... }, "~")
    queue[#queue + 1] = { text = text, target = target, tries = 0 }
    Pump()
    if queue[1] and not queueTicker then queueTicker = C_Timer.NewTicker(1, Pump) end
end

local function BoardString(board)
    local out = {}
    for y = ns.HIDDEN + 1, ns.ROWS do
        local row = board[y]
        for x = 1, ns.COLS do out[#out + 1] = row[x] or "." end
    end
    return table.concat(out)
end

---------------------------------------------------------------------------
-- Match flow
---------------------------------------------------------------------------

local UpdatePanel, ShowPopup, HidePopup, CreatePanel

local function NewMatch(mode, opponent, seed, id)
    M = {
        mode = mode, opponent = opponent, seed = seed, id = id or tostring(math.random(100000, 999999)),
        state = "countdown", countdown = COUNTDOWN, sentTotal = 0, gotTotal = 0, seq = 0, theirSeq = -1,
        them = { board = nil, lines = 0, sent = 0, out = false },
        lastHeard = Now(), lastSend = 0, needSend = true,
    }
    return M
end

local function StartGame()
    -- New game first, so opening the window does not start a solo game over the top of it.
    ns.NewGame({ seed = M.seed })
    ns.Open()
    if not panel then CreatePanel() end
    panel:Show()
    UpdatePanel()
    ns.SetDirty()
end

local function Finish(won, why)
    if not M or M.state == "over" then return end
    M.state = "over"
    M.won = won
    M.why = why
    local G = ns.Game()
    if G.versus and (G.state == "play" or G.state == "countdown") then G.state = "over" end
    local rec = Record()
    if won then rec.wins = rec.wins + 1 else rec.losses = rec.losses + 1 end
    local rivalKey = M.mode == "bot" and ("Bot: " .. M.bot.name) or M.opponent
    local rival = rec.rivals[rivalKey] or { w = 0, l = 0 }
    if won then rival.w = rival.w + 1 else rival.l = rival.l + 1 end
    rec.rivals[rivalKey] = rival
    ns.Sound(won and "UI_EPICLOOT_TOAST" or "IG_QUEST_FAILED")
    ns.SetDirty()
    UpdatePanel()
end

local function OpponentName()
    if not M then return "" end
    if M.mode == "bot" then return M.bot.name end
    return Short(M.opponent)
end

---------------------------------------------------------------------------
-- The bot: same pieces, its own board, picks each spot with a classic scoring of the board
---------------------------------------------------------------------------

local function BotFits(board, kind, rot, px, py)
    for _, c in ipairs(ns.Cells(kind, rot)) do
        local x, y = px + c[1], py + c[2]
        if x < 1 or x > ns.COLS or y < 1 or y > ns.ROWS or board[y][x] then return false end
    end
    return true
end

-- Scores the board after putting kind down at (rot, px, py). Higher is better.
local function Evaluate(board, kind, rot, px, py)
    local COLS, ROWS = ns.COLS, ns.ROWS
    local cells = ns.Cells(kind, rot)
    local mark = {}
    local top, bottom = ROWS, 1
    for _, c in ipairs(cells) do
        local x, y = px + c[1], py + c[2]
        mark[y] = mark[y] or {}
        mark[y][x] = true
        if y < top then top = y end
        if y > bottom then bottom = y end
    end
    -- Which rows end up full, and how many of the piece's cells go with them.
    local full, cleared, eroded = {}, 0, 0
    for y = top, bottom do
        local isFull = true
        for x = 1, COLS do
            if not (board[y][x] or (mark[y] and mark[y][x])) then isFull = false break end
        end
        if isFull then
            full[y] = true
            cleared = cleared + 1
            for x in pairs(mark[y]) do eroded = eroded + 1 end
        end
    end
    -- The board after clearing, as true/false, bottom rows last.
    local grid = {}
    for y = 1, cleared do grid[y] = {} end
    for y = 1, ROWS do
        if not full[y] then
            local row = {}
            for x = 1, COLS do row[x] = (board[y][x] or (mark[y] and mark[y][x])) and true or false end
            grid[#grid + 1] = row
        end
    end
    for y = 1, cleared do for x = 1, COLS do grid[y][x] = false end end

    local landing = ((ROWS - top + 1) + (ROWS - bottom + 1)) / 2
    local rowT, colT, holes, wells = 0, 0, 0, 0
    for y = 1, ROWS do
        local prev = true
        local row = grid[y]
        for x = 1, COLS do
            if row[x] ~= prev then rowT = rowT + 1 end
            prev = row[x]
        end
        if not prev then rowT = rowT + 1 end
    end
    for x = 1, COLS do
        local prev, seenBlock, depth = false, false, 0
        for y = 1, ROWS do
            local filled = grid[y][x]
            if filled ~= prev then colT = colT + 1 end
            prev = filled
            if filled then
                seenBlock = true
                depth = 0
            else
                if seenBlock then holes = holes + 1 end
                local left = x == 1 or grid[y][x - 1]
                local right = x == COLS or grid[y][x + 1]
                if left and right then
                    depth = depth + 1
                    wells = wells + depth
                else
                    depth = 0
                end
            end
        end
        if not prev then colT = colT + 1 end
    end
    return -4.500158825082766 * landing + 3.4181268101392694 * (cleared * eroded)
        - 3.2178882868487753 * rowT - 9.348695305445199 * colT
        - 7.899265427351652 * holes - 3.3855972247263626 * wells
end

local function BotChoose(B, kind)
    local options = {}
    local seen = {}
    for rot = 0, 3 do
        for px = -2, ns.COLS do
            if BotFits(B.board, kind, rot, px, 1) then
                local py = 1
                while BotFits(B.board, kind, rot, px, py + 1) do py = py + 1 end
                -- the same shape turned can land in the same cells; only keep one
                local cellsKey = {}
                for _, c in ipairs(ns.Cells(kind, rot)) do cellsKey[#cellsKey + 1] = (px + c[1]) .. "," .. (py + c[2]) end
                table.sort(cellsKey)
                local ck = table.concat(cellsKey, ";")
                if not seen[ck] then
                    seen[ck] = true
                    options[#options + 1] = { rot = rot, px = px, py = py, score = Evaluate(B.board, kind, rot, px, py) }
                end
            end
        end
    end
    if #options == 0 then return nil end
    table.sort(options, function(a, b) return a.score > b.score end)
    local bot = B.def
    if bot.blunder and math.random() < bot.blunder then return options[math.random(#options)] end
    if bot.mistakes > 0 and math.random() < bot.mistakes then
        return options[math.random(math.min(bot.pool, #options))]
    end
    return options[1]
end

local function BotTake(B)
    if #B.queue <= 3 then
        local bag = {}
        for i, k in ipairs(ns.KINDS) do bag[i] = k end
        for i = #bag, 2, -1 do
            local j = B.rand(i)
            bag[i], bag[j] = bag[j], bag[i]
        end
        for _, k in ipairs(bag) do B.queue[#B.queue + 1] = k end
    end
    return table.remove(B.queue, 1)
end

local function BotNextPiece(B)
    B.kind = BotTake(B)
    B.timer = 0
    if not BotFits(B.board, B.kind, 0, 4, 1) then
        B.plan = nil
        return false
    end
    B.plan = BotChoose(B, B.kind)
    return B.plan ~= nil
end

local function SendGarbageToPlayer(n)
    local G = ns.Game()
    G.incoming = (G.incoming or 0) + n
    M.them.sent = M.them.sent + n
    ns.Flash(n .. " garbage line" .. (n == 1 and "" or "s") .. " incoming!", 1, 0.4, 0.3)
    ns.SetDirty()
end

local function BotLock(B)
    local plan = B.plan
    local above = true
    for _, c in ipairs(ns.Cells(B.kind, plan.rot)) do
        local x, y = plan.px + c[1], plan.py + c[2]
        B.board[y][x] = B.kind
        if y > ns.HIDDEN then above = false end
    end
    if above then return false end
    local cleared, y = 0, ns.ROWS
    while y >= 1 do
        local isFull = true
        for x = 1, ns.COLS do if not B.board[y][x] then isFull = false break end end
        if isFull then
            table.remove(B.board, y)
            table.insert(B.board, 1, {})
            cleared = cleared + 1
        else
            y = y - 1
        end
    end
    if cleared > 0 then
        local attack = GARBAGE[cleared]
        if cleared == 4 and B.b2b then attack = attack + 1 end
        B.b2b = cleared == 4
        B.combo = B.combo + 1
        if B.combo >= 6 then attack = attack + 3 elseif B.combo >= 4 then attack = attack + 2 elseif B.combo >= 2 then attack = attack + 1 end
        B.lines = B.lines + cleared
        local cancel = math.min(attack, B.incoming)
        attack, B.incoming = attack - cancel, B.incoming - cancel
        if attack > 0 then SendGarbageToPlayer(attack) end
    else
        B.combo = -1
        if B.incoming > 0 then
            local n = math.min(B.incoming, MAX_RISE)
            B.incoming = B.incoming - n
            local hole = math.random(ns.COLS)
            local overflow = false
            for _ = 1, n do
                local topRow = table.remove(B.board, 1)
                for x = 1, ns.COLS do if topRow[x] then overflow = true end end
                local row = {}
                for x = 1, ns.COLS do if x ~= hole then row[x] = "G" end end
                B.board[#B.board + 1] = row
            end
            if overflow then return false end
        end
    end
    return true
end

local function BotTick(elapsed)
    local B = M.bot
    local G = ns.Game()
    B.timer = B.timer + elapsed
    -- The bot speeds up as the match goes on, like the falling pieces do.
    local think = B.def.think * math.max(0.6, 1 - (G.clock or 0) / 400)
    if B.timer >= think then
        if not BotLock(B) or not BotNextPiece(B) then
            Finish(true, M.bot.name .. " topped out!")
            return
        end
    end
    B.progress = math.min(1, B.timer / think)
    M.them.board = B.board
    M.them.lines = B.lines
    M.them.incoming = B.incoming
end

local function StartBot(key)
    if M and (M.state == "countdown" or M.state == "play" or M.state == "inviting") then
        ns.Say("finish or leave your current match first.")
        return
    end
    local def = BOT_BY_KEY[key] or BOTS[2]
    local seed = math.random(1, 2147483000)
    NewMatch("bot", nil, seed)
    local board = {}
    for y = 1, ns.ROWS do board[y] = {} end
    M.bot = { def = def, name = def.name, board = board, queue = {}, rand = ns.SeededRandom(seed),
        incoming = 0, combo = -1, b2b = false, lines = 0, timer = 0, progress = 0 }
    M.bot.name = def.name
    BotNextPiece(M.bot)
    M.them.board = board
    StartGame()
end

---------------------------------------------------------------------------
-- Hooks called by the game
---------------------------------------------------------------------------

function ns.InMatch()
    return M ~= nil and (M.state == "countdown" or M.state == "play")
end

-- Called after every piece locks in a versus game.
function ns.OnLock(cleared, backToBackTetris, combo)
    if not M or M.state ~= "play" then return end
    local G = ns.Game()
    if cleared > 0 then
        local attack = GARBAGE[cleared]
        if backToBackTetris then attack = attack + 1 end
        if combo >= 6 then attack = attack + 3 elseif combo >= 4 then attack = attack + 2 elseif combo >= 2 then attack = attack + 1 end
        -- Your attack first cancels garbage that's on its way to you.
        local cancel = math.min(attack, G.incoming or 0)
        attack, G.incoming = attack - cancel, (G.incoming or 0) - cancel
        if attack > 0 then
            M.sentTotal = M.sentTotal + attack
            if M.mode == "bot" then M.bot.incoming = M.bot.incoming + attack end
        end
    elseif (G.incoming or 0) > 0 then
        local n = math.min(G.incoming, MAX_RISE)
        G.incoming = G.incoming - n
        if not ns.AddGarbage(n, math.random(ns.COLS)) then
            ns.GameOver()
            return
        end
    end
    M.needSend = true
    UpdatePanel()
end

-- Called when you top out.
function ns.OnGameOver()
    if not M or M.state ~= "play" then return end
    if M.mode == "pvp" then Send(M.opponent, "L", M.id) end
    Finish(false, "You topped out.")
end

-- Leaves the current match (or cancels a challenge). Leaving a match you're in counts as a loss.
function ns.LeaveVersus()
    if not M then return end
    if M.state == "inviting" then
        Send(M.opponent, "Q", M.id)
        M = nil
        UpdatePanel()
        return
    end
    if M.state == "countdown" or M.state == "play" then
        if M.mode == "pvp" then Send(M.opponent, "Q", M.id) end
        Finish(false, "You left the match.")
    end
end

function ns.VersusOverlay()
    if not M then return nil end
    local G = ns.Game()
    if not G.versus then return nil end
    if M.state == "countdown" then
        return "Versus " .. OpponentName() .. "\n\n|cffffffff" .. math.max(1, math.ceil(M.countdown)) .. "|r"
    elseif M.state == "over" then
        local head = M.won and "|cff40ff40Victory!|r" or "|cffff4040Defeat|r"
        return head .. "\n\n|cffffffff" .. (M.why or "") .. "\n\nRematch from the panel, or press Space for a solo game.|r"
    end
    return nil
end

function ns.VersusTick(elapsed)
    if not M then return end
    local G = ns.Game()
    if M.state == "countdown" then
        local before = math.ceil(M.countdown)
        M.countdown = M.countdown - elapsed
        if math.ceil(M.countdown) ~= before then ns.SetDirty() end
        if M.countdown <= 0 then
            M.state = "play"
            M.lastHeard = Now()
            if G.versus and G.state == "countdown" then G.state = "play" end
            ns.Flash("Fight!  " .. (G.cry or ""), 1, 0.82, 0.2)
            ns.Sound("UI_LEVEL_UP")
            ns.SetDirty()
        end
        UpdatePanel()
        return
    end
    if M.state ~= "play" then return end
    if M.mode == "bot" then
        BotTick(elapsed)
    else
        local now = Now()
        if now - M.lastHeard > SILENCE_LIMIT then
            Finish(true, Short(M.opponent) .. " stopped answering.")
            return
        end
        if (M.needSend and now - M.lastSend >= SEND_GAP) or now - M.lastSend >= PING_GAP then
            M.seq = M.seq + 1
            local text = table.concat({ "S", M.id, M.seq, BoardString(G.board), M.sentTotal, G.lines }, "~")
            if TrySend(text, M.opponent) then
                M.needSend = false
                M.lastSend = now
            else
                M.seq = M.seq - 1
                M.lastSend = now - SEND_GAP + 0.5 -- try again shortly
            end
        end
    end
    UpdatePanel()
end

---------------------------------------------------------------------------
-- Challenges between players
---------------------------------------------------------------------------

local function Challenge(target)
    target = FullName(target)
    if not target or target == MyName() then
        ns.Say("pick another player to challenge.")
        return
    end
    if M and (M.state == "countdown" or M.state == "play" or M.state == "inviting") then
        ns.Say("finish or leave your current match first.")
        return
    end
    local seed = math.random(1, 2147483000)
    NewMatch("pvp", target, seed)
    M.state = "inviting"
    local match = M
    Send(target, "C", M.id, M.seed)
    UpdatePanel()
    C_Timer.After(INVITE_TIME + 2, function()
        if M == match and match.state == "inviting" then
            M = nil
            ns.Say("no answer from " .. Short(target) .. ". They need Warcraft Tetris 1.2 or newer, and must be on your faction.")
            UpdatePanel()
        end
    end)
end

local function Accept(invite)
    HidePopup()
    if M and (M.state == "countdown" or M.state == "play" or M.state == "inviting") then
        Send(invite.from, "D", invite.id)
        return
    end
    if InCombatLockdown() then
        ns.Say("finish your fight first.")
        Send(invite.from, "D", invite.id)
        return
    end
    NewMatch("pvp", invite.from, invite.seed, invite.id)
    Send(invite.from, "A", invite.id)
    StartGame()
end

local function OnMessage(kind, f, sender)
    local from = FullName(sender)
    if not from or from == MyName() then return end
    local id = f[1]
    if kind == "C" then
        local seed = tonumber(f[2])
        if not id or not seed then return end
        if M and (M.state == "countdown" or M.state == "play" or M.state == "inviting") then
            Send(from, "D", id, "busy")
            return
        end
        ShowPopup({ from = from, id = id, seed = seed })
        return
    end
    if kind == "Q" and popup and popup.invite and popup.invite.id == id then
        HidePopup()
        ns.Say(Short(from) .. " took back the challenge.")
        return
    end
    if not M or M.id ~= id or M.opponent ~= from then return end
    M.lastHeard = Now()
    if kind == "A" and M.state == "inviting" then
        M.state = "countdown"
        M.countdown = COUNTDOWN
        StartGame()
    elseif kind == "D" and M.state == "inviting" then
        M = nil
        ns.Say(Short(from) .. (f[2] == "busy" and " is busy in another match." or " said no to a game."))
        UpdatePanel()
    elseif kind == "S" then
        local seq = tonumber(f[2])
        local board, sent, lines = f[3], tonumber(f[4]), tonumber(f[5])
        if not seq or seq <= M.theirSeq or type(board) ~= "string" or #board ~= ns.COLS * (ns.ROWS - ns.HIDDEN) then return end
        M.theirSeq = seq
        M.them.boardText = board
        M.them.lines = lines or M.them.lines
        if sent and sent > M.gotTotal and M.state == "play" then
            local n = sent - M.gotTotal
            M.gotTotal = sent
            SendGarbageToPlayer(n)
        end
        UpdatePanel()
    elseif kind == "L" then
        Finish(true, Short(from) .. " topped out!")
    elseif kind == "Q" then
        if M.state == "countdown" or M.state == "play" then Finish(true, Short(from) .. " left the match.") end
    end
end

---------------------------------------------------------------------------
-- Challenge popup
---------------------------------------------------------------------------

HidePopup = function()
    if popup then
        popup.invite = nil
        popup:Hide()
    end
end

ShowPopup = function(invite)
    if not popup then
        popup = CreateFrame("Frame", "WarcraftTetrisChallenge", UIParent)
        popup:SetSize(320, 112)
        popup:SetPoint("TOP", 0, -150)
        popup:SetFrameStrata("DIALOG")
        local border = popup:CreateTexture(nil, "BACKGROUND", nil, -8)
        border:SetAllPoints()
        border:SetColorTexture(0.62, 0.48, 0.2, 1)
        local bg = popup:CreateTexture(nil, "BACKGROUND", nil, -7)
        bg:SetPoint("TOPLEFT", 2, -2)
        bg:SetPoint("BOTTOMRIGHT", -2, 2)
        bg:SetColorTexture(0.08, 0.06, 0.05, 0.97)
        popup.text = popup:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        popup.text:SetPoint("TOP", 0, -16)
        popup.text:SetWidth(290)
        local yes = ns.Button(popup, 120, "Accept", function() if popup.invite then Accept(popup.invite) end end)
        yes:SetPoint("BOTTOMLEFT", 30, 14)
        local no = ns.Button(popup, 120, "Decline", function()
            if popup.invite then Send(popup.invite.from, "D", popup.invite.id) end
            HidePopup()
        end)
        no:SetPoint("BOTTOMRIGHT", -30, 14)
    end
    popup.invite = invite
    popup.text:SetText("|cffffc94dWarcraft Tetris|r\n\n" .. Short(invite.from) .. " challenges you to a versus game!")
    popup:Show()
    ns.Sound("READY_CHECK")
    C_Timer.After(INVITE_TIME, function()
        if popup.invite == invite then
            Send(invite.from, "D", invite.id)
            HidePopup()
        end
    end)
end

---------------------------------------------------------------------------
-- Versus panel beside the game window
---------------------------------------------------------------------------

local MINI_CELL = 13

local function PartyNames()
    local names = {}
    local n = (GetNumSubgroupMembers and GetNumSubgroupMembers()) or 0
    for i = 1, math.min(n, 4) do
        local ok, name, realm = pcall(UnitName, "party" .. i)
        if ok and type(name) == "string" and not IsSecret(name) and not IsSecret(realm) then
            if type(realm) == "string" and realm ~= "" then name = name .. "-" .. realm end
            names[#names + 1] = name
        end
    end
    return names
end

local function TargetName()
    local ok, isPlayer = pcall(UnitIsPlayer, "target")
    if not ok or IsSecret(isPlayer) or not isPlayer then return nil end
    local ok2, name = pcall(GetUnitName, "target", true)
    if not ok2 or type(name) ~= "string" or IsSecret(name) then return nil end
    return name
end

CreatePanel = function()
    local f = ns.Frame()
    local p = CreateFrame("Frame", "WarcraftTetrisVersus", f)
    p:SetSize(200, f:GetHeight())
    p:SetPoint("TOPLEFT", f, "TOPRIGHT", -2, 0)
    p:EnableMouse(true)
    local border = p:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.62, 0.48, 0.2, 1)
    local bg = p:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 2, -2)
    bg:SetPoint("BOTTOMRIGHT", -2, 2)
    bg:SetColorTexture(0.08, 0.06, 0.05, 0.97)
    local function Text(parent, font, x, y, width)
        local t = parent:CreateFontString(nil, "OVERLAY", font)
        t:SetPoint("TOPLEFT", x, y)
        if width then t:SetWidth(width) t:SetJustifyH("LEFT") end
        return t
    end

    -- Lobby
    local lobby = CreateFrame("Frame", nil, p)
    lobby:SetAllPoints()
    p.lobby = lobby
    local title = lobby:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Versus")
    local intro = Text(lobby, "GameFontHighlightSmall", 12, -40, 176)
    intro:SetText("Same pieces for both of you. Clear 2 or more lines to send grey garbage rows to your rival. Top out and you lose.")
    local botLabel = Text(lobby, "GameFontNormal", 12, -104)
    botLabel:SetText("Play a bot")
    p.botButtons = {}
    for i, bot in ipairs(BOTS) do
        local b = ns.Button(lobby, 176, bot.level .. ": " .. bot.name, function() StartBot(bot.key) end)
        b:SetPoint("TOPLEFT", 12, -122 - (i - 1) * 24)
        b.tip = bot.tip
        p.botButtons[i] = b
    end
    local pvpLabel = Text(lobby, "GameFontNormal", 12, -204)
    pvpLabel:SetText("Play a player")
    local targetButton = ns.Button(lobby, 176, "Challenge my target", function()
        local name = TargetName()
        if name then Challenge(name) else ns.Say("target a player first.") end
    end)
    targetButton:SetPoint("TOPLEFT", 12, -222)
    targetButton.tip = "They need Warcraft Tetris too, and must be on your faction."
    local edit = CreateFrame("EditBox", nil, lobby, "InputBoxTemplate")
    edit:SetSize(100, 20)
    edit:SetPoint("TOPLEFT", 18, -250)
    edit:SetAutoFocus(false)
    edit:SetScript("OnEnterPressed", function(self) Challenge(self:GetText()) self:ClearFocus() end)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    p.edit = edit
    local byName = ns.Button(lobby, 66, "Challenge", function() Challenge(edit:GetText()) edit:ClearFocus() end)
    byName:SetPoint("TOPLEFT", 122, -250)
    byName.tip = "Type a player's name, then click Challenge."
    p.partyButtons = {}
    for i = 1, 4 do
        local b = ns.Button(lobby, 176, "", function(self) if self.who then Challenge(self.who) end end)
        b:SetPoint("TOPLEFT", 12, -278 - (i - 1) * 24)
        b:Hide()
        p.partyButtons[i] = b
    end
    p.status = Text(lobby, "GameFontHighlight", 12, -380, 176)
    p.cancel = ns.Button(lobby, 176, "Cancel challenge", function() ns.LeaveVersus() end)
    p.cancel:SetPoint("TOPLEFT", 12, -430)
    p.record = Text(lobby, "GameFontHighlightSmall", 12, -470, 176)
    local close = ns.Button(lobby, 22, "X", function() p:Hide() end)
    close:SetPoint("TOPRIGHT", -10, -10)

    -- Match view
    local view = CreateFrame("Frame", nil, p)
    view:SetAllPoints()
    p.view = view
    p.name = view:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    p.name:SetPoint("TOP", 0, -14)
    p.name:SetWidth(184)
    p.sub = view:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    p.sub:SetPoint("TOP", 0, -36)
    local w, h = ns.COLS * MINI_CELL, (ns.ROWS - ns.HIDDEN) * MINI_CELL
    local board = ns.Box(view, w, h)
    board:SetPoint("TOP", 0, -56)
    p.board = board
    p.cells = {}
    for y = 1, ns.ROWS - ns.HIDDEN do
        for x = 1, ns.COLS do
            local t = ns.Block(board, MINI_CELL)
            t:SetPoint("TOPLEFT", (x - 1) * MINI_CELL, -(y - 1) * MINI_CELL)
            p.cells[(y - 1) * ns.COLS + x] = t
        end
    end
    p.piece = {}
    for i = 1, 4 do p.piece[i] = ns.Block(board, MINI_CELL, "OVERLAY") end
    p.theirGarbage = view:CreateTexture(nil, "ARTWORK")
    p.theirGarbage:SetWidth(4)
    p.theirGarbage:SetPoint("BOTTOMRIGHT", board, "BOTTOMLEFT", -3, 0)
    p.theirGarbage:SetColorTexture(1, 0.2, 0.15, 0.9)
    p.boardNote = board:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    p.boardNote:SetPoint("CENTER")
    p.boardNote:SetWidth(w - 8)
    p.stats = Text(view, "GameFontHighlight", 14, -330, 176)
    p.result = view:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    p.result:SetPoint("TOP", 0, -396)
    p.rematch = ns.Button(view, 176, "Rematch", function()
        if not M then return end
        if M.mode == "bot" then StartBot(M.bot.def.key) else Challenge(M.opponent) end
    end)
    p.rematch:SetPoint("TOPLEFT", 12, -424)
    p.back = ns.Button(view, 176, "Back to versus menu", function() M = nil UpdatePanel() end)
    p.back:SetPoint("TOPLEFT", 12, -450)
    p.leave = ns.Button(view, 176, "Leave match", function() ns.LeaveVersus() end)
    p.leave:SetPoint("TOPLEFT", 12, -450)
    p.leave.tip = "Leaving counts as a loss."

    p:Hide()
    panel = p
    return p
end

local function PaintCell(t, kind, alpha)
    local c = ns.PIECES[kind] and ns.PIECES[kind].color or { 0.5, 0.5, 0.5 }
    t:SetVertexColor(c[1], c[2], c[3], alpha or 1)
    t:Show()
end

local function DrawTheirBoard()
    local p = panel
    local them = M.them
    local text = them.boardText
    local board = them.board
    for y = 1, ns.ROWS - ns.HIDDEN do
        for x = 1, ns.COLS do
            local i = (y - 1) * ns.COLS + x
            local kind
            if text then
                kind = text:sub(i, i)
                if kind == "." then kind = nil end
            elseif board then
                kind = board[y + ns.HIDDEN][x]
            end
            if kind then PaintCell(p.cells[i], kind) else p.cells[i]:Hide() end
        end
    end
    -- The bot's falling piece, drifting down to where it will land.
    local B = M.bot
    local showPiece = M.mode == "bot" and M.state == "play" and B.plan
    for i = 1, 4 do
        local t = p.piece[i]
        if showPiece then
            local c = ns.Cells(B.kind, B.plan.rot)[i]
            local py = 1 + math.floor((B.plan.py - 1) * (B.progress or 0) + 0.5)
            local x, y = B.plan.px + c[1], py + c[2]
            if y > ns.HIDDEN then
                t:ClearAllPoints()
                t:SetPoint("TOPLEFT", p.board, "TOPLEFT", (x - 1) * MINI_CELL, -(y - ns.HIDDEN - 1) * MINI_CELL)
                PaintCell(t, B.kind)
            else
                t:Hide()
            end
        else
            t:Hide()
        end
    end
    local incoming = them.incoming or 0
    p.theirGarbage:SetHeight(math.max(1, math.min(ns.ROWS - ns.HIDDEN, incoming) * MINI_CELL))
    p.theirGarbage:SetShown(M.mode == "bot" and incoming > 0)
end

UpdatePanel = function()
    local p = panel
    if not p then return end
    local inView = M and M.state ~= "inviting"
    p.lobby:SetShown(not inView)
    p.view:SetShown(inView and true or false)
    if not inView then
        local inviting = M and M.state == "inviting"
        p.status:SetText(inviting and ("Waiting for " .. Short(M.opponent) .. " to answer...") or "")
        p.cancel:SetShown(inviting and true or false)
        local names = PartyNames()
        for i, b in ipairs(p.partyButtons) do
            if names[i] then
                b.who = names[i]
                b.label:SetText("Challenge " .. Short(names[i]))
                b:Show()
            else
                b:Hide()
            end
        end
        local rec = Record()
        p.record:SetText(string.format("|cffffd100Your versus record|r\n%d wins, %d losses", rec.wins, rec.losses))
        return
    end
    p.name:SetText((M.mode == "bot" and "|cffff8040" or "|cff40c0ff") .. OpponentName() .. "|r")
    p.sub:SetText(M.mode == "bot" and (M.bot.def.level .. " bot") or "Player")
    DrawTheirBoard()
    p.stats:SetText(string.format("|cffffd100Their lines|r  %d\n|cffffd100Garbage you sent|r  %d\n|cffffd100Garbage they sent|r  %d\n|cffffd100Speed level|r  %d",
        M.them.lines or 0, M.sentTotal, M.them.sent, ns.Level()))
    if M.state == "countdown" then
        p.boardNote:SetText("Get ready...")
    elseif M.state == "over" then
        p.boardNote:SetText(M.won and "|cffff4040Topped out|r" or "|cff40ff40Winner|r")
    elseif M.mode == "pvp" and not M.them.boardText then
        p.boardNote:SetText("Waiting for their board...")
    else
        p.boardNote:SetText("")
    end
    local over = M.state == "over"
    p.result:SetText(over and (M.won and "|cff40ff40You win!|r" or "|cffff4040You lose|r") or "")
    p.rematch:SetShown(over)
    p.back:SetShown(over)
    p.leave:SetShown(not over)
end

function ns.ToggleVersusPanel()
    if not ns.Frame() then return end
    if not panel then CreatePanel() end
    if panel:IsShown() then panel:Hide() else panel:Show() UpdatePanel() end
end

---------------------------------------------------------------------------
-- Setup and commands
---------------------------------------------------------------------------

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("CHAT_MSG_ADDON")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:SetScript("OnEvent", function(_, event, prefix, text, channel, sender)
    if event == "PLAYER_LOGIN" then
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then C_ChatInfo.RegisterAddonMessagePrefix(PREFIX) end
        return
    end
    if event == "GROUP_ROSTER_UPDATE" then
        if panel and panel:IsShown() then UpdatePanel() end
        return
    end
    if IsSecret(prefix) or IsSecret(text) or IsSecret(sender) then return end
    if prefix ~= PREFIX or type(text) ~= "string" or type(sender) ~= "string" then return end
    local fields = {}
    for field in (text .. "~"):gmatch("([^~]*)~") do fields[#fields + 1] = field end
    local kind = table.remove(fields, 1)
    local ok, err = pcall(OnMessage, kind, fields, sender)
    if not ok and ns.debug then ns.Say("message error: " .. tostring(err)) end
end)

-- /tetris vs [easy|normal|hard|name]
function ns.VersusCommand(arg)
    arg = arg or ""
    if arg == "" then
        ns.Open()
        if not panel then CreatePanel() end
        panel:Show()
        UpdatePanel()
    elseif BOT_BY_KEY[arg:lower()] then
        StartBot(arg:lower())
    else
        Challenge(arg)
    end
end

-- For the automated tests.
ns.Versus = { Match = function() return M end, StartBot = StartBot, Challenge = Challenge, Accept = Accept,
    Evaluate = Evaluate, BotChoose = BotChoose, Popup = function() return popup end, Panel = function() return panel end }
