Warcraft Tetris 1.2.0 - World of Warcraft: Forever (Interface 16001)
===================================================================

A falling-blocks puzzle game you can play inside WoW Forever, on your own
or versus a bot or another player. Click the
Tetris button on the minimap, pick it from the minimap addon menu, or
type /tetris to open it.

INSTALL
Copy the WarcraftTetris folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

KEYS (while the game window is open)
Left / Right or A / D   move
Down or S               soft drop (falls faster, 1 point a row)
Up, X or W              turn clockwise
Z, Q or Ctrl            turn the other way
Space                   hard drop (2 points a row), also starts and restarts
C or Shift              hold the piece for later (once per piece)
P                       pause
Esc                     close (the game pauses)
R or N                  new game after a game over or while paused

Keys the game does not use, like Enter for chat, still work as normal.
The window only takes the keyboard while it is open.

BUTTONS (left side of the game window)
Start / Pause      start the game, pause it, or carry on
Preview: on/off    show or hide where the piece will land
Sound: on/off      turn sounds on or off
Minimap: on/off    show or hide the minimap button
Center window      move the window back to the middle
Versus             open the versus panel (see VERSUS below)
New game sits at the top left and X closes the window. Drag the window by
its edges to move it, and drag the minimap button to move it around the
minimap. Your best score and games played show on the right.

COMMANDS (optional, every setting is also a button)
/tetris          open or close the game
/tetris new      start a new game
/tetris ghost    show or hide the drop preview
/tetris sound    turn sounds on or off
/tetris best     show your best score, most lines and games played
/tetris minimap  show or hide the minimap button
/tetris reset    move the window back to the middle
/tetris vs       open the versus panel
/tetris vs easy  play a bot (easy, normal or hard)
/tetris vs Name  challenge a player
/tetris help     list the commands
/wtetris also works.

HOW IT PLAYS
- 10 x 20 board, a "next" preview of three pieces, and a hold slot.
- Pieces come in shuffled sets of seven, so you never wait too long for
  a long piece.
- Turning uses the standard wall kicks, so pieces can slide around
  corners and into gaps.
- A piece resting on the stack waits half a second before it locks, and
  moving or turning it restarts that wait (up to 15 times).
- Every 10 lines the level goes up and pieces fall faster.

SCORING
Clearing 1, 2, 3 or 4 lines scores 100, 300, 500 or 800 points times the
level. Four lines in a row after another four-line clear scores half as
much again. Clearing lines with pieces in a row adds a combo bonus.
Your best score is saved.

Each piece is coloured for a school of magic or a faction: Frost, Holy,
Arcane, Fel, Fire, Alliance and Horde.

VERSUS
Click Versus on the left of the game window. A panel opens beside it.
- Both of you get the same pieces in the same order, so it is all skill.
- Clear lines to send grey garbage rows to your rival: 2 lines send 1,
  3 lines send 2, and 4 lines send 4. Four-line clears back to back and
  combos send extra.
- Garbage on its way to you shows as a red bar beside your board. It rises
  from the bottom after your next piece that clears nothing, unless you
  clear lines first: your attacks cancel incoming garbage.
- Pieces fall faster as the match goes on. Top out and you lose.
- There is no pausing. Esc won't close the window during a match; use
  Leave match. Closing the window or entering combat counts as leaving.

Bots
  Easy: Kobold Tunneler      slow and makes plenty of mistakes
  Normal: Goblin Sapper      steady and tidy, a fair fight
  Hard: Dalaran Archmage     fast and plans every piece

Players
Challenge your target, a party member, or type a name. They need Warcraft
Tetris 1.2.0 or newer, and must be on your faction (the game only lets
addons talk to your own faction). They get a popup to accept or decline.
The panel shows their board live as you play.

Your versus wins and losses are saved, and so is your record against each
rival. Rematch or go back to the menu from the panel after a match.

COMBAT
Entering combat closes the window and pauses the game, so your keys are
back in your hands at once. Type /tetris to carry on afterwards.

CREDITS
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Tetris is a trademark of The Tetris Company. This is a fan-made game and
is not affiliated with or endorsed by The Tetris Company or Blizzard
Entertainment.
