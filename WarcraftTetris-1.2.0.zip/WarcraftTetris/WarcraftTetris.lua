-- Warcraft Tetris for World of Warcraft: Forever (Interface 16001)
-- A falling-blocks game in its own window. Type /tetris to play.
-- Keys are only captured while the game window is open and you are out of combat.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\"
local PREFIX = "|cffffc94dWarcraft Tetris:|r "
local COLS, ROWS, HIDDEN = 10, 22, 2         -- the top two rows are above the visible board
local CELL = 22
local MINI = 14
local LOCK_DELAY, MAX_RESETS = 0.5, 15
local DAS, ARR, SOFT_DROP = 0.16, 0.045, 0.035
local QUEUE = 3

local db
local frame

---------------------------------------------------------------------------
-- Pieces. Colours follow the schools of magic; cells are { x, y } in a box, y down.
---------------------------------------------------------------------------

local PIECES = {
    I = { size = 4, color = { 0.35, 0.85, 1.0 }, school = "Frost", cells = { { 0, 1 }, { 1, 1 }, { 2, 1 }, { 3, 1 } } },
    O = { size = 4, color = { 1.0, 0.85, 0.3 }, school = "Holy", cells = { { 1, 0 }, { 2, 0 }, { 1, 1 }, { 2, 1 } } },
    T = { size = 3, color = { 0.72, 0.42, 1.0 }, school = "Arcane", cells = { { 1, 0 }, { 0, 1 }, { 1, 1 }, { 2, 1 } } },
    S = { size = 3, color = { 0.4, 0.95, 0.35 }, school = "Fel", cells = { { 1, 0 }, { 2, 0 }, { 0, 1 }, { 1, 1 } } },
    Z = { size = 3, color = { 1.0, 0.32, 0.2 }, school = "Fire", cells = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 2, 1 } } },
    J = { size = 3, color = { 0.3, 0.5, 1.0 }, school = "Alliance", cells = { { 0, 0 }, { 0, 1 }, { 1, 1 }, { 2, 1 } } },
    L = { size = 3, color = { 1.0, 0.55, 0.15 }, school = "Horde", cells = { { 2, 0 }, { 0, 1 }, { 1, 1 }, { 2, 1 } } },
}
local KINDS = { "I", "O", "T", "S", "Z", "J", "L" }

-- All four rotations of every piece (clockwise turn: x, y -> size - 1 - y, x).
for _, piece in pairs(PIECES) do
    piece.rot = { piece.cells }
    for r = 2, 4 do
        local turned = {}
        for i, c in ipairs(piece.rot[r - 1]) do turned[i] = { piece.size - 1 - c[2], c[1] } end
        piece.rot[r] = turned
    end
end
-- Garbage rows sent by a versus rival: grey stone with a gap.
PIECES.G = { color = { 0.5, 0.5, 0.52 }, school = "Stone" }

-- Wall kicks (the standard rotation system), as { dx, dy } with y pointing up.
local KICKS = {
    ["0>1"] = { { 0, 0 }, { -1, 0 }, { -1, 1 }, { 0, -2 }, { -1, -2 } },
    ["1>0"] = { { 0, 0 }, { 1, 0 }, { 1, -1 }, { 0, 2 }, { 1, 2 } },
    ["1>2"] = { { 0, 0 }, { 1, 0 }, { 1, -1 }, { 0, 2 }, { 1, 2 } },
    ["2>1"] = { { 0, 0 }, { -1, 0 }, { -1, 1 }, { 0, -2 }, { -1, -2 } },
    ["2>3"] = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 0, -2 }, { 1, -2 } },
    ["3>2"] = { { 0, 0 }, { -1, 0 }, { -1, -1 }, { 0, 2 }, { -1, 2 } },
    ["3>0"] = { { 0, 0 }, { -1, 0 }, { -1, -1 }, { 0, 2 }, { -1, 2 } },
    ["0>3"] = { { 0, 0 }, { 1, 0 }, { 1, 1 }, { 0, -2 }, { 1, -2 } },
}
local KICKS_I = {
    ["0>1"] = { { 0, 0 }, { -2, 0 }, { 1, 0 }, { -2, -1 }, { 1, 2 } },
    ["1>0"] = { { 0, 0 }, { 2, 0 }, { -1, 0 }, { 2, 1 }, { -1, -2 } },
    ["1>2"] = { { 0, 0 }, { -1, 0 }, { 2, 0 }, { -1, 2 }, { 2, -1 } },
    ["2>1"] = { { 0, 0 }, { 1, 0 }, { -2, 0 }, { 1, -2 }, { -2, 1 } },
    ["2>3"] = { { 0, 0 }, { 2, 0 }, { -1, 0 }, { 2, 1 }, { -1, -2 } },
    ["3>2"] = { { 0, 0 }, { -2, 0 }, { 1, 0 }, { -2, -1 }, { 1, 2 } },
    ["3>0"] = { { 0, 0 }, { 1, 0 }, { -2, 0 }, { 1, -2 }, { -2, 1 } },
    ["0>3"] = { { 0, 0 }, { -1, 0 }, { 2, 0 }, { -1, 2 }, { 2, -1 } },
}

local CLEAR_NAMES = { "Single", "Double", "Triple" }
local CLEAR_POINTS = { 100, 300, 500, 800 }

---------------------------------------------------------------------------
-- Game state
---------------------------------------------------------------------------

local G = {}        -- the current game; G.state is "ready", "play", "paused" or "over"
local dirty = true

local function Say(text)
    print(PREFIX .. text)
end

local function Sound(name)
    if db and db.sound and type(SOUNDKIT) == "table" and SOUNDKIT[name] and type(PlaySound) == "function" then
        pcall(PlaySound, SOUNDKIT[name])
    end
end

local function NewBoard()
    local board = {}
    for y = 1, ROWS do board[y] = {} end
    return board
end

local function RefillBag()
    local bag = {}
    for i, k in ipairs(KINDS) do bag[i] = k end
    for i = #bag, 2, -1 do
        local j = G.rand and G.rand(i) or math.random(i) -- versus games share one piece order
        bag[i], bag[j] = bag[j], bag[i]
    end
    for _, k in ipairs(bag) do G.queue[#G.queue + 1] = k end
end

local function TakeNext()
    if #G.queue <= QUEUE then RefillBag() end
    return table.remove(G.queue, 1)
end

local function Cells(kind, rot)
    return PIECES[kind].rot[rot + 1]
end

local function Fits(kind, rot, px, py)
    for _, c in ipairs(Cells(kind, rot)) do
        local x, y = px + c[1], py + c[2]
        if x < 1 or x > COLS or y < 1 or y > ROWS or G.board[y][x] then return false end
    end
    return true
end

local function Level()
    local level = G.startLevel + math.floor(G.lines / 10)
    -- In versus, pieces also speed up over time so every match ends.
    if G.versus then level = math.max(level, 1 + math.floor((G.clock or 0) / 30)) end
    return level
end

local function GravityInterval()
    local level = Level()
    return math.max(0.02, (0.8 - (level - 1) * 0.007) ^ (level - 1))
end

local function Flash(text, r, g, b)
    G.flashText, G.flashTime = text, 1.4
    G.flashColor = { r or 1, g or 0.82, b or 0.2 }
end

local GameOver

-- Puts a new piece at the top. Returns false when there is no room (game over).
local function Spawn(kind)
    G.kind, G.rot, G.px, G.py = kind, 0, 4, 1
    G.lockTimer, G.resets, G.lowest = 0, 0, G.py
    G.gravityTimer = 0
    if not Fits(G.kind, G.rot, G.px, G.py) then
        GameOver()
        return false
    end
    -- Drop one row straight away when it fits, so the piece shows on the board sooner.
    if Fits(G.kind, G.rot, G.px, G.py + 1) then G.py = G.py + 1 end
    dirty = true
    return true
end

local function Grounded()
    return not Fits(G.kind, G.rot, G.px, G.py + 1)
end

-- Moving or turning a piece that is resting on something restarts its lock timer, a limited number of times.
local function TouchLock()
    if Grounded() and G.resets < MAX_RESETS then
        G.lockTimer = 0
        G.resets = G.resets + 1
    end
end

local function Move(dx)
    if Fits(G.kind, G.rot, G.px + dx, G.py) then
        G.px = G.px + dx
        TouchLock()
        dirty = true
        return true
    end
    return false
end

local function Rotate(dir)
    if G.kind == "O" then return false end
    local to = (G.rot + dir) % 4
    local kicks = (G.kind == "I" and KICKS_I or KICKS)[G.rot .. ">" .. to]
    for _, k in ipairs(kicks) do
        if Fits(G.kind, to, G.px + k[1], G.py - k[2]) then
            G.px, G.py, G.rot = G.px + k[1], G.py - k[2], to
            TouchLock()
            dirty = true
            return true
        end
    end
    return false
end

local function StepDown()
    if Fits(G.kind, G.rot, G.px, G.py + 1) then
        G.py = G.py + 1
        if G.py > G.lowest then
            G.lowest = G.py
            G.resets = 0
            G.lockTimer = 0
        end
        dirty = true
        return true
    end
    return false
end

local function ClearLines()
    local cleared = 0
    local y = ROWS
    while y >= 1 do
        local full = true
        for x = 1, COLS do
            if not G.board[y][x] then full = false break end
        end
        if full then
            table.remove(G.board, y)
            table.insert(G.board, 1, {})
            cleared = cleared + 1
        else
            y = y - 1
        end
    end
    return cleared
end

local function Lock()
    local above = true
    for _, c in ipairs(Cells(G.kind, G.rot)) do
        local x, y = G.px + c[1], G.py + c[2]
        G.board[y][x] = G.kind
        if y > HIDDEN then above = false end
    end
    G.pieces = G.pieces + 1
    if above then
        -- Locked entirely above the visible board.
        GameOver()
        return
    end

    local cleared = ClearLines()
    local backToBackTetris = cleared == 4 and G.backToBack
    if cleared > 0 then
        local levelBefore = Level()
        local points = CLEAR_POINTS[cleared] * levelBefore
        local tetris = cleared == 4
        if tetris and G.backToBack then points = math.floor(points * 1.5) end
        G.backToBack = tetris
        G.combo = G.combo + 1
        if G.combo > 0 then points = points + 50 * G.combo * levelBefore end
        G.score = G.score + points
        G.lines = G.lines + cleared
        if tetris then
            Flash("TETRIS!  " .. G.cry, 1, 0.82, 0.2)
            Sound("UI_EPICLOOT_TOAST")
        else
            Flash(CLEAR_NAMES[cleared] .. (G.combo > 0 and ("  combo x" .. (G.combo + 1)) or ""), 0.9, 0.9, 1)
            Sound("IG_QUEST_LIST_COMPLETE")
        end
        if Level() > levelBefore then
            Flash("Level " .. Level() .. "!  Your power grows.", 0.4, 1, 0.5)
            Sound("UI_LEVEL_UP")
        end
    else
        G.combo = -1
    end
    -- Versus: send garbage for the lines cleared, and let incoming garbage rise.
    if ns.OnLock then
        ns.OnLock(cleared, backToBackTetris, G.combo)
        if G.state ~= "play" then return end
    end
    G.holdUsed = false
    Spawn(TakeNext())
    dirty = true
end

-- Pushes the board up by count grey rows with a gap at column hole. Returns false when blocks go off the top.
ns.AddGarbage = function(count, hole)
    local overflow = false
    for _ = 1, count do
        local top = table.remove(G.board, 1)
        for x = 1, COLS do if top[x] then overflow = true end end
        local row = {}
        for x = 1, COLS do if x ~= hole then row[x] = "G" end end
        G.board[#G.board + 1] = row
    end
    dirty = true
    return not overflow
end

local function HardDrop()
    local rows = 0
    while Fits(G.kind, G.rot, G.px, G.py + 1) do
        G.py = G.py + 1
        rows = rows + 1
    end
    G.score = G.score + 2 * rows
    Lock()
end

local function Hold()
    if G.holdUsed then return end
    local current = G.kind
    if G.hold then
        Spawn(G.hold)
    else
        Spawn(TakeNext())
    end
    G.hold = current
    G.holdUsed = true
    dirty = true
end

GameOver = function()
    G.state = "over"
    if G.versus then
        -- Versus games keep their own record, not your solo best score.
        dirty = true
        if ns.OnGameOver then ns.OnGameOver() end
        return
    end
    db.games = (db.games or 0) + 1
    if G.score > (db.best or 0) then
        db.best = G.score
        G.newBest = true
    end
    if G.lines > (db.bestLines or 0) then db.bestLines = G.lines end
    Sound("IG_QUEST_FAILED")
    dirty = true
end

-- A Park-Miller random number generator, so two players with the same seed get the same pieces.
local function SeededRandom(seed)
    local state = (seed % 2147483646) + 1
    return function(n)
        state = (state * 16807) % 2147483647
        return (state % n) + 1
    end
end
ns.SeededRandom = SeededRandom

-- versus: nil for a solo game, or { seed = number } for a match (it starts with a countdown).
local function NewGame(versus)
    if not versus and ns.LeaveVersus then ns.LeaveVersus() end
    G = {
        state = "play", board = NewBoard(), queue = {}, score = 0, lines = 0, pieces = 0,
        startLevel = 1, combo = -1, backToBack = false, hold = nil, holdUsed = false,
        held = {}, dasDir = 0, dasTimer = 0, flashTime = 0, clock = 0,
    }
    if versus then
        G.versus = true
        G.rand = SeededRandom(versus.seed)
        G.incoming = 0
    end
    local ok, faction = pcall(UnitFactionGroup, "player")
    G.cry = (ok and faction == "Alliance") and "For the Alliance!" or "For the Horde!"
    RefillBag()
    Spawn(TakeNext())
    if versus then G.state = "countdown" end
    dirty = true
end

local function ReadyGame()
    NewGame()
    G.state = "ready"
end

---------------------------------------------------------------------------
-- Input
---------------------------------------------------------------------------

local ACTIONS = {
    LEFT = "left", A = "left", RIGHT = "right", D = "right", DOWN = "down", S = "down",
    UP = "cw", X = "cw", W = "cw", Z = "ccw", Q = "ccw", LCTRL = "ccw", RCTRL = "ccw",
    SPACE = "drop", C = "hold", LSHIFT = "hold", RSHIFT = "hold",
    P = "pause", ESCAPE = "close", R = "restart", N = "restart",
}

local function Press(action)
    local inMatch = ns.InMatch and ns.InMatch()
    if action == "close" then
        -- Esc doesn't quit a versus match by accident; the Leave button does.
        if inMatch then
            Flash("Use Leave match to quit", 1, 0.5, 0.3)
            return
        end
        frame:Hide()
        return
    end
    if G.state == "countdown" then return end
    if action == "restart" then
        if G.state ~= "play" and not inMatch then NewGame() end
        return
    end
    if action == "pause" then
        if G.versus then return end -- no pausing against a rival
        if G.state == "play" then G.state = "paused" elseif G.state == "paused" then G.state = "play" end
        dirty = true
        return
    end
    if G.state == "ready" or G.state == "paused" then
        if action == "drop" then G.state = "play" dirty = true end
        return
    end
    if G.state == "over" then
        if action == "drop" and not inMatch then NewGame() end
        return
    end
    if action == "left" or action == "right" then
        local dir = action == "left" and -1 or 1
        G.dasDir, G.dasTimer = dir, -DAS
        Move(dir)
    elseif action == "cw" then
        Rotate(1)
    elseif action == "ccw" then
        Rotate(-1)
    elseif action == "drop" then
        HardDrop()
    elseif action == "hold" then
        Hold()
    end
end

local function OnKeyDown(self, key)
    local action = ACTIONS[key]
    -- Keys the game does not use (Enter for chat, for example) still reach the rest of the game.
    if not InCombatLockdown() and type(self.SetPropagateKeyboardInput) == "function" then
        pcall(self.SetPropagateKeyboardInput, self, action == nil)
    end
    if not action then return end
    G.held[action] = true
    Press(action)
end

local function OnKeyUp(_, key)
    local action = ACTIONS[key]
    if not action or not G.held then return end
    G.held[action] = nil
    if (action == "left" and G.dasDir == -1) or (action == "right" and G.dasDir == 1) then
        -- Fall back to the other direction if it is still held.
        if G.held.left then G.dasDir = -1 elseif G.held.right then G.dasDir = 1 else G.dasDir = 0 end
        G.dasTimer = -DAS
    end
end

---------------------------------------------------------------------------
-- Drawing
---------------------------------------------------------------------------

local function Paint(tex, kind, alpha)
    local c = PIECES[kind].color
    tex:SetVertexColor(c[1], c[2], c[3], alpha or 1)
    tex:Show()
end

-- Draws a piece in a small box (hold and next).
local function DrawMini(textures, kind, box)
    if not kind then
        for _, t in ipairs(textures) do t:Hide() end
        return
    end
    local cells = Cells(kind, 0)
    local minX, maxX, minY, maxY = 9, -9, 9, -9
    for _, c in ipairs(cells) do
        minX, maxX = math.min(minX, c[1]), math.max(maxX, c[1])
        minY, maxY = math.min(minY, c[2]), math.max(maxY, c[2])
    end
    local w, h = (maxX - minX + 1) * MINI, (maxY - minY + 1) * MINI
    local ox, oy = (box:GetWidth() - w) / 2, (box:GetHeight() - h) / 2
    for i, c in ipairs(cells) do
        local t = textures[i]
        t:ClearAllPoints()
        t:SetPoint("TOPLEFT", box, "TOPLEFT", ox + (c[1] - minX) * MINI, -(oy + (c[2] - minY) * MINI))
        Paint(t, kind)
    end
end

local function Draw()
    dirty = false
    local f = frame
    -- Settled blocks
    for y = HIDDEN + 1, ROWS do
        local row = G.board[y]
        for x = 1, COLS do
            local t = f.cells[(y - HIDDEN - 1) * COLS + x]
            if row[x] then Paint(t, row[x]) else t:Hide() end
        end
    end
    -- Ghost and the falling piece
    local playing = G.state == "play" or G.state == "paused"
    local ghostY = G.py
    if playing then
        while Fits(G.kind, G.rot, G.px, ghostY + 1) do ghostY = ghostY + 1 end
    end
    for i, c in ipairs(Cells(G.kind, G.rot)) do
        local piece, ghost = f.piece[i], f.ghost[i]
        local x = G.px + c[1]
        local y, gy = G.py + c[2], ghostY + c[2]
        if playing and y > HIDDEN then
            piece:ClearAllPoints()
            piece:SetPoint("TOPLEFT", f.board, "TOPLEFT", (x - 1) * CELL, -(y - HIDDEN - 1) * CELL)
            Paint(piece, G.kind)
        else
            piece:Hide()
        end
        if playing and db.ghost and gy > HIDDEN and ghostY ~= G.py then
            ghost:ClearAllPoints()
            ghost:SetPoint("TOPLEFT", f.board, "TOPLEFT", (x - 1) * CELL, -(gy - HIDDEN - 1) * CELL)
            Paint(ghost, G.kind, 0.22)
        else
            ghost:Hide()
        end
    end
    -- Side panels
    DrawMini(f.holdCells, G.hold, f.holdBox)
    for i = 1, #f.holdCells do
        if G.holdUsed then f.holdCells[i]:SetAlpha(0.35) else f.holdCells[i]:SetAlpha(1) end
    end
    for n = 1, QUEUE do DrawMini(f.nextCells[n], G.queue[n], f.nextBoxes[n]) end
    -- Incoming garbage: a red bar beside the board, one block per row on its way.
    local incoming = G.versus and (G.incoming or 0) or 0
    f.garbage:SetHeight(math.max(1, math.min(ROWS - HIDDEN, incoming) * CELL))
    f.garbage:SetShown(incoming > 0)
    f.score:SetText(string.format("|cffffd100Score|r\n%d", G.score))
    f.level:SetText(string.format("|cffffd100Level|r\n%d", Level()))
    f.lines:SetText(string.format("|cffffd100Lines|r\n%d", G.lines))
    f.best:SetText(string.format("|cffffd100Best|r\n%d", math.max(db.best or 0, G.score)))
    f.games:SetText(string.format("|cffffd100Games|r\n%d", db.games or 0))
    -- Button labels follow the game and the settings.
    local pauseText = ({ play = "Pause", paused = "Resume", ready = "Start", over = "Play again" })[G.state] or "Start"
    if ns.InMatch and ns.InMatch() then pauseText = "Leave match" end
    f.pauseButton.label:SetText(pauseText)
    f.ghostButton.label:SetText("Preview: " .. (db.ghost and "on" or "off"))
    f.soundButton.label:SetText("Sound: " .. (db.sound and "on" or "off"))
    f.minimapButton.label:SetText("Minimap: " .. (db.minimap and "on" or "off"))
    -- Overlay
    local versusText = G.versus and ns.VersusOverlay and ns.VersusOverlay()
    if versusText then
        f.overlay:SetText(versusText)
    elseif G.state == "ready" then
        f.overlay:SetText("Warcraft Tetris\n\n|cffffffffPress Space to start|r")
    elseif G.state == "paused" then
        f.overlay:SetText("Paused\n\n|cffffffffPress P or Space to continue|r")
    elseif G.state == "over" then
        f.overlay:SetText("Game over\n\n|cffffffff" .. G.score .. " points, " .. G.lines .. " lines" ..
            (G.newBest and "\n|cff40ff40New best score!|r" or "") .. "\n\nPress Space to play again|r")
    else
        f.overlay:SetText("")
    end
    f.dim:SetShown(G.state ~= "play")
end

local function OnUpdate(_, elapsed)
    elapsed = math.min(elapsed, 0.1)
    if ns.VersusTick then ns.VersusTick(elapsed) end
    if G.state == "play" then G.clock = (G.clock or 0) + elapsed end
    if G.flashTime and G.flashTime > 0 then
        G.flashTime = G.flashTime - elapsed
        local c = G.flashColor or { 1, 1, 1 }
        frame.flash:SetText(G.flashText or "")
        frame.flash:SetTextColor(c[1], c[2], c[3], math.min(1, G.flashTime / 0.4))
        if G.flashTime <= 0 then frame.flash:SetText("") end
    end
    if G.state ~= "play" then
        if dirty then Draw() end
        return
    end

    -- Held left or right repeats after a short delay.
    if G.dasDir ~= 0 then
        G.dasTimer = G.dasTimer + elapsed
        while G.dasTimer >= ARR do
            G.dasTimer = G.dasTimer - ARR
            if not Move(G.dasDir) then G.dasTimer = 0 break end
        end
    end

    local soft = G.held.down
    local interval = GravityInterval()
    if soft then interval = math.min(interval, SOFT_DROP) end
    G.gravityTimer = G.gravityTimer + elapsed
    while G.gravityTimer >= interval do
        G.gravityTimer = G.gravityTimer - interval
        if StepDown() then
            if soft then G.score = G.score + 1 end
        else
            G.gravityTimer = 0
            break
        end
    end
    if G.state == "play" and Grounded() then
        G.lockTimer = G.lockTimer + elapsed
        if G.lockTimer >= LOCK_DELAY then Lock() end
    end
    if dirty then Draw() end
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------

local function Box(parent, width, height)
    local b = CreateFrame("Frame", nil, parent)
    b:SetSize(width, height)
    local edge = b:CreateTexture(nil, "BACKGROUND", nil, -6)
    edge:SetPoint("TOPLEFT", -2, 2)
    edge:SetPoint("BOTTOMRIGHT", 2, -2)
    edge:SetColorTexture(0.62, 0.48, 0.2, 1)
    local inner = b:CreateTexture(nil, "BACKGROUND", nil, -5)
    inner:SetAllPoints()
    inner:SetColorTexture(0.03, 0.03, 0.05, 1)
    return b
end

local function Block(parent, size, layer)
    local t = parent:CreateTexture(nil, layer or "ARTWORK")
    t:SetSize(size, size)
    t:SetTexture(TEXTURES .. "Block.tga")
    t:Hide()
    return t
end

local function Button(parent, width, text, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 20)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.16, 0.12, 0.06, 0.95)
    local label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    label:SetPoint("CENTER")
    label:SetText(text)
    b.label = label
    b:SetScript("OnEnter", function(self)
        bg:SetColorTexture(0.36, 0.27, 0.1, 0.95)
        if self.tip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(self.tip, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function()
        bg:SetColorTexture(0.16, 0.12, 0.06, 0.95)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", onClick)
    return b
end

local function CreateWindow()
    local boardW, boardH = COLS * CELL, (ROWS - HIDDEN) * CELL
    local f = CreateFrame("Frame", "WarcraftTetrisFrame", UIParent)
    f:SetSize(boardW + 270, boardH + 96)
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
            db.pos = { point, relPoint, x, y }
        end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
        f:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
    end

    local border = f:CreateTexture(nil, "BACKGROUND", nil, -8)
    border:SetAllPoints()
    border:SetColorTexture(0.62, 0.48, 0.2, 1)
    local bg = f:CreateTexture(nil, "BACKGROUND", nil, -7)
    bg:SetPoint("TOPLEFT", 2, -2)
    bg:SetPoint("BOTTOMRIGHT", -2, 2)
    bg:SetColorTexture(0.08, 0.06, 0.05, 0.97)

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -12)
    title:SetText("Warcraft Tetris")
    local close = Button(f, 22, "X", function() f:Hide() end)
    close:SetPoint("TOPRIGHT", -10, -10)
    local newGame = Button(f, 80, "New game", function() NewGame() end)
    newGame:SetPoint("TOPLEFT", 12, -10)

    -- Board
    local board = Box(f, boardW, boardH)
    board:SetPoint("TOPLEFT", 128, -44)
    f.board = board
    for x = 1, COLS - 1 do
        local line = board:CreateTexture(nil, "BACKGROUND", nil, -4)
        line:SetSize(1, boardH)
        line:SetPoint("TOPLEFT", x * CELL, 0)
        line:SetColorTexture(1, 1, 1, 0.05)
    end
    for y = 1, ROWS - HIDDEN - 1 do
        local line = board:CreateTexture(nil, "BACKGROUND", nil, -4)
        line:SetSize(boardW, 1)
        line:SetPoint("TOPLEFT", 0, -y * CELL)
        line:SetColorTexture(1, 1, 1, 0.05)
    end
    f.cells = {}
    for y = 1, ROWS - HIDDEN do
        for x = 1, COLS do
            local t = Block(board, CELL)
            t:SetPoint("TOPLEFT", (x - 1) * CELL, -(y - 1) * CELL)
            f.cells[(y - 1) * COLS + x] = t
        end
    end
    f.ghost, f.piece = {}, {}
    for i = 1, 4 do
        f.ghost[i] = Block(board, CELL, "ARTWORK")
        f.piece[i] = Block(board, CELL, "OVERLAY")
    end
    f.dim = board:CreateTexture(nil, "OVERLAY", nil, 6)
    f.dim:SetAllPoints()
    f.dim:SetColorTexture(0, 0, 0, 0.62)
    f.overlay = board:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.overlay:SetPoint("CENTER", 0, 20)
    f.overlay:SetWidth(boardW - 16)
    f.overlay:SetDrawLayer("OVERLAY", 7)
    f.flash = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    f.flash:SetPoint("BOTTOM", board, "TOP", 0, 6)

    -- Hold
    local holdLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    holdLabel:SetPoint("TOPLEFT", 18, -44)
    holdLabel:SetText("Hold")
    f.holdBox = Box(f, 96, 64)
    f.holdBox:SetPoint("TOPLEFT", 16, -62)
    f.holdCells = {}
    for i = 1, 4 do f.holdCells[i] = Block(f.holdBox, MINI) end

    -- Next
    local right = 128 + boardW + 18
    local nextLabel = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    nextLabel:SetPoint("TOPLEFT", right + 2, -44)
    nextLabel:SetText("Next")
    f.nextBoxes, f.nextCells = {}, {}
    for n = 1, QUEUE do
        local b = Box(f, 96, 54)
        b:SetPoint("TOPLEFT", right, -62 - (n - 1) * 62)
        f.nextBoxes[n] = b
        f.nextCells[n] = {}
        for i = 1, 4 do f.nextCells[n][i] = Block(b, MINI) end
    end

    -- Stats
    local function Stat(x, y)
        local s = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        s:SetPoint("TOPLEFT", x, y)
        s:SetJustifyH("LEFT")
        return s
    end
    f.score = Stat(right + 2, -62 - QUEUE * 62 - 6)
    f.level = Stat(right + 2, -62 - QUEUE * 62 - 46)
    f.lines = Stat(right + 2, -62 - QUEUE * 62 - 86)
    f.best = Stat(right + 2, -62 - QUEUE * 62 - 126)

    local keys = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    keys:SetPoint("TOPLEFT", 16, -142)
    keys:SetWidth(100)
    keys:SetJustifyH("LEFT")
    keys:SetSpacing(3)
    keys:SetText("|cffffd100Keys|r\nLeft, Right: move\nDown: soft drop\nUp or X: turn\nZ: turn back\nSpace: drop\nC or Shift: hold\nP: pause\nEsc: close")

    f.games = Stat(right + 2, -62 - QUEUE * 62 - 166)

    -- Clickable controls, so nothing needs a chat command.
    local function Side(y, onClick, tip)
        local b = Button(f, 100, onClick and "" or "", onClick)
        b:SetPoint("TOPLEFT", 14, y)
        b.tip = tip
        return b
    end
    f.pauseButton = Side(-306, function()
        if ns.InMatch and ns.InMatch() then ns.LeaveVersus() dirty = true return end
        if G.state == "play" or G.state == "paused" then Press("pause") else Press("drop") end
    end, "Start, pause or carry on. Same as P or Space. In a versus match, this leaves the match.")
    f.ghostButton = Side(-332, function()
        db.ghost = not db.ghost
        dirty = true
    end, "Shows where the falling piece will land.")
    f.soundButton = Side(-358, function()
        db.sound = not db.sound
        dirty = true
    end, "Sounds for line clears, level ups and game over.")
    f.minimapButton = Side(-384, function()
        db.minimap = not db.minimap
        if ns.UpdateMinimapButton then ns.UpdateMinimapButton() end
        dirty = true
    end, "A button on the minimap that opens the game. Drag it around the minimap to move it.")
    f.centerButton = Side(-410, function()
        db.pos = nil
        f:ClearAllPoints()
        f:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
    end, "Moves this window back to the middle of the screen. Drag the window by its edges to move it.")
    f.centerButton.label:SetText("Center window")
    f.versusButton = Side(-442, function()
        if ns.ToggleVersusPanel then ns.ToggleVersusPanel() end
    end, "Play against a bot or another player. Clearing lines sends grey garbage rows to your rival.")
    f.versusButton.label:SetText("|cffff8040Versus|r")

    -- Red bar beside the board: garbage on its way to you.
    f.garbage = f:CreateTexture(nil, "ARTWORK")
    f.garbage:SetWidth(6)
    f.garbage:SetPoint("BOTTOMRIGHT", board, "BOTTOMLEFT", -3, 0)
    f.garbage:SetColorTexture(1, 0.2, 0.15, 0.9)
    f.garbage:Hide()

    local foot = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    foot:SetPoint("BOTTOM", 0, 12)
    foot:SetText("The game pauses when you close it or enter combat.")

    f:EnableKeyboard(true)
    f:SetScript("OnKeyDown", OnKeyDown)
    f:SetScript("OnKeyUp", OnKeyUp)
    f:SetScript("OnUpdate", OnUpdate)
    f:SetScript("OnShow", function() dirty = true end)
    f:Hide() -- before the OnHide script, so creating the window can't count as leaving a match
    f:SetScript("OnHide", function()
        -- Closing the window (or entering combat) during a match counts as leaving it.
        if ns.InMatch and ns.InMatch() then ns.LeaveVersus() end
        if G.state == "play" and not G.versus then G.state = "paused" end
        if G.held then G.held = {} G.dasDir = 0 end
    end)
    return f
end

local function Open()
    if not frame then frame = CreateWindow() end
    if not G.state then ReadyGame() end
    frame:Show()
    Draw()
end

-- Opens or closes the game from a click, refusing during combat.
local function ToggleFromClick()
    if not db then return end
    if frame and frame:IsShown() then
        frame:Hide()
    elseif InCombatLockdown() then
        Say("finish your fight first. The game opens out of combat.")
    else
        Open()
    end
end

-- Entry in the minimap's addon menu.
function WarcraftTetris_OnCompartmentClick()
    ToggleFromClick()
end

---------------------------------------------------------------------------
-- Minimap button: click to play, drag to move it around the minimap
---------------------------------------------------------------------------

local minimapButton

local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 200)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "WarcraftTetrisMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    local back = b:CreateTexture(nil, "BACKGROUND")
    back:SetSize(22, 22)
    back:SetPoint("CENTER")
    back:SetColorTexture(0.05, 0.04, 0.06, 0.9)
    -- A small T made of blocks.
    for i, c in ipairs({ { -6, 4, 0.72, 0.42, 1 }, { 0, 4, 0.72, 0.42, 1 }, { 6, 4, 0.72, 0.42, 1 }, { 0, -2, 0.72, 0.42, 1 } }) do
        local t = b:CreateTexture(nil, "ARTWORK")
        t:SetSize(6, 6)
        t:SetPoint("CENTER", c[1], c[2])
        t:SetTexture(TEXTURES .. "Block.tga")
        t:SetVertexColor(c[3], c[4], c[5], 1)
    end
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", ToggleFromClick)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Warcraft Tetris", 1, 0.82, 0)
        GameTooltip:AddLine("Click to play or close.", 1, 1, 1)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

ns.UpdateMinimapButton = function()
    if not db or not Minimap then return end
    if db.minimap then
        if not minimapButton then CreateMinimapButton() end
        minimapButton:Show()
    elseif minimapButton then
        minimapButton:Hide()
    end
end

---------------------------------------------------------------------------
-- Slash commands and events
---------------------------------------------------------------------------

local function Help()
    Say("/tetris opens or closes the game. /tetris new starts a new game.")
    Say("/tetris ghost shows or hides the drop preview. /tetris sound turns sounds on or off.")
    Say("/tetris best shows your records. /tetris reset moves the window back to the middle.")
    Say("/tetris minimap shows or hides the minimap button. Every setting is also a button in the game window.")
    Say("/tetris vs opens versus mode. /tetris vs easy, normal or hard plays a bot. /tetris vs Name challenges a player.")
end

SLASH_WARCRAFTTETRIS1 = "/tetris"
SLASH_WARCRAFTTETRIS2 = "/wtetris"
SlashCmdList.WARCRAFTTETRIS = function(message)
    if not db then
        Say("still loading.")
        return
    end
    local command = string.lower(message or ""):match("^%s*(%S*)")
    if command == "help" then
        Help()
        return
    elseif command == "ghost" then
        db.ghost = not db.ghost
        dirty = true
        Say("drop preview " .. (db.ghost and "on." or "off."))
        return
    elseif command == "sound" then
        db.sound = not db.sound
        dirty = true
        Say("sounds " .. (db.sound and "on." or "off."))
        return
    elseif command == "minimap" then
        db.minimap = not db.minimap
        ns.UpdateMinimapButton()
        dirty = true
        Say("minimap button " .. (db.minimap and "on." or "off."))
        return
    elseif command == "best" then
        Say(string.format("best score %d, most lines %d, games played %d.", db.best or 0, db.bestLines or 0, db.games or 0))
        return
    elseif command == "reset" then
        db.pos = nil
        if frame then
            frame:ClearAllPoints()
            frame:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
        end
        Say("window position reset.")
        return
    end
    if InCombatLockdown() then
        Say("finish your fight first. The game opens out of combat.")
        return
    end
    if command == "new" then
        Open()
        NewGame()
        return
    end
    if command == "vs" or command == "versus" then
        ns.VersusCommand((message or ""):match("^%s*%S+%s*(.-)%s*$"))
        return
    end
    if frame and frame:IsShown() then
        frame:Hide()
    else
        Open()
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_DISABLED")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        WarcraftTetrisDB = type(WarcraftTetrisDB) == "table" and WarcraftTetrisDB or {}
        db = WarcraftTetrisDB
        if type(db.sound) ~= "boolean" then db.sound = true end
        if type(db.ghost) ~= "boolean" then db.ghost = true end
        if type(db.best) ~= "number" then db.best = 0 end
        if type(db.minimap) ~= "boolean" then db.minimap = true end
        ns.UpdateMinimapButton()
        return
    end
    -- Entering combat: pause and close, so the keyboard goes straight back to you.
    if frame and frame:IsShown() then
        frame:Hide()
        Say("paused for combat. Type /tetris to carry on.")
    end
end)

-- Shared with Versus.lua.
ns.PIECES, ns.KINDS, ns.Cells = PIECES, KINDS, Cells
ns.COLS, ns.ROWS, ns.HIDDEN = COLS, ROWS, HIDDEN
ns.NewGame, ns.GameOver, ns.Flash, ns.Sound, ns.Say = NewGame, function() GameOver() end, Flash, Sound, Say
ns.Block, ns.Box, ns.Button = Block, Box, Button
ns.Frame = function() return frame end
ns.DB = function() return db end
ns.SetDirty = function() dirty = true end
ns.Open = Open
ns.Level = Level

-- For the automated tests.
ns.Game = function() return G end
ns.Press = Press
ns.Tick = function(dt) OnUpdate(frame, dt) end
