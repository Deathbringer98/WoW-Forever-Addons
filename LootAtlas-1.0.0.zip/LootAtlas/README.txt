Loot Atlas 1.0.0 - World of Warcraft: Forever (Interface 16001)
================================================================

What every dungeon boss, raid boss, world boss and rare drops, filtered for
your class.

INSTALL
Copy the LootAtlas folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

OPEN IT
Click the bag on the minimap, pick it from the minimap addon menu, or type /la.

WHAT'S IN IT
- Every dungeon from Ragefire Chasm to Stratholme, in level order, with
  every boss and what it drops. Dungeon rares are marked.
- Every raid: Molten Core, Onyxia, Blackwing Lair, Zul'Gurub, both Ahn'Qiraj
  raids and Naxxramas.
- World bosses: Azuregos, Lord Kazzak and the Emerald Dragons.
- World epics: the rare drops any mob can drop.
- Rare mobs out in the world: over 350 of them with level, zone and a Map
  button for a waypoint. "Near my level" shows only the ones you can fight.
  Their loot isn't in the loot tables, so the list shows where to find them.

CLASS FILTER
The class button starts on your own class. Click it for the next class,
right-click to go back to yours.
  Best for class    armor of your class's best type (plate for warriors and
                    paladins, mail for hunters and shamans, leather for rogues
                    and druids, cloth for the rest), weapons you can use, and
                    stats your class wants
  Usable by class   everything your class can equip
  Everything        no filter
Class set pieces for other classes are hidden too. Item stats load from the
game as you browse, so a list can change a moment after you open it.

SEARCH
Type at least 3 letters in the search box to find an item anywhere, with
the boss and dungeon that drops it. /la <name> also works, and /la <dungeon>
jumps straight to a dungeon.

Hover an item for its tooltip. Shift-click to link it in chat, Ctrl-click
to try it on.

COMMANDS
/la            open or close
/la rares      rare mobs
/la <text>     open a dungeon by name, or search items
/la minimap    minimap button on or off

CREDITS AND LICENSE
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)

The loot tables come from AtlasLootClassic by Hoizame and contributors
(github.com/Hoizame/AtlasLootClassic), which is licensed under the GNU GPL
v2. Because of that, Loot Atlas is released under the GNU GPL v2 (see
LICENSE-GPL2.txt), unlike the rest of the collection, which is GPL v3.
Rare mob locations come from QuestieDB (GPL v3). Item and zone details come
from the WoW Forever game files.
