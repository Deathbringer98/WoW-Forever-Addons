-- Loot Atlas for World of Warcraft: Forever (Interface 16001)
-- What every dungeon boss, raid boss, world boss and rare drops, filtered for your class.
-- Loot tables come from AtlasLootClassic (GPL-2.0); rare mob locations from QuestieDB.
local ADDON, ns = ...

local PREFIX = "|cffa335eeLoot Atlas:|r "
local LEFT_ROWS, ITEM_ROWS = 18, 11

local db
local frame
local view = { inst = 1, boss = 1, leftOffset = 0, midOffset = 0, itemOffset = 0, search = "" }

local function I(name) return "Interface\\Icons\\" .. name end
local function Say(text) print(PREFIX .. text) end
local function IsSecret(v) return issecretvalue ~= nil and issecretvalue(v) end

---------------------------------------------------------------------------
-- Classes: what each can use, and which stats it wants
---------------------------------------------------------------------------

-- Armor subclasses: 0 misc, 1 cloth, 2 leather, 3 mail, 4 plate, 6 shield, 7 libram, 8 idol, 9 totem.
-- Weapon subclasses: 0 1h axe, 1 2h axe, 2 bow, 3 gun, 4 1h mace, 5 2h mace, 6 polearm, 7 1h sword,
-- 8 2h sword, 10 staff, 13 fist, 15 dagger, 16 thrown, 18 crossbow, 19 wand.
local function Set(list) local s = {} for _, v in ipairs(list) do s[v] = true end return s end
local CLASSES = {
    { file = "WARRIOR", name = "Warrior", armor = Set({ 0, 1, 2, 3, 4, 6 }), best = 4, weapons = Set({ 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 13, 15, 16, 18 }), stats = Set({ "STR", "AGI" }) },
    { file = "PALADIN", name = "Paladin", armor = Set({ 0, 1, 2, 3, 4, 6, 7 }), best = 4, weapons = Set({ 0, 1, 4, 5, 6, 7, 8 }), stats = Set({ "STR", "INT" }) },
    { file = "HUNTER", name = "Hunter", armor = Set({ 0, 1, 2, 3 }), best = 3, weapons = Set({ 0, 1, 2, 3, 6, 7, 8, 10, 13, 15, 16, 18 }), stats = Set({ "AGI", "INT" }) },
    { file = "ROGUE", name = "Rogue", armor = Set({ 0, 1, 2 }), best = 2, weapons = Set({ 2, 3, 4, 7, 13, 15, 16, 18 }), stats = Set({ "AGI", "STR" }) },
    { file = "PRIEST", name = "Priest", armor = Set({ 0, 1 }), best = 1, weapons = Set({ 4, 10, 15, 19 }), stats = Set({ "INT", "SPI" }) },
    { file = "SHAMAN", name = "Shaman", armor = Set({ 0, 1, 2, 3, 6, 9 }), best = 3, weapons = Set({ 0, 1, 4, 5, 10, 13, 15 }), stats = Set({ "INT", "STR", "AGI" }) },
    { file = "MAGE", name = "Mage", armor = Set({ 0, 1 }), best = 1, weapons = Set({ 7, 10, 15, 19 }), stats = Set({ "INT", "SPI" }) },
    { file = "WARLOCK", name = "Warlock", armor = Set({ 0, 1 }), best = 1, weapons = Set({ 7, 10, 15, 19 }), stats = Set({ "INT", "SPI" }) },
    { file = "DRUID", name = "Druid", armor = Set({ 0, 1, 2, 8 }), best = 2, weapons = Set({ 4, 5, 10, 13, 15 }), stats = Set({ "INT", "AGI", "STR", "SPI" }) },
}
local CLASS_BY_FILE = {}
for _, c in ipairs(CLASSES) do CLASS_BY_FILE[c.file] = c end

local STAT_KEYS = { ITEM_MOD_STRENGTH_SHORT = "STR", ITEM_MOD_AGILITY_SHORT = "AGI", ITEM_MOD_INTELLECT_SHORT = "INT", ITEM_MOD_SPIRIT_SHORT = "SPI" }
local SLOT_NAMES = {
    [1] = "Head", [2] = "Neck", [3] = "Shoulder", [4] = "Shirt", [5] = "Chest", [6] = "Waist", [7] = "Legs", [8] = "Feet",
    [9] = "Wrist", [10] = "Hands", [11] = "Finger", [12] = "Trinket", [13] = "One-Hand", [14] = "Shield", [15] = "Ranged",
    [16] = "Back", [17] = "Two-Hand", [19] = "Tabard", [20] = "Chest", [21] = "Main Hand", [22] = "Off Hand",
    [23] = "Held In Off-hand", [25] = "Thrown", [26] = "Ranged", [28] = "Relic",
}
local ARMOR_NAMES = { [1] = "Cloth", [2] = "Leather", [3] = "Mail", [4] = "Plate", [6] = "Shield", [7] = "Libram", [8] = "Idol", [9] = "Totem" }
local WEAPON_NAMES = { [0] = "Axe", [1] = "Axe", [2] = "Bow", [3] = "Gun", [4] = "Mace", [5] = "Mace", [6] = "Polearm", [7] = "Sword",
    [8] = "Sword", [10] = "Staff", [13] = "Fist Weapon", [15] = "Dagger", [16] = "Thrown", [18] = "Crossbow", [19] = "Wand", [20] = "Fishing Pole" }
-- Slots where armor type matters (cloaks are cloth for everyone, so they don't).
local TYPED_SLOTS = Set({ 1, 3, 5, 6, 7, 8, 9, 10, 20 })

local function MyClass()
    local ok, _, file = pcall(UnitClass, "player")
    if ok and type(file) == "string" and not IsSecret(file) then return file end
    return "WARRIOR"
end

-- Live item details the game sends when it has the item: stats and class restrictions.
local live = {}
local pending = {}

local function LoadItem(id)
    if live[id] then return live[id] end
    local link
    if C_Item and C_Item.GetItemInfo then
        local ok, _, l = pcall(C_Item.GetItemInfo, id)
        if ok then link = l end
    elseif type(GetItemInfo) == "function" then
        local ok, _, l = pcall(GetItemInfo, id)
        if ok then link = l end
    end
    if not link then
        if not pending[id] then
            pending[id] = true
            if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
        end
        return nil
    end
    local info = { link = link, stats = {}, classes = nil }
    local getStats = (C_Item and C_Item.GetItemStats) or GetItemStats
    if getStats then
        local ok, stats = pcall(getStats, link)
        if ok and type(stats) == "table" then
            for k in pairs(stats) do if STAT_KEYS[k] then info.stats[STAT_KEYS[k]] = true end end
        end
    end
    -- "Classes: Mage, Priest" on class sets.
    if C_TooltipInfo and C_TooltipInfo.GetItemByID then
        local ok, data = pcall(C_TooltipInfo.GetItemByID, id)
        if ok and type(data) == "table" and type(data.lines) == "table" then
            for _, line in ipairs(data.lines) do
                local text = line.leftText
                if type(text) == "string" and not IsSecret(text) then
                    local list = text:match("^Classes: (.+)$")
                    if list then info.classes = list end
                end
            end
        end
    end
    live[id] = info
    return info
end

-- Returns "ok", "maybe" (not loaded yet) or nil (not for this class).
local function FitsClass(id, classFile, mode)
    if mode == "all" then return "ok" end
    local item = ns.ITEMS[id]
    if not item then return "ok" end
    local cls = CLASS_BY_FILE[classFile]
    local itemClass, sub, inv = item[2], item[3], item[4]
    if itemClass == 4 then
        if not cls.armor[sub] then return nil end
        if mode == "best" and TYPED_SLOTS[inv] and sub >= 1 and sub <= 4 and sub ~= cls.best then
            -- Warriors and paladins still wear mail before plate; hunters and shamans leather before mail.
            return nil
        end
    elseif itemClass == 2 then
        if not cls.weapons[sub] then return nil end
    end
    local info = LoadItem(id)
    if not info then return "maybe" end
    if info.classes then
        local name = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[classFile]) or cls.name
        if not info.classes:find(name, 1, true) then return nil end
    end
    if mode == "best" then
        local any, wanted = false, false
        for stat in pairs(info.stats) do
            any = true
            if cls.stats[stat] then wanted = true end
        end
        if any and not wanted then return nil end
    end
    return "ok"
end

local function TypeText(id)
    local item = ns.ITEMS[id]
    if not item then return "" end
    local slot = SLOT_NAMES[item[4]] or ""
    local kind = ""
    if item[2] == 4 then kind = ARMOR_NAMES[item[3]] or "" elseif item[2] == 2 then kind = WEAPON_NAMES[item[3]] or "" end
    if item[2] == 4 and item[3] == 1 and item[4] == 16 then kind = "" end
    if kind ~= "" and slot ~= "" then return slot .. ", " .. kind end
    if slot ~= "" then return slot end
    if item[2] == 9 then return "Recipe" elseif item[2] == 12 then return "Quest item" elseif item[2] == 15 then return "Misc" end
    return kind
end

local function QualityColor(id)
    local q
    if C_Item and C_Item.GetItemQualityByID then
        local ok, v = pcall(C_Item.GetItemQualityByID, id)
        if ok then q = v end
    end
    if q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q] and ITEM_QUALITY_COLORS[q].hex then return ITEM_QUALITY_COLORS[q].hex end
    return "|cffffffff"
end

local function ItemIcon(id)
    if C_Item and C_Item.GetItemIconByID then
        local ok, icon = pcall(C_Item.GetItemIconByID, id)
        if ok and icon then return icon end
    end
    return I("INV_Misc_QuestionMark")
end

---------------------------------------------------------------------------
-- What the three columns show
---------------------------------------------------------------------------

-- Left column: instances, then World rares and World epics.
local LEFT = {}
local function BuildLeft()
    wipe(LEFT)
    local lastKind
    local HEAD = { dungeon = "Dungeons", raid20 = "Raids (20)", raid40 = "Raids (40)", world = "World" }
    for i, inst in ipairs(ns.INSTANCES) do
        if inst.kind ~= lastKind then
            LEFT[#LEFT + 1] = { head = HEAD[inst.kind] or inst.kind }
            lastKind = inst.kind
        end
        local levels = inst.kind == "dungeon" and string.format("  |cff808080%d-%d|r", inst.min, inst.max) or ""
        LEFT[#LEFT + 1] = { text = inst.name .. levels, inst = i }
    end
    LEFT[#LEFT + 1] = { text = "Rare mobs (world)", special = "rares" }
    LEFT[#LEFT + 1] = { text = "World epics (any mob)", special = "epics" }
end

local function MyFaction()
    local ok, f = pcall(UnitFactionGroup, "player")
    return ok and f or "Alliance"
end

-- Items for one boss (or world epic group), with your faction's extra drops.
local function BossItems(boss)
    local list = {}
    for _, id in ipairs(boss.items or {}) do list[#list + 1] = id end
    local extra = MyFaction() == "Horde" and boss.horde or boss.alliance
    for _, id in ipairs(extra or {}) do list[#list + 1] = id end
    return list
end

local function MidEntries()
    local entries = {}
    if view.special == "epics" then
        for i, g in ipairs(ns.WORLD_EPICS) do entries[#entries + 1] = { text = g.name, boss = i } end
    elseif view.special == "rares" then
        return entries
    else
        local inst = ns.INSTANCES[view.inst]
        for i, b in ipairs(inst and inst.bosses or {}) do
            local tag = b.special == "rare" and "  |cffff8040rare|r" or ""
            local lvl = (b.level and b.level > 0 and b.level < 100) and string.format("  |cff808080%d|r", b.level) or ""
            entries[#entries + 1] = { text = b.name .. lvl .. tag, boss = i }
        end
    end
    return entries
end

local function SelectedItems()
    if view.special == "epics" then
        local g = ns.WORLD_EPICS[view.boss]
        return g and g.items or {}, g and "World epics: " .. g.name or ""
    end
    local inst = ns.INSTANCES[view.inst]
    local boss = inst and inst.bosses[view.boss]
    if not boss then return {}, "" end
    return BossItems(boss), boss.name .. " (" .. inst.name .. ")"
end

-- Search across every boss and world epics.
local function SearchItems(text)
    local results, seen = {}, {}
    text = text:lower()
    local function Add(id, source)
        local item = ns.ITEMS[id]
        if item and not seen[id] and item[1]:lower():find(text, 1, true) then
            seen[id] = true
            results[#results + 1] = { id = id, source = source }
        end
    end
    for _, inst in ipairs(ns.INSTANCES) do
        for _, b in ipairs(inst.bosses) do
            for _, id in ipairs(BossItems(b)) do Add(id, b.name .. ", " .. inst.name) end
        end
    end
    for _, g in ipairs(ns.WORLD_EPICS) do for _, id in ipairs(g.items) do Add(id, "World epic") end end
    return results
end

local function ItemEntries()
    local list, title
    if view.search ~= "" then
        local found = SearchItems(view.search)
        list = {}
        for _, r in ipairs(found) do list[#list + 1] = r end
        title = string.format("Search: \"%s\"", view.search)
    else
        local ids
        ids, title = SelectedItems()
        list = {}
        for _, id in ipairs(ids) do list[#list + 1] = { id = id } end
    end
    local shown, hidden, waiting = {}, 0, 0
    for _, e in ipairs(list) do
        local fit = FitsClass(e.id, db.class, db.mode)
        if fit then
            shown[#shown + 1] = e
            if fit == "maybe" then waiting = waiting + 1 end
        else
            hidden = hidden + 1
        end
    end
    return shown, title, hidden, waiting
end

local function RareEntries()
    local entries = {}
    local level = UnitLevel and UnitLevel("player") or 60
    if IsSecret(level) or type(level) ~= "number" then level = 60 end
    for _, r in ipairs(ns.RARES) do
        if not db.raresNear or (r[3] <= level + 4 and r[4] >= level - 6) then entries[#entries + 1] = r end
    end
    return entries
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------

local Refresh
local MODES = { { key = "best", label = "Best for class" }, { key = "usable", label = "Usable by class" }, { key = "all", label = "Everything" } }

local function Text(parent, font, x, y, width)
    local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    t:SetPoint("TOPLEFT", x, y)
    if width then t:SetWidth(width) t:SetJustifyH("LEFT") t:SetWordWrap(false) end
    return t
end

local function Button(parent, width, label, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, 20)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
end

local function Waypoint(r)
    local placed = false
    if not InCombatLockdown() and C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates then
        placed = pcall(function()
            C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(r[6], r[7] / 100, r[8] / 100))
            if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
        end)
    end
    Say(string.format("%s (level %d%s) in %s at %.1f, %.1f.%s", r[2], r[3], r[9] and ", rare elite" or "", r[5], r[7], r[8],
        placed and " Waypoint set on your map." or ""))
end

-- A simple list of text rows with mouse-wheel scrolling.
local function TextList(parent, x, y, width, rows, rowH, offsetKey, onClick)
    local list = CreateFrame("Frame", nil, parent)
    list:SetSize(width, rows * rowH)
    list:SetPoint("TOPLEFT", x, y)
    list:EnableMouseWheel(true)
    list:SetScript("OnMouseWheel", function(self, delta)
        view[offsetKey] = math.max(0, math.min((self.total or 0) - rows, view[offsetKey] - delta * 3))
        Refresh()
    end)
    list.rows = {}
    for i = 1, rows do
        local r = CreateFrame("Button", nil, list)
        r:SetSize(width, rowH)
        r:SetPoint("TOPLEFT", 0, -(i - 1) * rowH)
        r.sel = r:CreateTexture(nil, "BACKGROUND")
        r.sel:SetAllPoints()
        r.sel:SetColorTexture(1, 0.82, 0, 0.18)
        r:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
        r.text = Text(r, "GameFontHighlightSmall", 4, -((rowH - 12) / 2), width - 8)
        r:SetScript("OnClick", function(self) if self.entry then onClick(self.entry) end end)
        list.rows[i] = r
    end
    return list
end

local function FillTextList(list, entries, offsetKey, isSelected)
    list.total = #entries
    view[offsetKey] = math.max(0, math.min(view[offsetKey], #entries - #list.rows))
    for i, r in ipairs(list.rows) do
        local e = entries[view[offsetKey] + i]
        r.entry = e
        if e then
            r:Show()
            r.text:SetText(e.head and ("|cffffd100" .. e.head .. "|r") or e.text)
            r.sel:SetShown(isSelected(e))
            r:EnableMouse(not e.head)
        else
            r:Hide()
        end
    end
end

local function MakeItemRow(parent, i)
    local r = CreateFrame("Button", nil, parent)
    r:SetSize(330, 36)
    r:SetPoint("TOPLEFT", 0, -(i - 1) * 36)
    r:RegisterForClicks("AnyUp")
    r:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    r.icon = r:CreateTexture(nil, "ARTWORK")
    r.icon:SetSize(30, 30)
    r.icon:SetPoint("LEFT", 2, 0)
    r.name = Text(r, "GameFontHighlight", 38, -3, 288)
    r.sub = Text(r, "GameFontHighlightSmall", 38, -20, 288)
    r.sub:SetTextColor(0.7, 0.7, 0.7)
    r.map = Button(r, 48, "Map", function(self) if self.rare then Waypoint(self.rare) end end)
    r.map:SetPoint("RIGHT", -2, 0)
    r:SetScript("OnEnter", function(self)
        if not self.id then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        local ok = pcall(GameTooltip.SetItemByID, GameTooltip, self.id)
        if not ok then GameTooltip:SetText(self.name:GetText() or "") end
        GameTooltip:AddLine("Shift-click to link, Ctrl-click to try it on.", 0.6, 0.6, 0.6)
        GameTooltip:Show()
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r:SetScript("OnClick", function(self)
        if not self.id then return end
        local info = LoadItem(self.id)
        local link = info and info.link
        if not link then return end
        if IsModifiedClick and IsModifiedClick("DRESSUP") and DressUpItemLink then DressUpItemLink(link)
        elseif IsModifiedClick and IsModifiedClick("CHATLINK") and ChatEdit_InsertLink then ChatEdit_InsertLink(link) end
    end)
    return r
end

local function CreateWindow()
    local f = CreateFrame("Frame", "LootAtlasFrame", UIParent, "BackdropTemplate")
    f:SetSize(760, 540)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, rel, x, y = self:GetPoint(1)
        if type(point) == "string" and type(x) == "number" then db.pos = { point, rel, x, y } end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[3]) == "number" then
        f:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        f:SetPoint("CENTER")
    end
    f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border", tile = true, tileSize = 32, edgeSize = 24,
        insets = { left = 6, right = 6, top = 6, bottom = 6 } })
    tinsert(UISpecialFrames, "LootAtlasFrame")
    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -14)
    title:SetText("Loot Atlas")
    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    -- Filter bar: class, mode, search.
    f.classButton = Button(f, 130, "", function()
        local i = 1
        for n, c in ipairs(CLASSES) do if c.file == db.class then i = n end end
        db.class = CLASSES[i % #CLASSES + 1].file
        view.itemOffset = 0
        Refresh()
    end)
    f.classButton:SetPoint("TOPLEFT", 16, -40)
    f.classButton:SetScript("OnMouseUp", nil)
    f.classButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    f.classButton:SetScript("OnClick", function(_, mouse)
        if mouse == "RightButton" then
            db.class = MyClass()
        else
            local i = 1
            for n, c in ipairs(CLASSES) do if c.file == db.class then i = n end end
            db.class = CLASSES[i % #CLASSES + 1].file
        end
        view.itemOffset = 0
        Refresh()
    end)
    f.modeButtons = {}
    for i, m in ipairs(MODES) do
        local b = Button(f, 112, m.label, function() db.mode = m.key view.itemOffset = 0 Refresh() end)
        b:SetPoint("TOPLEFT", 152 + (i - 1) * 116, -40)
        b.mode = m.key
        f.modeButtons[i] = b
    end
    local search = CreateFrame("EditBox", "LootAtlasSearch", f, "InputBoxTemplate")
    search:SetSize(170, 20)
    search:SetPoint("TOPRIGHT", -22, -40)
    search:SetAutoFocus(false)
    search:SetScript("OnTextChanged", function(self)
        local text = self:GetText() or ""
        view.search = #text >= 3 and text or ""
        view.itemOffset = 0
        Refresh()
    end)
    search:SetScript("OnEscapePressed", function(self) self:SetText("") self:ClearFocus() end)
    search:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    f.search = search
    local searchLabel = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    searchLabel:SetPoint("RIGHT", search, "LEFT", -8, 0)
    searchLabel:SetText("Search items")

    -- Columns.
    f.left = TextList(f, 16, -70, 190, LEFT_ROWS, 22, "leftOffset", function(e)
        view.search = ""
        f.search:SetText("")
        if e.special then view.special, view.boss = e.special, 1 else view.special, view.inst, view.boss = nil, e.inst, 1 end
        view.midOffset, view.itemOffset = 0, 0
        Refresh()
    end)
    f.mid = TextList(f, 214, -70, 190, LEFT_ROWS, 22, "midOffset", function(e)
        view.boss, view.itemOffset = e.boss, 0
        view.search = ""
        f.search:SetText("")
        Refresh()
    end)
    f.itemTitle = Text(f, "GameFontNormal", 414, -72, 330)
    f.itemNote = Text(f, "GameFontDisableSmall", 414, -88, 330)
    local items = CreateFrame("Frame", nil, f)
    items:SetSize(330, ITEM_ROWS * 36)
    items:SetPoint("TOPLEFT", 412, -104)
    items:EnableMouseWheel(true)
    items:SetScript("OnMouseWheel", function(self, delta)
        view.itemOffset = math.max(0, math.min((self.total or 0) - ITEM_ROWS, view.itemOffset - delta * 3))
        Refresh()
    end)
    f.items = items
    f.itemRows = {}
    for i = 1, ITEM_ROWS do f.itemRows[i] = MakeItemRow(items, i) end
    f.nearButton = Button(f, 150, "", function() db.raresNear = not db.raresNear view.itemOffset = 0 Refresh() end)
    f.nearButton:SetPoint("TOPLEFT", 214, -70)

    f.foot = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.foot:SetPoint("BOTTOM", 0, 14)
    f.foot:SetWidth(720)
    f.foot:SetText("Loot tables from AtlasLootClassic. Right-click the class button to go back to your own class.")
    f:SetScript("OnShow", function() Refresh() end)
    f:Hide()
    return f
end

Refresh = function()
    local f = frame
    if not f or not f:IsShown() then return end
    local cls = CLASS_BY_FILE[db.class] or CLASSES[1]
    local color = RAID_CLASS_COLORS and RAID_CLASS_COLORS[cls.file]
    f.classButton:SetText("Class: " .. ((color and color.colorStr) and ("|c" .. color.colorStr .. cls.name .. "|r") or cls.name))
    for _, b in ipairs(f.modeButtons) do b:SetEnabled(db.mode ~= b.mode) end

    FillTextList(f.left, LEFT, "leftOffset", function(e)
        if e.special then return view.special == e.special end
        return not view.special and e.inst == view.inst
    end)

    if view.special == "rares" then
        f.mid:Hide()
        f.nearButton:Show()
        f.nearButton:SetText(db.raresNear and "Near my level: on" or "Near my level: off")
        local rares = RareEntries()
        f.itemTitle:SetText("Rare mobs out in the world")
        f.itemNote:SetText(string.format("%d rares. Their loot isn't in the loot tables, so click Map to go and find out.", #rares))
        f.items:ClearAllPoints()
        f.items:SetPoint("TOPLEFT", 214, -104)
        f.items.total = #rares
        view.itemOffset = math.max(0, math.min(view.itemOffset, #rares - ITEM_ROWS))
        for i, r in ipairs(f.itemRows) do
            local e = rares[view.itemOffset + i]
            r.id, r.map.rare = nil, e
            if e then
                r:Show()
                r:SetWidth(520)
                r.name:SetWidth(440)
                r.sub:SetWidth(440)
                r.icon:SetTexture(I(e[9] and "Achievement_Boss_Generic" or "INV_Misc_Head_Dragon_01"))
                r.name:SetText(string.format("%s%s|r  level %d%s", e[9] and "|cffffa040" or "|cffffffff", e[2], e[3], e[4] ~= e[3] and ("-" .. e[4]) or ""))
                r.sub:SetText(e[5] .. (e[9] and "  |cffff8040rare elite|r" or "  rare"))
                r.map:Show()
            else
                r:Hide()
            end
        end
        return
    end
    f.nearButton:Hide()
    f.mid:Show()
    f.items:ClearAllPoints()
    f.items:SetPoint("TOPLEFT", 412, -104)
    FillTextList(f.mid, MidEntries(), "midOffset", function(e) return e.boss == view.boss end)

    local entries, title, hidden, waiting = ItemEntries()
    f.itemTitle:SetText(title)
    local note
    if db.mode == "all" then note = string.format("%d items", #entries)
    else note = string.format("%d for %s%s", #entries, cls.name, hidden > 0 and string.format(", %d hidden", hidden) or "") end
    if waiting > 0 then note = note .. ", loading details..." end
    f.itemNote:SetText(note)
    f.items.total = #entries
    view.itemOffset = math.max(0, math.min(view.itemOffset, #entries - ITEM_ROWS))
    for i, r in ipairs(f.itemRows) do
        local e = entries[view.itemOffset + i]
        r.map.rare = nil
        r.map:Hide()
        r:SetWidth(330)
        r.name:SetWidth(288)
        r.sub:SetWidth(288)
        if e then
            r.id = e.id
            r:Show()
            LoadItem(e.id) -- asks the game for it, so quality colour and links are ready
            local item = ns.ITEMS[e.id]
            r.icon:SetTexture(ItemIcon(e.id))
            r.name:SetText(QualityColor(e.id) .. (item and item[1] or ("item " .. e.id)) .. "|r")
            local sub = TypeText(e.id)
            if e.source then sub = (sub ~= "" and (sub .. "  ") or "") .. "|cff808080" .. e.source .. "|r" end
            r.sub:SetText(sub)
        else
            r.id = nil
            r:Hide()
        end
    end
    f.left.total = #LEFT
end

local function Open()
    if not db then return end
    if not frame then
        BuildLeft()
        frame = CreateWindow()
        -- Start on the first instance.
        for _, e in ipairs(LEFT) do if e.inst then view.inst = e.inst break end end
    end
    frame:Show()
    Refresh()
end

local function Toggle()
    if frame and frame:IsShown() then frame:Hide() else Open() end
end

function LootAtlas_OnCompartmentClick()
    Toggle()
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local minimapButton
local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 120)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "LootAtlasMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("AnyUp")
    b:RegisterForDrag("LeftButton")
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture(I("INV_Misc_Bag_10_Black"))
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", Toggle)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Loot Atlas", 0.64, 0.21, 0.93)
        GameTooltip:AddLine("Click to see what every boss and rare drops.", 1, 1, 1)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

---------------------------------------------------------------------------
-- Slash command and events
---------------------------------------------------------------------------

SLASH_LOOTATLAS1 = "/la"
SLASH_LOOTATLAS2 = "/lootatlas"
SlashCmdList.LOOTATLAS = function(message)
    local arg = (message or ""):match("^%s*(.-)%s*$")
    if arg == "" then Toggle() return end
    if arg:lower() == "minimap" then
        db.minimap = not db.minimap
        if db.minimap then if not minimapButton then CreateMinimapButton() end minimapButton:Show()
        elseif minimapButton then minimapButton:Hide() end
        return
    end
    if arg:lower() == "rares" then
        Open()
        view.special, view.itemOffset = "rares", 0
        Refresh()
        return
    end
    -- Anything else: search items, or jump to an instance by name.
    Open()
    for i, inst in ipairs(ns.INSTANCES) do
        if inst.name:lower():find(arg:lower(), 1, true) then
            view.special, view.inst, view.boss, view.search = nil, i, 1, ""
            frame.search:SetText("")
            Refresh()
            return
        end
    end
    frame.search:SetText(arg)
end

local refreshQueued = false
local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("GET_ITEM_INFO_RECEIVED")
events:RegisterEvent("ITEM_DATA_LOAD_RESULT")
events:SetScript("OnEvent", function(_, event, id)
    if event == "PLAYER_LOGIN" then
        LootAtlasDB = type(LootAtlasDB) == "table" and LootAtlasDB or {}
        db = LootAtlasDB
        if not db.class or not CLASS_BY_FILE[db.class] then db.class = MyClass() end
        if not db.mode then db.mode = "best" end
        if db.minimap == nil then db.minimap = true end
        if db.raresNear == nil then db.raresNear = true end
        if db.minimap and Minimap then CreateMinimapButton() end
        return
    end
    -- An item we asked for has arrived: refresh once, a moment later, for all of them.
    if type(id) == "number" then pending[id] = nil end
    if frame and frame:IsShown() and not refreshQueued then
        refreshQueued = true
        C_Timer.After(0.2, function() refreshQueued = false Refresh() end)
    end
end)

-- For the automated tests.
ns.Open, ns.View, ns.FitsClass, ns.Live, ns.Refresh = Open, function() return view end, FitsClass, live, function() Refresh() end
