-- Gnomish Grudge Match: hidden addon messages between players.
-- Messages look like "K~matchId~round~hash". Whispers go to the opponent; group and guild get spectator updates.
local _, ns = ...
local Net = {}
ns.Net = Net

local PREFIX = "GGM1"
local queue, ticker = {}, nil

local function IsSecret(v) return issecretvalue and issecretvalue(v) end

local function Clean(v)
    return (tostring(v or ""):gsub("~", "-"):gsub("[\r\n|]", ""))
end

local function Ok(result)
    if result == nil or result == true or result == 0 then return true end
    if Enum and Enum.SendAddonMessageResult and result == Enum.SendAddonMessageResult.Success then return true end
    return false
end

local function TrySend(item)
    if not (C_ChatInfo and C_ChatInfo.SendAddonMessage) then return true end
    local ok, result = pcall(C_ChatInfo.SendAddonMessage, PREFIX, item.text, item.channel, item.target)
    return ok and Ok(result)
end

local function Pump()
    while queue[1] do
        local item = queue[1]
        if TrySend(item) then
            table.remove(queue, 1)
        else
            item.tries = item.tries + 1
            if item.tries > 20 then table.remove(queue, 1) end -- gave up after ~40 sec
            return
        end
    end
    if ticker then ticker:Cancel() ticker = nil end
end

---Sends a message. Failed sends (throttled, or blocked for a moment) are retried every 2 sec.
function Net.Send(channel, target, kind, ...)
    local parts = { kind }
    for i = 1, select("#", ...) do parts[#parts + 1] = Clean(select(i, ...)) end
    local text = table.concat(parts, "~")
    queue[#queue + 1] = { text = text, channel = channel, target = target, tries = 0 }
    Pump()
    if queue[1] and not ticker then ticker = C_Timer.NewTicker(2, Pump) end
end

function Net.Whisper(target, kind, ...)
    Net.Send("WHISPER", target, kind, ...)
end

---Spectator updates go to your group and your guild.
function Net.Broadcast(kind, ...)
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        Net.Send("INSTANCE_CHAT", nil, kind, ...)
    elseif IsInRaid() then
        Net.Send("RAID", nil, kind, ...)
    elseif IsInGroup() then
        Net.Send("PARTY", nil, kind, ...)
    end
    if IsInGuild() and ns.db and ns.db.guildWatch then
        Net.Send("GUILD", nil, kind, ...)
    end
end

function Net.Init(onMessage)
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
    end
    local frame = CreateFrame("Frame")
    frame:RegisterEvent("CHAT_MSG_ADDON")
    frame:SetScript("OnEvent", function(_, _, prefix, text, channel, sender)
        if IsSecret(prefix) or IsSecret(text) or IsSecret(sender) then return end
        if prefix ~= PREFIX or type(text) ~= "string" or type(sender) ~= "string" then return end
        local fields = {}
        for field in (text .. "~"):gmatch("([^~]*)~") do fields[#fields + 1] = field end
        local kind = table.remove(fields, 1)
        local ok, err = pcall(onMessage, kind, fields, sender, channel)
        if not ok and ns.Debug then ns.Debug("message error: " .. tostring(err)) end
    end)
end
