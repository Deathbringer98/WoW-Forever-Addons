-- Gnomish Grudge Match: deterministic battle engine. No WoW API in here, so every client (players and spectators)
-- runs the exact same fight from the same seed and picks. Time runs in ticks of 0.1 sec.
local _, ns = ...
local Engine = {}
ns.Engine = Engine

local floor, max, min = math.floor, math.max, math.min
local MOD = 2147483647
local TICKS = 10                -- ticks per second
local LIMIT = 45 * TICKS        -- a fight lasts at most 45 sec

---------------------------------------------------------------------------
-- Random numbers and hashing (pure arithmetic, identical everywhere)
---------------------------------------------------------------------------

---Park-Miller generator. Returns an object with :Next() in [0, 1) and :Int(n) in [1, n].
function Engine.NewRng(seed)
    local state = floor(seed) % (MOD - 1) + 1
    local rng = {}
    function rng:Next()
        state = (state * 16807) % MOD
        return (state - 1) / (MOD - 1)
    end
    function rng:Int(n)
        return floor(self:Next() * n) + 1
    end
    return rng
end

---djb2 hash of a string, as a decimal string.
function Engine.Hash(text)
    local h = 5381
    for i = 1, #text do
        h = (h * 33 + text:byte(i)) % 4294967296
    end
    return tostring(h)
end

---The shared seed from both halves.
function Engine.CombineSeed(a, b)
    return (floor(tonumber(a) or 0) * 31 + floor(tonumber(b) or 0) * 7 + 12345) % (MOD - 2) + 1
end

---------------------------------------------------------------------------
-- Salvage offers
---------------------------------------------------------------------------

---The 3 parts per slot offered to one side in one round: offers[slot] = {part, part, part}.
---@param side number 1 or 2
function Engine.Offers(seed, round, side, faction)
    local rng = Engine.NewRng(seed + round * 7919 + side * 104729)
    local offers = {}
    for _, slot in ipairs(ns.SLOTS) do
        local pool = {}
        for i, part in ipairs(ns.PARTS[faction][slot]) do pool[i] = part end
        for i = #pool, 2, -1 do
            local j = rng:Int(i)
            pool[i], pool[j] = pool[j], pool[i]
        end
        offers[slot] = { pool[1], pool[2], pool[3] }
    end
    return offers
end

---Picks as a string "12312": the chosen option (1-3) per slot, in slot order.
function Engine.PartsFromPicks(offers, picks)
    local parts = {}
    for i, slot in ipairs(ns.SLOTS) do
        local choice = tonumber(picks:sub(i, i)) or 1
        parts[slot] = offers[slot][choice] or offers[slot][1]
    end
    return parts
end

---------------------------------------------------------------------------
-- Building a mech
---------------------------------------------------------------------------

function Engine.BuildMech(parts, name, faction)
    local m = {
        name = name, faction = faction, parts = parts,
        maxHp = 500, armor = 0, power = 0, interval = 2.0, speed = 0, dodge = 3, crit = 5, critMult = 1.5, powerPct = 0,
        traits = {},
    }
    for _, slot in ipairs(ns.SLOTS) do
        local p = parts[slot]
        m.maxHp = m.maxHp + (p.hp or 0)
        m.armor = m.armor + (p.armor or 0)
        m.power = m.power + (p.power or 0)
        m.interval = m.interval + (p.interval or 0)
        m.speed = m.speed + (p.speed or 0)
        m.dodge = m.dodge + (p.dodge or 0)
        m.crit = m.crit + (p.crit or 0)
        m.critMult = m.critMult + (p.critMult or 0)
        m.powerPct = m.powerPct + (p.powerPct or 0)
        if p.trait then
            m.traits[#m.traits + 1] = { def = p.trait, part = p }
        end
    end
    m.armor = min(m.armor, 60)
    m.dodge = min(m.dodge, 45)
    m.interval = max(0.8, m.interval * (1 - m.speed * 0.04))
    m.display = parts.chassis.display
    return m
end

---Rough strength of a mech, used by the bots to rank builds and by the stats panel.
function Engine.Rating(m)
    local ehp = m.maxHp / (1 - m.armor / 100) / (1 - m.dodge / 100)
    local dps = m.power * (1 + m.powerPct / 100) * (1 + m.crit / 100 * (m.critMult - 1)) / m.interval
    for _, t in ipairs(m.traits) do
        local d = t.def
        if d.key == "shield" then ehp = ehp + d.amount * (d.recharge > 0 and 1.8 or 1)
        elseif d.key == "repair" then ehp = ehp * 1.25
        elseif d.key == "reflect" then dps = dps * (1 + d.pct / 140)
        elseif d.key == "cloak" then ehp = ehp * 1.1
        elseif d.key == "salvage" then ehp = ehp + d.heal
        elseif d.key == "bribe" then ehp = ehp * (1 + d.chance / 100)
        elseif d.key == "scrap" then ehp = ehp * 1.15
        elseif d.key == "chain" then dps = dps * (1 + d.chance / 100 * d.mult)
        elseif d.key == "pen" then dps = dps * (1 + d.pct / 300)
        elseif d.key == "chill" then ehp = ehp * 1.08
        elseif d.key == "burn" then dps = dps + d.dps * 0.8
        elseif d.key == "crush" then dps = dps * 1.08
        elseif d.key == "nth" then dps = dps * (1 + (d.mult - 1) / d.n)
        elseif d.key == "overheat" then ehp = ehp * 0.85
        elseif d.key == "nitro" then dps = dps * 1.12
        elseif d.key == "ramp" then dps = dps + 20 / m.interval
        elseif d.key == "ram" or d.key == "stomp" then dps = dps * 1.06
        elseif d.key == "alarm" then dps = dps * 1.1
        elseif d.key == "chicken" then dps = dps + d.dmg / d.every
        elseif d.key == "deathray" then dps = dps + d.dmg * 0.85 / 9
        elseif d.key == "bomb" then dps = dps + d.dmg / 8 * 1.2
        elseif d.key == "rockets" then dps = dps + d.count * d.dmg / 7
        elseif d.key == "mortar" then dps = dps + d.dmg * 0.75 / 7
        elseif d.key == "sapper" then dps = dps + 8
        elseif d.key == "stun" then dps = dps + (d.dmg or 0) / 9; ehp = ehp * 1.12
        elseif d.key == "shrink" then ehp = ehp * 1.14
        elseif d.key == "oil" then dps = dps * 1.12
        end
    end
    return floor(ehp * dps / 100)
end

---------------------------------------------------------------------------
-- The fight
---------------------------------------------------------------------------

local function Trait(m, key)
    for _, t in ipairs(m.traits) do
        if t.def.key == key then return t.def, t.part end
    end
end

local function Fresh(m)
    local f = {
        m = m, hp = m.maxHp, shield = 0, attacks = 0, dealt = 0,
        nextAttack = 0, stunUntil = -1, slowUntil = -1, slowPct = 0, shrinkUntil = -1, shrinkPct = 0,
        oilUntil = -1, oilPct = 0, burnUntil = -1, burnDps = 0, crush = 0, scrap = 0, ramp = 0,
        shieldRenewed = false, sapperUsed = false, salvageUsed = false,
        cannons = {},
    }
    local shield = Trait(m, "shield")
    if shield then f.shield = shield.amount end
    for _, t in ipairs(m.traits) do
        local p = t.part
        if p.slot == "cannon" and t.def.key ~= "sapper" then
            f.cannons[#f.cannons + 1] = { def = t.def, part = p, next = floor((p.first or 3) * TICKS), cd = p.cd and floor(p.cd * TICKS) }
        end
    end
    local repair = Trait(m, "repair")
    if repair then f.nextRepair = repair.every * TICKS end
    local overheat = Trait(m, "overheat")
    if overheat then f.nextOverheat = overheat.every * TICKS end
    return f
end

---Runs one round. Returns winner (1 or 2), and the event list when record is true.
---@param seed number round seed
function Engine.Fight(mechA, mechB, seed, record)
    local rng = Engine.NewRng(seed)
    local s = { Fresh(mechA), Fresh(mechB) }
    local events = record and {} or nil
    local tick = 0

    local function Log(kind, side, value, extra)
        if events then
            events[#events + 1] = { t = tick, kind = kind, side = side, value = value, extra = extra,
                hp1 = s[1].hp, hp2 = s[2].hp, sh1 = s[1].shield, sh2 = s[2].shield }
        end
    end

    -- Deals damage from side a to side b. kind is the event name, armor/dodge rules come from opts.
    local function Hit(a, b, raw, kind, opts)
        local A, B = s[a], s[b]
        opts = opts or {}
        if not opts.sure then
            local cloak = Trait(B.m, "cloak")
            if cloak and tick < cloak.dur * TICKS then
                Log("miss", a, 0, kind)
                return 0
            end
            local dodge = (tick < B.oilUntil) and 0 or B.m.dodge
            if rng:Next() * 100 < dodge then
                Log("dodge", a, 0, kind)
                return 0
            end
        end
        local dmg = raw
        local crit = false
        if opts.canCrit and rng:Next() * 100 < A.m.crit then
            dmg = dmg * A.m.critMult
            crit = true
        end
        if tick < A.shrinkUntil then dmg = dmg * (1 - A.shrinkPct / 100) end
        if tick < B.oilUntil then dmg = dmg * (1 + B.oilPct / 100) end
        if not opts.pierce then
            local armor = max(0, B.m.armor + B.scrap - B.crush)
            armor = armor * (1 - (opts.pen or 0) / 100)
            dmg = dmg * (1 - min(armor, 75) / 100)
        end
        dmg = floor(dmg + 0.5)
        if dmg < 1 then dmg = 1 end
        local absorbed = 0
        if B.shield > 0 then
            absorbed = min(B.shield, dmg)
            B.shield = B.shield - absorbed
        end
        B.hp = B.hp - (dmg - absorbed)
        A.dealt = A.dealt + dmg
        Log(kind, a, dmg, crit and "crit" or (absorbed > 0 and "absorb" or nil))
        -- on-hit reactions of the target
        local scrap = Trait(B.m, "scrap")
        if scrap and opts.attack then B.scrap = min(scrap.max, B.scrap + scrap.per) end
        local reflect = Trait(B.m, "reflect")
        if reflect and opts.attack and dmg > 0 then
            local back = floor(dmg * reflect.pct / 100 + 0.5)
            if back > 0 then
                A.hp = A.hp - back
                B.dealt = B.dealt + back
                Log("reflect", b, back)
            end
        end
        return dmg
    end

    local function CheckThresholds(side)
        local S, O = s[side], s[3 - side]
        if S.hp <= 0 then return end
        local shield = Trait(S.m, "shield")
        if shield and shield.recharge > 0 and not S.shieldRenewed and S.hp <= S.m.maxHp * shield.recharge then
            S.shieldRenewed = true
            S.shield = S.shield + shield.amount
            Log("shield", side, shield.amount)
        end
        local salvage = Trait(S.m, "salvage")
        if salvage and not S.salvageUsed and S.hp <= S.m.maxHp * salvage.below then
            S.salvageUsed = true
            S.hp = min(S.m.maxHp, S.hp + salvage.heal)
            Log("heal", side, salvage.heal, "salvage")
        end
        local sapper = Trait(S.m, "sapper")
        if sapper and not S.sapperUsed and S.hp <= S.m.maxHp * sapper.below and O.hp > 0 then
            S.sapperUsed = true
            Log("special", side, 0, "sapper")
            Hit(side, 3 - side, sapper.dmg, "sapper", { sure = true, pierce = true })
            S.hp = S.hp - sapper.self
            Log("selfdamage", side, sapper.self)
        end
    end

    local function Attack(a)
        local A, B = s[a], s[3 - a]
        local bribe = Trait(B.m, "bribe")
        A.attacks = A.attacks + 1
        if bribe and rng:Next() * 100 < bribe.chance then
            Log("bribed", a, 0)
            return
        end
        local raw = A.m.power * (1 + A.m.powerPct / 100) + A.ramp
        local alarm = Trait(A.m, "alarm")
        if alarm and A.hp < A.m.maxHp * alarm.below then raw = raw * (1 + alarm.pct / 100) end
        local nth = Trait(A.m, "nth")
        local big = nth and A.attacks % nth.n == 0
        if big then raw = raw * nth.mult end
        local ram = Trait(A.m, "ram")
        if ram and A.attacks == 1 then raw = raw * ram.mult; big = true end
        local pen = Trait(A.m, "pen")
        local dmg = Hit(a, 3 - a, raw, big and "bigattack" or "attack", { canCrit = true, attack = true, pen = pen and pen.pct })
        local ramp = Trait(A.m, "ramp")
        if ramp then A.ramp = min(ramp.max, A.ramp + ramp.per) end
        if dmg > 0 then
            local stomp = Trait(A.m, "stomp")
            if stomp and A.attacks == 1 then
                B.stunUntil = tick + floor(stomp.dur * TICKS)
                Log("stun", a, stomp.dur, "stomp")
            end
            local chain = Trait(A.m, "chain")
            if chain and rng:Next() * 100 < chain.chance then
                Hit(a, 3 - a, raw * chain.mult, "chain", { sure = true })
            end
            local chill = Trait(A.m, "chill")
            if chill and rng:Next() * 100 < chill.chance then
                B.slowUntil, B.slowPct = tick + floor(chill.dur * TICKS), chill.slow
                Log("chill", a, chill.slow)
            end
            local burn = Trait(A.m, "burn")
            if burn then
                B.burnUntil, B.burnDps = tick + floor(burn.dur * TICKS), burn.dps
            end
            local crush = Trait(A.m, "crush")
            if crush and B.crush < crush.armor * crush.max and rng:Next() * 100 < crush.chance then
                B.crush = B.crush + crush.armor
                Log("crush", a, crush.armor)
            end
        end
    end

    local function Interval(side)
        local S = s[side]
        local interval = S.m.interval
        local nitro = Trait(S.m, "nitro")
        if nitro and tick < nitro.dur * TICKS then interval = interval * (1 - nitro.pct / 100) end
        if tick < S.slowUntil then interval = interval * (1 + S.slowPct / 100) end
        return max(5, floor(interval * TICKS + 0.5))
    end

    local function Cannon(a, c)
        local A, B = s[a], s[3 - a]
        local d, key = c.def, c.def.key
        Log("special", a, 0, key)
        if key == "shrink" then
            B.shrinkUntil, B.shrinkPct = tick + d.dur * TICKS, d.pct
            if d.dmg then Hit(a, 3 - a, d.dmg, "zap", { sure = true }) end
        elseif key == "deathray" then
            if rng:Next() * 100 < d.backfire then
                A.hp = A.hp - d.self
                Log("backfire", a, d.self)
            else
                Hit(a, 3 - a, d.dmg, "deathray", { sure = true })
            end
        elseif key == "chicken" then
            Hit(a, 3 - a, d.dmg, "chicken", {})
        elseif key == "stun" then
            if Hit(a, 3 - a, d.dmg, "stun", { sure = true }) > 0 then
                B.stunUntil = tick + floor(d.dur * TICKS)
            end
        elseif key == "bomb" then
            Hit(a, 3 - a, d.dmg, "bomb", { sure = true, pierce = true })
        elseif key == "rockets" then
            for _ = 1, d.count do Hit(a, 3 - a, d.dmg, "rocket", {}) end
        elseif key == "oil" then
            B.oilUntil, B.oilPct = tick + d.dur * TICKS, d.pct
            if d.dmg then Hit(a, 3 - a, d.dmg, "zap", { sure = true }) end
        elseif key == "mortar" then
            if rng:Next() * 100 < d.miss then
                Log("miss", a, 0, "mortar")
            else
                Hit(a, 3 - a, d.dmg, "mortar", { sure = true })
            end
        end
    end

    Log("start", 0, 0)
    local winner
    while tick <= LIMIT do
        -- Alternate who acts first each tick, so neither side always has the edge.
        local order = (tick % 2 == 0) and { 1, 2 } or { 2, 1 }
        for _, side in ipairs(order) do
            local S, O = s[side], s[3 - side]
            if S.hp > 0 and O.hp > 0 then
                -- timers that run even while stunned
                if tick < S.burnUntil and tick % TICKS == 0 then
                    S.hp = S.hp - S.burnDps
                    O.dealt = O.dealt + S.burnDps
                    Log("burn", 3 - side, S.burnDps)
                end
                if S.nextRepair and tick >= S.nextRepair then
                    local repair = Trait(S.m, "repair")
                    local heal = floor(S.m.maxHp * repair.pct / 100)
                    S.hp = min(S.m.maxHp, S.hp + heal)
                    S.nextRepair = tick + repair.every * TICKS
                    Log("heal", side, heal, "repair")
                end
                if S.nextOverheat and tick >= S.nextOverheat then
                    local over = Trait(S.m, "overheat")
                    local burn = floor(S.m.maxHp * over.pct / 100)
                    S.hp = S.hp - burn
                    S.nextOverheat = tick + over.every * TICKS
                    Log("selfdamage", side, burn, "overheat")
                end
                if tick >= S.stunUntil then
                    if tick >= S.nextAttack then
                        Attack(side)
                        S.nextAttack = tick + Interval(side)
                    end
                    for _, c in ipairs(S.cannons) do
                        if c.next and tick >= c.next then
                            Cannon(side, c)
                            if c.def.key == "chicken" then
                                c.next = tick + floor(c.def.every * TICKS)
                            else
                                c.next = c.cd and (tick + c.cd) or nil
                            end
                        end
                    end
                end
                CheckThresholds(side)
                CheckThresholds(3 - side)
            end
        end
        if s[1].hp <= 0 or s[2].hp <= 0 then
            if s[1].hp <= 0 and s[2].hp <= 0 then
                winner = (s[1].hp >= s[2].hp) and 1 or 2
            else
                winner = s[1].hp > 0 and 1 or 2
            end
            Log("ko", 3 - winner, 0)
            break
        end
        tick = tick + 1
    end
    if not winner then
        local p1, p2 = s[1].hp / s[1].m.maxHp, s[2].hp / s[2].m.maxHp
        if p1 == p2 then
            winner = (s[1].dealt >= s[2].dealt) and 1 or 2
        else
            winner = p1 > p2 and 1 or 2
        end
        tick = LIMIT
        Log("timeout", winner, 0)
    end
    return winner, events, { s[1].hp, s[2].hp, s[1].dealt, s[2].dealt, tick }
end

Engine.TICKS = TICKS
