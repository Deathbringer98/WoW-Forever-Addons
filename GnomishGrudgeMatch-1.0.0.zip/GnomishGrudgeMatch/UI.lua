-- Gnomish Grudge Match: windows, workshop, arena playback and minimap button.
local _, ns = ...
local UI = {}
ns.UI = UI
local Engine = ns.Engine

local W, H = 820, 560
local GOLD = { 1, 0.82, 0 }
local main, screens, current = nil, {}, nil

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Backdrop(frame, bgAlpha, gold)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = gold and "Interface\\DialogFrame\\UI-DialogBox-Gold-Border" or "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 32, edgeSize = gold and 24 or 14,
        insets = { left = gold and 6 or 3, right = gold and 6 or 3, top = gold and 6 or 3, bottom = gold and 6 or 3 },
    })
    frame:SetBackdropColor(1, 1, 1, bgAlpha or 1)
end

local function Text(parent, font, text, r, g, b)
    local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    if text then fs:SetText(text) end
    if r then fs:SetTextColor(r, g, b) end
    return fs
end

local function Button(parent, label, w, h, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w or 120, h or 26)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
end

local function Tooltip(frame, title, lines)
    frame:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        local t = type(title) == "function" and title() or title
        GameTooltip:SetText(t or "", 1, 0.82, 0)
        local list = type(lines) == "function" and lines() or lines
        for _, line in ipairs(list or {}) do GameTooltip:AddLine(line, 1, 1, 1, true) end
        GameTooltip:Show()
    end)
    frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

local function Colored(faction, text)
    return "|c" .. ns.FACTIONS[faction].hex .. text .. "|r"
end

local function Play(file)
    if ns.db and ns.db.sound and file then pcall(PlaySoundFile, file, "SFX") end
end
local function PlayOne(list)
    if type(list) == "table" then Play(list[math.random(#list)]) else Play(list) end
end

local function PartTooltipLines(part)
    local lines = { "|cffaaaaaa" .. ns.SLOT_NAMES[part.slot] .. "|r" }
    local stats = {}
    if part.hp then stats[#stats + 1] = (part.hp > 0 and "+" or "") .. part.hp .. " health" end
    if part.power then stats[#stats + 1] = part.power .. " damage per hit" end
    if part.interval then stats[#stats + 1] = (part.interval > 0 and "slower " or "faster ") .. "attacks" end
    if part.speed and part.speed ~= 0 then stats[#stats + 1] = (part.speed > 0 and "+" or "") .. part.speed .. " speed" end
    if part.armor then stats[#stats + 1] = part.armor .. "% armor" end
    if part.dodge then stats[#stats + 1] = part.dodge .. "% dodge" end
    if part.crit then stats[#stats + 1] = "+" .. part.crit .. "% crit" end
    if part.powerPct then stats[#stats + 1] = "+" .. part.powerPct .. "% damage" end
    if #stats > 0 then lines[#lines + 1] = "|cff80ff80" .. table.concat(stats, ", ") .. "|r" end
    lines[#lines + 1] = part.text
    return lines
end

local function ShortStats(part)
    if part.slot == "chassis" then return part.hp .. " hp, " .. (part.dodge or 0) .. "% dodge" end
    if part.slot == "arms" then return part.power .. " dmg" .. (part.interval and (part.interval < 0 and ", fast" or ", slow") or "") end
    if part.trait then return (part.text:match("^([^:%.]+)[:.]") or "Special") end
    return part.text:match("^([^%.]+)") or ""
end

-- How big each mech model is in the game (bounding box times display scale).
-- The camera backs off for big ones so every mech fills its box about the same.
local MODEL_SIZE = {
    [5926] = 2.96, [6569] = 2.33, [6980] = 6.03, [15381] = 0.88, [6888] = 2.24,
    [1269] = 5.67, [1303] = 4.25, [2280] = 5.67, [11912] = 4.25, [13310] = 5.67,
}

local function CamFor(display)
    local size = MODEL_SIZE[display] or 2.24
    local cam = 1.25 * (size / 2.24) ^ 0.7
    if cam < 0.8 then cam = 0.8 end
    return cam
end

local function SetModel(model, display, facing)
    pcall(model.ClearModel, model)
    pcall(model.SetDisplayInfo, model, display)
    pcall(model.SetFacing, model, facing or 0)
    pcall(model.SetPortraitZoom, model, 0)
    pcall(model.SetCamDistanceScale, model, CamFor(display))
    pcall(model.SetAnimation, model, 0)
end

local function Anim(model, id)
    pcall(model.SetAnimation, model, id)
end

---------------------------------------------------------------------------
-- Main window
---------------------------------------------------------------------------

local function Screen(name)
    local f = CreateFrame("Frame", nil, main)
    f:SetPoint("TOPLEFT", 10, -34)
    f:SetPoint("BOTTOMRIGHT", -10, 10)
    f:Hide()
    screens[name] = f
    return f
end

local function Show(name)
    for key, f in pairs(screens) do f:SetShown(key == name) end
    current = name
    main:Show()
end

local function CreateMain()
    main = CreateFrame("Frame", "GnomishGrudgeMatchFrame", UIParent, "BackdropTemplate")
    main:SetSize(W, H)
    main:SetPoint("CENTER")
    main:SetFrameStrata("HIGH")
    main:SetClampedToScreen(true)
    main:SetMovable(true)
    main:EnableMouse(true)
    main:RegisterForDrag("LeftButton")
    main:SetScript("OnDragStart", main.StartMoving)
    main:SetScript("OnDragStop", main.StopMovingOrSizing)
    Backdrop(main, 1, true)
    tinsert(UISpecialFrames, "GnomishGrudgeMatchFrame")
    main:Hide()

    local left = main:CreateTexture(nil, "ARTWORK")
    left:SetSize(26, 26)
    left:SetPoint("TOPLEFT", 14, -9)
    left:SetTexture(ns.FACTIONS.gnome.icon)
    local right = main:CreateTexture(nil, "ARTWORK")
    right:SetSize(26, 26)
    right:SetPoint("TOPRIGHT", -40, -9)
    right:SetTexture(ns.FACTIONS.goblin.icon)
    local title = Text(main, "GameFontNormalLarge", "Gnomish Grudge Match")
    title:SetPoint("TOP", 0, -14)
    local close = CreateFrame("Button", nil, main, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)
end

function UI.Toggle()
    if not main then CreateMain() UI.BuildScreens() end
    if main:IsShown() then
        main:Hide()
    else
        if ns.Core.match and current then Show(current) else UI.ShowLobby() end
    end
end

function UI.Open()
    if not main then CreateMain() UI.BuildScreens() end
    main:Show()
end

---------------------------------------------------------------------------
-- Lobby
---------------------------------------------------------------------------

local lobby = {}

local function FactionCard(parent, key, x)
    local f = ns.FACTIONS[key]
    local card = CreateFrame("Button", nil, parent, "BackdropTemplate")
    card:SetSize(380, 96)
    card:SetPoint("TOPLEFT", x, -30)
    Backdrop(card, 0.8)
    local icon = card:CreateTexture(nil, "ARTWORK")
    icon:SetSize(64, 64)
    icon:SetPoint("LEFT", 14, 0)
    icon:SetTexture(f.icon)
    local name = Text(card, "GameFontNormalLarge", f.name, unpack(f.color))
    name:SetPoint("TOPLEFT", icon, "TOPRIGHT", 12, -2)
    local motto = Text(card, "GameFontHighlightSmall", f.motto)
    motto:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -6)
    motto:SetWidth(270)
    motto:SetJustifyH("LEFT")
    card.glow = card:CreateTexture(nil, "OVERLAY")
    card.glow:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
    card.glow:SetBlendMode("ADD")
    card.glow:SetPoint("TOPLEFT", 4, -4)
    card.glow:SetPoint("BOTTOMRIGHT", -4, 4)
    card.check = card:CreateTexture(nil, "OVERLAY")
    card.check:SetSize(28, 28)
    card.check:SetPoint("TOPRIGHT", -8, -8)
    card.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
    card:SetScript("OnClick", function()
        ns.db.faction = key
        PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
        UI.RefreshLobby()
    end)
    card.key = key
    return card
end

local function BuildLobby()
    local s = Screen("lobby")
    local pick = Text(s, "GameFontNormal", "1. Pick your side")
    pick:SetPoint("TOPLEFT", 10, -8)
    lobby.cards = { FactionCard(s, "gnome", 10), FactionCard(s, "goblin", 410) }

    local bots = Text(s, "GameFontNormal", "2. Fight a bot")
    bots:SetPoint("TOPLEFT", 10, -140)
    local x = 10
    for _, key in ipairs({ "easy", "normal", "hard" }) do
        local bot = ns.BOTS[key]
        local b = Button(s, bot.name, 180, 30, function() ns.Core.StartBot(key) end)
        b:SetPoint("TOPLEFT", x, -162)
        Tooltip(b, bot.name, { bot.text, "|cffaaaaaaYou fight with your side; the bot takes the other.|r" })
        x = x + 190
    end
    local botRecord = Text(s, "GameFontHighlightSmall", "")
    botRecord:SetPoint("LEFT", s, "TOPLEFT", 590, -177)
    lobby.botRecord = botRecord

    local players = Text(s, "GameFontNormal", "3. Challenge a player")
    players:SetPoint("TOPLEFT", 10, -210)
    local target = Button(s, "Challenge my target", 180, 28, function()
        if UnitIsPlayer("target") and not UnitIsUnit("target", "player") then
            ns.Core.Challenge(GetUnitName("target", true))
        else
            ns.Print("Target another player first.")
        end
    end)
    target:SetPoint("TOPLEFT", 10, -232)
    Tooltip(target, "Challenge my target", { "Sends a grudge match challenge to the player you have targeted.", "They need Gnomish Grudge Match too." })
    local box = CreateFrame("EditBox", nil, s, "InputBoxTemplate")
    box:SetSize(170, 24)
    box:SetPoint("LEFT", target, "RIGHT", 18, 0)
    box:SetAutoFocus(false)
    box:SetScript("OnEnterPressed", function(self) self:ClearFocus() ns.Core.Challenge(self:GetText()) end)
    local boxLabel = Text(s, "GameFontDisableSmall", "or type a name")
    boxLabel:SetPoint("BOTTOMLEFT", box, "TOPLEFT", 0, 2)
    local send = Button(s, "Challenge", 100, 26, function() box:ClearFocus() ns.Core.Challenge(box:GetText()) end)
    send:SetPoint("LEFT", box, "RIGHT", 8, 0)
    lobby.party = {}
    for i = 1, 4 do
        local b = Button(s, "", 180, 24)
        b:SetPoint("TOPLEFT", 10 + (i - 1) * 190, -266)
        b:Hide()
        lobby.party[i] = b
    end

    local watch = Text(s, "GameFontNormal", "Watch a match")
    watch:SetPoint("TOPLEFT", 10, -304)
    lobby.watchNone = Text(s, "GameFontDisableSmall", "Nobody in your group or guild is fighting right now. Their matches show up here.")
    lobby.watchNone:SetPoint("TOPLEFT", 10, -326)
    lobby.watch = {}
    for i = 1, 3 do
        local b = Button(s, "", 380, 24)
        b:SetPoint("TOPLEFT", 10, -322 - (i - 1) * 28)
        b:Hide()
        lobby.watch[i] = b
    end

    local how = CreateFrame("Frame", nil, s, "BackdropTemplate")
    how:SetPoint("TOPLEFT", 410, -304)
    how:SetSize(380, 150)
    Backdrop(how, 0.7)
    local howTitle = Text(how, "GameFontNormal", "How it works")
    howTitle:SetPoint("TOPLEFT", 10, -8)
    local howText = Text(how, "GameFontHighlightSmall",
        "Each round you get salvage: 3 choices for each of 5 mech parts. Pick one of each and lock in. " ..
        "You can see what parts your rival was offered, so try to guess their build and counter it.\n\n" ..
        "Then the mechs fight on their own. Best of 3 rounds wins the grudge.")
    howText:SetPoint("TOPLEFT", 10, -26)
    howText:SetWidth(360)
    howText:SetJustifyH("LEFT")

    lobby.record = Text(s, "GameFontHighlight", "")
    lobby.record:SetPoint("BOTTOMLEFT", 10, 12)
    local sound = Button(s, "", 110, 22, function() ns.db.sound = not ns.db.sound UI.RefreshLobby() end)
    sound:SetPoint("BOTTOMRIGHT", -10, 8)
    lobby.sound = sound
    local guild = Button(s, "", 150, 22, function() ns.db.guildWatch = not ns.db.guildWatch UI.RefreshLobby() end)
    guild:SetPoint("RIGHT", sound, "LEFT", -8, 0)
    Tooltip(guild, "Guild can watch", { "When on, your guild gets told about your player matches and can watch them. Your group always can." })
    lobby.guild = guild
end

function UI.RefreshLobby()
    if not main or not lobby.cards then return end
    for _, card in ipairs(lobby.cards) do
        local on = ns.db.faction == card.key
        card.glow:SetShown(on)
        card.check:SetShown(on)
        card:SetAlpha(on and 1 or 0.65)
    end
    -- party members
    local list = {}
    if IsInGroup() then
        local prefix = IsInRaid() and "raid" or "party"
        local count = IsInRaid() and GetNumGroupMembers() or GetNumSubgroupMembers()
        for i = 1, count do
            local unit = prefix .. i
            if UnitExists(unit) and UnitIsPlayer(unit) and not UnitIsUnit(unit, "player") then
                list[#list + 1] = GetUnitName(unit, true)
            end
        end
    end
    for i, b in ipairs(lobby.party) do
        local name = list[i]
        b:SetShown(name ~= nil)
        if name then
            b:SetText("Challenge " .. ns.Short(name))
            b:SetScript("OnClick", function() ns.Core.Challenge(name) end)
        end
    end
    -- live matches
    local live = {}
    for id, m in pairs(ns.Core.live) do
        if not m.over and GetTime() - m.started < 900 then live[#live + 1] = { id = id, m = m } end
    end
    lobby.watchNone:SetShown(#live == 0)
    for i, b in ipairs(lobby.watch) do
        local entry = live[i]
        b:SetShown(entry ~= nil)
        if entry then
            local m = entry.m
            b:SetText("Watch " .. Colored(m.factions[1], ns.Short(m.names[1])) .. " vs " .. Colored(m.factions[2], ns.Short(m.names[2])))
            b:SetScript("OnClick", function() ns.Core.Watch(entry.id) end)
        end
    end
    local rec = ns.db.record
    local rivals = {}
    for name, r in pairs(rec.rivals) do rivals[#rivals + 1] = { name = name, r = r } end
    table.sort(rivals, function(a, b) return a.r.w + a.r.l > b.r.w + b.r.l end)
    local text = string.format("Record: |cff40ff40%d wins|r, |cffff5050%d losses|r", rec.wins, rec.losses)
    if rivals[1] then text = text .. string.format("   Biggest grudge: %s (%d-%d)", rivals[1].name, rivals[1].r.w, rivals[1].r.l) end
    lobby.record:SetText(text)
    local bits = {}
    for _, key in ipairs({ "easy", "normal", "hard" }) do
        local r = rec.bots[key]
        if r then bits[#bits + 1] = string.format("%s %d-%d", ns.BOTS[key].name:match("%S+$"), r.w, r.l) end
    end
    lobby.botRecord:SetText(#bits > 0 and ("|cffaaaaaa" .. table.concat(bits, "  ") .. "|r") or "")
    lobby.sound:SetText(ns.db.sound and "Sound: on" or "Sound: off")
    lobby.guild:SetText(ns.db.guildWatch and "Guild can watch: on" or "Guild can watch: off")
end

function UI.ShowLobby()
    UI.Open()
    Show("lobby")
    UI.RefreshLobby()
end

---------------------------------------------------------------------------
-- Waiting, versus splash
---------------------------------------------------------------------------

local waitText, versus = nil, {}

local function BuildWaiting()
    local s = Screen("waiting")
    waitText = Text(s, "GameFontNormalLarge", "")
    waitText:SetPoint("CENTER", 0, 30)
    local cancel = Button(s, "Cancel", 120, 26, function() ns.Core.Forfeit(true) UI.ShowLobby() end)
    cancel:SetPoint("TOP", waitText, "BOTTOM", 0, -24)
end

function UI.ShowWaitingForAnswer(match)
    UI.Open()
    Show("waiting")
    if match.state == "inviting" then
        waitText:SetText("Challenge sent to " .. ns.Short(match.opponent) .. ".\nWaiting for an answer...")
    else
        waitText:SetText("Challenge accepted!\nGetting the workshop ready...")
    end
end

local function BuildVersus()
    local s = Screen("versus")
    versus.bg = s:CreateTexture(nil, "BACKGROUND")
    versus.bg:SetAllPoints()
    versus.bg:SetTexCoord(0, 1, 0.1, 0.9)
    local shade = s:CreateTexture(nil, "BORDER")
    shade:SetAllPoints()
    shade:SetColorTexture(0, 0, 0, 0.45)
    versus.icon1 = s:CreateTexture(nil, "ARTWORK")
    versus.icon1:SetSize(110, 110)
    versus.icon1:SetPoint("CENTER", -230, 30)
    versus.icon2 = s:CreateTexture(nil, "ARTWORK")
    versus.icon2:SetSize(110, 110)
    versus.icon2:SetPoint("CENTER", 230, 30)
    versus.name1 = Text(s, "GameFontNormalHuge", "")
    versus.name1:SetPoint("TOP", versus.icon1, "BOTTOM", 0, -12)
    versus.name2 = Text(s, "GameFontNormalHuge", "")
    versus.name2:SetPoint("TOP", versus.icon2, "BOTTOM", 0, -12)
    local vs = Text(s, "GameFontNormalHuge", "VS")
    vs:SetPoint("CENTER", 0, 30)
    vs:SetTextColor(1, 0.3, 0.1)
    versus.arena = Text(s, "GameFontNormalLarge", "")
    versus.arena:SetPoint("BOTTOM", 0, 50)
end

local function Side(match, slot) -- which side is drawn left (1) or right (2)
    if match.side == 2 then return 3 - slot end
    return slot
end

function UI.ShowVersus(match, done)
    UI.Open()
    Show("versus")
    local a, b = Side(match, 1), Side(match, 2)
    local arena = ns.ArenaFor(match)
    versus.bg:SetTexture(arena.texture)
    versus.icon1:SetTexture(ns.FACTIONS[match.factions[a]].icon)
    versus.icon2:SetTexture(ns.FACTIONS[match.factions[b]].icon)
    versus.name1:SetText(Colored(match.factions[a], ns.Short(match.names[a])))
    versus.name2:SetText(Colored(match.factions[b], ns.Short(match.names[b])))
    versus.arena:SetText(arena.name)
    PlayOne(match.factions[a] == "goblin" and ns.SOUNDS.goblin.aggro or ns.SOUNDS.gnome.aggro)
    C_Timer.After(2.6, function()
        if ns.Core.match == match then done() end
    end)
end

---------------------------------------------------------------------------
-- Workshop (picking parts)
---------------------------------------------------------------------------

local shop = { rows = {}, scout = {} }
local selection = {}

local function UpdateShopPreview()
    local match = ns.Core.match
    if not match or not match.offers then return end
    local offers = match.offers[match.side]
    local picks = ""
    for i = 1, 5 do picks = picks .. (selection[i] or 1) end
    local parts = Engine.PartsFromPicks(offers, picks)
    local mech = Engine.BuildMech(parts, "you", match.factions[match.side])
    if shop.display ~= mech.display then
        shop.display = mech.display
        SetModel(shop.model, mech.display, 0.6)
    end
    local lines = {
        string.format("Health  |cffffffff%d|r", mech.maxHp),
        string.format("Damage  |cffffffff%d|r per hit%s", math.floor(mech.power * (1 + mech.powerPct / 100)), mech.powerPct > 0 and " (boosted)" or ""),
        string.format("Attacks  |cffffffffevery %.1f sec|r", mech.interval),
        string.format("Armor  |cffffffff%d%%|r   Dodge  |cffffffff%d%%|r", mech.armor, mech.dodge),
        string.format("Crit  |cffffffff%d%%|r for |cffffffffx%.2f|r", mech.crit, mech.critMult),
        string.format("Power rating  |cffffd100%d|r", Engine.Rating(mech)),
    }
    shop.stats:SetText(table.concat(lines, "\n"))
    for i, row in ipairs(shop.rows) do
        for j, b in ipairs(row.buttons) do
            local on = (selection[i] or 0) == j
            b.glow:SetShown(on)
            b:SetBackdropBorderColor(on and 1 or 0.5, on and 0.82 or 0.5, on and 0 or 0.5)
        end
    end
end

local function BuildWorkshop()
    local s = Screen("workshop")
    shop.title = Text(s, "GameFontNormalLarge", "")
    shop.title:SetPoint("TOPLEFT", 10, -6)
    shop.score = Text(s, "GameFontHighlight", "")
    shop.score:SetPoint("TOPRIGHT", -10, -8)
    shop.timer = CreateFrame("StatusBar", nil, s)
    shop.timer:SetSize(500, 8)
    shop.timer:SetPoint("TOPLEFT", 10, -30)
    shop.timer:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    shop.timer:SetStatusBarColor(1, 0.7, 0.1)
    for i, slot in ipairs(ns.SLOTS) do
        local row = { buttons = {} }
        local y = -46 - (i - 1) * 74
        row.label = Text(s, "GameFontNormal", ns.SLOT_NAMES[slot])
        row.label:SetPoint("TOPLEFT", 10, y - 2)
        local help = CreateFrame("Frame", nil, s)
        help:SetAllPoints(row.label)
        Tooltip(help, ns.SLOT_NAMES[slot], { ns.SLOT_HELP[slot] })
        for j = 1, 3 do
            local b = CreateFrame("Button", nil, s, "BackdropTemplate")
            b:SetSize(166, 54)
            b:SetPoint("TOPLEFT", 10 + (j - 1) * 172, y - 18)
            Backdrop(b, 0.85)
            b.icon = b:CreateTexture(nil, "ARTWORK")
            b.icon:SetSize(40, 40)
            b.icon:SetPoint("LEFT", 7, 0)
            b.name = Text(b, "GameFontNormalSmall", "")
            b.name:SetPoint("TOPLEFT", b.icon, "TOPRIGHT", 6, -1)
            b.name:SetWidth(110)
            b.name:SetJustifyH("LEFT")
            b.info = Text(b, "GameFontHighlightSmall", "")
            b.info:SetPoint("TOPLEFT", b.name, "BOTTOMLEFT", 0, -3)
            b.info:SetWidth(110)
            b.info:SetJustifyH("LEFT")
            b.info:SetTextColor(0.75, 0.75, 0.75)
            b.glow = b:CreateTexture(nil, "OVERLAY")
            b.glow:SetTexture("Interface\\Buttons\\ButtonHilight-Square")
            b.glow:SetBlendMode("ADD")
            b.glow:SetPoint("TOPLEFT", 4, -4)
            b.glow:SetPoint("BOTTOMRIGHT", -4, 4)
            b:SetScript("OnClick", function()
                local match = ns.Core.match
                if not match or match.locked then return end
                selection[i] = j
                PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON or 856)
                UpdateShopPreview()
            end)
            Tooltip(b, function() return b.part and b.part.name end, function() return b.part and PartTooltipLines(b.part) end)
            row.buttons[j] = b
        end
        shop.rows[i] = row
    end

    local right = CreateFrame("Frame", nil, s, "BackdropTemplate")
    right:SetPoint("TOPLEFT", 540, -40)
    right:SetPoint("BOTTOMRIGHT", 0, 40)
    Backdrop(right, 0.75)
    shop.model = CreateFrame("PlayerModel", nil, right)
    shop.model:SetSize(240, 170)
    shop.model:SetPoint("TOP", 0, -6)
    shop.stats = Text(right, "GameFontNormalSmall", "")
    shop.stats:SetPoint("TOPLEFT", 12, -180)
    shop.stats:SetJustifyH("LEFT")
    shop.stats:SetSpacing(3)
    local scoutTitle = Text(right, "GameFontNormal", "Scouting report")
    scoutTitle:SetPoint("TOPLEFT", 12, -290)
    shop.scoutName = Text(right, "GameFontDisableSmall", "")
    shop.scoutName:SetPoint("TOPLEFT", scoutTitle, "BOTTOMLEFT", 0, -2)
    for i = 1, 5 do
        for j = 1, 3 do
            local f = CreateFrame("Frame", nil, right)
            f:SetSize(26, 26)
            f:SetPoint("TOPLEFT", 12 + (j - 1) * 30 + (i > 3 and 0 or 0), -326 - (i - 1) * 0)
            f.icon = f:CreateTexture(nil, "ARTWORK")
            f.icon:SetAllPoints()
            Tooltip(f, function() return f.part and f.part.name end, function() return f.part and PartTooltipLines(f.part) end)
            shop.scout[(i - 1) * 3 + j] = f
        end
    end
    -- lay the 15 scouting icons out as 5 columns (slots) of 3
    for i = 1, 5 do
        for j = 1, 3 do
            local f = shop.scout[(i - 1) * 3 + j]
            f:ClearAllPoints()
            f:SetPoint("TOPLEFT", 12 + (i - 1) * 50, -330 - (j - 1) * 28)
        end
    end

    shop.random = Button(s, "Surprise me", 120, 28, function()
        local match = ns.Core.match
        if not match or match.locked then return end
        for i = 1, 5 do selection[i] = math.random(3) end
        UpdateShopPreview()
    end)
    shop.random:SetPoint("BOTTOMLEFT", 10, 6)
    shop.lock = Button(s, "Lock in", 180, 32, function() UI.LockIn() end)
    shop.lock:SetPoint("BOTTOMRIGHT", -10, 4)
    shop.status = Text(s, "GameFontHighlight", "")
    shop.status:SetPoint("BOTTOM", 0, 14)
    local leave = Button(s, "Leave match", 110, 22, function() ns.Core.Forfeit() end)
    leave:SetPoint("LEFT", shop.random, "RIGHT", 8, 0)

    local acc = 0
    s:SetScript("OnUpdate", function(self, elapsed)
        acc = acc + elapsed
        local match = ns.Core.match
        if match and match.deadline then
            local left = math.max(0, match.deadline - GetTime())
            shop.timer:SetMinMaxValues(0, 75)
            shop.timer:SetValue(left)
        end
        if acc > 1 then
            acc = 0
            ns.Core.CheckDeadline()
        end
    end)
end

function UI.LockIn()
    local match = ns.Core.match
    if not match or match.locked or match.state ~= "draft" then return end
    for i = 1, 5 do
        if not selection[i] then
            shop.status:SetText("|cffff8080Pick a part for every slot first (or press Surprise me).|r")
            return
        end
    end
    local picks = ""
    for i = 1, 5 do picks = picks .. selection[i] end
    shop.lock:Disable()
    shop.random:Disable()
    PlaySound(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960)
    ns.Core.Lock(picks)
end

---Time ran out: fill empty slots at random and lock in.
function UI.AutoLock()
    for i = 1, 5 do selection[i] = selection[i] or math.random(3) end
    UpdateShopPreview()
    UI.LockIn()
end

function UI.SetWorkshopStatus(text)
    if shop.status then shop.status:SetText(text) end
end

function UI.ShowWorkshop(match)
    UI.Open()
    Show("workshop")
    wipe(selection)
    shop.display = nil
    local me, them = match.side, 3 - match.side
    shop.title:SetText(string.format("Round %d: the Workshop", match.round))
    shop.score:SetText(string.format("%s %d - %d %s", Colored(match.factions[me], ns.Short(match.names[me])), match.score[me], match.score[them],
        Colored(match.factions[them], ns.Short(match.names[them]))))
    for i, slot in ipairs(ns.SLOTS) do
        for j, b in ipairs(shop.rows[i].buttons) do
            local part = match.offers[me][slot][j]
            b.part = part
            b.icon:SetTexture(part.icon)
            b.name:SetText(part.name)
            b.info:SetText(ShortStats(part))
        end
        for j = 1, 3 do
            local f = shop.scout[(i - 1) * 3 + j]
            f.part = match.offers[them][slot][j]
            f.icon:SetTexture(f.part.icon)
        end
    end
    shop.scoutName:SetText(ns.Short(match.names[them]) .. " was offered:")
    shop.lock:Enable()
    shop.random:Enable()
    shop.status:SetText("Pick one part in each row, then Lock in.")
    for i = 1, 5 do selection[i] = nil end
    selection[1] = 1
    UpdateShopPreview()
    selection[1] = nil
    UpdateShopPreview()
end

---------------------------------------------------------------------------
-- Arena (the fight)
---------------------------------------------------------------------------

local arena = { pos = {}, models = {}, bars = {}, shields = {}, hpText = {}, names = {}, partIcons = {}, floats = {}, shots = {} }
local play = nil -- the fight being shown

local ANIM = { stand = 0, death = 1, dead = 6, wound = 9, attack = 16, cast = 52, roar = 55 }
local KIND_NAMES = {
    sapper = "SUPER SAPPER CHARGE!", shrink = "SHRINK RAY!", deathray = "DEATH RAY!", chicken = nil, stun = nil,
    bomb = "ARCANE BOMB!", rockets = "ROCKET BARRAGE!", oil = "OIL SLICK!", mortar = "MORTAR STRIKE!",
}

local function Float(side, text, r, g, b, big)
    local f
    for _, fs in ipairs(arena.floats) do
        if not fs.busy then f = fs break end
    end
    if not f then
        f = arena.overlay:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
        f.anim = f:CreateAnimationGroup()
        local move = f.anim:CreateAnimation("Translation")
        move:SetOffset(0, 60)
        move:SetDuration(1.1)
        local fade = f.anim:CreateAnimation("Alpha")
        fade:SetFromAlpha(1)
        fade:SetToAlpha(0)
        fade:SetStartDelay(0.6)
        fade:SetDuration(0.5)
        f.anim:SetScript("OnFinished", function() f:Hide() f.busy = false end)
        arena.floats[#arena.floats + 1] = f
    end
    f.busy = true
    f:SetFontObject(big and "GameFontNormalHuge" or "GameFontNormalLarge")
    f:SetText(text)
    f:SetTextColor(r or 1, g or 1, b or 1)
    f:ClearAllPoints()
    f:SetPoint("CENTER", arena.models[side], "CENTER", math.random(-30, 30), 40)
    f:Show()
    f.anim:Stop()
    f.anim:Play()
end

local function Banner(text, r, g, b)
    arena.banner:SetText(text)
    arena.banner:SetTextColor(r or 1, g or 0.82, b or 0)
    arena.bannerAnim:Stop()
    arena.banner:SetAlpha(1)
    arena.banner:Show()
    arena.bannerAnim:Play()
end

local function Shoot(from, to, icon, speed, onHit)
    local shot
    for _, s in ipairs(arena.shots) do
        if not s.busy then shot = s break end
    end
    if not shot then
        shot = CreateFrame("Frame", nil, arena.overlay)
        shot:SetSize(30, 30)
        shot.tex = shot:CreateTexture(nil, "ARTWORK")
        shot.tex:SetAllPoints()
        shot.anim = shot:CreateAnimationGroup()
        shot.move = shot.anim:CreateAnimation("Translation")
        shot.anim:SetScript("OnFinished", function()
            shot:Hide()
            shot.busy = false
            if shot.onHit then shot.onHit() end
        end)
        arena.shots[#arena.shots + 1] = shot
    end
    shot.busy = true
    shot.onHit = onHit
    shot.tex:SetTexture(icon)
    shot:ClearAllPoints()
    shot:SetPoint("CENTER", arena.models[from], "CENTER", 0, 30)
    local dx = (arena.models[to]:GetLeft() or 0) - (arena.models[from]:GetLeft() or 0)
    shot.move:SetOffset(dx, 0)
    shot.move:SetDuration(0.45 / speed)
    shot:Show()
    shot.anim:Play()
end

local function Boom(side)
    local b = arena.boom[side]
    b:Show()
    b.anim:Stop()
    b.anim:Play()
end

local function Lunge(side, speed)
    local m = arena.models[side]
    m.lunge:Stop()
    m.lungeMove:SetOffset(side == 1 and 50 or -50, 0)
    m.lungeMove:SetDuration(0.12 / speed)
    m.lungeBack:SetOffset(side == 1 and -50 or 50, 0)
    m.lungeBack:SetDuration(0.18 / speed)
    m.lunge:Play()
end

local function Shake()
    arena.shake:Stop()
    arena.shake:Play()
end

local function MechSounds(side, what)
    local p = play
    if not p then return end
    local faction = p.mechs[p.order[side]].faction
    local set = ns.SOUNDS[faction]
    if faction == "gnome" and p.mechs[p.order[side]].parts.chassis.id == "g_strider" then set = set.alt end
    PlayOne(set[what])
end

local function Log(text)
    arena.log3:SetText(arena.log2:GetText() or "")
    arena.log2:SetText(arena.log1:GetText() or "")
    arena.log1:SetText(text)
end

local function UpdateBars(e)
    if not play then return end
    -- Rockets and bombs update the bars when they land, which can be after a later
    -- event already did. Never go back to an older health value.
    local seq = e.seq or 0
    if seq < (play.barSeq or 0) then return end
    play.barSeq = seq
    for screenSide = 1, 2 do
        local side = play.order[screenSide]
        local mech = play.mechs[side]
        local hp = math.max(0, e["hp" .. side])
        local sh = e["sh" .. side] or 0
        arena.bars[screenSide]:SetMinMaxValues(0, mech.maxHp)
        arena.bars[screenSide]:SetValue(hp)
        arena.shields[screenSide]:SetMinMaxValues(0, mech.maxHp)
        arena.shields[screenSide]:SetValue(math.min(mech.maxHp, sh))
        arena.shields[screenSide]:SetShown(sh > 0)
        arena.hpText[screenSide]:SetText(string.format("%d / %d%s", hp, mech.maxHp, sh > 0 and ("  |cff99ddff+" .. sh .. "|r") or ""))
    end
end

---Shows one event of the fight.
local function ShowEvent(e)
    local p = play
    local speed = ns.db.speed
    local function Screen(side) return side == p.order[1] and 1 or 2 end
    local a = e.side ~= 0 and Screen(e.side) or nil
    local d = a and (3 - a) or nil
    local name = a and p.mechs[e.side].name
    local k = e.kind
    if k == "attack" or k == "bigattack" then
        Lunge(a, speed)
        Anim(arena.models[a], ANIM.attack)
        MechSounds(a, "attack")
        C_Timer.After(0.12 / speed, function()
            if play ~= p then return end
            Anim(arena.models[d], ANIM.wound)
            local crit = e.extra == "crit"
            Float(d, (crit and "CRIT " or "") .. e.value, 1, crit and 0.4 or 0.9, crit and 0.1 or 0.2, crit or k == "bigattack")
            if crit or k == "bigattack" then Shake() end
            if e.extra == "absorb" then Float(d, "absorbed", 0.6, 0.85, 1) end
            UpdateBars(e)
        end)
        if k == "bigattack" then Log(name .. " lands a huge hit for " .. e.value .. "!") end
        return
    elseif k == "dodge" or k == "miss" then
        Float(d, k == "dodge" and "Dodge!" or "Miss", 0.8, 0.8, 0.8)
        if e.extra == "mortar" then Shoot(a, d, "Interface\\Icons\\INV_Misc_Bomb_08", speed) end
        return
    elseif k == "chain" then
        Shoot(a, d, "Interface\\Icons\\Spell_Nature_Lightning", speed * 1.5, function()
            if play ~= p then return end
            Float(d, e.value, 0.5, 0.7, 1)
            UpdateBars(e)
        end)
        Play(ns.SOUNDS.lightning)
        return
    elseif k == "special" then
        local partName
        for _, part in pairs(p.mechs[e.side].parts) do
            if part.trait and part.trait.key == e.extra then partName = part.name end
        end
        local label = KIND_NAMES[e.extra]
        if label then
            local f = ns.FACTIONS[p.mechs[e.side].faction]
            Banner(label, unpack(f.color))
            Anim(arena.models[a], ANIM.cast)
        end
        if e.extra == "rockets" then Play(ns.SOUNDS.rockets) end
        if e.extra == "shrink" then
            Play(ns.SOUNDS.arcane)
            pcall(arena.models[d].SetModelScale, arena.models[d], 0.6)
            C_Timer.After(4 / speed, function() if play == p then pcall(arena.models[d].SetModelScale, arena.models[d], 1) end end)
            Log(name .. " fires the " .. (partName or "Shrink Ray") .. "!")
        elseif e.extra == "oil" then
            Float(d, "Oiled!", 0.3, 0.3, 0.3)
            Log(name .. " sprays oil everywhere.")
        elseif partName and label then
            Log(name .. ": " .. partName .. "!")
        end
        return
    elseif k == "stun" and e.extra == "stomp" then
        Float(d, "Stomped!", 1, 1, 0.4)
        Shake()
    elseif k == "rocket" or k == "mortar" or k == "bomb" or k == "deathray" or k == "chicken" or k == "sapper" or k == "stun" then
        local icons = {
            rocket = "Interface\\Icons\\INV_Gizmo_RocketLauncher", mortar = "Interface\\Icons\\INV_Misc_Bomb_08",
            bomb = "Interface\\Icons\\INV_Misc_Bomb_05", deathray = "Interface\\Icons\\INV_Gizmo_06",
            chicken = "Interface\\Icons\\Spell_Magic_PolymorphChicken", sapper = "Interface\\Icons\\INV_Gizmo_SuperSapperCharge",
            stun = "Interface\\Icons\\INV_Misc_Net_01",
        }
        local delay = (k == "rocket") and (math.random() * 0.25) or 0
        C_Timer.After(delay / speed, function()
            if play ~= p then return end
            Shoot(a, d, icons[k], speed, function()
                if play ~= p then return end
                Boom(d)
                if k ~= "chicken" and k ~= "stun" then Shake() end
                Float(d, e.value, 1, 0.55, 0.1, k == "sapper" or k == "deathray")
                if k == "stun" then Float(d, "Stunned!", 1, 1, 0.4) end
                if k == "mortar" or k == "bomb" or k == "sapper" then Play(ns.SOUNDS.fire) end
                if k == "deathray" then Play(ns.SOUNDS.arcane) end
                Anim(arena.models[d], ANIM.wound)
                UpdateBars(e)
            end)
        end)
        if k == "sapper" then Log(name .. " blows the Super Sapper Charge!") end
        return
    elseif k == "zap" then
        Float(d, e.value, 0.8, 0.5, 1)
    elseif k == "chill" then
        Float(d, "Chilled!", 0.5, 0.8, 1)
    elseif k == "crush" then
        Float(d, "Armor crushed!", 1, 0.6, 0.2)
    elseif k == "burn" then
        Float(d, e.value, 1, 0.5, 0)
    elseif k == "reflect" then
        Float(d, e.value .. " reflected", 0.8, 0.8, 0.8)
    elseif k == "heal" then
        Float(a, "+" .. e.value, 0.3, 1, 0.3)
        Play(ns.SOUNDS.heal)
        if e.extra == "salvage" then Log(name .. " patches itself up with scrap!") end
    elseif k == "shield" then
        Float(a, "Shield!", 0.6, 0.85, 1)
        Play(ns.SOUNDS.shield)
        Log(name .. "'s shield flickers back on.")
    elseif k == "selfdamage" then
        Float(a, e.value, 1, 0.2, 0.2)
        if e.extra == "overheat" then Float(a, "Overheat", 1, 0.3, 0.1) end
    elseif k == "backfire" then
        Float(a, "BACKFIRE " .. e.value, 1, 0.2, 0.8, true)
        Shake()
        Log("The Death Ray backfires on " .. name .. "!")
    elseif k == "bribed" then
        Float(a, "Bribed!", 1, 0.85, 0.2)
        Log(name .. " got paid to skip a turn.")
    elseif k == "ko" then
        local loser = a
        Anim(arena.models[loser], ANIM.death)
        MechSounds(loser, "death")
        Boom(loser)
        Shake()
        C_Timer.After(1.1, function() if play == p then Anim(arena.models[loser], ANIM.dead) end end)
        C_Timer.After(0.3, function() if play == p then Anim(arena.models[3 - loser], ANIM.roar) end end)
    elseif k == "timeout" then
        Banner("TIME!", 1, 1, 1)
    end
    UpdateBars(e)
end

local function BuildArena()
    local s = Screen("arena")
    arena.screen = s
    arena.bg = s:CreateTexture(nil, "BACKGROUND")
    arena.bg:SetAllPoints()
    arena.bg:SetTexCoord(0, 1, 0.24, 0.9)
    local shade = s:CreateTexture(nil, "BORDER")
    shade:SetPoint("BOTTOMLEFT")
    shade:SetPoint("BOTTOMRIGHT")
    shade:SetHeight(90)
    shade:SetColorTexture(0, 0, 0, 0.6)
    local topShade = s:CreateTexture(nil, "BORDER")
    topShade:SetPoint("TOPLEFT")
    topShade:SetPoint("TOPRIGHT")
    topShade:SetHeight(96)
    topShade:SetColorTexture(0, 0, 0, 0.5)

    for i = 1, 2 do
        local m = CreateFrame("PlayerModel", nil, s)
        m:SetSize(330, 300)
        m:SetPoint("BOTTOM", s, "BOTTOM", i == 1 and -190 or 190, 70)
        m.lunge = m:CreateAnimationGroup()
        m.lungeMove = m.lunge:CreateAnimation("Translation")
        m.lungeMove:SetOrder(1)
        m.lungeBack = m.lunge:CreateAnimation("Translation")
        m.lungeBack:SetOrder(2)
        arena.models[i] = m

        local x = i == 1 and 14 or -14
        local anchor = i == 1 and "TOPLEFT" or "TOPRIGHT"
        local icon = s:CreateTexture(nil, "ARTWORK")
        icon:SetSize(40, 40)
        icon:SetPoint(anchor, x, -10)
        arena["icon" .. i] = icon
        local name = Text(s, "GameFontNormalLarge", "")
        name:SetPoint(anchor, icon, i == 1 and "TOPRIGHT" or "TOPLEFT", i == 1 and 8 or -8, 0)
        name:SetWidth(300)
        name:SetJustifyH(i == 1 and "LEFT" or "RIGHT")
        name:SetWordWrap(false)
        arena.names[i] = name
        local bar = CreateFrame("StatusBar", nil, s, "BackdropTemplate")
        bar:SetSize(300, 18)
        bar:SetPoint(anchor, icon, i == 1 and "BOTTOMRIGHT" or "BOTTOMLEFT", i == 1 and 8 or -8, 0)
        bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        bar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
        bar:SetBackdropColor(0, 0, 0, 0.6)
        if i == 2 then bar:SetReverseFill(true) end
        arena.bars[i] = bar
        local shield = CreateFrame("StatusBar", nil, bar)
        shield:SetAllPoints()
        shield:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        shield:SetStatusBarColor(0.6, 0.85, 1, 0.55)
        if i == 2 then shield:SetReverseFill(true) end
        arena.shields[i] = shield
        local hp = Text(bar, "GameFontHighlightSmall", "")
        hp:SetPoint("CENTER")
        arena.hpText[i] = hp
        arena.partIcons[i] = {}
        for j = 1, 5 do
            local f = CreateFrame("Frame", nil, s)
            f:SetSize(22, 22)
            f:SetPoint(anchor, bar, i == 1 and "BOTTOMLEFT" or "BOTTOMRIGHT", (i == 1 and 1 or -1) * (j - 1) * 25, -6)
            f.icon = f:CreateTexture(nil, "ARTWORK")
            f.icon:SetAllPoints()
            Tooltip(f, function() return f.part and f.part.name end, function() return f.part and PartTooltipLines(f.part) end)
            arena.partIcons[i][j] = f
        end
    end

    arena.overlay = CreateFrame("Frame", nil, s)
    arena.overlay:SetAllPoints()
    arena.overlay:SetFrameLevel(s:GetFrameLevel() + 20)
    arena.boom = {}
    for i = 1, 2 do
        local b = arena.overlay:CreateTexture(nil, "OVERLAY")
        b:SetTexture("Interface\\Cooldown\\star4")
        b:SetBlendMode("ADD")
        b:SetVertexColor(1, 0.6, 0.2)
        b:SetSize(140, 140)
        b:SetPoint("CENTER", arena.models[i], "CENTER", 0, 20)
        b:Hide()
        b.anim = b:CreateAnimationGroup()
        local grow = b.anim:CreateAnimation("Scale")
        grow:SetScaleFrom(0.3, 0.3)
        grow:SetScaleTo(1.4, 1.4)
        grow:SetDuration(0.3)
        local fade = b.anim:CreateAnimation("Alpha")
        fade:SetFromAlpha(1)
        fade:SetToAlpha(0)
        fade:SetDuration(0.35)
        b.anim:SetScript("OnFinished", function() b:Hide() end)
        arena.boom[i] = b
    end

    arena.round = Text(arena.overlay, "GameFontNormalLarge", "")
    arena.round:SetPoint("TOP", 0, -12)
    arena.scoreText = Text(arena.overlay, "GameFontHighlightLarge", "")
    arena.scoreText:SetPoint("TOP", arena.round, "BOTTOM", 0, -4)
    arena.banner = Text(arena.overlay, "GameFontNormalHuge", "")
    arena.banner:SetPoint("CENTER", 0, 70)
    arena.bannerAnim = arena.banner:CreateAnimationGroup()
    local scale = arena.bannerAnim:CreateAnimation("Scale")
    scale:SetScaleFrom(1.6, 1.6)
    scale:SetScaleTo(1, 1)
    scale:SetDuration(0.2)
    local hold = arena.bannerAnim:CreateAnimation("Alpha")
    hold:SetFromAlpha(1)
    hold:SetToAlpha(0)
    hold:SetStartDelay(1.2)
    hold:SetDuration(0.4)
    arena.bannerAnim:SetScript("OnFinished", function() arena.banner:Hide() end)
    arena.big = Text(arena.overlay, "GameFontNormalHuge", "")
    arena.big:SetPoint("CENTER", 0, 20)
    arena.bigSub = Text(arena.overlay, "GameFontHighlightLarge", "")
    arena.bigSub:SetPoint("TOP", arena.big, "BOTTOM", 0, -8)

    arena.shake = s:CreateAnimationGroup()
    for i, dx in ipairs({ 6, -12, 10, -4 }) do
        local t = arena.shake:CreateAnimation("Translation")
        t:SetOffset(dx, (i % 2 == 0) and 3 or -3)
        t:SetDuration(0.04)
        t:SetOrder(i)
    end

    arena.log1 = Text(arena.overlay, "GameFontHighlight", "")
    arena.log1:SetPoint("BOTTOMLEFT", 14, 52)
    arena.log2 = Text(arena.overlay, "GameFontDisable", "")
    arena.log2:SetPoint("BOTTOMLEFT", 14, 32)
    arena.log3 = Text(arena.overlay, "GameFontDisableSmall", "")
    arena.log3:SetPoint("BOTTOMLEFT", 14, 14)

    local x = -10
    for _, sp in ipairs({ 4, 2, 1 }) do
        local b = Button(arena.overlay, sp .. "x", 44, 24, function() ns.db.speed = sp UI.RefreshSpeed() end)
        b:SetPoint("BOTTOMRIGHT", x, 46)
        arena["speed" .. sp] = b
        x = x - 48
    end
    arena.skip = Button(arena.overlay, "Skip fight", 110, 24, function() UI.SkipFight() end)
    arena.skip:SetPoint("BOTTOMRIGHT", -10, 14)
    arena.leave = Button(arena.overlay, "Leave", 80, 24, function() ns.Core.Forfeit() end)
    arena.leave:SetPoint("RIGHT", arena.skip, "LEFT", -8, 0)

    s:SetScript("OnUpdate", function(_, elapsed)
        local p = play
        if not p or p.done then return end
        p.time = p.time + elapsed * ns.db.speed
        local tick = p.time * Engine.TICKS
        while p.events[p.index] and p.events[p.index].t <= tick do
            ShowEvent(p.events[p.index])
            p.index = p.index + 1
        end
        if not p.events[p.index] and not p.ending then
            p.ending = true
            C_Timer.After(2 / ns.db.speed, function()
                if play == p then
                    p.done = true
                    p.onDone()
                end
            end)
        end
    end)
end

function UI.RefreshSpeed()
    for _, sp in ipairs({ 1, 2, 4 }) do
        local b = arena["speed" .. sp]
        if b then b:SetEnabled(ns.db.speed ~= sp) end
    end
end

function UI.SkipFight()
    local p = play
    if not p or p.done then return end
    local last = p.events[#p.events]
    p.index = #p.events + 1
    UpdateBars(last)
    if last.kind == "ko" then
        local screenSide = last.side == p.order[1] and 1 or 2
        Anim(arena.models[screenSide], ANIM.dead)
    end
end

function UI.PlayFight(match, mechs, events, info, onDone)
    UI.Open()
    Show("arena")
    local order = (match.side == 2) and { 2, 1 } or { 1, 2 }
    play = { match = match, mechs = mechs, events = events, info = info, onDone = onDone, index = 1, time = -1.2, order = order }
    for i, e in ipairs(events) do e.seq = i end
    arena.bg:SetTexture(ns.ArenaFor(match).texture)
    arena.big:SetText("")
    arena.bigSub:SetText("")
    arena.log1:SetText("")
    arena.log2:SetText("")
    arena.log3:SetText("")
    arena.round:SetText(string.format("Round %d", match.round))
    arena.scoreText:SetText(string.format("%d - %d", match.score[order[1]], match.score[order[2]]))
    for screenSide = 1, 2 do
        local mech = mechs[order[screenSide]]
        local f = ns.FACTIONS[mech.faction]
        SetModel(arena.models[screenSide], mech.display, screenSide == 1 and 0.75 or -0.75)
        pcall(arena.models[screenSide].SetModelScale, arena.models[screenSide], 1)
        arena["icon" .. screenSide]:SetTexture(f.icon)
        local nameText = arena.names[screenSide]
        nameText:SetFontObject(GameFontNormalLarge)
        nameText:SetText(Colored(mech.faction, mech.name))
        if nameText:GetStringWidth() > 300 then nameText:SetFontObject(GameFontNormal) end
        arena.bars[screenSide]:SetStatusBarColor(unpack(f.color))
        for j, slot in ipairs(ns.SLOTS) do
            local icon = arena.partIcons[screenSide][j]
            icon.part = mech.parts[slot]
            icon.icon:SetTexture(icon.part.icon)
        end
    end
    UpdateBars(events[1])
    arena.leave:SetShown(match.mode ~= "watch")
    UI.RefreshSpeed()
    Banner("FIGHT!", 1, 0.3, 0.1)
    PlaySound(SOUNDKIT and SOUNDKIT.PVP_THROUGH_QUEUE or 8459)
end

function UI.ShowBetweenRounds(match, winner)
    local name = ns.Short(match.names[winner])
    arena.big:SetText(Colored(match.factions[winner], name) .. " wins round " .. match.round .. "!")
    arena.bigSub:SetText("Next round starts in a moment...")
    arena.scoreText:SetText(string.format("%d - %d", match.score[play and play.order[1] or 1], match.score[play and play.order[2] or 2]))
end

function UI.ShowWatchWaiting(match)
    UI.Open()
    Show("arena")
    arena.big:SetText("Round " .. match.round)
    arena.bigSub:SetText("Waiting for both players to pick their parts...")
end

---------------------------------------------------------------------------
-- Result
---------------------------------------------------------------------------

local result = {}

local function BuildResult()
    local s = Screen("result")
    result.bg = s:CreateTexture(nil, "BACKGROUND")
    result.bg:SetAllPoints()
    result.bg:SetTexCoord(0, 1, 0.12, 0.88)
    local shade = s:CreateTexture(nil, "BORDER")
    shade:SetAllPoints()
    shade:SetColorTexture(0, 0, 0, 0.55)
    result.model = CreateFrame("PlayerModel", nil, s)
    result.model:SetSize(360, 320)
    result.model:SetPoint("CENTER", 0, -10)
    result.title = Text(s, "GameFontNormalHuge", "")
    result.title:SetPoint("TOP", 0, -30)
    result.sub = Text(s, "GameFontHighlightLarge", "")
    result.sub:SetPoint("TOP", result.title, "BOTTOM", 0, -10)
    result.again = Button(s, "Rematch", 150, 30, function()
        local match = ns.Core.match
        if not match then return UI.ShowLobby() end
        if match.mode == "bot" then ns.Core.StartBot(match.bot)
        elseif match.mode == "pvp" then ns.Core.Challenge(match.opponent)
        else UI.ShowLobby() end
    end)
    result.again:SetPoint("BOTTOM", -85, 20)
    local lobbyButton = Button(s, "Back to lobby", 150, 30, function() ns.Core.match = nil UI.ShowLobby() end)
    lobbyButton:SetPoint("BOTTOM", 85, 20)
end

function UI.ShowResult(match)
    play = nil
    UI.Open()
    Show("result")
    local w = match.winner
    result.bg:SetTexture(ns.ArenaFor(match).texture)
    local winnerName = Colored(match.factions[w], ns.Short(match.names[w]))
    if match.mode == "watch" then
        result.title:SetText(winnerName .. " wins the grudge!")
        result.again:Hide()
    elseif w == match.side then
        result.title:SetText("|cffffd100VICTORY!|r")
        result.again:Show()
        Play(ns.SOUNDS.victory)
    else
        result.title:SetText("|cffff4040DEFEAT|r")
        result.again:Show()
    end
    result.sub:SetText(string.format("%s  %d - %d  %s", ns.Short(match.names[1]), match.score[1], match.score[2], ns.Short(match.names[2])))
    -- the winning faction's mech takes a bow
    local winnerParts = ns.PARTS[match.factions[w]].chassis[1]
    SetModel(result.model, winnerParts.display, 0.4)
    C_Timer.After(0.2, function() Anim(result.model, ANIM.roar) end)
    if match.factions[w] == "goblin" then PlayOne(ns.SOUNDS.goblin.voice) else PlayOne(ns.SOUNDS.gnomeVoice) end
    UI.RefreshLobby()
end

---------------------------------------------------------------------------
-- Invite popup
---------------------------------------------------------------------------

local invite

function UI.ShowInvite(sender, faction, version, onAccept, onDecline)
    if not invite then
        invite = CreateFrame("Frame", "GnomishGrudgeMatchInvite", UIParent, "BackdropTemplate")
        invite:SetSize(340, 150)
        invite:SetPoint("TOP", 0, -140)
        invite:SetFrameStrata("DIALOG")
        Backdrop(invite, 1, true)
        invite.icon = invite:CreateTexture(nil, "ARTWORK")
        invite.icon:SetSize(48, 48)
        invite.icon:SetPoint("TOPLEFT", 18, -18)
        invite.text = Text(invite, "GameFontHighlight", "")
        invite.text:SetPoint("TOPLEFT", invite.icon, "TOPRIGHT", 10, 0)
        invite.text:SetWidth(250)
        invite.text:SetJustifyH("LEFT")
        invite.accept = Button(invite, "Accept", 120, 26)
        invite.accept:SetPoint("BOTTOMLEFT", 30, 16)
        invite.decline = Button(invite, "Decline", 120, 26)
        invite.decline:SetPoint("BOTTOMRIGHT", -30, 16)
        invite.timer = CreateFrame("StatusBar", nil, invite)
        invite.timer:SetSize(280, 6)
        invite.timer:SetPoint("BOTTOM", 0, 50)
        invite.timer:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
        invite.timer:SetStatusBarColor(1, 0.7, 0.1)
        invite.timer:SetMinMaxValues(0, 40)
        invite:SetScript("OnUpdate", function(self)
            local left = 40 - (GetTime() - self.started)
            self.timer:SetValue(math.max(0, left))
            if left <= 0 then self.onDecline() self:Hide() end
        end)
    end
    invite.icon:SetTexture(ns.FACTIONS[faction].icon)
    invite.text:SetText(string.format("%s challenges you to a |cffffd100Gnomish Grudge Match|r with the %s!\n\nYou fight as the %s.",
        Colored(faction, ns.Short(sender)), ns.FACTIONS[faction].name, ns.FACTIONS[ns.db.faction].name))
    invite.started = GetTime()
    invite.onDecline = onDecline
    invite.accept:SetScript("OnClick", function() invite:Hide() onAccept() end)
    invite.decline:SetScript("OnClick", function() invite:Hide() onDecline() end)
    invite:Show()
    PlaySound(SOUNDKIT and SOUNDKIT.READY_CHECK or 8960)
end

function UI.HideInvite()
    if invite then invite:Hide() end
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

function UI.CreateMinimapButton()
    local b = CreateFrame("Button", "GnomishGrudgeMatchMinimapButton", Minimap)
    b:SetSize(31, 31)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("AnyUp")
    b:RegisterForDrag("LeftButton")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture("Interface\\Icons\\INV_Gizmo_02")
    local border = b:CreateTexture(nil, "OVERLAY")
    border:SetSize(53, 53)
    border:SetPoint("TOPLEFT")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    local function Place()
        local angle = math.rad(ns.db.minimap.angle)
        b:ClearAllPoints()
        b:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * 80, math.sin(angle) * 80)
    end
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            ns.db.minimap.angle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
            Place()
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            ns.Core.StartBot("normal")
        else
            UI.Toggle()
        end
    end)
    Tooltip(b, "Gnomish Grudge Match", { "Gnome and goblin mechs battle it out.", "|cffffd100Click:|r open the lobby", "|cffffd100Right-click:|r quick fight vs a bot", "|cffffd100Drag:|r move this button" })
    Place()
    b:SetShown(not ns.db.minimap.hide)
    UI.minimapButton = b
end

function UI.BuildScreens()
    BuildLobby()
    BuildWaiting()
    BuildVersus()
    BuildWorkshop()
    BuildArena()
    BuildResult()
end
