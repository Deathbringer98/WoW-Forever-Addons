-- Gnomish Grudge Match: bot opponents.
--   easy   (Apprentice Tinker): random parts.
--   normal (Chief Mekgineer):   the build with the best rating, with a little variety.
--   hard   (Trade Prince):      tests its best builds in real fights against builds you could make, picks the winner.
local _, ns = ...
local AI = {}
ns.AI = AI
local Engine = ns.Engine

---Every possible pick string ("11111" .. "33333") with its mech and rating, best first.
function AI.RankedBuilds(offers, name, faction)
    local list = {}
    for a = 1, 3 do for b = 1, 3 do for c = 1, 3 do for d = 1, 3 do for e = 1, 3 do
        local picks = a .. b .. c .. d .. e
        local mech = Engine.BuildMech(Engine.PartsFromPicks(offers, picks), name, faction)
        list[#list + 1] = { picks = picks, mech = mech, rating = Engine.Rating(mech) }
    end end end end end
    table.sort(list, function(x, y)
        if x.rating ~= y.rating then return x.rating > y.rating end
        return x.picks < y.picks
    end)
    return list
end

---Chooses picks. With yield set (a function), the hard bot pauses between fights so the game never stutters.
---@return string picks
function AI.Choose(difficulty, myOffers, theirOffers, myFaction, theirFaction, rng, yield)
    if difficulty == "easy" then
        local picks = ""
        for _ = 1, 5 do picks = picks .. rng:Int(3) end
        return picks
    end
    local mine = AI.RankedBuilds(myOffers, "bot", myFaction)
    if difficulty == "normal" then
        return mine[rng:Int(3)].picks
    end
    -- hard: the top 16 builds, each tested against 8 likely enemy builds
    local theirs = AI.RankedBuilds(theirOffers, "you", theirFaction)
    local samples = {}
    for i = 1, 5 do samples[#samples + 1] = theirs[i].mech end
    for _ = 1, 3 do samples[#samples + 1] = theirs[rng:Int(#theirs)].mech end
    local best, bestScore = mine[1].picks, -1
    for i = 1, math.min(16, #mine) do
        local score = 0
        for j, enemy in ipairs(samples) do
            local winner, _, info = Engine.Fight(mine[i].mech, enemy, 1000 + i * 37 + j, false)
            if winner == 1 then score = score + 1000 + info[1] else score = score - info[2] end
        end
        if score > bestScore then best, bestScore = mine[i].picks, score end
        if yield then yield() end
    end
    return best
end
