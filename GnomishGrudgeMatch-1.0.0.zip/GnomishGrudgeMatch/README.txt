Gnomish Grudge Match 1.0.0 - World of Warcraft: Forever (Interface 16001)
========================================================================

Gnomeregan tinkers against Venture Co. goblins. Build a battle mech from
salvage, then watch it fight. Play against a bot, challenge another player,
and let your group or guild watch.

INSTALL
Copy the GnomishGrudgeMatch folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

OPEN IT
Click the gizmo button on the minimap, pick it from the minimap addon menu,
or type /grudge. Right-click the minimap button for a quick fight against a bot.

HOW A MATCH WORKS
1. Pick your side: Gnomeregan Tinkers or Venture Co. Goblins.
2. Each round you get salvage: 3 choices for each of 5 parts.
     Chassis     the mech's body and legs (health, speed, dodge, and its look)
     Arms        the main weapon
     Power Core  a passive bonus
     Cannon      a special weapon that fires on its own
     Plating     armor and defensive tricks
   Hover any part to see exactly what it does. The panel on the right shows
   your mech and its stats as you pick. The Scouting report shows the parts
   your rival was offered, so you can guess their build and counter it.
3. Press Lock in. Then the two mechs fight on their own, with real gnome
   spider tanks, mechanostriders, steam tonks and goblin shredders, rockets,
   death rays, battle chickens, oil slicks and sapper charges.
4. Best of 3 rounds wins the grudge. Fights can be watched at 1x, 2x or 4x,
   or skipped.

BOTS
  Apprentice Tinker  picks parts more or less at random
  Chief Mekgineer    builds a solid mech every time
  Trade Prince       tests builds against yours before choosing

PLAYING ANOTHER PLAYER
Target them and press "Challenge my target", type their name, or use the
buttons for your party members. They need Gnomish Grudge Match too, and
must be on your faction (the game only lets addons talk to your own faction).
Both players' picks are sealed when you lock in and only shown once both have
locked, so nobody can change their parts after seeing yours. If someone leaves
or doesn't lock in, the other player wins.

WATCHING
When someone in your group (or your guild, if "Guild can watch" is on) starts
a player match, it shows up in the lobby under "Watch a match".

Your wins, losses and biggest grudge are saved.

CREDITS AND LICENSE
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Released under the GNU GPL v3. Mech models, sounds and art are Blizzard's,
used from the game client.
