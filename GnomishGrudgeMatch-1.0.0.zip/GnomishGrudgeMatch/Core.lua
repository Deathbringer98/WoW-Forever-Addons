-- Gnomish Grudge Match: matches, rounds, challenges and spectating.
local addonName, ns = ...
local Core = {}
ns.Core = Core
local Engine, AI, Net = ns.Engine, ns.AI, ns.Net

local PICK_TIME = 75        -- seconds to pick parts
local INVITE_TIME = 40      -- seconds an invite stays open
local WINS_NEEDED = 2       -- best of 3

local defaults = {
    faction = "gnome", speed = 1, sound = true, guildWatch = true,
    minimap = { angle = 200, hide = false },
    record = { wins = 0, losses = 0, bots = {}, rivals = {} },
}

function ns.Print(msg) print("|cffffd100Gnomish Grudge Match:|r " .. msg) end
function ns.Debug(msg) if ns.db and ns.db.debug then ns.Print("|cff999999" .. msg .. "|r") end end

local function Copy(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            dst[k] = type(dst[k]) == "table" and dst[k] or {}
            Copy(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

local function FullName(name)
    if not name or name == "" then return nil end
    if name:find("-", 1, true) then return name end
    local realm = GetNormalizedRealmName and GetNormalizedRealmName()
    return realm and (name .. "-" .. realm) or name
end
ns.FullName = FullName

function ns.Short(name)
    if not name then return "?" end
    return Ambiguate and Ambiguate(name, "none") or name:gsub("%-.*", "")
end

local function MyName() return FullName(UnitName("player")) end
local function Random() return math.random(100000000, 999999999) end

---The current match, or nil. Only one at a time.
Core.match = nil
---Matches other players are fighting that we can watch: liveMatches[id] = {names, factions, seed, rounds = {}, from}
Core.live = {}

---------------------------------------------------------------------------
-- Rounds
---------------------------------------------------------------------------

local function OtherFaction(f) return f == "gnome" and "goblin" or "gnome" end

local function ArenaFor(match)
    return ns.ARENAS[(match.seed % #ns.ARENAS) + 1]
end
ns.ArenaFor = ArenaFor

---Offers for both sides of a round.
local function DealRound(match)
    match.offers = {
        Engine.Offers(match.seed, match.round, 1, match.factions[1]),
        Engine.Offers(match.seed, match.round, 2, match.factions[2]),
    }
    match.picks = {}
    match.commits = {}
    match.locked = false
end

---Runs the fight for the current round from both sides' picks and plays it.
local function Fight(match)
    local mechs = {}
    for side = 1, 2 do
        local parts = Engine.PartsFromPicks(match.offers[side], match.picks[side])
        mechs[side] = Engine.BuildMech(parts, ns.Short(match.names[side]), match.factions[side])
    end
    local winner, events, info = Engine.Fight(mechs[1], mechs[2], match.seed + match.round * 31337, true)
    match.state = "fight"
    if match.mode == "pvp" and match.side == 1 then
        Net.Broadcast("P", match.id, match.round, match.picks[1], match.picks[2])
    end
    ns.UI.PlayFight(match, mechs, events, info, function()
        Core.RoundOver(match, winner)
    end)
end

function Core.RoundOver(match, winner)
    if Core.match ~= match then return end
    match.score[winner] = match.score[winner] + 1
    if match.score[winner] >= WINS_NEEDED then
        match.state = "over"
        match.winner = winner
        Core.Finish(match)
        return
    end
    match.state = "between"
    ns.UI.ShowBetweenRounds(match, winner)
    C_Timer.After(4, function()
        if Core.match ~= match or match.state ~= "between" then return end
        match.round = match.round + 1
        Core.StartDraft(match)
    end)
end

function Core.StartDraft(match)
    if match.mode == "watch" then
        match.state = "waitpicks"
        ns.UI.ShowWatchWaiting(match)
        Core.TryWatchRound(match)
        return
    end
    DealRound(match)
    match.state = "draft"
    match.deadline = GetTime() + PICK_TIME
    ns.UI.ShowWorkshop(match)
    if match.mode == "bot" then
        -- The bot thinks while you do. The hard bot spreads its test fights over a few frames.
        local side = 3 - match.side
        local rng = Engine.NewRng(match.seed + match.round * 17)
        local co = coroutine.create(function()
            return AI.Choose(match.bot, match.offers[side], match.offers[match.side], match.factions[side], match.factions[match.side], rng, coroutine.yield)
        end)
        local function Step()
            if Core.match ~= match then return end
            local ok, picks = coroutine.resume(co)
            if not ok then
                ns.Debug("bot error: " .. tostring(picks))
                picks = "11111"
            end
            if coroutine.status(co) == "dead" then
                match.picks[side] = picks
                if match.locked then Fight(match) end
            else
                C_Timer.After(0, Step)
            end
        end
        C_Timer.After(0.1, Step)
    end
end

---The player locks in their parts.
function Core.Lock(picks)
    local match = Core.match
    if not match or match.state ~= "draft" or match.locked then return end
    match.locked = true
    match.picks[match.side] = picks
    if match.mode == "bot" then
        if match.picks[3 - match.side] then
            Fight(match)
        else
            ns.UI.SetWorkshopStatus(ns.BOTS[match.bot].name .. " is still tinkering...")
        end
        return
    end
    match.salt = tostring(Random())
    local hash = Engine.Hash(picks .. match.salt .. match.id .. match.round)
    match.commits[match.side] = hash
    Net.Whisper(match.opponent, "K", match.id, match.round, hash)
    ns.UI.SetWorkshopStatus("Locked in. Waiting for " .. ns.Short(match.opponent) .. "...")
    Core.MaybeReveal(match)
end

---Reveal our picks once we have both commitments, so neither side can change after seeing the other.
function Core.MaybeReveal(match)
    if match.revealed or not (match.commits[1] and match.commits[2]) then return end
    match.revealed = true
    Net.Whisper(match.opponent, "R", match.id, match.round, match.picks[match.side], match.salt)
    Core.MaybeFight(match)
end

function Core.MaybeFight(match)
    if match.state == "draft" and match.picks[1] and match.picks[2] and match.revealed then
        match.revealed = false
        Fight(match)
    end
end

---Timer: called every second by the workshop screen.
function Core.CheckDeadline()
    local match = Core.match
    if not match or match.state ~= "draft" then return end
    if not match.locked and GetTime() >= match.deadline then
        ns.UI.AutoLock()
    end
    if match.mode == "pvp" and match.locked and GetTime() >= match.deadline + 45 then
        ns.Print(ns.Short(match.opponent) .. " didn't lock in. You win by forfeit.")
        match.score[match.side] = WINS_NEEDED
        match.winner = match.side
        match.state = "over"
        Core.Finish(match)
    end
end

function Core.Finish(match)
    local won = match.winner == match.side
    local rec = ns.db.record
    if match.mode ~= "watch" then
        if won then rec.wins = rec.wins + 1 else rec.losses = rec.losses + 1 end
        local key = match.mode == "bot" and match.bot or ns.Short(match.opponent)
        local book = match.mode == "bot" and rec.bots or rec.rivals
        book[key] = book[key] or { w = 0, l = 0 }
        if won then book[key].w = book[key].w + 1 else book[key].l = book[key].l + 1 end
    end
    if match.mode == "pvp" and match.side == 1 then
        Net.Broadcast("E", match.id, match.winner)
    end
    ns.UI.ShowResult(match)
end

---------------------------------------------------------------------------
-- Starting matches
---------------------------------------------------------------------------

local function NewMatch(mode, side, names, factions, seed, id)
    local match = {
        mode = mode, side = side, names = names, factions = factions, seed = seed, id = id or tostring(Random()),
        round = 1, score = { 0, 0 }, state = "starting",
    }
    Core.match = match
    return match
end

function Core.StartBot(difficulty, botFaction)
    if Core.match and Core.match.state ~= "over" then Core.Forfeit(true) end
    local me = ns.db.faction
    local them = botFaction or OtherFaction(me)
    local names = ns.BOT_NAMES[them]
    local botName = names[math.random(#names)] .. " (" .. ns.BOTS[difficulty].name .. ")"
    local match = NewMatch("bot", 1, { MyName(), botName }, { me, them }, Random())
    match.bot = difficulty
    match.opponent = botName
    ns.UI.ShowVersus(match, function() Core.StartDraft(match) end)
end

function Core.Challenge(target)
    target = FullName(target)
    if not target or target == MyName() then
        ns.Print("Pick another player to challenge.")
        return
    end
    if Core.match and Core.match.state ~= "over" then
        ns.Print("Finish or leave your current match first.")
        return
    end
    local seedHalf = Random()
    local match = NewMatch("pvp", 1, { MyName(), target }, { ns.db.faction, nil }, 0)
    match.opponent = target
    match.seedHalf = seedHalf
    match.state = "inviting"
    Net.Whisper(target, "C", match.id, ns.db.faction, ns.VERSION, Engine.Hash(tostring(seedHalf)))
    ns.UI.ShowWaitingForAnswer(match)
    C_Timer.After(INVITE_TIME, function()
        if Core.match == match and match.state == "inviting" then
            Core.match = nil
            ns.Print("No answer from " .. ns.Short(target) .. ". They need Gnomish Grudge Match installed, and must be on your faction.")
            ns.UI.ShowLobby()
        end
    end)
end

function Core.Forfeit(silent)
    local match = Core.match
    if not match then return end
    if match.mode == "pvp" and match.opponent and match.state ~= "over" then
        Net.Whisper(match.opponent, "Q", match.id)
        if match.state ~= "inviting" and not silent then
            match.winner = 3 - match.side
            match.state = "over"
            Core.Finish(match)
            return
        end
    end
    Core.match = nil
    if not silent then ns.UI.ShowLobby() end
end

function Core.Watch(id)
    local live = Core.live[id]
    if not live then return end
    if Core.match and Core.match.state ~= "over" and Core.match.mode ~= "watch" then
        ns.Print("You can't watch while you're in a match.")
        return
    end
    local match = NewMatch("watch", 1, live.names, live.factions, live.seed, id)
    match.live = live
    ns.UI.ShowVersus(match, function() Core.StartDraft(match) end)
end

---Spectators: plays the next round once its picks have arrived.
function Core.TryWatchRound(match)
    local picks = match.live.rounds[match.round]
    if not picks or match.state ~= "waitpicks" then return end
    DealRound(match)
    match.picks = { picks[1], picks[2] }
    Fight(match)
end

---------------------------------------------------------------------------
-- Messages
---------------------------------------------------------------------------

local pendingInvites = {}

local handlers = {}

-- C: challenge. fields: id, faction, version, seedHash
function handlers.C(f, sender)
    local id, faction, version, seedHash = f[1], f[2], f[3], f[4]
    if not ns.FACTIONS[faction] then return end
    if Core.match and Core.match.state ~= "over" then
        Net.Whisper(sender, "D", id, "busy")
        return
    end
    pendingInvites[id] = { from = sender, faction = faction, seedHash = seedHash, time = GetTime() }
    ns.UI.ShowInvite(sender, faction, version, function()
        local invite = pendingInvites[id]
        if not invite or GetTime() - invite.time > INVITE_TIME then
            ns.Print("That challenge ran out.")
            return
        end
        pendingInvites[id] = nil
        local half = Random()
        local match = NewMatch("pvp", 2, { sender, MyName() }, { faction, ns.db.faction }, 0, id)
        match.opponent = sender
        match.seedHalf = half
        match.seedHash = invite.seedHash
        match.state = "accepted"
        Net.Whisper(sender, "A", id, ns.db.faction, half)
        ns.UI.ShowWaitingForAnswer(match)
    end, function()
        pendingInvites[id] = nil
        Net.Whisper(sender, "D", id, "no")
    end)
end

-- A: accepted. fields: id, faction, theirSeedHalf
function handlers.A(f, sender)
    local match = Core.match
    if not match or match.id ~= f[1] or match.state ~= "inviting" or ns.FullName(sender) ~= match.opponent then return end
    if not ns.FACTIONS[f[2]] then return end
    match.factions[2] = f[2]
    match.seed = Engine.CombineSeed(match.seedHalf, f[3])
    Net.Whisper(match.opponent, "S", match.id, match.seedHalf)
    Net.Broadcast("W", match.id, match.names[1], match.factions[1], match.names[2], match.factions[2], match.seed)
    ns.UI.ShowVersus(match, function() Core.StartDraft(match) end)
end

-- S: start. fields: id, challengerSeedHalf
function handlers.S(f, sender)
    local match = Core.match
    if not match or match.id ~= f[1] or match.state ~= "accepted" then return end
    if Engine.Hash(f[2]) ~= match.seedHash then
        ns.Print("The match couldn't start: the seed didn't check out. Try again.")
        Core.match = nil
        ns.UI.ShowLobby()
        return
    end
    match.seed = Engine.CombineSeed(f[2], match.seedHalf)
    ns.UI.ShowVersus(match, function() Core.StartDraft(match) end)
end

-- D: declined
function handlers.D(f, sender)
    local match = Core.match
    if match and match.id == f[1] and match.state == "inviting" then
        Core.match = nil
        ns.Print(ns.Short(sender) .. (f[2] == "busy" and " is already in a match." or " declined your challenge."))
        ns.UI.ShowLobby()
    end
end

-- Q: opponent left
function handlers.Q(f, sender)
    local match = Core.match
    if match and match.id == f[1] and match.mode == "pvp" and match.state ~= "over" then
        ns.Print(ns.Short(sender) .. " left the match. You win!")
        match.winner = match.side
        match.state = "over"
        Core.Finish(match)
    end
    pendingInvites[f[1]] = nil
    ns.UI.HideInvite(f[1])
end

-- K: commitment. fields: id, round, hash
function handlers.K(f, sender)
    local match = Core.match
    if not match or match.id ~= f[1] or tonumber(f[2]) ~= match.round then return end
    match.commits[3 - match.side] = f[3]
    if match.locked then Core.MaybeReveal(match) end
end

-- R: reveal. fields: id, round, picks, salt
function handlers.R(f, sender)
    local match = Core.match
    if not match or match.id ~= f[1] or tonumber(f[2]) ~= match.round then return end
    local side = 3 - match.side
    local picks, salt = f[3], f[4]
    if not picks:match("^[123][123][123][123][123]$") or Engine.Hash(picks .. salt .. match.id .. match.round) ~= match.commits[side] then
        ns.Print(ns.Short(sender) .. "'s parts didn't match what they locked in. Match cancelled.")
        Core.match = nil
        ns.UI.ShowLobby()
        return
    end
    match.picks[side] = picks
    Core.MaybeFight(match)
end

-- W: a match started that we can watch. fields: id, name1, faction1, name2, faction2, seed
function handlers.W(f, sender, channel)
    if ns.FullName(sender) == MyName() then return end
    if not (ns.FACTIONS[f[3]] and ns.FACTIONS[f[5]]) then return end
    Core.live[f[1]] = { names = { f[2], f[4] }, factions = { f[3], f[5] }, seed = tonumber(f[6]), rounds = {},
        from = channel, started = GetTime() }
    local inMatch = Core.match and Core.match.state ~= "over"
    if not inMatch then
        ns.Print(string.format("%s and %s started a grudge match! Open /grudge to watch.", ns.Short(f[2]), ns.Short(f[4])))
    end
    ns.UI.RefreshLobby()
end

-- P: picks of a round for spectators. fields: id, round, picks1, picks2
function handlers.P(f, sender)
    local live = Core.live[f[1]]
    if not live then return end
    live.rounds[tonumber(f[2])] = { f[3], f[4] }
    local match = Core.match
    if match and match.mode == "watch" and match.id == f[1] then Core.TryWatchRound(match) end
end

-- E: a watched match ended
function handlers.E(f, sender)
    local live = Core.live[f[1]]
    if live then live.over = true end
    ns.UI.RefreshLobby()
end

function Core.OnMessage(kind, fields, sender, channel)
    local handler = handlers[kind]
    if handler then handler(fields, sender, channel) end
end

---------------------------------------------------------------------------
-- Start-up and commands
---------------------------------------------------------------------------

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent", function(self, _, name)
    if name ~= addonName then return end
    self:UnregisterEvent("ADDON_LOADED")
    GnomishGrudgeMatchDB = type(GnomishGrudgeMatchDB) == "table" and GnomishGrudgeMatchDB or {}
    Copy(defaults, GnomishGrudgeMatchDB)
    ns.db = GnomishGrudgeMatchDB
    Net.Init(Core.OnMessage)
    ns.UI.CreateMinimapButton()
end)

SLASH_GNOMISHGRUDGEMATCH1 = "/grudge"
SLASH_GNOMISHGRUDGEMATCH2 = "/ggm"
SlashCmdList.GNOMISHGRUDGEMATCH = function(message)
    local command, arg = (message or ""):match("^%s*(%S*)%s*(.-)%s*$")
    command = command:lower()
    if command == "challenge" or command == "duel" then
        Core.Challenge(arg ~= "" and arg or (UnitIsPlayer("target") and GetUnitName("target", true)))
    elseif command == "bot" then
        Core.StartBot(ns.BOTS[arg] and arg or "normal")
    elseif command == "watch" then
        for id, live in pairs(Core.live) do
            if not live.over then Core.Watch(id) return end
        end
        ns.Print("No match to watch right now.")
    else
        ns.UI.Toggle()
    end
end

function GnomishGrudgeMatch_OnCompartmentClick()
    ns.UI.Toggle()
end

function GnomishGrudgeMatch_OnCompartmentEnter(_, button)
    GameTooltip:SetOwner(button or UIParent, "ANCHOR_LEFT")
    GameTooltip:SetText("Gnomish Grudge Match", 1, 0.82, 0)
    GameTooltip:AddLine("Click to open the lobby.", 1, 1, 1)
    GameTooltip:Show()
end
