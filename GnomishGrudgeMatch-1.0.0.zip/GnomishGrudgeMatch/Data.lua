-- Gnomish Grudge Match: factions, salvage parts, arenas, bots and sounds.
local _, ns = ...

ns.VERSION = "1.0.0"
ns.SLOTS = { "chassis", "arms", "core", "cannon", "plating" }
ns.SLOT_NAMES = { chassis = "Chassis", arms = "Arms", core = "Power Core", cannon = "Cannon", plating = "Plating" }
ns.SLOT_HELP = {
    chassis = "The frame and legs. Sets the mech's look, health, speed and dodge.",
    arms = "The main weapon. Every basic attack uses it.",
    core = "The engine. A passive bonus for the whole fight.",
    cannon = "A special weapon that fires on its own every few seconds.",
    plating = "Armor and defensive tricks.",
}

local function I(name) return "Interface\\Icons\\" .. name end

ns.FACTIONS = {
    gnome = {
        key = "gnome", name = "Gnomeregan Tinkers", short = "Gnome",
        color = { 0.35, 0.75, 1 }, hex = "ff59bfff",
        icon = I("INV_Misc_Head_Gnome_01"),
        motto = "Precision, science and a frankly irresponsible amount of arcane power.",
    },
    goblin = {
        key = "goblin", name = "Venture Co. Goblins", short = "Goblin",
        color = { 0.45, 0.9, 0.3 }, hex = "ff73e64d",
        icon = I("INV_Gizmo_GoblinBoomBox_01"),
        motto = "Time is money, friend. Saws, rockets and more explosions than strictly necessary.",
    },
}

-- Parts. Stats add up; "trait" is a special rule handled by the battle engine.
-- hp: health, armor: % damage cut, power: damage per hit (arms), interval: seconds added to the attack timer,
-- speed: attack speed (4% per point), dodge and crit: %.
ns.PARTS = {
    gnome = {
        chassis = {
            { id = "g_spider", name = "Spider Tank Frame", icon = I("INV_Gizmo_02"), display = 5926, hp = 380, speed = 0, dodge = 5,
                text = "A sturdy all-rounder from the Gnomeregan motor pool." },
            { id = "g_strider", name = "Mechanostrider Legs", icon = I("Ability_Mount_MechaStrider"), display = 6569, hp = 300, speed = 3, dodge = 12,
                text = "Fast and hard to hit, but light." },
            { id = "g_pounder", name = "Pounder Hull", icon = I("INV_Gizmo_08"), display = 6980, hp = 470, speed = -2, dodge = 0,
                text = "Heavy and slow. Built to take a beating." },
            { id = "g_tonk", name = "Steam Tonk Treads", icon = I("INV_Gizmo_GoblingTonkController"), display = 15381, hp = 340, speed = 1, dodge = 8,
                trait = { key = "ram", mult = 2.5 }, text = "Tonk Ram: the first attack hits for 2.5x damage." },
            { id = "g_alarm", name = "Alarm-o-Bot Body", icon = I("INV_Gizmo_05"), display = 6888, hp = 320, speed = 2, dodge = 10,
                trait = { key = "alarm", below = 0.5, pct = 25 }, text = "Red Alert: +25% damage below half health." },
        },
        arms = {
            { id = "g_welder", name = "Arc Welder", icon = I("Spell_Nature_Lightning"), power = 52,
                trait = { key = "chain", chance = 25, mult = 0.6 }, text = "Chain Lightning: 25% chance for an extra zap of 60% damage." },
            { id = "g_pistons", name = "Mithril Grip Pistons", icon = I("INV_Ingot_Mithril"), power = 66, interval = 0.3,
                text = "Big, slow punches." },
            { id = "g_drill", name = "Gyromatic Drill", icon = I("INV_Gizmo_RocketBoot_01"), power = 46, interval = -0.3,
                trait = { key = "pen", pct = 35 }, text = "Bores through 35% of armor. Fast." },
            { id = "g_frost", name = "Frost Coil Projector", icon = I("Spell_Frost_FrostBolt02"), power = 46,
                trait = { key = "chill", chance = 30, slow = 30, dur = 3 }, text = "Chill: 30% chance to slow enemy attacks by 30% for 3 sec." },
            { id = "g_wrench", name = "Mekgineer's Wrench", icon = I("INV_Misc_Wrench_01"), power = 56, crit = 12,
                text = "+12% critical strike chance." },
        },
        core = {
            { id = "g_crystal", name = "Arcane Power Crystal", icon = I("INV_Misc_Orb_05"), powerPct = 18,
                text = "+18% damage." },
            { id = "g_gyro", name = "Gyro-Stabilized Core", icon = I("INV_Misc_Gear_03"), speed = 4, dodge = 3,
                text = "+4 speed and +3% dodge." },
            { id = "g_repair", name = "Repair-Bot Bay", icon = I("INV_Gizmo_03"), trait = { key = "repair", pct = 2.5, every = 5 }, text = "Repair-Bot: heals 2.5% max health every 5 sec." },
            { id = "g_dynamo", name = "Overcharged Dynamo", icon = I("INV_Battery_02"),
                trait = { key = "nth", n = 4, mult = 2 }, text = "Every 4th attack deals double damage." },
            { id = "g_truesilver", name = "Truesilver Transformer", icon = I("INV_Ingot_08"), crit = 20, critMult = 0.35,
                text = "+20% crit chance and crits hit 35% harder." },
        },
        cannon = {
            { id = "g_shrink", name = "Shrink Ray", icon = I("INV_Gizmo_09"), first = 3, cd = 8,
                trait = { key = "shrink", pct = 40, dur = 5, dmg = 30 }, text = "Every 8 sec: 30 damage and shrinks the enemy, -40% damage for 5 sec." },
            { id = "g_deathray", name = "Gnomish Death Ray", icon = I("INV_Gizmo_06"), first = 5, cd = 9,
                trait = { key = "deathray", dmg = 170, backfire = 20, self = 70 }, text = "Every 9 sec: 170 damage. 20% chance it backfires for 70 on you." },
            { id = "g_chicken", name = "Battle Chicken Hatch", icon = I("Spell_Magic_PolymorphChicken"), first = 1.5,
                trait = { key = "chicken", dmg = 17, every = 1.5 }, text = "Releases a Battle Chicken that pecks for 17 every 1.5 sec." },
            { id = "g_net", name = "Net-o-Matic Projector", icon = I("INV_Misc_Net_01"), first = 4, cd = 9,
                trait = { key = "stun", dur = 2, dmg = 40 }, text = "Every 9 sec: 40 damage and nets the enemy, stunned for 2 sec." },
            { id = "g_bomb", name = "Arcane Bomb Launcher", icon = I("INV_Misc_Bomb_05"), first = 4, cd = 9,
                trait = { key = "bomb", dmg = 105, pierce = true }, text = "Every 9 sec: 105 damage that ignores armor." },
        },
        plating = {
            { id = "g_mithril", name = "Mithril Plating", icon = I("INV_Chest_Plate04"), armor = 25,
                text = "25% armor." },
            { id = "g_arcshield", name = "Arcane Shield Emitter", icon = I("Spell_Holy_PowerWordShield"),
                trait = { key = "shield", amount = 180, recharge = 0.5 }, text = "Starts with a 180 shield, renewed once at half health." },
            { id = "g_rivets", name = "Thorium Rivets", icon = I("INV_Ingot_07"), armor = 14,
                trait = { key = "reflect", pct = 18 }, text = "14% armor and reflects 18% of damage taken from attacks." },
            { id = "g_cloak", name = "Cloaking Field Plates", icon = I("Spell_Shadow_AntiMagicShell"), dodge = 13,
                trait = { key = "cloak", dur = 4 }, text = "+13% dodge, and nothing can hit it for the first 4 sec." },
            { id = "g_bulkhead", name = "Truesilver Bulkhead", icon = I("INV_Shield_05"), hp = 210, armor = 8,
                text = "+210 health and 8% armor." },
        },
    },
    goblin = {
        chassis = {
            { id = "b_shredder", name = "Venture Co. Shredder", icon = I("INV_Gizmo_01"), display = 1269, hp = 400, speed = 0, dodge = 3,
                text = "The classic logging shredder. Reliable, loud, smells of oil." },
            { id = "b_stomper", name = "Steamwheedle Stomper", icon = I("INV_Gizmo_FelIronCasing"), display = 1303, hp = 450, speed = -1, dodge = 0,
                trait = { key = "stomp", dur = 1.5 }, text = "Stomp: the first hit stuns the enemy for 1.5 sec." },
            { id = "b_buzzer", name = "Bilgewater Buzzer", icon = I("INV_Gizmo_RocketBootExtreme"), display = 2280, hp = 310, speed = 3, dodge = 11,
                text = "Quick and slippery." },
            { id = "b_junker", name = "Gadgetzan Junker", icon = I("INV_Gizmo_Pipe_03"), display = 11912, hp = 360, speed = 1, dodge = 6,
                trait = { key = "salvage", below = 0.3, heal = 200 }, text = "Emergency Salvage: heals 200 once when below 30% health." },
            { id = "b_gilded", name = "Trade Prince's Gilded Frame", icon = I("INV_Misc_Coin_02"), display = 13310, hp = 340, speed = 1, dodge = 5,
                trait = { key = "bribe", chance = 8 }, text = "Bribe the Pilot: 8% chance an enemy attack doesn't happen." },
        },
        arms = {
            { id = "b_saw", name = "Shredder Saw", icon = I("INV_Misc_EngGizmos_14"), power = 53,
                trait = { key = "pen", pct = 50 }, text = "Cuts through 50% of armor." },
            { id = "b_flame", name = "Flamethrower", icon = I("Spell_Fire_Fire"), power = 40,
                trait = { key = "burn", dps = 10, dur = 4 }, text = "Sets the enemy on fire: 10 damage a second for 4 sec." },
            { id = "b_rivet", name = "Rivet Gun", icon = I("INV_Misc_Ammo_Gunpowder_03"), power = 33, interval = -0.7,
                text = "Very fast, light hits." },
            { id = "b_wrench", name = "Big Bonkin' Wrench", icon = I("INV_Misc_Wrench_02"), power = 74, interval = 0.4, crit = 5,
                text = "Huge slow swings, +5% crit." },
            { id = "b_claw", name = "Hydraulic Claw", icon = I("INV_Gizmo_Pipe_02"), power = 56,
                trait = { key = "crush", chance = 25, armor = 8, max = 3 }, text = "25% chance to crush 8% of enemy armor (stacks 3 times)." },
        },
        core = {
            { id = "b_overclock", name = "Overclocked Engine", icon = I("Spell_Fire_SelfDestruct"), powerPct = 32,
                trait = { key = "overheat", pct = 2, every = 5 }, text = "+32% damage, but burns 2% of its own max health every 5 sec." },
            { id = "b_nitro", name = "Nitro Boosters", icon = I("INV_Gizmo_RocketBoot_01"),
                trait = { key = "nitro", dur = 7, pct = 45 }, text = "Attacks 45% faster for the first 7 sec." },
            { id = "b_kajacola", name = "Kaja'Cola Injector", icon = I("INV_Drink_05"), speed = 5, hp = -40,
                text = "+5 speed, -40 health. Pure sugar." },
            { id = "b_turbine", name = "Gold-Lined Turbine", icon = I("INV_Misc_Coin_01"),
                trait = { key = "ramp", per = 2.2, max = 55 }, text = "Every attack adds +2.2 damage, up to +55." },
            { id = "b_battery", name = "Black Market Battery", icon = I("INV_Battery_01"), crit = 20, critMult = 0.5,
                text = "+20% crit chance and crits hit 50% harder." },
        },
        cannon = {
            { id = "b_rockets", name = "Rocket Barrage", icon = I("INV_Gizmo_RocketLauncher"), first = 3, cd = 7,
                trait = { key = "rockets", count = 3, dmg = 43 }, text = "Every 7 sec: 3 rockets for 43 each." },
            { id = "b_sapper", name = "Super Sapper Charge", icon = I("INV_Gizmo_SuperSapperCharge"),
                trait = { key = "sapper", below = 0.4, dmg = 300, self = 80 }, text = "Below 40% health: blows up for 300 damage, 80 to itself. Once." },
            { id = "b_oil", name = "Oil Slick Sprayer", icon = I("INV_Misc_Ammo_Gunpowder_06"), first = 2, cd = 8,
                trait = { key = "oil", dur = 4, pct = 25, dmg = 20 }, text = "Every 8 sec: 20 damage, and the enemy can't dodge and takes 25% more damage for 4 sec." },
            { id = "b_mortar", name = "Goblin Mortar", icon = I("INV_Misc_Bomb_08"), first = 4, cd = 7,
                trait = { key = "mortar", dmg = 150, miss = 25 }, text = "Every 7 sec: 150 damage, but misses 25% of the time." },
            { id = "b_magnet", name = "Magnet Mine", icon = I("INV_Misc_EngGizmos_05"), first = 5, cd = 9,
                trait = { key = "stun", dur = 1.5, dmg = 70 }, text = "Every 9 sec: 70 damage and stuns for 1.5 sec." },
        },
        plating = {
            { id = "b_scrap", name = "Scrap Plating", icon = I("INV_Gizmo_Pipe_04"), armor = 12,
                trait = { key = "scrap", per = 3, max = 18 }, text = "12% armor, +3% more every time it's hit (up to +18%)." },
            { id = "b_junkbox", name = "Junkbox Shielding", icon = I("INV_Gizmo_KhoriumPowerCore"),
                trait = { key = "shield", amount = 200, recharge = 0 }, text = "Starts with a 200 shield." },
            { id = "b_smoke", name = "Smokescreen Plates", icon = I("INV_Misc_Bomb_09"), dodge = 16,
                text = "+16% dodge." },
            { id = "b_hull", name = "Reinforced Hull", icon = I("INV_Chest_Plate07"), hp = 250,
                text = "+250 health." },
            { id = "b_bumpers", name = "Spiked Bumpers", icon = I("INV_Gizmo_Pipe_01"), armor = 8,
                trait = { key = "reflect", pct = 22 }, text = "8% armor and reflects 22% of damage taken from attacks." },
        },
    },
}

-- Lookup by id.
ns.PART_BY_ID = {}
for faction, slots in pairs(ns.PARTS) do
    for slot, list in pairs(slots) do
        for i, part in ipairs(list) do
            part.slot, part.faction, part.index = slot, faction, i
            ns.PART_BY_ID[part.id] = part
        end
    end
end

ns.ARENAS = {
    { name = "Gnomeregan Proving Grounds", texture = "Interface\\Glues\\LoadingScreens\\LoadScreenGnomeregan" },
    { name = "Blackrock Rail Yard", texture = "Interface\\Glues\\LoadingScreens\\LoadScreenBlackrockTrainDepot" },
    { name = "Shadowforge Scrap Pit", texture = "Interface\\Glues\\LoadingScreens\\LoadScreenBlackrockDepths" },
    { name = "Gadgetzan Junkyard", texture = "Interface\\Glues\\LoadingScreens\\LoadScreenKalimdor" },
}

ns.BOTS = {
    easy = { name = "Apprentice Tinker", text = "Picks parts more or less at random. Good for learning." },
    normal = { name = "Chief Mekgineer", text = "Builds a solid mech every time." },
    hard = { name = "Trade Prince", text = "Studies your parts and tests builds against them before choosing." },
}
ns.BOT_NAMES = {
    gnome = { "Fizzlebolt", "Sprocketwhistle", "Tinkerspanner", "Gearspark", "Cogsworth" },
    goblin = { "Gizzik", "Razzlecash", "Boomgrin", "Nixx Sprocketspring", "Krazzle" },
}

-- Sound files (FileDataIDs) checked against the WoW Forever build.
ns.SOUNDS = {
    gnome = { attack = { 550502, 550499 }, wound = { 550496, 550498 }, death = 550491, aggro = 550497,
        alt = { attack = { 555125, 555123, 555132 }, wound = { 555128, 555129, 555130 }, death = 555126 } },
    goblin = { attack = { 550827, 550826, 550821 }, wound = { 550830, 550822, 550828 }, death = 550829, aggro = 550823,
        voice = { 550748, 550737, 550742 } },
    gnomeVoice = { 550429, 550423, 550428 },
    rockets = 598625, arcane = 568678, fire = 568461, lightning = 568516, heal = 568287, shield = 569473,
    victory = 567431, tonk = 560901,
}
