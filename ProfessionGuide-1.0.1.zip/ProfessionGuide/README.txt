Profession Guide 1.0.1 - World of Warcraft: Forever (Interface 16001)
======================================================================

Level every profession from 1 to 300: what to craft at each skill, the
materials you need, and where to farm them.

INSTALL
Copy the ProfessionGuide folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game.

OPEN IT
Click the book on the minimap (right-click it for farm spots), pick it from
the minimap addon menu, or type /pg.

CRAFTING PROFESSIONS
Alchemy, Blacksmithing, Enchanting, Engineering, Leatherworking, Tailoring,
Cooking and First Aid each have a leveling plan from 1 to 300:
- Each step says which recipe to craft, from what skill to what skill, and
  about how many times.
- The step you are on is highlighted, using your real skill.
- Every material shows how many you have (bags and bank) and how many you
  need. Hover it to see where to farm it; click it to see every farm spot.
- Shopping list: everything you still need up to your current cap.
- When you are near your cap, it tells you to train the next rank and the
  character level that needs.
- Recipes that need a pattern say so, and who sells it.

The plans are built from Forever's own recipe data, which differs from
Classic in places (Forever has new recipes and different breakpoints). The
colours in your profession window have the final say: open it and click
"Craft now" for a live list of the recipes that still give skill, best first.

GATHERING
- Skinning: the highest level you can skin, and beasts near that level to
  farm, with zones, leather type and a Map button.
- Mining and Herbalism: every ore and herb by the skill it needs, with zones.
- Fishing: where to fish at your skill.

FARM MATERIALS
Pick a material (cloth, leather, elementals, spider silk, venom sacs and
more) to see every mob that drops it, with levels and zones. Click Map to
put a waypoint on your map. Item tooltips also say where to farm a
material.

COMMANDS
/pg              open or close
/pg tailoring    open a profession (any name works, even the first letters)
/pg farm         farm materials
/pg now          live list from your open profession window
/pg tooltips     farm lines on item tooltips on or off
/pg minimap      minimap button on or off

CREDITS AND LICENSE
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
Released under the GNU GPL v3. Mob levels and spawn points come from
QuestieDB (GPL v3); recipe data comes from the WoW Forever game files.
