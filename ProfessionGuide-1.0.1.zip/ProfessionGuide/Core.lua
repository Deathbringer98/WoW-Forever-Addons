-- Profession Guide for World of Warcraft: Forever (Interface 16001)
-- What to craft at every skill level, the materials for it, and where to farm them.
-- Leveling steps are built from Forever's own recipe data (Data_Guides.lua); mob levels and
-- map points come from QuestieDB (Data_Farm.lua). The "Craft now" list reads the real recipe
-- colours from your open profession window.
local ADDON, ns = ...

local PREFIX = "|cff66ccffProfession Guide:|r "
local ROWS = 11
local ROW_H = 38

local db
local frame
local view = { kind = "prof", prof = nil, offset = 0 }

local function I(name) return "Interface\\Icons\\" .. name end
local function Say(text) print(PREFIX .. text) end
local function IsSecret(v) return issecretvalue ~= nil and issecretvalue(v) end

-- Every profession: skill line ID, icon, and whether it crafts (has a leveling plan).
local PROFS = {
    { name = "Alchemy", line = 171, icon = I("Trade_Alchemy"), craft = true },
    { name = "Blacksmithing", line = 164, icon = I("Trade_BlackSmithing"), craft = true },
    { name = "Enchanting", line = 333, icon = I("Trade_Engraving"), craft = true },
    { name = "Engineering", line = 202, icon = I("Trade_Engineering"), craft = true },
    { name = "Leatherworking", line = 165, icon = I("INV_Misc_ArmorKit_17"), craft = true },
    { name = "Tailoring", line = 197, icon = I("Trade_Tailoring"), craft = true },
    { name = "Cooking", line = 185, icon = I("INV_Misc_Food_15"), craft = true },
    { name = "First Aid", line = 129, icon = I("Spell_Holy_SealOfSacrifice"), craft = true },
    { name = "Mining", line = 186, icon = I("Trade_Mining") },
    { name = "Herbalism", line = 182, icon = I("Trade_Herbalism") },
    { name = "Skinning", line = 393, icon = I("INV_Misc_Pelt_Wolf_01") },
    { name = "Fishing", line = 356, icon = I("Trade_Fishing") },
}
local PROF_BY_NAME = {}
for _, p in ipairs(PROFS) do PROF_BY_NAME[p.name] = p end

-- Trainer ranks and the character level each needs.
local RANKS = {
    { cap = 75, name = "Apprentice", level = 1 },
    { cap = 150, name = "Journeyman", level = 10 },
    { cap = 225, name = "Expert", level = 20 },
    { cap = 300, name = "Artisan", level = 35 },
}

---------------------------------------------------------------------------
-- Reading your professions
---------------------------------------------------------------------------

-- Returns skill[name] = { level, max } for every profession you know.
local function ReadSkills()
    local skills = {}
    if type(GetProfessions) == "function" and type(GetProfessionInfo) == "function" then
        -- prof1, prof2, archaeology, fishing, cooking, first aid; any of them can be nil.
        local ok, a, b, c, d, e, f = pcall(GetProfessions)
        local list = { a, b, c, d, e, f }
        if ok then
            for i = 1, 6 do
                local index = list[i]
                if index and not IsSecret(index) then
                    local ok, name, _, level, max, _, _, line = pcall(GetProfessionInfo, index)
                    if ok and type(name) == "string" and not IsSecret(level) then
                        for _, p in ipairs(PROFS) do
                            if p.line == line or p.name == name then skills[p.name] = { level = level or 0, max = max or 0 } end
                        end
                    end
                end
            end
        end
    end
    -- Classic-style skill list, if that is what the client has.
    if next(skills) == nil and type(GetNumSkillLines) == "function" and type(GetSkillLineInfo) == "function" then
        local ok, n = pcall(GetNumSkillLines)
        for i = 1, (ok and n or 0) do
            local ok2, name, header, _, level, _, _, max = pcall(GetSkillLineInfo, i)
            if ok2 and not header and PROF_BY_NAME[name] then skills[name] = { level = level or 0, max = max or 0 } end
        end
    end
    return skills
end

local function ItemCount(id)
    if C_Item and C_Item.GetItemCount then
        local ok, n = pcall(C_Item.GetItemCount, id, true)
        if ok and type(n) == "number" then return n end
    end
    if type(GetItemCount) == "function" then
        local ok, n = pcall(GetItemCount, id, true)
        if ok and type(n) == "number" then return n end
    end
    return 0
end

local function ItemIcon(id)
    if C_Item and C_Item.GetItemIconByID then
        local ok, icon = pcall(C_Item.GetItemIconByID, id)
        if ok and icon then return icon end
    end
    if type(GetItemIcon) == "function" then
        local ok, icon = pcall(GetItemIcon, id)
        if ok and icon then return icon end
    end
    return I("INV_Misc_QuestionMark")
end

---------------------------------------------------------------------------
-- Map waypoints
---------------------------------------------------------------------------

local function Waypoint(spot)
    local npc, name, minL, maxL, zone, map, x, y = unpack(spot)
    local placed = false
    if not InCombatLockdown() and C_Map and C_Map.SetUserWaypoint and UiMapPoint and UiMapPoint.CreateFromCoordinates then
        local ok = pcall(function()
            C_Map.SetUserWaypoint(UiMapPoint.CreateFromCoordinates(map, x / 100, y / 100))
            if C_SuperTrack and C_SuperTrack.SetSuperTrackedUserWaypoint then C_SuperTrack.SetSuperTrackedUserWaypoint(true) end
        end)
        placed = ok
    end
    Say(string.format("%s (level %s) in %s at %.1f, %.1f.%s", name, minL == maxL and minL or (minL .. "-" .. maxL), zone, x, y,
        placed and " Waypoint set on your map." or ""))
end

---------------------------------------------------------------------------
-- Building the list for each view
---------------------------------------------------------------------------

-- Each list entry: { text = line 1, sub = line 2, mats = { {id, need} }, spot = farm spot, spell = id,
--                    state = "done" | "now" | "next", tip = extra tooltip lines }
local function FarmLines(item)
    local spots = ns.FARM[item]
    if not spots or #spots == 0 then return nil end
    local lines = {}
    for i = 1, math.min(3, #spots) do
        local s = spots[i]
        lines[#lines + 1] = string.format("%s (%d-%d), %s", s[2], s[3], s[4], s[5])
    end
    return lines
end

local function TrainerNote(skill)
    if not skill or skill.max >= 300 or skill.max == 0 then return nil end
    if skill.level < skill.max - 10 then return nil end
    for _, r in ipairs(RANKS) do
        if r.cap > skill.max then
            return string.format("|cffff8040Almost at your cap of %d. Train %s at your trainer (needs character level %d).|r", skill.max, r.name, r.level)
        end
    end
end

local function CraftEntries(prof, skill)
    local steps = ns.GUIDES[prof] or {}
    local level = skill and skill.level or 0
    local entries = {}
    for _, st in ipairs(steps) do
        local state = (level >= st.to) and "done" or (level >= st.from and "now" or "next")
        local text = string.format("%s%d-%d|r  %dx %s", state == "now" and "|cffffd100" or (state == "done" and "|cff808080" or "|cffffffff"),
            st.from, st.to, st.crafts, st.name)
        local tip = {}
        tip[#tip + 1] = string.format("Turns yellow at %d, grey at %d.", st.yellow, st.grey)
        if st.pattern then
            if st.vendor then
                tip[#tip + 1] = string.format("|cff40c0ffNeeds a pattern: sold by %s.|r", st.vendor[2])
            else
                tip[#tip + 1] = "|cff40c0ffNeeds a pattern.|r"
            end
        else
            tip[#tip + 1] = "Learned from your trainer."
        end
        local mats = {}
        for _, m in ipairs(st.mats) do mats[#mats + 1] = { m[1], m[2] * st.crafts, m[3] } end
        entries[#entries + 1] = { text = text, mats = mats, spell = st.spell, state = state, tip = tip, step = st }
    end
    return entries
end

local function ShoppingEntries(prof, skill)
    local level = skill and skill.level or 0
    local cap = skill and skill.max > 0 and skill.max or 300
    local need, names, order = {}, {}, {}
    for _, st in ipairs(ns.GUIDES[prof] or {}) do
        if st.to > level and st.from < cap then
            -- Only the part of the step still ahead of you.
            local from = math.max(st.from, level)
            local share = (math.min(st.to, cap) - from) / math.max(1, st.to - st.from)
            local crafts = math.ceil(st.crafts * share)
            for _, m in ipairs(st.mats) do
                if not need[m[1]] then order[#order + 1] = m[1] end
                need[m[1]] = (need[m[1]] or 0) + m[2] * crafts
                names[m[1]] = m[3]
            end
        end
    end
    local entries = {}
    for _, id in ipairs(order) do
        local have = ItemCount(id)
        local color = have >= need[id] and "|cff40ff40" or "|cffffffff"
        local farm = FarmLines(names[id])
        entries[#entries + 1] = { text = string.format("%s%s|r  %d / %d", color, names[id], have, need[id]),
            sub = farm and ("Farm: " .. farm[1]) or "", mats = { { id, need[id], names[id] } }, item = names[id] }
    end
    return entries
end

-- Live list from the open profession window: recipes that still give skill, best first.
local function CraftNowEntries()
    local entries = {}
    local COLORS = { [0] = "|cffff8040", [1] = "|cffffff00", [2] = "|cff40c040", optimal = "|cffff8040", medium = "|cffffff00", easy = "|cff40c040" }
    local WORDS = { [0] = "orange: 1 point every craft", [1] = "yellow: usually a point", [2] = "green: sometimes a point",
        optimal = "orange: 1 point every craft", medium = "yellow: usually a point", easy = "green: sometimes a point" }
    if C_TradeSkillUI and C_TradeSkillUI.GetAllRecipeIDs and C_TradeSkillUI.GetRecipeInfo then
        local ok, ids = pcall(C_TradeSkillUI.GetAllRecipeIDs)
        if ok and type(ids) == "table" then
            for _, id in ipairs(ids) do
                local ok2, info = pcall(C_TradeSkillUI.GetRecipeInfo, id)
                if ok2 and type(info) == "table" and info.learned ~= false then
                    local diff = info.relativeDifficulty
                    if diff == nil and info.difficulty then diff = info.difficulty end
                    if diff ~= nil and diff ~= 3 and diff ~= "trivial" and COLORS[diff] then
                        entries[#entries + 1] = { text = COLORS[diff] .. (info.name or "?") .. "|r", sub = WORDS[diff] ..
                            ((info.numAvailable or 0) > 0 and ("  |cff40ff40you can make " .. info.numAvailable .. " now|r") or ""),
                            rank = (type(diff) == "number" and diff or (diff == "optimal" and 0 or diff == "medium" and 1 or 2)) * 1000 - (info.numAvailable or 0),
                            spell = id }
                    end
                end
            end
        end
    elseif type(GetNumTradeSkills) == "function" and type(GetTradeSkillInfo) == "function" then
        local ok, n = pcall(GetNumTradeSkills)
        for i = 1, (ok and n or 0) do
            local ok2, name, kind, available = pcall(GetTradeSkillInfo, i)
            if ok2 and COLORS[kind] then
                entries[#entries + 1] = { text = COLORS[kind] .. name .. "|r", sub = WORDS[kind] ..
                    ((available or 0) > 0 and ("  |cff40ff40you can make " .. available .. " now|r") or ""),
                    rank = (kind == "optimal" and 0 or kind == "medium" and 1 or 2) * 1000 - (available or 0) }
            end
        end
    end
    table.sort(entries, function(a, b) return a.rank < b.rank end)
    return entries
end

local function MaxSkinLevel(skill)
    if skill < 100 then return math.floor(skill / 10) + 10 end
    return math.floor(skill / 5)
end

local function LeatherFor(level)
    if level < 20 then return "Light Leather" elseif level < 30 then return "Medium Leather"
    elseif level < 40 then return "Heavy Leather" elseif level < 50 then return "Thick Leather" end
    return "Rugged Leather"
end

local function GatherEntries(prof, skill)
    local level = skill and skill.level or 0
    local entries = {}
    if prof == "Skinning" then
        local top = MaxSkinLevel(math.max(1, level))
        entries.note = string.format("|cffffd100You can skin beasts up to level %d.|r Skin ones close to that level for a skill-up every time. Click Map for a waypoint.", top)
        for _, s in ipairs(ns.SKIN) do
            local ok = s[3] <= top
            local best = ok and s[3] >= top - 8
            entries[#entries + 1] = { text = string.format("%s%s|r  level %d-%d", best and "|cffffd100" or (ok and "|cffffffff" or "|cff808080"), s[2], s[3], s[4]),
                sub = string.format("%s, %s", s[5], LeatherFor(s[3])) .. (s[9] and "  |cffff4040elite|r" or ""), spot = s,
                state = best and "now" or (ok and "done" or "next") }
        end
    elseif prof == "Mining" or prof == "Herbalism" then
        local list = prof == "Mining" and ns.MINING or ns.HERBS
        for i, n in ipairs(list) do
            local nextAt = list[i + 1] and list[i + 1][1] or 400
            local ok = level >= n[1]
            local best = ok and level < nextAt + 25
            local zones = prof == "Mining" and n[4] or n[3]
            entries[#entries + 1] = { text = string.format("%s%s|r  from %d skill", best and "|cffffd100" or (ok and "|cffffffff" or "|cff808080"), n[2], n[1]),
                sub = zones, state = best and "now" or (ok and "done" or "next") }
        end
        entries[#entries + 1] = { text = "|cffffffffTip|r", sub = prof == "Mining" and "Turn on Find Minerals, and smelt your ore: smelting gives skill too."
            or "Turn on Find Herbs. Every herb gives skill until it turns grey." }
    elseif prof == "Fishing" then
        for i, f in ipairs(ns.FISHING) do
            local nextAt = ns.FISHING[i + 1] and ns.FISHING[i + 1][1] or 400
            local best = level >= f[1] and level < nextAt
            entries[#entries + 1] = { text = string.format("%sFrom %d skill|r", best and "|cffffd100" or "|cffffffff", f[1]), sub = f[2], state = best and "now" or nil }
        end
        entries[#entries + 1] = { text = "|cffffffffTip|r", sub = "Buy a better pole and lures from a fishing trainer or supplies vendor. Fish in waters at or below your level range." }
    end
    return entries
end

-- Groups for the Farm view, in order.
local FARM_GROUPS = {
    { "Cloth", { "Linen Cloth", "Wool Cloth", "Silk Cloth", "Mageweave Cloth", "Runecloth" } },
    { "Leather", { "Light Leather", "Medium Leather", "Heavy Leather", "Thick Leather", "Rugged Leather" } },
    { "Elementals", { "Elemental Earth", "Elemental Fire", "Elemental Water", "Elemental Air", "Heart of Fire",
        "Essence of Earth", "Essence of Fire", "Essence of Water", "Essence of Air" } },
    { "Other", { "Spider's Silk", "Thick Spider's Silk", "Ironweb Spider Silk", "Small Venom Sac", "Large Venom Sac", "Murloc Eye", "Coyote Meat", "Scorpid Stinger" } },
}

local function FarmEntries(item)
    local entries = {}
    if not item then
        for _, g in ipairs(FARM_GROUPS) do
            entries[#entries + 1] = { text = "|cffffd100" .. g[1] .. "|r" }
            for _, name in ipairs(g[2]) do
                if ns.FARM[name] and #ns.FARM[name] > 0 then
                    entries[#entries + 1] = { text = "   " .. name, sub = #ns.FARM[name] .. " places to farm", item = name, pick = true }
                end
            end
        end
        return entries
    end
    local myLevel = UnitLevel and UnitLevel("player") or 60
    for _, s in ipairs(ns.FARM[item] or {}) do
        local tooHigh = type(myLevel) == "number" and not IsSecret(myLevel) and s[3] > myLevel + 3
        entries[#entries + 1] = { text = string.format("%s%s|r  level %d-%d", tooHigh and "|cffff6060" or "|cffffffff", s[2], s[3], s[4]),
            sub = s[5] .. (s[9] and "  |cffff4040elite|r" or ""), spot = s }
    end
    return entries
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------

local Refresh

local function Text(parent, font, x, y, width)
    local t = parent:CreateFontString(nil, "OVERLAY", font or "GameFontHighlight")
    t:SetPoint("TOPLEFT", x, y)
    if width then t:SetWidth(width) t:SetJustifyH("LEFT") end
    return t
end

local function SmallButton(parent, width, label, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, 20)
    b:SetText(label)
    b:SetScript("OnClick", onClick)
    return b
end

local function ShowItemTip(owner, id, name)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    local ok = pcall(GameTooltip.SetItemByID, GameTooltip, id)
    if not ok then GameTooltip:SetText(name or ("item " .. id)) end
    local farm = name and FarmLines(name)
    if farm then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Farm it from:", 0.4, 0.8, 1)
        for _, l in ipairs(farm) do GameTooltip:AddLine(l, 1, 1, 1) end
        GameTooltip:AddLine("Click to see every place on the map.", 0.6, 0.6, 0.6)
    end
    GameTooltip:Show()
end

local function MakeRow(parent, i)
    local r = CreateFrame("Button", nil, parent)
    r:SetSize(500, ROW_H)
    r:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
    r.hl = r:CreateTexture(nil, "BACKGROUND")
    r.hl:SetAllPoints()
    r.hl:SetColorTexture(1, 0.82, 0, 0.12)
    r.text = Text(r, "GameFontHighlight", 6, -4, 300)
    r.text:SetWordWrap(false)
    r.sub = Text(r, "GameFontHighlightSmall", 6, -21, 420)
    r.sub:SetWordWrap(false)
    r.sub:SetTextColor(0.75, 0.75, 0.75)
    r.mats = {}
    for m = 1, 6 do
        local b = CreateFrame("Button", nil, r)
        b:SetSize(64, 16)
        b:SetPoint("TOPLEFT", 6 + (m - 1) * 70, -20)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(15, 15)
        b.icon:SetPoint("LEFT")
        b.count = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.count:SetPoint("LEFT", b.icon, "RIGHT", 3, 0)
        b:SetScript("OnEnter", function(self) ShowItemTip(self, self.id, self.name) end)
        b:SetScript("OnLeave", function() GameTooltip:Hide() end)
        b:SetScript("OnClick", function(self)
            if ns.FARM[self.name] then
                view.kind, view.item, view.offset = "farm", self.name, 0
                Refresh()
            end
        end)
        r.mats[m] = b
    end
    r.map = SmallButton(r, 52, "Map", function(self) if self.spot then Waypoint(self.spot) end end)
    r.map:SetPoint("RIGHT", -4, 0)
    r:SetScript("OnEnter", function(self)
        local e = self.entry
        if not e then return end
        if e.spell then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            local ok = pcall(GameTooltip.SetSpellByID, GameTooltip, e.spell)
            if not ok then GameTooltip:SetText(e.text) end
            for _, l in ipairs(e.tip or {}) do GameTooltip:AddLine(l, 1, 1, 1, true) end
            GameTooltip:Show()
        elseif e.item and not e.pick then
            ShowItemTip(self, e.mats and e.mats[1][1], e.item)
        end
    end)
    r:SetScript("OnLeave", function() GameTooltip:Hide() end)
    r:SetScript("OnClick", function(self)
        local e = self.entry
        if e and e.pick then
            view.item, view.offset = e.item, 0
            Refresh()
        elseif e and e.item and ns.FARM[e.item] then
            view.kind, view.item, view.offset = "farm", e.item, 0
            Refresh()
        end
    end)
    return r
end

local function FillRow(r, e)
    r.entry = e
    if not e then r:Hide() return end
    r:Show()
    r.text:SetText(e.text or "")
    r.hl:SetShown(e.state == "now")
    for m, b in ipairs(r.mats) do
        local mat = e.mats and not e.item and e.mats[m]
        if mat then
            b.id, b.name = mat[1], mat[3]
            b.icon:SetTexture(ItemIcon(mat[1]))
            local have = ItemCount(mat[1])
            b.count:SetText(string.format("%s%d/%d|r", have >= mat[2] and "|cff40ff40" or "|cffffffff", have, mat[2]))
            b:Show()
        else
            b:Hide()
        end
    end
    local showMats = e.mats and not e.item
    r.sub:SetShown(not showMats)
    r.sub:SetText(e.sub or "")
    r.map.spot = e.spot
    r.map:SetShown(e.spot ~= nil)
end

local function CreateWindow()
    local f = CreateFrame("Frame", "ProfessionGuideFrame", UIParent, "BackdropTemplate")
    f:SetSize(700, 520)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:EnableMouse(true)
    f:SetMovable(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, rel, x, y = self:GetPoint(1)
        if type(point) == "string" and type(x) == "number" then db.pos = { point, rel, x, y } end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[3]) == "number" then
        f:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        f:SetPoint("CENTER")
    end
    f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border", tile = true, tileSize = 32, edgeSize = 24,
        insets = { left = 6, right = 6, top = 6, bottom = 6 } })
    tinsert(UISpecialFrames, "ProfessionGuideFrame")

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -14)
    title:SetText("Profession Guide")
    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -4, -4)

    -- Left column: professions, then Farm and Craft now.
    f.profButtons = {}
    for i, p in ipairs(PROFS) do
        local b = CreateFrame("Button", nil, f)
        b:SetSize(150, 26)
        b:SetPoint("TOPLEFT", 16, -42 - (i - 1) * 28)
        b.bg = b:CreateTexture(nil, "BACKGROUND")
        b.bg:SetAllPoints()
        b.bg:SetColorTexture(1, 0.82, 0, 0.15)
        b.icon = b:CreateTexture(nil, "ARTWORK")
        b.icon:SetSize(22, 22)
        b.icon:SetPoint("LEFT", 2, 0)
        b.icon:SetTexture(p.icon)
        b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        b.label:SetPoint("LEFT", b.icon, "RIGHT", 6, 0)
        b.label:SetJustifyH("LEFT")
        b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
        b:SetScript("OnClick", function()
            view.kind, view.prof, view.offset = "prof", p.name, 0
            Refresh()
        end)
        b.prof = p
        f.profButtons[i] = b
    end
    local farmButton = SmallButton(f, 150, "Farm materials", function()
        view.kind, view.item, view.offset = "farm", nil, 0
        Refresh()
    end)
    farmButton:SetPoint("TOPLEFT", 16, -42 - #PROFS * 28 - 6)
    local craftNow = SmallButton(f, 150, "Craft now", function()
        view.kind, view.offset = "now", 0
        Refresh()
    end)
    craftNow:SetPoint("TOPLEFT", farmButton, "BOTTOMLEFT", 0, -4)
    f.craftNow = craftNow

    -- Right side: header, tabs, list.
    f.header = Text(f, "GameFontNormal", 184, -44, 490)
    f.note = Text(f, "GameFontHighlightSmall", 184, -62, 490)
    f.tabSteps = SmallButton(f, 110, "Leveling steps", function() view.kind, view.offset = "prof", 0 Refresh() end)
    f.tabSteps:SetPoint("TOPLEFT", 184, -82)
    f.tabShop = SmallButton(f, 110, "Shopping list", function() view.kind, view.offset = "shop", 0 Refresh() end)
    f.tabShop:SetPoint("LEFT", f.tabSteps, "RIGHT", 6, 0)
    f.back = SmallButton(f, 110, "All materials", function() view.item, view.offset = nil, 0 Refresh() end)
    f.back:SetPoint("TOPLEFT", 184, -82)

    local list = CreateFrame("Frame", nil, f)
    list:SetSize(500, ROWS * ROW_H)
    list:SetPoint("TOPLEFT", 180, -108)
    list:EnableMouseWheel(true)
    list:SetScript("OnMouseWheel", function(_, delta)
        view.offset = math.max(0, math.min((view.total or 0) - ROWS, view.offset - delta * 3))
        Refresh()
    end)
    f.rows = {}
    for i = 1, ROWS do f.rows[i] = MakeRow(list, i) end
    f.scrollText = Text(f, "GameFontDisableSmall", 184, -108 - ROWS * ROW_H - 4, 490)

    f.foot = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    f.foot:SetPoint("BOTTOM", 0, 14)
    f.foot:SetWidth(660)
    f.foot:SetText("Steps come from Forever's recipe data. The colours in your profession window have the final say: open it and click Craft now.")

    f:SetScript("OnShow", function() Refresh() end)
    f:Hide()
    return f
end

Refresh = function()
    local f = frame
    if not f or not f:IsShown() then return end
    local skills = ReadSkills()
    for _, b in ipairs(f.profButtons) do
        local s = skills[b.prof.name]
        b.label:SetText(b.prof.name .. (s and string.format("  |cffffd100%d|r", s.level) or ""))
        b.bg:SetShown(view.kind ~= "farm" and view.kind ~= "now" and view.prof == b.prof.name)
        b.icon:SetDesaturated(s == nil)
    end
    local prof = view.prof and PROF_BY_NAME[view.prof]
    local skill = prof and skills[prof.name]
    local entries
    f.tabSteps:Hide() f.tabShop:Hide() f.back:Hide()
    if view.kind == "farm" then
        f.header:SetText(view.item and ("Where to farm " .. view.item) or "Farm materials")
        f.note:SetText(view.item and "Click Map to put a waypoint on your map. Red names are well above your level."
            or "Pick a material to see every mob that drops it, with levels and zones.")
        f.back:SetShown(view.item ~= nil)
        entries = FarmEntries(view.item)
    elseif view.kind == "now" then
        f.header:SetText("Craft now")
        entries = CraftNowEntries()
        f.note:SetText(#entries > 0 and "Recipes in your open profession window that still give skill, best first."
            or "Open a profession window (your crafting spellbook), then click Craft now again.")
    elseif prof and prof.craft then
        f.tabSteps:Show() f.tabShop:Show()
        f.header:SetText(prof.name .. (skill and string.format("  |cffffffff%d / %d|r", skill.level, skill.max) or "  |cff808080not learned|r"))
        f.note:SetText(TrainerNote(skill) or (view.kind == "shop" and "Everything you still need up to your current cap. Click a material to see where to farm it."
            or "Hover a step for details and a material for where to farm it. Click a material to see every farm spot."))
        if view.kind == "shop" then entries = ShoppingEntries(prof.name, skill) else
            entries = CraftEntries(prof.name, skill)
            -- Jump to your current step the first time a profession opens.
            if view.jump ~= prof.name then
                view.jump = prof.name
                for i, e in ipairs(entries) do if e.state == "now" then view.offset = math.max(0, i - 2) end end
            end
        end
    elseif prof then
        f.header:SetText(prof.name .. (skill and string.format("  |cffffffff%d / %d|r", skill.level, skill.max) or "  |cff808080not learned|r"))
        entries = GatherEntries(prof.name, skill)
        f.note:SetText(TrainerNote(skill) or entries.note or "")
        if view.jump ~= prof.name then
            view.jump = prof.name
            for i, e in ipairs(entries) do if e.state == "now" then view.offset = math.max(0, i - 3) break end end
        end
    else
        entries = {}
    end
    view.total = #entries
    view.offset = math.max(0, math.min(view.offset, #entries - ROWS))
    for i = 1, ROWS do FillRow(f.rows[i], entries[view.offset + i]) end
    f.scrollText:SetText(#entries > ROWS and string.format("Scroll for more (%d-%d of %d)", view.offset + 1, math.min(#entries, view.offset + ROWS), #entries) or "")
end

local Start
local function Open(profName)
    if not db and Start then Start() end
    if not db then return end
    if not frame then frame = CreateWindow() end
    if profName then view.kind, view.prof, view.offset = "prof", profName, 0 end
    if not view.prof then
        -- Start on the first profession you know, crafting ones first.
        local skills = ReadSkills()
        for _, p in ipairs(PROFS) do if skills[p.name] then view.prof = p.name break end end
        view.prof = view.prof or "Tailoring"
    end
    frame:Show()
    Refresh()
end

local function Toggle()
    if frame and frame:IsShown() then frame:Hide() else Open() end
end

function ProfessionGuide_OnCompartmentClick()
    Toggle()
end

---------------------------------------------------------------------------
-- Material tooltips: where to farm it, on every item tooltip
---------------------------------------------------------------------------

local itemToName
local function AddFarmLines(tooltip, itemID)
    if not db or not db.tooltips or not itemID or IsSecret(itemID) then return end
    if not itemToName then
        itemToName = {}
        for _, steps in pairs(ns.GUIDES) do
            for _, st in ipairs(steps) do
                for _, m in ipairs(st.mats) do itemToName[m[1]] = m[3] end
            end
        end
    end
    local name = itemToName[itemID]
    local lines = name and FarmLines(name)
    if not lines then return end
    tooltip:AddLine("Profession Guide: farm from " .. lines[1], 0.4, 0.8, 1, true)
end

local function HookTooltips()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
            if tooltip == GameTooltip or tooltip == ItemRefTooltip then
                pcall(AddFarmLines, tooltip, data and data.id)
            end
        end)
    elseif GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnTooltipSetItem", function(tooltip)
            local ok, _, link = pcall(tooltip.GetItem, tooltip)
            local id = ok and type(link) == "string" and tonumber(link:match("item:(%d+)"))
            if id then pcall(AddFarmLines, tooltip, id) end
        end)
    end
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local minimapButton
local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 165)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "ProfessionGuideMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("AnyUp")
    b:RegisterForDrag("LeftButton")
    local icon = b:CreateTexture(nil, "BACKGROUND")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER", 0, 1)
    icon:SetTexture(I("INV_Misc_Book_09"))
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", function(_, mouse)
        if mouse == "RightButton" then
            Open()
            view.kind, view.item, view.offset = "farm", nil, 0
            Refresh()
        else
            Toggle()
        end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Profession Guide", 0.4, 0.8, 1)
        GameTooltip:AddLine("Click: leveling steps for your professions", 1, 1, 1)
        GameTooltip:AddLine("Right-click: where to farm materials", 1, 1, 1)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(math.atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

---------------------------------------------------------------------------
-- Slash command and events
---------------------------------------------------------------------------

SLASH_PROFESSIONGUIDE1 = "/pg"
SLASH_PROFESSIONGUIDE2 = "/profguide"
SlashCmdList.PROFESSIONGUIDE = function(message)
    local arg = (message or ""):lower():match("^%s*(.-)%s*$")
    if arg == "" then Toggle() return end
    if arg == "farm" then Open() view.kind, view.item, view.offset = "farm", nil, 0 Refresh() return end
    if arg == "now" then Open() view.kind, view.offset = "now", 0 Refresh() return end
    if arg == "tooltips" then
        db.tooltips = not db.tooltips
        Say("farm lines on item tooltips " .. (db.tooltips and "on." or "off."))
        return
    end
    if arg == "minimap" then
        db.minimap = not db.minimap
        if db.minimap then if not minimapButton then CreateMinimapButton() end minimapButton:Show()
        elseif minimapButton then minimapButton:Hide() end
        return
    end
    for _, p in ipairs(PROFS) do
        if p.name:lower():find(arg, 1, true) == 1 then Open(p.name) return end
    end
    Say("/pg opens the guide. /pg tailoring (or any profession), /pg farm, /pg now, /pg tooltips, /pg minimap.")
end

local started = false
Start = function()
    if started then return end
    started = true
    ProfessionGuideDB = type(ProfessionGuideDB) == "table" and ProfessionGuideDB or {}
    db = ProfessionGuideDB
    if db.tooltips == nil then db.tooltips = true end
    if db.minimap == nil then db.minimap = true end
    if db.minimap and Minimap then pcall(CreateMinimapButton) end
    pcall(HookTooltips)
end
ns.Start = Start

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then Start() return end
    if frame and frame:IsShown() then Refresh() end
end)
-- The client errors on events it doesn't know (Classic-only ones), so register each safely.
for _, e in ipairs({ "PLAYER_LOGIN", "SKILL_LINES_CHANGED", "BAG_UPDATE_DELAYED", "TRADE_SKILL_SHOW",
    "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_UPDATE" }) do
    pcall(events.RegisterEvent, events, e)
end
if IsLoggedIn and IsLoggedIn() then Start() end

-- For the automated tests.
ns.Open, ns.Refresh, ns.View, ns.ReadSkills = Open, function() Refresh() end, function() return view end, ReadSkills
ns.MaxSkinLevel, ns.Frame = MaxSkinLevel, function() return frame end
