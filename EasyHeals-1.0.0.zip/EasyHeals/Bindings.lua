-- Easy Heals click bindings: what each mouse click does on a player's frame, per class.
-- Each binding lists spells best first; the first one you have learned is used.
-- mod is "", "shift-", "ctrl-" or "alt-". button is 1 (left), 2 (right) or 3 (middle).
-- Spell names are WoW Forever's.
local _, ns = ...

local TARGET = "target"

ns.Bindings = {
    PRIEST = {
        { mod = "", button = 1, spells = { "Flash Heal", "Heal", "Lesser Heal" }, what = "Quick heal" },
        { mod = "", button = 2, spells = { "Renew" }, what = "Heal over time" },
        { mod = "", button = 3, spells = { "Power Word: Shield" }, what = "Shield from damage" },
        { mod = "shift-", button = 1, spells = { "Greater Heal", "Heal", "Lesser Heal" }, what = "Big heal" },
        { mod = "shift-", button = 2, spells = { "Prayer of Healing" }, what = "Heal the whole group" },
        { mod = "ctrl-", button = 1, spells = TARGET, what = "Target them" },
        { mod = "ctrl-", button = 2, spells = { "Dispel Magic" }, what = "Remove a bad spell" },
        { mod = "alt-", button = 1, spells = { "Abolish Disease", "Cure Disease" }, what = "Cure a disease" },
        { mod = "alt-", button = 2, spells = { "Resurrection" }, what = "Bring back to life" },
    },
    PALADIN = {
        { mod = "", button = 1, spells = { "Flash of Light", "Holy Light" }, what = "Quick heal" },
        { mod = "", button = 2, spells = { "Holy Light" }, what = "Big heal" },
        { mod = "", button = 3, spells = { "Holy Shock" }, what = "Instant heal" },
        { mod = "shift-", button = 1, spells = { "Lay on Hands" }, what = "Emergency full heal (long cooldown)" },
        { mod = "shift-", button = 2, spells = { "Blessing of Protection" }, what = "Protect from attacks" },
        { mod = "ctrl-", button = 1, spells = TARGET, what = "Target them" },
        { mod = "ctrl-", button = 2, spells = { "Cleanse", "Purify" }, what = "Remove poison and disease" },
        { mod = "alt-", button = 1, spells = { "Blessing of Freedom" }, what = "Free from slows and roots" },
        { mod = "alt-", button = 2, spells = { "Redemption" }, what = "Bring back to life" },
    },
    DRUID = {
        { mod = "", button = 1, spells = { "Rejuvenation" }, what = "Heal over time" },
        { mod = "", button = 2, spells = { "Healing Touch" }, what = "Big heal" },
        { mod = "", button = 3, spells = { "Regrowth" }, what = "Quick heal plus heal over time" },
        { mod = "shift-", button = 1, spells = { "Swiftmend" }, what = "Instant heal" },
        { mod = "shift-", button = 2, spells = { "Wild Growth" }, what = "Heal the group around them" },
        { mod = "ctrl-", button = 1, spells = TARGET, what = "Target them" },
        { mod = "ctrl-", button = 2, spells = { "Remove Curse" }, what = "Remove a curse" },
        { mod = "alt-", button = 1, spells = { "Abolish Poison", "Cure Poison" }, what = "Cure poison" },
        { mod = "alt-", button = 2, spells = { "Rebirth" }, what = "Bring back to life, even in combat" },
    },
    SHAMAN = {
        { mod = "", button = 1, spells = { "Lesser Healing Wave", "Healing Wave" }, what = "Quick heal" },
        { mod = "", button = 2, spells = { "Healing Wave" }, what = "Big heal" },
        { mod = "", button = 3, spells = { "Chain Heal" }, what = "Heal that jumps to others" },
        { mod = "shift-", button = 1, spells = { "Riptide" }, what = "Instant heal plus heal over time" },
        { mod = "ctrl-", button = 1, spells = TARGET, what = "Target them" },
        { mod = "ctrl-", button = 2, spells = { "Cure Poison" }, what = "Cure poison" },
        { mod = "alt-", button = 1, spells = { "Cure Disease" }, what = "Cure a disease" },
        { mod = "alt-", button = 2, spells = { "Ancestral Spirit" }, what = "Bring back to life" },
    },
    MAGE = {
        { mod = "", button = 1, spells = TARGET, what = "Target them" },
        { mod = "", button = 2, spells = { "Arcane Intellect" }, what = "Intellect buff" },
        { mod = "ctrl-", button = 2, spells = { "Remove Lesser Curse" }, what = "Remove a curse" },
    },
}

-- Classes without heals: clicking targets the player.
ns.DefaultBindings = {
    { mod = "", button = 1, spells = TARGET, what = "Target them" },
}

ns.TARGET = TARGET
