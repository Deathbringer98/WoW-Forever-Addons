-- Easy Heals for World of Warcraft: Forever (Interface 16001)
-- Click-to-heal frames made for new healers. Your party (or raid) shows as shiny health bars; click a
-- name to heal that player. A key next to the frames shows what every click does.
--
-- How it plays by the rules: WoW Forever hides your party's health from addons as a number. So the
-- bars, the health percent, the green-to-red colour and the low-health glow are all drawn by the
-- game's own widgets, which may show hidden values; the addon never reads them. Healing on click uses
-- secure unit buttons, the same kind of button Blizzard's own frames use.
local ADDON, ns = ...

local TEXTURES = "Interface\\AddOns\\" .. ADDON .. "\\Textures\\"
local PREFIX = "|cffff7fbfEasy Heals:|r "
local GOLD = { 1, 0.82, 0.35 }

local db
local playerClass
local anchor, partyBox, raidBox, legend, welcome, settings, minimapButton
local buttons = {}          -- every unit button
local resolved = {}         -- the class's bindings with the spell you know
local pending = {}          -- things to do when combat ends
local curves = {}

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function Say(text)
    print(PREFIX .. text)
end

local function IsSecret(v)
    return type(issecretvalue) == "function" and issecretvalue(v) == true
end

local function Plain(fn, ...)
    if type(fn) ~= "function" then return nil end
    local results = { pcall(fn, ...) }
    if not results[1] or IsSecret(results[2]) then return nil end
    return select(2, unpack(results))
end

local function InCombat()
    return type(InCombatLockdown) == "function" and InCombatLockdown()
end

-- Runs fn now, or when combat ends if it touches secure frames.
local function OutOfCombat(key, fn)
    if InCombat() then
        pending[key] = fn
    else
        fn()
    end
end

local function ClassColor(class)
    local c = class and type(RAID_CLASS_COLORS) == "table" and RAID_CLASS_COLORS[class]
    if type(c) == "table" and type(c.r) == "number" then return c.r, c.g, c.b end
    return 0.8, 0.8, 0.8
end

local function SpellIcon(name)
    local info = type(C_Spell) == "table" and Plain(C_Spell.GetSpellInfo, name)
    return type(info) == "table" and info.iconID or 134400
end

local CLICK_NAMES = { [1] = "Left click", [2] = "Right click", [3] = "Middle click" }
local MOD_NAMES = { [""] = "", ["shift-"] = "Shift + ", ["ctrl-"] = "Ctrl + ", ["alt-"] = "Alt + " }

---------------------------------------------------------------------------
-- Curves: they turn the hidden health percent into a colour, a number and a glow, inside the game
---------------------------------------------------------------------------

local function MakeCurves()
    if type(C_CurveUtil) ~= "table" or type(CreateColor) ~= "function" then return end
    local ok = pcall(function()
        local color = C_CurveUtil.CreateColorCurve()
        color:AddPoint(0.0, CreateColor(1.0, 0.12, 0.12, 1))
        color:AddPoint(0.35, CreateColor(1.0, 0.45, 0.1, 1))
        color:AddPoint(0.6, CreateColor(1.0, 0.85, 0.15, 1))
        color:AddPoint(1.0, CreateColor(0.2, 0.95, 0.35, 1))
        curves.color = color
        local percent = C_CurveUtil.CreateCurve()
        percent:AddPoint(0, 0)
        percent:AddPoint(1, 100)
        curves.percent = percent
        -- The red warning glow: off above 50% health, full below 25%.
        local danger = C_CurveUtil.CreateCurve()
        danger:AddPoint(0, 1)
        danger:AddPoint(0.25, 1)
        danger:AddPoint(0.5, 0)
        danger:AddPoint(1, 0)
        curves.danger = danger
    end)
    if not ok then curves = {} end
end

---------------------------------------------------------------------------
-- Click bindings
---------------------------------------------------------------------------

local function Known(name)
    local info = type(C_Spell) == "table" and Plain(C_Spell.GetSpellInfo, name)
    local id = type(info) == "table" and info.spellID
    if type(id) ~= "number" then return false end
    local known = Plain(IsPlayerSpell, id)
    return known ~= false
end

local function ResolveBindings()
    resolved = {}
    for _, b in ipairs(ns.Bindings[playerClass] or ns.DefaultBindings) do
        local spell
        if b.spells == ns.TARGET then
            spell = ns.TARGET
        else
            for _, name in ipairs(b.spells) do
                if Known(name) then spell = name break end
            end
        end
        if spell then resolved[#resolved + 1] = { mod = b.mod, button = b.button, spell = spell, what = b.what } end
    end
    -- Ctrl + left click always targets, so you can always pick someone.
    local hasTarget = false
    for _, r in ipairs(resolved) do if r.spell == ns.TARGET then hasTarget = true end end
    if not hasTarget then table.insert(resolved, { mod = "ctrl-", button = 1, spell = ns.TARGET, what = "Target them" }) end
end

local ATTRIBUTE_COMBOS = { "", "shift-", "ctrl-", "alt-" }

local function ApplyBindings(button)
    -- Clear every combination first, so a click you have not bound does nothing.
    for _, mod in ipairs(ATTRIBUTE_COMBOS) do
        for btn = 1, 3 do
            button:SetAttribute(mod .. "type" .. btn, nil)
            button:SetAttribute(mod .. "spell" .. btn, nil)
        end
    end
    for _, r in ipairs(resolved) do
        if r.spell == ns.TARGET then
            button:SetAttribute(r.mod .. "type" .. r.button, "target")
        else
            button:SetAttribute(r.mod .. "type" .. r.button, "spell")
            button:SetAttribute(r.mod .. "spell" .. r.button, r.spell)
        end
    end
end

local RefreshLegend

local function ApplyAllBindings()
    OutOfCombat("bindings", function()
        ResolveBindings()
        for _, b in ipairs(buttons) do ApplyBindings(b) end
        if RefreshLegend then RefreshLegend() end
    end)
end

---------------------------------------------------------------------------
-- Unit buttons
---------------------------------------------------------------------------

local function Glow(parent, layer, r, g, b, a, pad)
    local t = parent:CreateTexture(nil, layer)
    t:SetPoint("TOPLEFT", -pad, pad)
    t:SetPoint("BOTTOMRIGHT", pad, -pad)
    t:SetTexture(TEXTURES .. "Glow.tga")
    t:SetVertexColor(r, g, b, a)
    return t
end

local function ShowTooltip(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    local name = Plain(UnitName, self.unitToken)
    GameTooltip:SetText(type(name) == "string" and name or "Player", 1, 1, 1)
    for _, r in ipairs(resolved) do
        local spell = r.spell == ns.TARGET and "Target" or r.spell
        GameTooltip:AddDoubleLine(MOD_NAMES[r.mod] .. CLICK_NAMES[r.button], spell, 1, 0.82, 0.35, 0.6, 1, 0.75)
    end
    GameTooltip:Show()
end

local function MakeUnitButton(parent, unit, width, height)
    local b = CreateFrame("Button", "EasyHeals_" .. unit, parent, "SecureUnitButtonTemplate")
    b:SetSize(width, height)
    b:SetAttribute("unit", unit)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b.unitToken = unit

    -- Everything you see sits on an ordinary frame inside the secure button.
    local look = CreateFrame("Frame", nil, b)
    look:SetAllPoints()
    look:SetFrameLevel(b:GetFrameLevel())
    b.look = look

    b.danger = CreateFrame("Frame", nil, look)
    b.danger:SetAllPoints()
    b.danger.tex = Glow(b.danger, "BACKGROUND", 1, 0.1, 0.1, 1, 10)
    b.danger:SetAlpha(0)
    local pulse = b.danger.tex:CreateAnimationGroup()
    pulse:SetLooping("BOUNCE")
    local fade = pulse:CreateAnimation("Alpha")
    fade:SetFromAlpha(1)
    fade:SetToAlpha(0.25)
    fade:SetDuration(0.55)
    pulse:Play()

    b.border = Glow(look, "BACKGROUND", GOLD[1], GOLD[2], GOLD[3], 0.55, 3)
    local bg = look:CreateTexture(nil, "BACKGROUND", nil, 1)
    bg:SetAllPoints()
    bg:SetColorTexture(0.04, 0.03, 0.06, 0.92)

    local bar = CreateFrame("StatusBar", nil, look)
    bar:SetPoint("TOPLEFT", 4, -3)
    bar:SetPoint("BOTTOMRIGHT", -3, 3)
    bar:SetStatusBarTexture(TEXTURES .. "Bar.tga")
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(1)
    bar:SetStatusBarColor(0.2, 0.95, 0.35)
    b.bar = bar
    local sheen = bar:CreateTexture(nil, "OVERLAY")
    sheen:SetPoint("TOPLEFT")
    sheen:SetPoint("TOPRIGHT")
    sheen:SetHeight(height * 0.45)
    sheen:SetColorTexture(1, 1, 1, 0.12)

    b.stripe = look:CreateTexture(nil, "ARTWORK")
    b.stripe:SetPoint("TOPLEFT", 0, 0)
    b.stripe:SetPoint("BOTTOMLEFT", 0, 0)
    b.stripe:SetWidth(4)
    b.stripe:SetColorTexture(1, 1, 1, 1)

    local text = CreateFrame("Frame", nil, look)
    text:SetAllPoints()
    text:SetFrameLevel(bar:GetFrameLevel() + 2)
    b.name = text:CreateFontString(nil, "OVERLAY", height >= 36 and "GameFontNormal" or "GameFontNormalSmall")
    b.name:SetPoint("LEFT", 10, 0)
    b.name:SetPoint("RIGHT", -38, 0)
    b.name:SetJustifyH("LEFT")
    b.name:SetWordWrap(false)
    b.name:SetShadowOffset(1, -1)
    b.percent = text:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.percent:SetPoint("RIGHT", -6, 0)
    b.percent:SetShadowOffset(1, -1)
    b.status = text:CreateFontString(nil, "OVERLAY", "GameFontRedSmall")
    b.status:SetPoint("RIGHT", -6, 0)

    -- Mouse over: a bright edge and the click key in a tooltip.
    b.hover = Glow(look, "OVERLAY", 1, 1, 1, 0.9, 2)
    b.hover:SetBlendMode("ADD")
    b.hover:Hide()

    -- A sparkle burst on every click.
    b.spark = text:CreateTexture(nil, "OVERLAY")
    b.spark:SetSize(height * 1.6, height * 1.6)
    b.spark:SetPoint("CENTER")
    b.spark:SetTexture(TEXTURES .. "Spark.tga")
    b.spark:SetBlendMode("ADD")
    b.spark:SetAlpha(0)
    local burst = b.spark:CreateAnimationGroup()
    local grow = burst:CreateAnimation("Scale")
    grow:SetScaleFrom(0.4, 0.4)
    grow:SetScaleTo(1.6, 1.6)
    grow:SetDuration(0.35)
    local show = burst:CreateAnimation("Alpha")
    show:SetFromAlpha(0.9)
    show:SetToAlpha(0)
    show:SetDuration(0.35)
    b.burst = burst

    b:HookScript("OnEnter", function(self)
        self.hover:Show()
        if db.tooltips then ShowTooltip(self) end
    end)
    b:HookScript("OnLeave", function(self)
        self.hover:Hide()
        GameTooltip:Hide()
    end)
    b:SetScript("PostClick", function(self, _, down)
        if not down then
            self.spark:SetAlpha(1)
            self.burst:Stop()
            self.burst:Play()
        end
    end)

    ApplyBindings(b)
    if type(RegisterUnitWatch) == "function" then RegisterUnitWatch(b) end
    buttons[#buttons + 1] = b
    return b
end

-- Draws one button. Hidden values go straight into the game's widgets and are never looked at.
local function UpdateButton(b)
    local unit = b.unitToken
    pcall(function()
        local name = UnitName(unit)
        b.name:SetText(name)
    end)
    local class = select(2, Plain(UnitClass, unit))
    local r, g, bl = ClassColor(class)
    b.name:SetTextColor(r, g, bl)
    b.stripe:SetVertexColor(r, g, bl, 1)

    local dead = Plain(UnitIsDeadOrGhost, unit) == true
    local offline = Plain(UnitIsConnected, unit) == false
    if dead or offline then
        b.bar:SetMinMaxValues(0, 1)
        b.bar:SetValue(1)
        b.bar:SetStatusBarColor(0.25, 0.25, 0.28)
        b.status:SetText(offline and "OFFLINE" or "DEAD")
        b.percent:SetText("")
        b.danger:SetAlpha(0)
    else
        b.status:SetText("")
        pcall(b.bar.SetMinMaxValues, b.bar, 0, UnitHealthMax(unit))
        pcall(b.bar.SetValue, b.bar, UnitHealth(unit))
        local colored = false
        if curves.color then
            colored = pcall(function()
                local c = UnitHealthPercent(unit, true, curves.color)
                b.bar:SetStatusBarColor(c:GetRGB())
            end)
        end
        if not colored then b.bar:SetStatusBarColor(r * 0.8, g * 0.8, bl * 0.8) end
        if db.numbers and curves.percent then
            local okText = pcall(function() b.percent:SetFormattedText("%d%%", UnitHealthPercent(unit, true, curves.percent)) end)
            if not okText then b.percent:SetText("") end
        else
            b.percent:SetText("")
        end
        if curves.danger then
            pcall(function() b.danger:SetAlpha(UnitHealthPercent(unit, true, curves.danger)) end)
        end
    end

    -- Fade players who are out of your healing range.
    if unit == "player" then
        b.look:SetAlpha(1)
    else
        local faded = pcall(function()
            local inRange = UnitInRange(unit)
            if type(C_CurveUtil) == "table" and C_CurveUtil.EvaluateColorValueFromBoolean then
                b.look:SetAlpha(C_CurveUtil.EvaluateColorValueFromBoolean(inRange, 1, 0.4))
            else
                b.look:SetAlphaFromBoolean(inRange, 1, 0.4)
            end
        end)
        if not faded then b.look:SetAlpha(1) end
    end
end

---------------------------------------------------------------------------
-- The frames: a fancy title bar, party list and raid grid
---------------------------------------------------------------------------

local PARTY_W, PARTY_H = 170, 38
local RAID_W, RAID_H = 86, 32

local function SmallButton(parent, text, tip, onClick)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(20, 18)
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.25, 0.08, 0.18, 0.9)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.label:SetPoint("CENTER")
    b.label:SetText(text)
    b:SetScript("OnEnter", function(self)
        bg:SetColorTexture(0.55, 0.18, 0.38, 0.95)
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText(tip, 1, 1, 1, 1, true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() bg:SetColorTexture(0.25, 0.08, 0.18, 0.9) GameTooltip:Hide() end)
    b:SetScript("OnClick", onClick)
    return b
end

local ToggleLegend, ToggleSettings

local function CreateFrames()
    anchor = CreateFrame("Frame", "EasyHealsAnchor", UIParent)
    anchor:SetSize(PARTY_W, 26)
    anchor:SetClampedToScreen(true)
    anchor:SetMovable(true)
    anchor:EnableMouse(true)
    anchor:RegisterForDrag("LeftButton")
    anchor:SetScript("OnDragStart", function(self) if not db.locked and not InCombat() then self:StartMoving() end end)
    anchor:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        local point, _, relPoint, x, y = self:GetPoint(1)
        if type(point) == "string" and type(relPoint) == "string" and type(x) == "number" and type(y) == "number" then
            db.pos = { point, relPoint, x, y }
        end
    end)
    local pos = db.pos
    if type(pos) == "table" and type(pos[1]) == "string" and type(pos[2]) == "string" and type(pos[3]) == "number" and type(pos[4]) == "number" then
        anchor:SetPoint(pos[1], UIParent, pos[2], pos[3], pos[4])
    else
        anchor:SetPoint("LEFT", UIParent, "LEFT", 40, 60)
    end
    anchor:SetScale(db.scale)

    -- Title bar: a glowing ribbon with a heart.
    Glow(anchor, "BACKGROUND", 1, 0.35, 0.7, 0.6, 6)
    local ribbon = anchor:CreateTexture(nil, "BACKGROUND", nil, 1)
    ribbon:SetAllPoints()
    ribbon:SetTexture(TEXTURES .. "Bar.tga")
    ribbon:SetVertexColor(0.55, 0.12, 0.38, 1)
    local heart = anchor:CreateTexture(nil, "ARTWORK")
    heart:SetSize(20, 20)
    heart:SetPoint("LEFT", 4, 0)
    heart:SetTexture(TEXTURES .. "Heart.tga")
    heart:SetVertexColor(1, 0.35, 0.55, 1)
    local beat = heart:CreateAnimationGroup()
    beat:SetLooping("BOUNCE")
    local thump = beat:CreateAnimation("Scale")
    thump:SetScaleFrom(1, 1)
    thump:SetScaleTo(1.18, 1.18)
    thump:SetDuration(0.6)
    beat:Play()
    local title = anchor:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("LEFT", heart, "RIGHT", 4, 0)
    title:SetText("Easy Heals")
    title:SetTextColor(1, 0.9, 0.95)
    local gear = SmallButton(anchor, "*", "Settings", function() ToggleSettings() end)
    gear:SetPoint("RIGHT", -3, 0)
    local help = SmallButton(anchor, "?", "Show or hide the click key: what each click does.", function() ToggleLegend() end)
    help:SetPoint("RIGHT", gear, "LEFT", -3, 0)

    -- Party (and you, when solo) when not in a raid; the raid grid when in a raid. The game switches them.
    partyBox = CreateFrame("Frame", "EasyHealsParty", anchor, "SecureHandlerStateTemplate")
    partyBox:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -6)
    partyBox:SetSize(PARTY_W, 5 * (PARTY_H + 5))
    raidBox = CreateFrame("Frame", "EasyHealsRaid", anchor, "SecureHandlerStateTemplate")
    raidBox:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -6)
    raidBox:SetSize(8 * (RAID_W + 4), 5 * (RAID_H + 4))
    if type(RegisterStateDriver) == "function" then
        RegisterStateDriver(partyBox, "visibility", "[group:raid] hide; show")
        RegisterStateDriver(raidBox, "visibility", "[group:raid] show; hide")
    else
        raidBox:Hide()
    end
    local units = { "player", "party1", "party2", "party3", "party4" }
    for i, unit in ipairs(units) do
        local b = MakeUnitButton(partyBox, unit, PARTY_W, PARTY_H)
        b:SetPoint("TOPLEFT", 0, -(i - 1) * (PARTY_H + 5))
    end
    for i = 1, 40 do
        local b = MakeUnitButton(raidBox, "raid" .. i, RAID_W, RAID_H)
        local column, row = math.floor((i - 1) / 5), (i - 1) % 5
        b:SetPoint("TOPLEFT", column * (RAID_W + 4), -row * (RAID_H + 4))
    end

    -- One timer draws every visible button a few times a second.
    local wait = 0
    anchor:SetScript("OnUpdate", function(_, elapsed)
        wait = wait + elapsed
        if wait < 0.15 then return end
        wait = 0
        for _, b in ipairs(buttons) do
            if b:IsVisible() then UpdateButton(b) end
        end
    end)
end

---------------------------------------------------------------------------
-- The click key (legend)
---------------------------------------------------------------------------

local function CreateLegend()
    local l = CreateFrame("Frame", "EasyHealsLegend", UIParent)
    l:SetSize(300, 60)
    l:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 14, 0)
    l:SetFrameStrata("MEDIUM")
    Glow(l, "BACKGROUND", 1, 0.35, 0.7, 0.45, 6)
    local bg = l:CreateTexture(nil, "BACKGROUND", nil, 1)
    bg:SetAllPoints()
    bg:SetColorTexture(0.05, 0.03, 0.07, 0.94)
    local title = l:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", 12, -10)
    title:SetText("How to heal: click a name")
    title:SetTextColor(1, 0.75, 0.9)
    l.rows = {}
    for i = 1, 10 do
        local r = CreateFrame("Frame", nil, l)
        r:SetSize(280, 24)
        r:SetPoint("TOPLEFT", 10, -32 - (i - 1) * 26)
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetSize(22, 22)
        r.icon:SetPoint("LEFT")
        r.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        r.click = r:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        r.click:SetPoint("TOPLEFT", r.icon, "TOPRIGHT", 8, 1)
        r.click:SetTextColor(GOLD[1], GOLD[2], GOLD[3])
        r.what = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.what:SetPoint("BOTTOMLEFT", r.icon, "BOTTOMRIGHT", 8, -1)
        r.what:SetWidth(240)
        r.what:SetJustifyH("LEFT")
        r.what:SetWordWrap(false)
        l.rows[i] = r
    end
    l.tip = l:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    l.tip:SetWidth(280)
    l.tip:SetJustifyH("LEFT")
    l.tip:SetText("Bars turn yellow, then red, as health drops. A red glow means they need you NOW. Faded frames are too far away to heal.")
    legend = l
end

RefreshLegend = function()
    if not legend then return end
    local n = 0
    for i, row in ipairs(legend.rows) do
        local r = resolved[i]
        if r then
            n = i
            row.icon:SetTexture(r.spell == ns.TARGET and 132212 or SpellIcon(r.spell))
            row.click:SetText(MOD_NAMES[r.mod] .. CLICK_NAMES[r.button])
            row.what:SetText((r.spell == ns.TARGET and "Target" or r.spell) .. "  |cffbbbbbb" .. r.what .. "|r")
            row:Show()
        else
            row:Hide()
        end
    end
    legend.tip:ClearAllPoints()
    legend.tip:SetPoint("TOPLEFT", 12, -36 - n * 26)
    legend:SetHeight(60 + n * 26 + 24)
end

ToggleLegend = function()
    db.legend = not db.legend
    if legend then legend:SetShown(db.legend) end
end

---------------------------------------------------------------------------
-- Welcome and settings windows
---------------------------------------------------------------------------

local function Panel(name, width, height, titleText)
    local p = CreateFrame("Frame", name, UIParent)
    p:SetSize(width, height)
    p:SetPoint("CENTER", UIParent, "CENTER", 0, 80)
    p:SetFrameStrata("DIALOG")
    p:EnableMouse(true)
    p:SetMovable(true)
    p:RegisterForDrag("LeftButton")
    p:SetScript("OnDragStart", p.StartMoving)
    p:SetScript("OnDragStop", p.StopMovingOrSizing)
    p:SetClampedToScreen(true)
    Glow(p, "BACKGROUND", 1, 0.35, 0.7, 0.7, 10)
    local bg = p:CreateTexture(nil, "BACKGROUND", nil, 1)
    bg:SetAllPoints()
    bg:SetColorTexture(0.06, 0.03, 0.08, 0.96)
    local ribbon = p:CreateTexture(nil, "ARTWORK")
    ribbon:SetPoint("TOPLEFT", 2, -2)
    ribbon:SetPoint("TOPRIGHT", -2, -2)
    ribbon:SetHeight(30)
    ribbon:SetTexture(TEXTURES .. "Bar.tga")
    ribbon:SetVertexColor(0.55, 0.12, 0.38, 1)
    local heart = p:CreateTexture(nil, "OVERLAY")
    heart:SetSize(22, 22)
    heart:SetPoint("TOPLEFT", 10, -6)
    heart:SetTexture(TEXTURES .. "Heart.tga")
    heart:SetVertexColor(1, 0.4, 0.6, 1)
    local title = p:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", heart, "RIGHT", 6, 0)
    title:SetText(titleText)
    title:SetTextColor(1, 0.9, 0.95)
    return p
end

local function BigButton(parent, width, text, onClick, tip)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(width, 26)
    local edge = Glow(b, "BACKGROUND", 1, 0.45, 0.75, 0.6, 3)
    local bg = b:CreateTexture(nil, "BACKGROUND", nil, 1)
    bg:SetAllPoints()
    bg:SetTexture(TEXTURES .. "Bar.tga")
    bg:SetVertexColor(0.42, 0.1, 0.3, 1)
    b.label = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    b.label:SetPoint("CENTER")
    b.label:SetText(text)
    b:SetScript("OnEnter", function(self)
        bg:SetVertexColor(0.7, 0.18, 0.5, 1)
        edge:SetAlpha(1)
        if tip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(tip, 1, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    b:SetScript("OnLeave", function()
        bg:SetVertexColor(0.42, 0.1, 0.3, 1)
        edge:SetAlpha(0.6)
        GameTooltip:Hide()
    end)
    b:SetScript("OnClick", onClick)
    return b
end

local function ShowWelcome()
    if not welcome then
        local p = Panel("EasyHealsWelcome", 380, 250, "Welcome to Easy Heals!")
        local text = p:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        text:SetPoint("TOPLEFT", 18, -48)
        text:SetWidth(344)
        text:SetJustifyH("LEFT")
        text:SetSpacing(4)
        text:SetText("|cffff9ecc1.|r Your group shows up as shiny health bars on the left. Drag the pink title bar to move them.\n\n" ..
            "|cffff9ecc2.|r To heal someone, just |cffffd100left-click their name|r. No targeting needed.\n\n" ..
            "|cffff9ecc3.|r The key next to the bars shows every click. Hover any name to see it too.\n\n" ..
            "|cffff9ecc4.|r Red bars and a pulsing red glow mean: heal them first!")
        local ok = BigButton(p, 160, "Let's heal!", function() p:Hide() db.welcomed = true end)
        ok:SetPoint("BOTTOM", 0, 16)
        welcome = p
    end
    welcome:Show()
end

local SETTINGS = {
    { "locked", "Lock frames", "Stop the frames from being dragged by accident." },
    { "legend", "Show click key", "The key next to the frames that shows what each click does." },
    { "numbers", "Show health %", "Show each player's health as a number on their bar." },
    { "tooltips", "Hover help", "Show the click key in a tooltip when you hover a name." },
    { "minimap", "Minimap button", "A heart on the minimap that opens these settings. Drag it to move it." },
}

local RefreshSettings

local function Rescale(delta)
    OutOfCombat("scale", function()
        db.scale = math.max(0.6, math.min(1.8, db.scale + delta))
        anchor:SetScale(db.scale)
        if legend then legend:SetScale(db.scale) end
        RefreshSettings()
    end)
end

local function CreateSettings()
    local p = Panel("EasyHealsSettings", 300, 92 + #SETTINGS * 32 + 72, "Easy Heals")
    p.toggles = {}
    for i, s in ipairs(SETTINGS) do
        local b = BigButton(p, 264, "", function()
            db[s[1]] = not db[s[1]]
            if s[1] == "legend" and legend then legend:SetShown(db.legend) end
            if s[1] == "minimap" and ns.UpdateMinimapButton then ns.UpdateMinimapButton() end
            RefreshSettings()
        end, s[3])
        b:SetPoint("TOPLEFT", 18, -48 - (i - 1) * 32)
        b.field, b.title = s[1], s[2]
        p.toggles[i] = b
    end
    local y = -48 - #SETTINGS * 32
    local smaller = BigButton(p, 128, "Smaller", function() Rescale(-0.1) end, "Make the frames smaller.")
    smaller:SetPoint("TOPLEFT", 18, y)
    local bigger = BigButton(p, 128, "Bigger", function() Rescale(0.1) end, "Make the frames bigger.")
    bigger:SetPoint("TOPLEFT", 154, y)
    local again = BigButton(p, 264, "Show the welcome guide", function() ShowWelcome() end)
    again:SetPoint("TOPLEFT", 18, y - 32)
    local close = BigButton(p, 264, "Close", function() p:Hide() end)
    close:SetPoint("TOPLEFT", 18, y - 64)
    p:SetHeight(-(y - 64) + 46)
    p:SetScript("OnShow", function() RefreshSettings() end)
    p:Hide()
    if type(UISpecialFrames) == "table" then table.insert(UISpecialFrames, "EasyHealsSettings") end
    settings = p
end

RefreshSettings = function()
    if not settings or not settings:IsShown() then return end
    for _, b in ipairs(settings.toggles) do
        b.label:SetText(b.title .. ": " .. (db[b.field] and "|cff7dff9don|r" or "|cffff7d7doff|r"))
    end
end

ToggleSettings = function()
    if not settings then CreateSettings() end
    settings:SetShown(not settings:IsShown())
end

function EasyHeals_OnCompartmentClick()
    if db then ToggleSettings() end
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

local function PlaceMinimapButton()
    local angle = math.rad(db.minimapAngle or 100)
    local radius = (Minimap:GetWidth() or 140) / 2 + 8
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end

local function CreateMinimapButton()
    local b = CreateFrame("Button", "EasyHealsMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp")
    b:RegisterForDrag("LeftButton")
    local back = b:CreateTexture(nil, "BACKGROUND")
    back:SetSize(22, 22)
    back:SetPoint("CENTER")
    back:SetColorTexture(0.12, 0.03, 0.08, 0.95)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(18, 18)
    icon:SetPoint("CENTER")
    icon:SetTexture(TEXTURES .. "Heart.tga")
    icon:SetVertexColor(1, 0.4, 0.6, 1)
    local ring = b:CreateTexture(nil, "OVERLAY")
    ring:SetSize(54, 54)
    ring:SetPoint("TOPLEFT")
    ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    b:SetScript("OnClick", ToggleSettings)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Easy Heals", 1, 0.5, 0.75)
        GameTooltip:AddLine("Click for settings.", 1, 1, 1)
        GameTooltip:AddLine("Drag to move this button.", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local cx, cy = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            if mx and cx and scale and scale > 0 then
                db.minimapAngle = math.deg(atan2(cy / scale - my, cx / scale - mx))
                PlaceMinimapButton()
            end
        end)
    end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    minimapButton = b
    PlaceMinimapButton()
end

ns.UpdateMinimapButton = function()
    if not db or not Minimap then return end
    if db.minimap then
        if not minimapButton then CreateMinimapButton() end
        minimapButton:Show()
    elseif minimapButton then
        minimapButton:Hide()
    end
end

---------------------------------------------------------------------------
-- Start up
---------------------------------------------------------------------------

local function Setup()
    if anchor then return end
    ResolveBindings()
    CreateFrames()
    CreateLegend()
    legend:SetScale(db.scale)
    legend:SetShown(db.legend)
    RefreshLegend()
    ns.UpdateMinimapButton()
    if not db.welcomed then ShowWelcome() end
end

SLASH_EASYHEALS1 = "/easyheals"
SLASH_EASYHEALS2 = "/eh"
SlashCmdList.EASYHEALS = function(message)
    if not db then return end
    local command = string.lower(message or ""):match("^%s*(%S*)")
    if command == "help" or command == "welcome" then
        ShowWelcome()
    else
        ToggleSettings()
    end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        EasyHealsDB = type(EasyHealsDB) == "table" and EasyHealsDB or {}
        db = EasyHealsDB
        for key, value in pairs({ locked = false, legend = true, numbers = true, tooltips = true, minimap = true, welcomed = false }) do
            if type(db[key]) ~= "boolean" then db[key] = value end
        end
        if type(db.scale) ~= "number" then db.scale = 1 end
        local ok, _, classFile = pcall(UnitClass, "player")
        playerClass = ok and classFile or "PRIEST"
        MakeCurves()
        for _, name in ipairs({ "PLAYER_REGEN_ENABLED", "SPELLS_CHANGED", "LEARNED_SPELL_IN_SKILL_LINE", "PLAYER_LEVEL_UP" }) do
            pcall(self.RegisterEvent, self, name)
        end
        -- Secure frames can only be made out of combat (a /reload in a fight waits for it to end).
        OutOfCombat("setup", Setup)
        return
    end
    if event == "PLAYER_REGEN_ENABLED" then
        local jobs = pending
        pending = {}
        if jobs.setup then jobs.setup() end
        for key, fn in pairs(jobs) do
            if key ~= "setup" then fn() end
        end
        return
    end
    -- New spells learned: update what each click casts.
    if anchor then ApplyAllBindings() end
end)

-- For the automated tests.
ns.Resolved = function() return resolved end
ns.Buttons = buttons
ns.UpdateButton = UpdateButton
