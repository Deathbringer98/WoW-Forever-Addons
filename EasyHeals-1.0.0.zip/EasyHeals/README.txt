Easy Heals 1.0.0 - World of Warcraft: Forever (Interface 16001)
==============================================================

Healing made easy. Your group shows up as shiny health bars, and you heal
someone by clicking their name. No targeting, no macros, nothing to set up.

INSTALL
Copy the EasyHeals folder into:
  World of Warcraft\_forever_\Interface\AddOns\
Then fully restart the game. A welcome guide pops up the first time.

HOW TO HEAL
Left-click a name to heal that player. The pink "How to heal" key next to
the bars shows every click, with the spell icon:

  Priest    Left: Flash Heal        Right: Renew           Middle: Power Word: Shield
            Shift+Left: Greater Heal   Shift+Right: Prayer of Healing
            Ctrl+Right: Dispel Magic   Alt+Left: Cure Disease   Alt+Right: Resurrection
  Paladin   Left: Flash of Light    Right: Holy Light      Middle: Holy Shock
            Shift+Left: Lay on Hands   Shift+Right: Blessing of Protection
            Ctrl+Right: Cleanse        Alt+Left: Blessing of Freedom   Alt+Right: Redemption
  Druid     Left: Rejuvenation      Right: Healing Touch   Middle: Regrowth
            Shift+Left: Swiftmend      Shift+Right: Wild Growth
            Ctrl+Right: Remove Curse   Alt+Left: Cure Poison   Alt+Right: Rebirth
  Shaman    Left: Lesser Healing Wave  Right: Healing Wave   Middle: Chain Heal
            Shift+Left: Riptide        Ctrl+Right: Cure Poison
            Alt+Left: Cure Disease     Alt+Right: Ancestral Spirit
  Everyone  Ctrl+Left: target that player

Spells you have not learned yet are skipped (a quick heal uses Heal or
Lesser Heal until you learn Flash Heal, and so on), and the key updates by
itself as you learn new spells. Other classes can click a name to target it,
and mages get Arcane Intellect and Remove Lesser Curse.

READING THE BARS
- Green bar: healthy. It turns yellow, then orange, then red as they lose
  health.
- A pulsing red glow around a frame: below half health. Heal them first!
- A faded frame: too far away to heal. Walk closer.
- DEAD or OFFLINE is written on the bar.
- Hover a name to see the click key in a tooltip.
- Every click shows a little sparkle, so you know it went through.

The frames show you when you are on your own, your party in a group, and a
40-player grid in a raid. Drag the pink title bar to move them.

SETTINGS
Click the heart on the minimap, the "*" on the title bar, pick Easy Heals in
the minimap addon menu, or type /eh. Every setting is a button:
  Lock frames, Show click key, Show health %, Hover help, Minimap button,
  Smaller / Bigger, and Show the welcome guide again.
The "?" on the title bar shows or hides the click key.

HOW IT PLAYS BY THE RULES
WoW Forever hides your party's health from addons as a number. Easy Heals
never reads it: the bars, the percent, the colours and the red glow are all
drawn by the game's own widgets, which are allowed to show hidden values.
Healing on click uses secure unit buttons, the same kind Blizzard's own
frames use. Frame size and click spells can only change out of combat, so
changes made during a fight apply as soon as it ends.

CREDITS
Matthew Menchinton, CircuitSpecter Studio (circuitspecter.org)
